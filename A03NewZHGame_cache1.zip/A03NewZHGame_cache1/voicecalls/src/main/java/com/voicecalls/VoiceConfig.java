package com.voicecalls;

import android.support.annotation.DrawableRes;

public interface VoiceConfig {

    /**
     * 语音客服页面背景图
     *
     * @return 图片资源文件
     */
    @DrawableRes
    int voiceBackground();

    /**
     * 最小化的时候显示的图标
     *
     * @return 图标资源文件
     */
    @DrawableRes
    int configFloatWindowIcon();

    /**
     * 打电话页面显示图标
     *
     * @return 图标资源文件
     */
    @DrawableRes
    int configCallIcon();

    /**
     * 图标下面显示的名字
     *
     * @return 名字
     */
    String configCallServerName();
}
