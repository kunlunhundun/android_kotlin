package com.voicecalls;

import android.app.Application;

import com.jxccp.lib.sip.CallApi;

public class VoiceLibrary {

    private static VoiceConfig config;
    private static Application application;

    public static void init(Application application, VoiceConfig config) {
        VoiceLibrary.application = application;
        VoiceLibrary.config = config;
        CallApi.initialize(application);
    }


    public static Application get() {
        return application;
    }

    public static VoiceConfig getConfig() {
        return config;
    }
}
