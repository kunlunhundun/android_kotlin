package com.voicecalls;

import android.Manifest;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.jxccp.lib.sip.CallApi;
import com.jxccp.lib.sip.CallException;
import com.jxccp.lib.sip.CallListener;
import com.mylhyl.acp.Acp;
import com.mylhyl.acp.AcpListener;
import com.mylhyl.acp.AcpOptions;
import com.mylhyl.circledialog.CircleDialog;

import java.util.List;

/**
 * 语音通话界面
 * https://www.jianshu.com/p/af2c38efc524
 */
public class VoiceCallActivity extends AppCompatActivity implements View.OnClickListener,
        SensorEventListener {
    private static final int FLOAT_REQUESTCODE = 10;
    private final String TAG = getClass().getSimpleName();
    private static final String PHONE_NUMBER = "phone_number";
    private static final String UID = "uid";
    private AudioManager mAudioManager;
    VoiceCallFloatService.MyBinder mBinder;
    private boolean mIsBound = false;
    private int mTime;
    private String mPhoneNumber;
    private String mUid;
    private VoiceCallFloatService voiceCallFloatService = null;
    private SensorManager sensorManager;
    private Sensor sensor;
    private PowerManager powerManager;
    private PowerManager.WakeLock wakeLock;
    //public boolean isSpeaking = false;
    private ImageView hideIv, slientIv, hangUpIv, speakerIv, severIv;
    private TextView statusTv, timeTv, severNameTv;
    private Handler mHandler = new Handler();
    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            mTime++;
            int minute = mTime / 60;
            int seconds = mTime % 60;
            String time = (minute > 9 ? minute : "0" + minute) + " : " + (seconds > 9 ? seconds :
                    "0" + seconds);
            if (timeTv.getVisibility() != View.VISIBLE) {
                timeTv.setVisibility(View.VISIBLE);
            }
            timeTv.setText(time);
            mHandler.postDelayed(mRunnable, 1000);
        }
    };

    ServiceConnection mServiceConnnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mBinder = (VoiceCallFloatService.MyBinder) iBinder;
            voiceCallFloatService = mBinder.getService();
            if (/*isSpeaking && */null != voiceCallFloatService) {
                //voiceCallFloatService.initWindow();
                voiceCallFloatService.setSeconds(mTime);
                voiceCallFloatService.setFloatImg(VoiceLibrary.getConfig().configFloatWindowIcon());
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
        }
    };

    public static void startCallActivity(final Context context, final String phoneNumber, final
    String number) {
        Acp.getInstance(context).request(
                new AcpOptions.Builder().setPermissions(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.MODIFY_AUDIO_SETTINGS).build(), new AcpListener() {
                    @Override
                    public void onGranted() {
                        // uid 用来唯一标记一个用户ID，不可为空，共11位
                        Intent intent = new Intent(context, VoiceCallActivity.class);
                        intent.putExtra(PHONE_NUMBER, phoneNumber);
                        intent.putExtra(UID, number);
                        context.startActivity(intent);
                    }

                    @Override
                    public void onDenied(List<String> permissions) {
                    }
                });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void showOverDialog() {
        new CircleDialog.Builder(this)
                .setTitle("温馨提示")
                .setText("显示语音电话小窗口，需开启在其他应用程序之上显示内容的权限")
                .setNegative("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                        delayFinish();
                    }
                })
                .setPositive("去开启", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri
                                .parse("package:" + getPackageName()));
                        startActivityForResult(intent, FLOAT_REQUESTCODE);
                    }
                })
                .show();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_call);
        initView();
        mPhoneNumber = getIntent().getStringExtra(PHONE_NUMBER);
        mUid = getIntent().getStringExtra(UID);

        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.setSpeakerphoneOn(false);//默认关闭扬声器
        mAudioManager.setMicrophoneMute(false);//默认开启麦克
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                mAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                mAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                mAudioManager.setStreamVolume(AudioManager.MODE_IN_COMMUNICATION, 7, 0);
            } catch (Exception e) {
                NotificationManager notificationManager = (NotificationManager)
                        getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !notificationManager
                        .isNotificationPolicyAccessGranted()) {
                    Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                    startActivity(intent);
                }
            }
        } else {
            mAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            mAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            mAudioManager.setStreamVolume(AudioManager.MODE_IN_COMMUNICATION, 7, 0);
        }

        //注册距离感应器
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);

        //监控屏幕操作
        powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, TAG);

        slientIv.setOnClickListener(this);
        hangUpIv.setOnClickListener(this);
        speakerIv.setOnClickListener(this);
        hideIv.setOnClickListener(this);

        CallApi.addListener(mCallListener);

        //发起呼叫后开启检测网络信号广播
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        intentFilter.addAction(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(broadcastReceiver, intentFilter);
        startCall();
    }

    private void initView() {
        hideIv = findViewById(R.id.iv_hide);
        slientIv = findViewById(R.id.iv_slient);
        hangUpIv = findViewById(R.id.iv_hang_up);
        speakerIv = findViewById(R.id.iv_speaker);
        statusTv = findViewById(R.id.tv_status);
        timeTv = findViewById(R.id.tv_time);
        severNameTv = findViewById(R.id.tv_k8_server);
        severIv = findViewById(R.id.iv_k8);

        RelativeLayout voiceBackground = findViewById(R.id.voice_call_background);
        voiceBackground.setBackgroundResource(VoiceLibrary.getConfig().voiceBackground());
        severIv.setImageResource(VoiceLibrary.getConfig().configCallIcon());
        severIv.setImageResource(VoiceLibrary.getConfig().configCallIcon());
        severNameTv.setText(VoiceLibrary.getConfig().configCallServerName());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null) {
            boolean hideWindow = intent.getBooleanExtra("hideWindow", false);
            if (hideWindow) {
                unBindService();
            }
        }
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                final int flag = NetUtil.getAPNType(context);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (flag == 2 || flag == 0) {
                            if (statusTv.getVisibility() != View.VISIBLE) {
                                statusTv.setVisibility(View.VISIBLE);
                                statusTv.setText("当前网络不稳定");
                            }
                        } else {
                            statusTv.setVisibility(View.INVISIBLE);
                        }
                    }
                });
            } else if (action.equals(Intent.ACTION_HEADSET_PLUG)) {//实时检测耳机插拔
                int state = intent.getIntExtra("state", 0);
                if (state == 0) {   // 耳机拔出
                    mAudioManager.setSpeakerphoneOn(true);
                } else if (state == 1) {    // 耳机插入
                    mAudioManager.setSpeakerphoneOn(false);
                }
            }
        }
    };

    /**
     * 居中展示吐司
     *
     * @param content
     */
    private void showCenterToast(final String content) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast toast = Toast.makeText(VoiceCallActivity.this, content, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        });
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.iv_hide) {
            startVoiceCallFloatService();
        } else if (i == R.id.iv_slient) {
            changeVoiceSlient();
        } else if (i == R.id.iv_hang_up) {
            terminateCall();
        } else if (i == R.id.iv_speaker) {
            if (mAudioManager.isSpeakerphoneOn()) {
                mAudioManager.setSpeakerphoneOn(false);//不外放
                speakerIv.setBackgroundResource(R.drawable.voice_call_speaker);
                showCenterToast("请使用听筒接听");
            } else {
                mAudioManager.setSpeakerphoneOn(true);
                speakerIv.setBackgroundResource(R.drawable.voice_call_speaker_selected);
            }
        }
    }

    /**
     * 断开service
     */
    private void unBindService() {
        if (mIsBound) {
            if (null != voiceCallFloatService) {
                voiceCallFloatService.closeWindows();
            }
            unbindService(mServiceConnnection);
            mIsBound = false;
        }
    }

    /**
     * 发起呼叫
     */
    private void startCall() {
        //showCenterToast("请使用听筒接听");
        unBindService();
        new Thread() {
            @Override
            public void run() {
                try {
                    Log.e(TAG, mPhoneNumber + ", " + mUid);
                    CallApi.makeCall(mPhoneNumber, mUid);
                } catch (CallException e) {
                    processCallException(e);
                }
            }
        }.start();
    }

    public void delayFinish() {
        hangUpIv.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 800);
    }

    private void changeVoiceSlient() {
        if (mAudioManager.isMicrophoneMute()) {//检测麦克风是否静音
            mAudioManager.setMicrophoneMute(false);
            slientIv.setBackgroundResource(R.drawable.voice_call_slient);
        } else {
            mAudioManager.setMicrophoneMute(true);//关闭麦克风
            slientIv.setBackgroundResource(R.drawable.voice_call_slient_selected);
        }
    }

    private void startVoiceCallFloatService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!Settings.canDrawOverlays(this)) {
                showOverDialog();
            } else {
                startVoiceCallService();
            }
        } else {
            startVoiceCallService();
        }
    }

    private void startVoiceCallService() {
        Intent intent = new Intent(this, VoiceCallFloatService.class);
        bindService(intent, mServiceConnnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
        moveTaskToBack(true);
    }

    private void processCallException(CallException e) {
        switch (e.getCode()) {
            case CallException.CODE_NOT_INITIALIZED:
            case CallException.CODE_NETWORK_NOT_AVAILABLE:
            case CallException.CODE_CLIENT_BUSY:
                Log.e(TAG, e.getCode() + ", " + e.getMessage());
                //showCenterToast(e.getMessage());
                break;
            case CallException.CODE_JXACCOUNT_INIT_FAILED:
                showCenterToast("语音客服系统维护中，请稍后再试");
                break;
        }
        delayFinish();
    }

    /**
     * 结束呼叫
     */
    private void terminateCall() {
        //showCenterToast("通话已结束");
        new Thread() {
            @Override
            public void run() {
                try {
                    CallApi.terminateCall();
                } catch (CallException e) {
                    e.printStackTrace();
                }
            }
        }.start();
        delayFinish();
    }

    /**
     * 呼叫状态监听器
     */
    private CallListener mCallListener = new CallListener() {

        @Override
        public void onIncomingCall(String from) {

        }

        @Override
        public void onStateChanged(final int state, final int stateCode) {
            switch (state) {
                case -1:
                    Log.d(TAG, "未定义的状态");
                case 0:
                    Log.d(TAG, "正在拨号中...");
                case 2:
                    Log.d(TAG, "对方正在振铃...");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            statusTv.setVisibility(View.VISIBLE);
                            statusTv.setText("正在拨号中...");
                            // isSpeaking = false;
                        }
                    });
                    break;
                case 1:
                    Log.d(TAG, "收到来电");
                    break;
                case 3:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            statusTv.setVisibility(View.VISIBLE);
                            statusTv.setText("被叫正忙");
                            // isSpeaking = false;
                        }
                    });
                    Log.d(TAG, "被叫正忙");
                    break;
                case 4:
                    Log.d(TAG, "通话已建立");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            statusTv.setVisibility(View.INVISIBLE);
                            timeTv.setVisibility(View.VISIBLE);
                            timeTv.setText("00:00");
                            mHandler.postDelayed(mRunnable, 1000);
                            if (null != voiceCallFloatService) {
                                voiceCallFloatService.setSeconds(mTime);
                            }
                            Log.d(TAG, "计时开始");
                            // isSpeaking = true;
                        }
                    });
                    break;
                case 5:
                    Log.d(TAG, "通话已中断");
                    // isSpeaking = false;
                    showCenterToast("通话已挂断");
                    delayFinish();
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onError(int reason) {
            switch (reason) {
                case CallListener.REASON_TIMEOUT:
                    Log.e(TAG, "超时导致建立通话失败");
                    break;
                default:
                    break;
            }
            delayFinish();
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacksAndMessages(mRunnable);
        CallApi.removeListener(mCallListener);
        unregisterReceiver(broadcastReceiver);
        sensorManager.unregisterListener(this);
        unBindService();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (mAudioManager.isWiredHeadsetOn()) {      // 如果耳机已插入，设置距离传感器失效
            return;
        }
        float distance = sensorEvent.values[0];
        if (distance >= sensor.getMaximumRange()) {     // 用户远离听筒,亮屏
            setScreenOn();
        } else {    // 用户贴近听筒，熄屏防误触
            setScreenOff();
        }
    }

    /**
     * 熄屏
     */
    private void setScreenOff() {
        if (wakeLock == null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, TAG);
        }
        wakeLock.acquire();
    }

    /**
     * 亮屏
     */
    private void setScreenOn() {
        if (wakeLock != null) {
            wakeLock.setReferenceCounted(false);
            wakeLock.release();
            wakeLock = null;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case FLOAT_REQUESTCODE:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (Settings.canDrawOverlays(this)) {
                        startVoiceCallService();
                    }
                }
                break;
        }
    }
}
