package android.support.v4.app;

import android.support.annotation.CallSuper;

public class DialogFragment3 extends DialogFragment {
    public DialogFragment3() {
    }

    @CallSuper
    public int show(FragmentTransaction transaction, String tag) {
        this.mDismissed = false;
        this.mShownByMe = true;
        transaction.add(this, tag);
        this.mViewDestroyed = false;
        this.mBackStackId = transaction.commitAllowingStateLoss();
        return this.mBackStackId;
    }

    @CallSuper
    public void show(FragmentManager manager, String tag) {
        this.mDismissed = false;
        this.mShownByMe = true;
        FragmentTransaction ft = manager.beginTransaction();
        ft.add(this, tag);
        ft.commitAllowingStateLoss();
    }

    public final void showWithException(FragmentTransaction transaction, String tag) {
        super.show(transaction, tag);
    }
}

