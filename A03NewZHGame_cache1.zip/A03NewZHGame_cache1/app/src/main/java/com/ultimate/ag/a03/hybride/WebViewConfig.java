package com.ultimate.ag.a03.hybride;

//import com.ivi.webview.AbstractWebConfig;
//import com.ivi.webview.model.UserInfo;
import com.ultimate.ag.a03.config.ConfigUtils;

/*kunluntest public class WebViewConfig extends AbstractWebConfig {
    @Override
    public boolean isDebug() {
        //是否显示log日志
        return true;
    }

    @Override
    public boolean isShowLineLoading() {
        //是否显示网页加载过程中的水平进度条
        return true;
    }

    public boolean isShowCircleLoading() {
        //是否显示网页加载过程中的圆形进度条
        return true;
    }

    @Override
    public UserInfo getUserInfo() {
        //返回用户信息
        return new UserInfo.Build()
                .userToken(ConfigUtils.INSTANCE.getToken())
                .loginName(ConfigUtils.INSTANCE.getLoginName())
                .build();
    }

    @Override
    public String[] getDomains() {
        //返回手机站域名列表
        String[] strs = new String[1];
        strs[0] = ConfigUtils.INSTANCE.getDOMAIN_NAME();
        return strs;
    }

    @Override
    public String getCDNHost() {
        return null;
    }

    @Override
    public String fileProvidedAuth() {
        //返回FileProvided配置的Auth(必须注册FileProvided)
        return "";
    }

    @Override
    public RequestType userParamsTransMethod() {
        //传递用户信息时是用户POST还是GET
        return RequestType.GET;
    }
} */