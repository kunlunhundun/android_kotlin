package com.ultimate.ag.a03.util


import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.util.Log
import java.io.*
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipFile

/**
 * 解压
 */
open class ZipExtractorTask(inp: String, out: String, var mContext: Context?, private val mReplaceAll: Boolean) : AsyncTask<Void, Int, Long>() {
    private val TAG = "WARDY|ZipExtractorTask"
    private val mInput: File
    private val mOutput: File
    //	private final ProgressDialog mDialog;
    private var mProgress = 0


    override fun doInBackground(vararg params: Void): Long? {
        // TODO Auto-generated method stub
        return unzip()
    }

    override fun onPostExecute(result: Long?) {
        // TODO Auto-generated method stub
        //super.onPostExecute(result);

        if (isCancelled)
            return
        //这里表示解压完成  可以进行显示WebView 发送广播 并更新保存的 时间
        Log.d(TAG, "解压完成")
        val intent = Intent()
        intent.action = "unzip.complete"
        mContext!!.sendBroadcast(intent)
        //释放context
        mContext = null
    }

    override fun onPreExecute() {
        // TODO Auto-generated method stub
        //super.onPreExecute();
    }

    fun onProgressUpdate(vararg values: Int) {
        // TODO Auto-generated method stub
    }

    private fun unzip(): Long {
        var extractedSize = 0L
        val entries: Enumeration<ZipEntry>
        var zip: ZipFile? = null
        try {
            zip = ZipFile(mInput)
            val uncompressedSize = getOriginalSize(zip)
            publishProgress(0, uncompressedSize.toInt())

            entries = zip.entries() as Enumeration<ZipEntry>
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory) {
                    continue
                }
                val destination = File(mOutput, entry.name)
                if (!destination.parentFile.exists()) {
                    Log.e(TAG, "make=" + destination.parentFile.absolutePath)
                    destination.parentFile.mkdirs()
                }
                if (destination.exists() && mContext != null && !mReplaceAll) {

                }
                val outStream = ProgressReportingOutputStream(destination)
                extractedSize += copy(zip.getInputStream(entry), outStream).toLong()
                outStream.close()
            }
        } catch (e: ZipException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        } finally {
            try {
                zip?.close()

            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }

        }

        return extractedSize
    }

    private fun getOriginalSize(file: ZipFile): Long {
        val entries = file.entries() as Enumeration<ZipEntry>
        var originalSize = 0L
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (entry.size >= 0) {
                originalSize += entry.size
            }
        }
        return originalSize
    }

    private fun copy(input: InputStream, output: OutputStream): Int {
        val buffer = ByteArray(1024 * 8)
        val inp = BufferedInputStream(input, 1024 * 8)
        val out = BufferedOutputStream(output, 1024 * 8)
        var count = 0
        var n = 0
        try {
            n = inp.read(buffer, 0, 1024 * 8)
            while (n != -1) {
                out.write(buffer, 0, n)
                count += n
                n = inp.read(buffer, 0, 1024 * 8)
            }
            out.flush()
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        } finally {
            try {
                out.close()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }

            try {
                inp.close()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }

        }
        return count
    }

    private inner class ProgressReportingOutputStream @Throws(FileNotFoundException::class)
    constructor(file: File)// TODO Auto-generated constructor stub
        : FileOutputStream(file) {
        @Throws(IOException::class)
        override fun write(buffer: ByteArray, byteOffset: Int, byteCount: Int) {
            // TODO Auto-generated method stub
            super.write(buffer, byteOffset, byteCount)
            mProgress += byteCount
            publishProgress(mProgress)
        }

    }

    init {
        mInput = File(inp)
        mOutput = File(out)
        if (!mOutput.exists()) {
            if (!mOutput.mkdirs()) {
                Log.e(TAG, "Failed to make directories:" + mOutput.absolutePath)
            }
        }
    }
}