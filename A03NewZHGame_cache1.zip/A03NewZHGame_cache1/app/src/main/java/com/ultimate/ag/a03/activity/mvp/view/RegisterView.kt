package com.ultimate.ag.a03.activity.mvp.view

/**
 * 注册界面view
 */
interface RegisterView: IBaseView{

    /**
     * 注册成功
     */
    fun registerSucess()

    /**
     * 注册失败
     */
    fun registerFail()

    /**
     * 用户名已注册
     */
    fun alreadyRegistered()
}