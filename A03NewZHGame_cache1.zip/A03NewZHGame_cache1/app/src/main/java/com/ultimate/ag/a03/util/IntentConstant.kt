package com.ultimate.ag.a03.util

/**
 * @author Javan.W
 * @date   2019/3/11
 * @Description Intent 传递的key常量
 */
object IntentConstant {

    // 注册账号
    val REGISTER_ACCOUNT = "register_account"
    // 注册手机号
    val REGISTER_PHONENUM = "register_phonenum"
    // 切换MainActivity tab
    val MAIN_TAB_INDEX = "main_tab_index"
    // 银行卡数量
    val BANKCARD_NUM = "bankcard_num"
    // 分享地址
    val SHARE_URL = "share_url"
    // 图片类型
    val SHARE_TYPE = "share_type"
    // webview 右边标题类型 1表示推荐好友活动规则
    val WEBVIEW_RIGHT_TITLE_TYPE = "webview_right_title_type"
    // 领取好礼的推荐账号
    val GIFS_ACCOUNT = "gifs_account"
    // 礼物类型
    val GIFTS_TYPE = "gifts_type"
    // 打开分享好友
    val START_SHARE_FRIENDS = "start_share_friends"
}