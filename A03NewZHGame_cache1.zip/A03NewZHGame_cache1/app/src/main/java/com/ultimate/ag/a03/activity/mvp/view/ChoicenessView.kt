package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.BannerImageObj
import com.ultimate.ag.a03.data.response.GetOnlineNumResponse
import com.ultimate.ag.a03.data.response.HomeBestResponse
import com.ultimate.ag.a03.data.response.InGameResponse

interface ChoicenessView : IBaseView {


    /**
     * 显示banner展示
     */
    fun showBanner(bannerImages: MutableList<BannerImageObj>)

    /**
     * 显示本月发放红利
     */
    fun showTotalPromoAmount(totalPromoAmount: String?)

    /**
     * 显示热门游戏
     */
    fun showHotGames(hotGames: MutableList<HomeBestResponse.HotGameObj>)

    /**
     * 注册热门游戏点击事件
     */
    fun initHotGamesListener(hotGames: MutableList<HomeBestResponse.HotGameObj>)

    /**
     * 显示实时盈利榜
     */
    fun showTopPlayers(topPlayers: MutableList<HomeBestResponse.TopPlayerObj>)

    /**
     * 显示取现状态
     */
    fun showithdrawState(withdrawTimeCost: String?, pendingWithdrawCount: String?)

    /**
     * 开始游戏
     */
    fun startGame(url: String?)

    /**
     * 获取首页精选数据业务失败
     */
    fun getDataFail(data: HomeBestResponse)

    /**
     * 进入游戏业务失败
     */
    fun inGameFail(data: InGameResponse)

    /**
     * 获取在线人数
     */
    fun setOnlineNumber(data: GetOnlineNumResponse)

    /**
     * 显示我的红利弹窗
     */
    fun showPromoDialog()

    /**
     * 显示vip弹窗
     */
    fun showVipDialog()

    /**
     * 获取在线人数失败
     */
    fun hideOnlineNumber()

    /**
     * 下拉刷新结束
     */
    fun finishRefresh(success: Boolean)
}