package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.SuggestionResponse

interface SuggestionView: IBaseView{

    /**
     * 发送反馈建议成功
     */
    fun onSendSuggestionSuccess(data: SuggestionResponse)

    /**
     * 发送反馈建议失败
     */
    fun onSendSuggestionFail(data: SuggestionResponse)
}