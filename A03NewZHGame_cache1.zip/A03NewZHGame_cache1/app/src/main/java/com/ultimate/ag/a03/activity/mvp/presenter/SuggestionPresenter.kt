package com.ultimate.ag.a03.activity.mvp.presenter

import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.SuggestionModel
import com.ultimate.ag.a03.activity.mvp.view.SuggestionView
import com.ultimate.ag.a03.data.request.SuggestRequest
import com.ultimate.ag.a03.data.response.SuggestionResponse
import com.ultimate.ag.a03.net.ApiErrorModel

class SuggestionPresenter : BasePresenter<SuggestionView, SuggestionModel>() {

    /**
     * 发送反馈建议
     */
    fun sendSuggestion(request: SuggestRequest) {

        if (!isViewAttached)
            return

        view?.showLoading()
        model?.createSuggest(request, view!!.getRxActivity(), object : MvpCallback<SuggestionResponse> {
            override fun onSuccess(data: SuggestionResponse) {
                if (!isViewAttached)
                    return

                view?.onSendSuggestionSuccess(data)
            }

            override fun onBusinessFail(data: SuggestionResponse) {
                if (!isViewAttached)
                    return

                view?.onSendSuggestionFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }
}