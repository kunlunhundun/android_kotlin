package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.InGameResponse
import com.ultimate.ag.a03.data.response.SportsPicturesResponse
import com.ultimate.ag.a03.data.response.SportsResponse

interface SportsView: IBaseView{

    /**
     * 显示体育赛事信息
     */
    fun showSports(body: MutableList<SportsResponse.SportsObj>)

    /**
     * 显示体育图片
     */
    fun showSportsPictures(sportsPictures: MutableList<SportsPicturesResponse.SportsPicturesObj>)

    /**
     * 获取体育信息失败
     */
    fun getSportsFail(data: SportsResponse)

    /**
     * 获取体育图片失败
     */
    fun getSportsPicturesFail(data: SportsPicturesResponse)

    /**
     * 获取沙巴体育地址失败
     */
    fun getSportsAdressFail(data: InGameResponse)

    /**
     * 进入沙巴体育
     */
    fun inSabaGame(data: InGameResponse)

    /**
     * 进入BB体育
     */
    fun inBBGame(data: InGameResponse)

    /**
     * 下拉刷新结束
     */
    fun finishRefresh(success: Boolean)
}