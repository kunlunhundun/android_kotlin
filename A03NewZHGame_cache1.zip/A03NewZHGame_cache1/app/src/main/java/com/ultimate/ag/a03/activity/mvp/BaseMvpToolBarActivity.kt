package com.ultimate.ag.a03.activity.mvp

import android.graphics.Color
import android.os.Bundle
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.activity.mvp.model.IModel
import com.ultimate.ag.a03.activity.mvp.view.IBaseView
import com.ultimate.ag.a03.view.CommonDialog


/**
 * Created by ward.y on 2018/2/21.
 */
abstract class BaseMvpToolBarActivity : BaseMvpActivity<IBaseView,IModel>(),View.OnLayoutChangeListener {
    private var mToolbarTitle: TextView? = null
    private var mToolbarAction: TextView? = null
    private var mToolbarIcon: ImageView? = null
    private var mToolbar: Toolbar? = null
    private var isShowBack: Boolean = true
    private var isShowAction: Boolean = false
    private var mClickListener:View.OnClickListener? =null
    val MODE_WHITE: Int = 1
    val MODE_BLACK: Int = 2
    val MODE_GREY: Int = 3
    //屏幕高度
    var screenHeight = 0
    //软件盘弹起后所占高度阀值
    var keyHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //获取屏幕高度
        screenHeight = this.windowManager.defaultDisplay.height
        //阀值设置为屏幕高度的1/3
        keyHeight = screenHeight / 3
        setContentView(getLayoutId())
        mToolbar = findViewById(R.id.tool_bar)
        mToolbarIcon = findViewById(R.id.toolbar_icon)
        mToolbarTitle = findViewById(R.id.toolbar_title)
        mToolbarAction = findViewById(R.id.action_area)
        if (mToolbar != null) {
            //将Toolbar显示到界面
            setSupportActionBar(mToolbar)
        }
        if (mToolbarTitle != null) {
            //getTitle()的值是activity的android:lable属性值
            mToolbarTitle?.text = title
            //设置默认的标题不显示
            supportActionBar?.setDisplayShowTitleEnabled(false)
        }
        mToolbarIcon?.setOnClickListener {
            if (mClickListener==null){
                finish()
            }else{
                mClickListener?.onClick(it)
            }

        }

        mToolbar?.setOnLongClickListener {
            if (BuildConfig.DEBUG){
                val bundle = Bundle()
                bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_DEBUG)
                val dialog = CommonDialog()
                dialog.arguments = bundle
                dialog.show(supportFragmentManager, "debug")
                true
            }

            false
        }


    }


    protected fun setTile(title: String) {
        if (mToolbar != null) {
            //将Toolbar显示到界面
            mToolbarTitle?.text = title
        }
    }

    protected fun setBackListener(listener: View.OnClickListener) {
        mClickListener = listener
    }

    protected fun setLogo(id: Int) {
        if (mToolbar != null) {
            //将Toolbar显示到界面
            mToolbarIcon?.setImageResource(id)
        }
    }

    protected fun setMode(mode: Int) {
        when (mode) {
            MODE_BLACK -> {
                mToolbarTitle?.setTextColor(Color.BLACK)
                mToolbarAction?.setTextColor(Color.BLACK)
            }
            MODE_WHITE -> {
                mToolbarTitle?.setTextColor(Color.WHITE)
                mToolbarAction?.setTextColor(Color.WHITE)
            }

            MODE_GREY -> {
                mToolbarAction?.setTextColor(Color.parseColor("#666666"))
            }
        }
    }

    protected fun setBackground(id: Int) {
        mToolbar?.setBackgroundResource(id)
    }

    protected fun setActionText(string: String) {
        mToolbarAction?.text = string
        isShowAction(true)
    }

     fun setActionIcon(id: Int) {
        val drawable = resources.getDrawable(id)
        drawable.setBounds(0, 0, drawable.minimumWidth, drawable.minimumHeight)
        mToolbarAction?.setCompoundDrawables(null, null, drawable, null)
        isShowAction(true)
    }

    protected fun getActionView(): TextView? {
        return mToolbarAction
    }

    /**
     * this activity layout res
     * 设置layout布局,在子类重写该方法.
     * @return res layout xml referenceId
     */
    protected abstract fun getLayoutId(): Int

    protected fun getToobar(): Toolbar? {
        return mToolbar
    }

    protected fun isShowBack(isShowBack: Boolean): Boolean {
        this.isShowBack = isShowBack
        if (isShowBack) {
            mToolbarIcon?.visibility = View.VISIBLE
        } else {
            mToolbarIcon?.visibility = View.GONE
        }
        return this.isShowBack
    }

    protected fun isShowAction(isShowAction: Boolean): Boolean {
        this.isShowAction = isShowAction
        if (isShowBack) {
            mToolbarAction?.visibility = View.VISIBLE
        } else {
            mToolbarAction?.visibility = View.GONE
        }
        return this.isShowAction
    }

    override fun onPause() {
        super.onPause()

    }

    override fun onDestroy() {
        super.onDestroy()


    }



    override fun onLayoutChange(p0: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {

    }
}