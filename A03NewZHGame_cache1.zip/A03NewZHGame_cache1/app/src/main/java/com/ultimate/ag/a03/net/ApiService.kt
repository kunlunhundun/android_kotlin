/*******************************************************************************
 *
 *所有的api接口维护在这里
 *
 *******************************************************************************/
package com.ultimate.ag.a03.net

import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.*
import io.reactivex.Observable
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    /**
     * 获取指纹设备信息
     */
    @POST("rest/device/deviceInfoBySessionId")
    fun getDeviceInfoBySessionId(@Body usernameRegisterRequest: GetDeviceInfoRequest): Observable<GetDeviceIdResponse>

    /**
     * 会员注册接口
     */
    @POST("customer/createRealAccount")
    fun usernameRegister(@Body usernameRegisterRequest: UsernameRegisterRequest): Observable<UserNameRegisterResponse>

    @POST("customer/createTryAccount")
    fun createTryAccount(@Body createTryAccountRequest: CreateTryAccountRequest): Observable<CreateTryAccountResponse>

    /**
     * 手机 登录/注册/找回密码/绑定手机/解绑手机号 获取验证码接口
     */
    @POST("sms/sendCode")
    fun sendCode(@Body sendSmsRequest: SendSmsRequest): Observable<SendSmsResponse>

    /**
     * 首页-精选
     */
    @POST("a03/home/best")
    fun homeBest(@Body homeBestRequest: HomeBestRequest): Observable<HomeBestResponse>

    @POST("captcha/generate")
    fun generateCode(@Body generateCodeRequest: GenerateCodeRequest): Observable<GenerateCodeResponse>

    @POST("customer/login")
    fun usernameLogin(@Body userNameLoginRequest: UserNameLoginRequest): Observable<UserNameLoginResponse>

    @POST("customer/validate")
    fun customerValidate(@Body validateCodeRequest: ValidateCodeRequest): Observable<ValidateCodeResponse>

    @POST("captcha/validate")
    fun captchaValidate(@Body validateCodeRequest: ValidateCodeRequest): Observable<ValidateCodeResponse>

    @POST("customer/createAccountByMobileNo")
    fun mobileRegister(@Body mobileRegisterRequest: MobileRegisterRequest): Observable<MobileRegisterResponse>

    @POST("customer/loginByMobileNo")
    fun loginByMobileNo(@Body mobileLoginRequest: MobileLoginRequest): Observable<MobileLoginResponse>

    @POST("sms/verifySmsCode")
    fun verifySmsCode(@Body VerifySmsCodeRequest: VerifySmsCodeRequest): Observable<VerifySmsCodeResponse>


    /**
     * 手机登录后选择一个账号登录
     */
    @POST("customer/loginByValidateId")
    fun loginByValidateId(@Body loginByValidateIdRequest: MobileLoginRequest): Observable<MobileLoginResponse>

    /**
     * 极速注册
     */
    @POST("customer/createAccountAuto")
    fun createAccountAuto(@Body createAccountAutoRequest: CreateAccountAutoRequest): Observable<MobileLoginResponse>

    /**
     * 手机登录后选择一个账号登录
     */
    @POST("customer/modifyTempLoginName")
    fun modifyTempLoginName(@Body modifyTempLoginNameRequest: ModifyLoginNameRequest): Observable<MobileLoginResponse>

    /**
     * 绑定手机号接口
     */
    @POST("customer/bindMobileNoV2")
    fun bindMobileNoV2(@Body bindMobileRequest: BindMobileRequest): Observable<BindMobileResponse>


    /**
     *绑定手机号V2
     */
    @POST("customer/reBindMobileNoV2")
    fun reBindMobileNoV2(@Body unBindPhoneRequest: UnBindPhoneRequest): Observable<UnBindPhoneResponse>

    @POST("customer/preModifyPwdBySmsCode")
    fun preModifyPwdBySmsCode(@Body preModifyPwdBySmsCodeRequest: PreModifyPwdBySmsCodeRequest): Observable<PreModifyPwdBySmsCodeResponse>

    /**
     * 自动登录接口
     */
    @POST("customer/getByToken")
    fun autoLogin(@Body autoLoginRequest: AutoLoginRequest): Observable<AutoLoginResponse>

    /*
    * 获取h5站点所需token
    */
    @POST("getH5TokenByApp")
    fun getH5TokenByApp(@Body getH5TokenByAppRequest: GetH5TokenByAppRequest): Observable<GetH5TokenByAppResponse>

    /**
     * 根据用户名发送验证码
     */
    @POST("sms/sendCodeByLoginName")
    fun sendCodeByLoginName(@Body sendSmsRequest: SendCodeByLoginNameRequest): Observable<SendSmsResponse>

    @POST("customer/modifyPwdBySmsCode")
    fun modifyPwdBySmsCode(@Body modifyPwdBySmsCodeRequest: ModifyPwdBySmsCodeRequest): Observable<ModifyPwdBySmsCodeResponse>

    /*
    * 忘记密码的时候 通过手机号找回密码 请求短信码-》 验证手机短信码
    */
    @POST("customer/preForgetPwdByMobileNo")
    fun preForgetPwdByMobileNo(@Body preFogetPwdByMobileNoRequest: PreFogetPwdByMobileNoRequest): Observable<PreForgetPwdByMobileNoResponse>


    /**
     * 修改登录密码
     */
    @POST("customer/modifyPwd")
    fun modifyPwd(@Body modifyPassWordRequest: ModifyPassWordRequest): Observable<ModifyPassWordResponse>

    /**
     * 获取电子游戏
     */
    @POST("a03/home/game")
    fun homeGame(@Body homeGameRequest: HomeGameRequest): Observable<HomeGameResponse>

    /**
     * 获取电子游戏
     */
    @POST("game/queryFavorite")
    fun queryFavorite(@Body queryFavoriteRequest: QueryFavoriteRequest): Observable<QueryFavoriteResponse>

    /**
     * 修改个人游戏收藏
     */
    @POST("game/updateFavorite")
    fun updateFavorite(@Body updateFavoriteRequest: UpdateFavoriteRequest): Observable<UpdateFavoriteResponse>

    /**
     *获取游戏进桌链接
     */
    @POST("game/inGame")
    fun inGame(@Body inGameRequest: InGameRequest): Observable<InGameResponse>

    /**
     *退出游戏
     */
    @POST("game/outGame")
    fun outGame(@Body inGameRequest: OutGameRequest): Observable<OutGameResponse>

    /**
     * 分页查询全部电游列表
     */
    @POST("game/queryGameList")
    fun queryGameList(@Body queryGameListRequest: QueryGameListRequest): Observable<QueryGameListResponse>

    /**
     * 查询游戏厅状态
     */
    @POST("game/queryGame")
    fun queryGame(@Body queryGameListRequest: QueryGameRequest): Observable<QueryGameResponse>

    /**
     * 消息中心
     */
    @POST("message")
    fun getMessage(@Body getMessageRequest: GetMessageRequest): Observable<GetMessageResponse>

    /**
     * 其他游戏
     */
    @POST("a03/home/other")
    fun otherGame(@Body otherGameRequest: OtherGameRequest): Observable<OtherGameResponseObject>

    /**
     * 查询常量接口
     */
    @POST("constant/query")
    fun queryConstant(@Body queryConstantRequest: QueryConstantRequest): Observable<QueryConstantResponse>

    /**
     * 分页查询全部电游列表
     */
    @POST("game/queryRecGame")
    fun queryRecGame(@Body queryRecGameRequest: QueryRecGameRequest): Observable<QueryRecGameResponse>

    /**
     * 体育竞猜
     */
    @POST("a03/querySports")
    fun athleticContest(@Body sprotsRequest: SportsRequest): Observable<SportsResponse>

    /**
     * 查询体育竞赛图片
     */
    @POST("a03/queryByKeyList")
    fun queryByKeyList(@Body sportsPictureRequest: SportsPicturesRequest): Observable<SportsPicturesResponse>

    /**
     * 查询话题和实力标签
     */
    @POST("a03/queryByKeyList")
    fun queryTopicTitleList(@Body queryByKeyListRequest: QueryByKeyListRequest): Observable<QueryByKeyListResponse>

    /**
     * 查询游戏平台
     */
    @POST("a03/queryByKeyList")
    fun queryGamePlatformList(@Body queryByKeyListRequest: QueryByKeyListRequest): Observable<GamePlatformListResponse>

    /**
     * 根据话题和实力ID、标签Name查询文章内容
     */
    @POST("a03/article/queryArticles")
    fun queryArticle(@Body request: QueryArticleRequest): Observable<QueryArticleResponse>

    /**
     * 根据话题和实力ID、标签Name查询文章内容
     */
    @POST("a03/article/queryArticleDetails")
    fun queryArticleDetails(@Body request: QueryArticleDetailsRequest): Observable<QueryArticleDetailsResponse>

    /**
     * 阅读次数
     */
    @POST("a03/article/updateReadNum")
    fun updateReadNum(@Body request: UpdateReadNumRequest): Observable<UpdateReadNumResponse>

    /**
     *新获取支付方式列表
     */
    @POST("deposit/queryPayWaysV2")
    fun queryPayWaysV2(@Body baseMsgRequest: BaseMsgRequest): Observable<QueryPayWaysV2Response>

    /**
     *获取支付方式列表V3
     */
    @POST("deposit/queryPayWaysV3")
    fun queryPayWaysV3(@Body baseMsgRequest: BaseMsgRequest): Observable<QueryPayWaysV3Response>


    /**
     * 获取个人信息接口
     */

    @POST("customer/getByLoginName")
    fun getByLoginName(@Body getByLoginNameRequest: GetByLoginNameRequest): Observable<GetByLoginNameResponse>

    /**
     * 根据用户名获取会员统计信息
     */
    @POST("customer/getByLoginNameEx")
    fun getByLoginNameEx(@Body getByLoginNameRequest: GetByLoginNameExRequest):
            Observable<GetByLoginNameExResponse>

    /**
     * 查询用户名是否已被占用
     */
    @POST("customer/checkLoginName")
    fun checkLoginName(@Body checkLoginNameRequest: CheckLoginNameRequest):
            Observable<CheckLoginNameResponse>

    /**
     *查询在线支付银行列表
     */
    @POST("deposit/queryOnlineBanks")
    fun queryOnlineBanks(@Body queryOnlineBanksRequest: QueryOnlineBanksRequest): Observable<OnlineBanksResponse>

    /**
     *创建在线支付订单
     */
    @POST("deposit/createOnlineOrder")
    fun createOnlineOrder(@Body createOnlineRequest: CreateOnlineRequest): Observable<CreateOnlineResponse>

    /**
     *获取限额
     */
    @POST("deposit/queryPayLimitByType")
    fun queryPayLimitByType(@Body queryPayLimitByTypeRequest: QueryPayLimitByTypeRequest): Observable<QueryPayLimitByTypeResponse>

    /**
     *查询BQ存款银行
     */
    @POST("deposit/queryBQBanks")
    fun quireBank(@Body quireBankResponse: QueryPayRequest): Observable<QureyPayResponse>

    /**
     *查询手工存款银行列表
     */
    @POST("deposit/queryRequestBanks")
    fun queryRequestBanks(@Body baseMsgRequest: BaseMsgRequest): Observable<QueryBanksResponse>

    /**
     *交易记录
     */
    @POST("credit/query")
    fun queryOrderRecord(@Body orderRecordRequest: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     * 催单接口
     */
    @POST("message/remain")
    fun remainOrder(@Body remainOrderRequest: RemainOrderRequest): Observable<RemainOrderResponse>

    /**
     *创建支付订单
     */
    @POST("deposit/BQPayment")
    fun creatPayOrder(@Body creatPayOrderRequest: CreatPayOrderRequest): Observable<CreatPayOrderResponse>

    /**
     *查询快捷金额及限额
     */
    @POST("deposit/queryAmountList")
    fun queryAmountList(@Body queryAmountListRequest: QueryAmountListRequest): Observable<QueryAmountListResponse>

    /**
     *创建手工存款提案
     */
    @POST("deposit/createRequest")
    fun createHandDeposit(@Body createHandDepositRequest: CreateHandDepositRequest): Observable<CreateHandDepositResponse>

    /**
     * 获取账户金额
     */
    @POST("customer/getBalance")
    fun getBalance(@Body getBalanceRequest: GetBalanceRequest): Observable<GetBalanceResponse>

    /**
     * 管理银行卡接口
     */
    @POST("account/query")
    fun cardManager(@Body cardManagerRequest: CardManagerRequest): Observable<CardManagerResponse>

    /**
     *创建取款提案
     */
    @POST("withdraw/createRequest")
    fun creatWithdrawalsProposal(@Body creatWPRequest: CreatMPRequest): Observable<CreatWPResponse>

    /**
     * 删除银行卡接口
     */
    @POST("account/delete")
    fun deleteBankCard(@Body deleteBankCardRequest: DeleteBankCardRequest): Observable<DeleteBankCardResponse>

    /**
     * 查询洗码大类
     */
    @POST("xm/queryXmpPlatformRequest")
    fun washCodePlatformRequest(@Body washCodeRequest: WashCodeCreatRequest): Observable<WashCodePlatResponse>

    /**
     * 查询洗码额度
     */
    @POST("xm/calcAmountV3")
    fun creatWashCode(@Body washCodeRequest: WashCodeCreatRequest): Observable<WashCodeCreatResponse>

    /**
     *创建洗码提案
     */
    @POST("xm/createRequest")
    fun creatWashCodeProposal(@Body washCodeRequest: CreatWashCodeProposalRequest): Observable<CreatCodeProposalResponse>

    /**
     * 我的 - 获取本月红利、本月洗码接口
     */
    @POST("statis")
    fun getStatis(@Body request: StatisRequest): Observable<StatisResponse>

    /**
     * 完善个人信息接口
     */
    @POST("customer/modifyRealName")
    fun modifyRealName(@Body modifyRealNameRequest: ModifyRealNameRequest): Observable<ModifyRealNameResponse>

    /**
     *修改用户信息
     */
    @POST("customer/modify")
    fun modify(@Body modifyUserInfoRequest: ModifyUserInfoRequest): Observable<ModifyUserInfoResponse>

    /**
     *获取可用用户头像列表
     */
    @POST("a03/queryAvatars")
    fun queryAvatars(@Body request: QueryAvatarRequest): Observable<QueryAvatarResponse>

    /**
     * VIP特享接口
     */
    @POST("a03/vips/queryVipPremiums")
    fun queryVipPremiums(@Body vipPremiumsRequest: VipPremiumsRequest): Observable<VipPremiumsReponse>

    /**
     * VIP洗码比例接口
     */
    @POST("a03/vips/queryXMRate")
    fun queryXMRate(@Body XMRateRequest: XMRateRequest): Observable<XMRateResponse>

    /**
     * VIP特享领取
     */
    @POST("a03/vips/queryPromotions")
    fun queryPromotions(@Body promotionsRequest: PromotionsRequest): Observable<PromotionsResponse>

    /**
     * 申请菲律宾游
     */
    @POST("a03/vips/queryApplys")
    fun queryApplys(@Body travelRequest: TravelRequest): Observable<TravelResponse>

    /**
     * 报名参观
     */
    @POST("a03/vips/insertApplyVisits")
    fun insertApplyVisits(@Body vipVisitRequest: VipVisitRequest): Observable<VipVisitResponse>

    /**
     * 报名参观
     */
    @POST("callback")
    fun mobileCall(@Body mobileCallRequest: MobileCallRequest): Observable<MobileCallResponse>

    /**
     * 修改限红
     */
    @POST("limitRed/modify")
    fun modifyLimitRed(@Body modifyLimitRedRequest: ModifyLimitRedRequest): Observable<ModifyLimitRedResponse>

    /**
     * 识别银行卡接口
     */
    @POST("getByCardBin")
    fun getByCardBin(@Body getByCardBinRequest: GetByCardBinRequest): Observable<GetByCardBinResponse>

    /**
     * 添加银行卡接口
     */
    @POST("account/createBank")
    fun createBank(@Body createBankRequest: CreateBankRequest): Observable<CreatBankResponse>

    /**
     * 添加比特币钱包接口
     */
    @POST("account/createBtc")
    fun createBtc(@Body createBtcRequest: CreateBtcRequest): Observable<CreatBtcResponse>

    /**
     * 查询积分
     */
    @POST("a03/integral/queryInfo")
    fun queryInfo(@Body request: QueryInfoRequest): Observable<QueryInfoResponse>

    /**
     * 兑换积分
     */
    @POST("a03/integral/exchange")
    fun exchangePoint(@Body request: ExchangePointRequest): Observable<ExchangePointResponse>


    /**
     *登出
     */
    @POST("customer/logout")
    fun logout(@Body loginOutRequest: LoginOutRequest): Observable<LoginOutResponse>

    /**
     *检查更新
     */
    @POST("upgrade")
    fun upgrade(@Body upgradeRequest: UpgradeRequest): Observable<UpgradeResponse>

    /**
     *设置推送服务
     */
    @POST("subscribe/modifyByGroup")
    fun setNotice(@Body noticeSetRequest: NoticeSetRequest): Observable<NoticeSetResponse>

    /**
     *获取推送通知
     */
    @POST("subscribe/queryByGroup")
    fun querySet(@Body querySetRequest: QuerySetRequest): Observable<QuerySetResponse>

    /**
     * 客服帮助接口
     */
    @POST("message/getAssistant")
    fun getAssistant(@Body getAssistantRequest: GetAssistantRequest): Observable<GetAssistantResponse>


    /**
     * 电话回拨接口
     */
    @POST("callback")
    fun callBack(@Body callBackRequest: CallBackRequest): Observable<CallBackResponse>

    /**
     * 获取活动信息接口
     */
    @POST("message/getNotices")
    fun getNotices(@Body getNoticeRequest: GetNoticeRequest): Observable<GetNoticeResponse>

    /**
     * 分页查询用户站内信列表
     */
    @POST("letter/query")
    fun getLetter(@Body getNoticeRequest: GetNoticeRequest): Observable<GetNoticeResponse>

    /**
     * 删除系统信息接口
     */
    @POST("message/delNotice")
    fun delNotice(@Body delNoticeRequest: DelNoticeRequest): Observable<DelNoticeResponse>

    /**
     * 删除letter
     */
    @POST("letter/delete")
    fun delLetter(@Body delNoticeRequest: DelNoticeRequest): Observable<DelNoticeResponse>

    /**
     * 查询充值页面优惠广告信息
     */
    @POST("constant/query")
    fun rechargePromoQuery(@Body rechargePromoRequest: RechargePromoRequest): Observable<RechargePromoResponse>

    /**
     * 我的-获取用户额度信息
     */
    @POST("customer/getBalance")
    fun getBalance(@Body balanceRequest: BalanceRequest): Observable<BalanceResponse>

    /**
     * 我的红利
     */
    @POST("a03/promo/a03MyPromo")
    fun getMyPromo(@Body myPromoRequest: MyPromoRequest): Observable<MyPromoResponse>


    /***
     * 闪屏页面接口
     */
    @POST("welcome")
    fun welcome(@Body request: WelcomeRequest): Observable<WelcomeResponseObject>

    /**
     * 反馈建议
     */
    @POST("createSuggest")
    fun createSuggest(@Body request: SuggestRequest): Observable<SuggestionResponse>

    /**
     *获取厅方在线人数
     */
    @POST("game/getOnlineNum")
    fun getOnlineNum(@Body getOnlineNumRequest: GetOnlineNumRequest): Observable<GetOnlineNumResponse>

    /**
     *更换域名
     */
    @POST("getDsGwAddress")
    fun changeUrl(@Body changeUrlRequest: ChangeUrlRequest): Observable<ChangeUrlResponse>

    /**
     * PT转账
     */
    @POST("game/transferToGame")
    fun transferToGame(@Body toGameRequest: ToGameRequest): Observable<ToGameResponse>

    /**
     * 转账至本地
     */
    @POST("game/transferToLocal")
    fun transferToLocal(@Body toLocalRequest: ToLocalRequest): Observable<ToLocalResponse>


    /**
     * 交易记录,最后一次交易
     */
    @POST("credit/query")
    fun queryBQBanks(@Body bqBanksRequest: BQBanksRequest): Observable<BQBanksResponse>

    /**
     * 查询当前限红
     */
    @POST("a03/queryByKeyList")
    fun queryByKeyList2(@Body redLimitedRequest: RedLimitedRequest): Observable<RedLimitedResponse>

    /**
     * 查询IP限制
     */
    @POST("areaLimit")
    fun areaLimit(@Body queryAreaLimitRequest: QueryAreaLimitRequest): Observable<QueryAreaLimitResponse>

    /**
     * 查询福利
     */
    @POST("a03/findPromoDatas")
    fun findPromoDatas(@Body promoDataRequest: PromoDataRequest): Observable<PromoDataResponse>

    /**
     * 查询晋级礼金,盈利返利,菲律宾游状态
     */
    @POST("a03/vips/viewPromotionsStatus")
    fun viewPromotionsStatus(@Body promotionsStatusRequest: PromotionsStatusRequest): Observable<PromotionsStatusResponse>

    /**
     * 查询推荐码
     */
    @POST("customer/queryCustomers")
    fun queryCustomers(@Body queryCustomersRequest: QueryCustomersRequest): Observable<QueryCustomersResponse>

    /**
     * 资金转入小金库
     */
    @POST("yeb/transferIn")
    fun transferIn(@Body request: TransferInMinAmtRequest): Observable<TransferResponse>

    /**
     * 资金转出小金库
     */
    @POST("yeb/transferOut")
    fun transferOut(@Body request: TransferInMinAmtRequest): Observable<TransferResponse>

    /**
     * 过夜利息利息统计
     */
    @POST("yeb/yebInterestStatis")
    fun yebInterestStatis(@Body request: YebInterestStatisRequest): Observable<YebInterestAmtResponse>

    /**
     * 获取客户助手
     */
    @POST("message/getAssistant")
    fun getAssistant(@Body request: AssistantRequest): Observable<AssistantResponse>

    /**
     * 解除激活手机
     */
    @POST("customer/unActivityPhone")
    fun unActivityPhone(@Body request: UnActivityPhoneRequest): Observable<UnAcitivityPhoneResponse>

    /**
     * 查询会员订阅设置
     */
    @POST("subscribe/query")
    fun querySubscribe(@Body request: SubscribeRequest): Observable<SubscribeResponse>

    /**
     * 查询会员订阅设置
     */
    @POST("subscribe/modify")
    fun modifySubscribe(@Body request: ModifySubscribeRequest): Observable<ModifySubscribeResponse>

    /**
     * 查询转账交易记录
     */
    @POST("credit/queryCreditLogs")
    fun queryCreditLogs(@Body request: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     * 查询小金库交易记录
     */
    @POST("yeb/yebInterestCreditLogs")
    fun yebInterestCreditLogs(@Body request: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     * 查询会员投注记录
     */
    @POST("bet/queryBets")
    fun queryBets(@Body request: QueryBetsRequest): Observable<OrderRecordResponse>

    /**
     * 查询电游详情
     */
    @POST("bet/findBetById")
    fun findBetById(@Body request: FindBetDetailsRequest): Observable<FindBetDetailsResponse>

    /**
     * 查询站内信未读数
     */
    @POST("letter/query")
    fun queryUnreadLetter(@Body request: LetterUnreadRequest): Observable<GetNoticeResponse>

    /**
     * 更新站内信未读数
     */
    @POST("letter/view")
    fun updateLetter(@Body request: LetterUnreadRequest): Observable<GetNoticeResponse>

    /**
     * 获取最小转入金额
     */
    @POST("yeb/transferInMinAmt")
    fun getTransferInMinAmt(@Body request: TransferInMinAmtRequest): Observable<TransferInMinAmtResponse>

    /**
     * 埋点
     */
    @POST("data_gather")
    fun coverPointMessage(@Body coverPointRequest: CoverPointRequest): Observable<CoverPointResponse>

    /**
     * 埋点
     */
    @POST("data_gather_batch")
    fun coverPointListMessage(@Body coverPointRequest: MutableList<CoverPointRequest>?): Observable<CoverPointResponse>

    /**
     * 马甲包接口
     */
    @POST("dynamic/query")
    fun dynamicQuery(@Body dynamicRequest: DynamicRequest): Observable<DynamicResponse>

    /**
     * 查询图片列表
     */
    @POST("a03/queryImageList")
    fun queryImageList(@Body imageListRequest: ImageListRequest): Observable<ImageListResponse>


    @POST("a03/queryImageList")
    fun findShareList(@Body imageListRequest: ImageListRequest): Observable<ShareResponse>

    // 查询是否有可领取的好友推荐奖励
    @POST("a03/getUserStatus")
    fun getUserStatus(@Body request: UserStatusRequest): Observable<UserStatusResponse>

    // 查询已注册好友
    @POST("a03/getByParentLoginName")
    fun findRegisterFriends(@Body request: PageRequest): Observable<RegisterFriendResponse>

    // 查询满足条件的好友
    @POST("a03/getByParentLoginName")
    fun findConditionFriends(@Body request: PageRequest): Observable<ConditionFriendResponse>

    // 查询我的好友推荐收入
    @POST("a03/queryDownlineAction")
    fun findRecommendFriendsIncome(@Body request: CommonRequest): Observable<RecommendFriendIncomeResponse>

    // 叮嘱接口 发送叮嘱消息
    @POST("a03/createLetter")
    fun sendExhortMsg(@Body request: ExhortRequest): Observable<CommonResponse>

    // 领取好礼
    @POST("a03/createOtherRequest")
    fun receiveGifts(@Body request: ReceiveGiftsRequest): Observable<CommonResponse>

}