package com.ultimate.ag.a03.activity.mvp.presenter

import android.text.TextUtils
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.VipPrivilegeModel
import com.ultimate.ag.a03.activity.mvp.view.VipPrivilegeView
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.*
import com.ultimate.ag.a03.net.ApiErrorModel

class VipPremiumsPresenter : BasePresenter<VipPrivilegeView, VipPrivilegeModel>() {


    /**
     * 获取账户余额
     */
    fun getBalance(request: GetBalanceRequest) {
        if (!isViewAttached)
            return
        model?.getBalance(request, view!!.getRxActivity(), object :
                MvpCallback<GetBalanceResponse> {
            override fun onSuccess(data: GetBalanceResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {
                    view?.showBalance(data)
                }
            }

            override fun onBusinessFail(data: GetBalanceResponse) {

            }

            override fun onFail(model: ApiErrorModel) {
            }

            override fun complete() {
            }

        })

    }

    /**
     * 获取VIP特享数据
     */
    fun getPremiumsData(request: VipPremiumsRequest) {
        if (!isViewAttached)
            return

        model?.getVipPremiums(request, view!!.getRxActivity(), object : MvpCallback<VipPremiumsReponse> {
            override fun onSuccess(data: VipPremiumsReponse) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(true)
                if (data != null) {

                    view?.showVipPremiums(data)
                    view?.showProgress(data)
                }
            }

            override fun onBusinessFail(data: VipPremiumsReponse) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(false)
                view?.showVipPremiumsFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(false)
                if (!TextUtils.isEmpty(model.message)) {
                    view?.showToast(model.message)
                }
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 获取VIP洗码比例
     */
    fun getXMRate(request: XMRateRequest) {
        if (!isViewAttached)
            return
        model?.getXMRate(request, view!!.getRxActivity(), object : MvpCallback<XMRateResponse> {
            override fun onSuccess(data: XMRateResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {
                    view?.showXMRate(data)
                }
            }

            override fun onBusinessFail(data: XMRateResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {
                    view?.showXMRateFail(data)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                if (!TextUtils.isEmpty(model.message)) {
                    view?.showToast(model.message)
                }
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 领取VIP特权
     */
    fun getPromotions(request: PromotionsRequest) {
        if (!isViewAttached)
            return

        view!!.showLoading()
        model!!.getPromotions(request, view!!.getRxActivity(), object : MvpCallback<PromotionsResponse> {
            override fun onSuccess(data: PromotionsResponse) {

                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onBusinessFail(data: PromotionsResponse) {
                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                if (!TextUtils.isEmpty(model.message)) {
                    view?.showToast(model.message)
                }
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }


        })
    }

    /**
     * 报名菲律宾游
     */
    fun travelApply(request: TravelRequest) {

        if (!isViewAttached)
            return

        view!!.showLoading()
        model!!.queryApplys(request, view!!.getRxActivity(), object : MvpCallback<TravelResponse> {
            override fun onSuccess(data: TravelResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {
                    view?.travleApplySuccess(data)
                }
            }

            override fun onBusinessFail(data: TravelResponse) {
                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 报名菲律宾游
     */
    fun vipVisit(request: VipVisitRequest) {

        if (!isViewAttached)
            return

        view!!.showLoading()
        model!!.insertApplyVisits(request, view!!.getRxActivity(), object : MvpCallback<VipVisitResponse> {
            override fun onSuccess(data: VipVisitResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {
                    view?.vipVisitSuccess(data)
                }
            }

            override fun onBusinessFail(data: VipVisitResponse) {
                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 电话回拨
     */
    fun mobileCall(request: VipVisitRequest) {

        if (!isViewAttached)
            return

        view!!.showLoading()
        model!!.mobileCall(request, view!!.getRxActivity(), object : MvpCallback<VipVisitResponse> {
            override fun onSuccess(data: VipVisitResponse) {
                if (!isViewAttached)
                    return

                view?.showToast("稍后会有专属秘书回电")
            }

            override fun onBusinessFail(data: VipVisitResponse) {
                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 查询晋级礼金,盈利返利,菲律宾游状态
     */
    fun checkPromotionsStatus(request: PromotionsStatusRequest) {

        if (!isViewAttached)
            return

//        view!!.showLoading()
        model!!.viewPromotionsStatus(request, view!!.getRxActivity(), object : MvpCallback<PromotionsStatusResponse> {
            override fun onSuccess(data: PromotionsStatusResponse) {
                if (!isViewAttached)
                    return

                if(data != null){

                    view?.controlPromotions(data)
                }
            }

            override fun onBusinessFail(data: PromotionsStatusResponse) {
                if (!isViewAttached)
                    return

                if (data != null && data.head.errMsg != null) {
                    view?.showToast(data.head.errMsg!!)
                }
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                if (!TextUtils.isEmpty(model.message)) {
                    view?.showToast(model.message)
                }
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }
}