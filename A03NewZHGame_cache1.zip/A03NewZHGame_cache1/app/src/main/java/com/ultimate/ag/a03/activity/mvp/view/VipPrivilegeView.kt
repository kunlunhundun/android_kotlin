package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.*

interface VipPrivilegeView: IBaseView{

    /**
     * 展示VIP特享信息
     */
    fun showVipPremiums(data: VipPremiumsReponse)

    /**
     * 显示VIP进度
     */
    fun showProgress(data: VipPremiumsReponse)

    /**
     * 展示VIP特享信息失败
     */
    fun showVipPremiumsFail(data: VipPremiumsReponse)

    /**
     * 显示VIP洗码比例
     */
    fun showXMRate(data: XMRateResponse)

    /**
     * 显示VIP洗码比例失败
     */
    fun showXMRateFail(data: XMRateResponse)

    /**
     * 提交菲律宾游成功
     */
    fun travleApplySuccess(data: TravelResponse)

    /**
     * 提交报名参观成功
     */
    fun vipVisitSuccess(data: VipVisitResponse)

    /**
     * 显示账户余额
     */
    fun showBalance(data: GetBalanceResponse)

    /**
     * 下拉刷新结束
     */
    fun finishRefresh(success: Boolean)

    /**
     * 设置领取按钮的点击状态
     */
    fun controlPromotions(data: PromotionsStatusResponse)

}