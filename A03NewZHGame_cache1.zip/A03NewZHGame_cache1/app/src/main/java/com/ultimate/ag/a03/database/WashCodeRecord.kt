package com.ultimate.ag.a03.database

import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class WashCodeRecord : DataSupport() {
    var loginName: String? = ""
    var firstTime: Int? = 0
    var bankfirstTime: Int? = 0

}