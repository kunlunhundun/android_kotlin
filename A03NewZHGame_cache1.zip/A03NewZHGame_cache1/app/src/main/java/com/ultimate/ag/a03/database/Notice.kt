package com.ultimate.ag.a03.database

import com.ultimate.ag.a03.config.ConfigUtils
import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class Notice : DataSupport() {
    var loginName: String? = ConfigUtils.loginName
    var noticeDeleteId: Int? = null
    var noticeReadId: Int? = null
}