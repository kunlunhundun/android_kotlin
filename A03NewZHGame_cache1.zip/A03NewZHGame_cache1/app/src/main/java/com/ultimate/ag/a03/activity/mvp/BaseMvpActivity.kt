package com.ultimate.ag.a03.activity.mvp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.components.support.RxFragment
import com.ultimate.ag.a03.activity.mvp.model.IModel
import com.ultimate.ag.a03.activity.mvp.presenter.BasePresenter
import com.ultimate.ag.a03.activity.mvp.view.IBaseView
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.LoadingDialog
import com.ultimate.ag.a03.util.ACache
import com.ultimate.ag.a03.util.AndroidWorkaround
import com.ultimate.ag.a03.util.ToastUtils


/**
 * Created by ward.y on 2018/2/5.
 */

abstract class BaseMvpActivity<V : IBaseView,P: IModel> : RxAppCompatActivity(), IBaseView {
    private val isAddActivityList = "isAddActivityList"
    private var mActivity: Activity? = null
    open lateinit var mAcach: ACache
    private var onstop = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 21) {
            val decorView = window.decorView
            val option = (View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            decorView.systemUiVisibility = option
            window.statusBarColor = Color.TRANSPARENT
        }
        AndroidWorkaround.assistActivity(findViewById(android.R.id.content))

        mActivity = this
        mAcach = AppInitManager.getAcache()
        if (intent.getBooleanExtra(isAddActivityList, false)) {
            AppInitManager.getActivityListManager().addActivity(mActivity)

        }



        @Suppress("UNCHECKED_CAST")
        getPresenter()?.attachView(this as V)

    }

    override fun onStart() {
        super.onStart()
        if (!onstop) {
            initView()
            initListener()
        } else {
            onstop = false
        }

    }

    override fun onRestart() {
        super.onRestart()

    }

    override fun onResume() {
        super.onResume()
        AppInitManager.getActivityListManager().currentActivity = mActivity
    }

    override fun onStop() {
        super.onStop()
        if (AppInitManager.getActivityListManager().currentActivity == mActivity) {
            AppInitManager.getActivityListManager().currentActivity = null

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        //解除presenter
        cancelLoading()
        getPresenter()?.detachView()
        AppInitManager.getActivityListManager().removeActivity(mActivity)
        mActivity = null
    }

    /**
     * 跳转页面方法，方便加入Activity管理
     * @param isAdd false 为不加入管理
     */

    fun goToPage(intent: Intent, isAdd: Boolean) {

        intent.putExtra(isAddActivityList, isAdd)
        startActivity(intent)

    }

    /**
     * 跳转页面方法，方便加入Activity管理
     */

    fun goToPage(intent: Intent) {

        goToPage(intent, true)

    }

    fun goToPageForResult(intent: Intent, isAdd: Boolean, requstCode: Int) {
        intent.putExtra(isAddActivityList, isAdd)
        startActivityForResult(intent, requstCode)
    }

    override fun showToast(message: String) {
        ToastUtils.show(message)
    }

    override fun showToast(id: Int) {
        ToastUtils.show(id)
    }

    override fun getContext(): Context {

        return baseContext
    }

    override fun getRxActivity(): RxAppCompatActivity {
        return this
    }

    override fun getRxFragment(): RxFragment? {
        return null
    }

    abstract fun getPresenter(): BasePresenter<V,P>?

    override fun showLoading() {
        LoadingDialog.show(this)
    }

    override fun cancelLoading() {
        LoadingDialog.cancel()
    }

}