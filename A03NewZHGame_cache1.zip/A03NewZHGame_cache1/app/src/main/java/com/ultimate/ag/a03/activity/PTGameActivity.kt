package com.ultimate.ag.a03.activity

import android.os.Bundle
import android.text.TextUtils
import android.view.WindowManager
import com.google.gson.Gson
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.data.PostMapObject
import com.ultimate.ag.a03.data.request.OutGameRequest
import com.ultimate.ag.a03.data.response.OutGameResponse
import com.ultimate.ag.a03.hybride.BrowserActivity
import com.ultimate.ag.a03.hybride.GameWebViewClient
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import kotlinx.android.synthetic.main.activity_ptgame.*
import java.io.UnsupportedEncodingException
import java.net.URLEncoder

class PTGameActivity : BaseToolBarActivity() {
    var mGameCode: String? = null
    var mGameId: String? = null
    var mGameName: String? = null

    override fun initListener() {

    }

    var postMap: PostMapObject? = null
    var mUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mUrl = intent.getStringExtra(BrowserActivity.PARAM_URL)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        mGameCode = intent.getStringExtra(H5GameActivity.PARAM_GAME_CODE)
        mGameId = intent.getStringExtra(H5GameActivity.PARAM_GAME_ID)
        mGameName = intent.getStringExtra(H5GameActivity.PARAM_GAME_NAME)
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_ptgame
    }

    override fun initData() {
        webview.webViewClient = GameWebViewClient(this)
        if (!TextUtils.isEmpty(intent.getStringExtra("postMap"))) {
            postMap = Gson().fromJson(intent.getStringExtra("postMap"), PostMapObject::class.java)

            webview.settings.defaultTextEncodingName = "UTF-8"
            val builder1 = StringBuilder()
            try {//拼接post提交参数
                builder1.append("?gameID=").append(URLEncoder.encode(postMap?.gameID, "UTF-8")).append("&")
                        .append("gameType=").append(URLEncoder.encode(postMap?.gameType, "UTF-8")).append("&")
                        .append("password=").append(URLEncoder.encode(postMap?.password, "UTF-8")).append("&")
                        .append("username=").append(URLEncoder.encode(postMap?.username, "UTF-8"))

            } catch (e: UnsupportedEncodingException) {
                e.printStackTrace()
            }

            val postData = builder1.toString()
            webview.loadUrl("$mUrl$postData")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        val outGameRequest = OutGameRequest()
        outGameRequest.gameCode = mGameCode
        outGameRequest.gameName = mGameName
        outGameRequest.gameId = mGameId
        ApiClient.instance.service.outGame(outGameRequest)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<OutGameResponse>(this, false) {

                    override fun businessFail(data: OutGameResponse) {

                    }

                    override fun businessSuccess(data: OutGameResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }
                })

    }
}
