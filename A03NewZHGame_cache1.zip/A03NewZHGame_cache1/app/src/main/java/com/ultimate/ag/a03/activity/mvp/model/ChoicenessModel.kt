package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.TagItem
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.GetOnlineNumResponse
import com.ultimate.ag.a03.data.response.HomeBestResponse
import com.ultimate.ag.a03.data.response.InGameResponse
import com.ultimate.ag.a03.data.response.PromoDataResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.Utils

class ChoicenessModel : IModel {


    /**
     * 获取首页精选界面网络数据
     */
    fun getNetData(request: HomeBestRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<HomeBestResponse>) {
        ApiClient.instance.frontService.homeBest(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<HomeBestResponse>() {
                    override fun businessFail(data: HomeBestResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: HomeBestResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    private var mProcedureId: String = ""

    /**
     * 进入游戏网络请求
     */
    fun inGameNet(request: InGameRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<InGameResponse>) {

        val tagItem = TagItem("logingame_click", "请求游戏url", "游戏", "进游戏", "页面操作指标")
        mProcedureId = Utils.getProcedureId("EnterGameProcedure")
        val coverData = CoverPointRequest.Data()
        Utils.setGameCoverData(request, coverData)
        Utils.coverPointRequest(tagItem, "MainActivity", "ChoicenessFragment", mProcedureId, coverData)

        ApiClient.instance.service.inGame(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<InGameResponse>() {
                    override fun businessFail(data: InGameResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: InGameResponse) {

                        val tagItem = TagItem("logingame_show", "加载游戏url", "游戏", "其他", "页面操作指标")
                        Utils.coverPointRequest(tagItem, "MainActivity", "ChoicenessFragment", mProcedureId, coverData)

                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 获取AG在线人数
     */
    fun getOnlineNumber(request: GetOnlineNumRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<GetOnlineNumResponse>) {
        ApiClient.instance.service.getOnlineNum(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<GetOnlineNumResponse>() {
                    override fun businessFail(data: GetOnlineNumResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: GetOnlineNumResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 获取每日红利
     */
    fun getPromoDatas(request: PromoDataRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<PromoDataResponse>) {
        ApiClient.instance.frontService.findPromoDatas(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<PromoDataResponse>() {
                    override fun businessFail(data: PromoDataResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: PromoDataResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}