package com.ultimate.ag.a03.eventbus;

/**
 * @author Javan.W
 * @date 2019/4/6
 * @Description 领取礼物成功
 */
public class ReceiveGiftsSucceedEvent {
}
