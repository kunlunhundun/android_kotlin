package com.ultimate.ag.a03.database

import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class LockRecord : DataSupport() {
    var token: String? = null
    var fingerPrint: Boolean = false
    var gestureLock: Boolean = false
    var gestureLockPwd: String? = null
}