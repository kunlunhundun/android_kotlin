package com.ultimate.ag.a03.activity

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.data.request.ModifySubscribeRequest
import com.ultimate.ag.a03.data.request.SubscribeRequest
import com.ultimate.ag.a03.data.response.ModifySubscribeResponse
import com.ultimate.ag.a03.data.response.SubscribeResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.StatusBarUtil
import com.ultimate.ag.a03.util.ToastUtils
import com.ultimate.ag.a03.view.SwitchButton
import kotlinx.android.synthetic.main.activity_notification_settings.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class NotificationSettingsActivity : BaseToolBarActivity() {


    override fun getLayoutId(): Int {
        return R.layout.activity_notification_settings
    }

    private var mPhoneSMSSettingAdapter: BaseQuickAdapter<SubscribeResponse.Body, BaseViewHolder>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StatusBarUtil.StatusBarLightMode(this)
        setTile(getString(R.string.notification_setting_activity_title))
        setBackground(R.color.white)
        isShowBack(true)
        setActionText("保存")
        OverScrollDecoratorHelper.setUpOverScroll(sl_setting)

        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        rv_phone_setting.layoutManager = layoutManager
        mPhoneSMSSettingAdapter = object : BaseQuickAdapter<SubscribeResponse.Body, BaseViewHolder>(R.layout.layout_notice_setting) {
            override fun convert(helper: BaseViewHolder, item: SubscribeResponse.Body) {
                helper.setText(R.id.tv_setting, item.name)
                val switchButton = helper.getView<SwitchButton>(R.id.sb_setting)
                switchButton.isChecked = item.subscribed == 1

                switchButton.setOnCheckedChangeListener { view, isChecked ->
                    val request = ModifySubscribeRequest()
                    request.type = 1
                    val list = mutableListOf<ModifySubscribeRequest.Subscribes>()
                    val subscribes = ModifySubscribeRequest.Subscribes()
                    subscribes.code = item.code
                    subscribes.subscribed = if (isChecked) 1 else 0
                    list.add(subscribes)
                    request.subscribes = list
                    ApiClient.instance.service.modifySubscribe(request)
                            .compose(NetworkScheduler.compose())
                            .bindUntilEvent(this@NotificationSettingsActivity, ActivityEvent.DESTROY)
                            .subscribe(object : ApiResponse<ModifySubscribeResponse>(this@NotificationSettingsActivity, false) {
                                override fun businessFail(data: ModifySubscribeResponse) {
                                    ToastUtils.show("" + data.head.errMsg)
                                }

                                override fun businessSuccess(data: ModifySubscribeResponse) {
                                    ToastUtils.show("修改成功")
                                }

                                override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                                    ToastUtils.show("" + apiErrorModel.message)
                                }

                            })
                }
            }
        }
        rv_phone_setting.adapter = mPhoneSMSSettingAdapter
    }

    override fun initData() {

        getSubscribeData()

    }

    private fun getSubscribeData() {
        val request = SubscribeRequest()
        request.type = 1
        ApiClient.instance.service.querySubscribe(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SubscribeResponse>(this, false) {
                    override fun businessFail(data: SubscribeResponse) {

                    }

                    override fun businessSuccess(data: SubscribeResponse) {
                        data.body?.let {
                            for (item in data.body!!) {
                                if (item.name.equals("优惠")) {
                                    item.name = "红利"
                                }
                                if (item.name.equals("存款")) {
                                    item.name = "充值"
                                }
                                if (item.name.equals("取款")) {
                                    item.name = "提现"
                                }
                            }
                            mPhoneSMSSettingAdapter?.setNewData(data.body)
                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }

    override fun initListener() {
        getActionView()?.setOnClickListener { finish() }
    }

//    private fun querySet() {
//        val request = QuerySetRequest()
//        ApiClient.instance.service.querySet(request)
//                .compose(NetworkScheduler.compose())
//                .bindUntilEvent(this, ActivityEvent.DESTROY)
//                .subscribe(object : ApiResponse<QuerySetResponse>(this, false) {
//                    override fun businessFail(data: QuerySetResponse) {
//
//                    }
//
//                    override fun businessSuccess(data: QuerySetResponse) {
//                        when (data.body?.capitalNotice) {
//                            0 -> {
//                                datas!![0].appPush = false
//                                datas!![0].smsPush = false
//                            }
//                            1 -> {
//                                datas!![0].appPush = false
//                                datas!![0].smsPush = true
//                            }
//                            2 -> {
//                                datas!![0].appPush = true
//                                datas!![0].smsPush = false
//                            }
//                            3 -> {
//                                datas!![0].appPush = true
//                                datas!![0].smsPush = true
//                            }
//                        }
//
//                        when (data.body?.securityNotice) {
//                            0 -> {
//                                datas!![1].appPush = false
//                                datas!![1].smsPush = false
//                            }
//                            1 -> {
//                                datas!![1].appPush = false
//                                datas!![1].smsPush = true
//                            }
//                            2 -> {
//                                datas!![1].appPush = true
//                                datas!![1].smsPush = false
//                            }
//                            3 -> {
//                                datas!![1].appPush = true
//                                datas!![1].smsPush = true
//                            }
//                        }
//
//
//                        when (data.body?.promotionNotice) {
//                            0 -> {
//                                datas!![2].appPush = false
//                                datas!![2].smsPush = false
//                            }
//                            1 -> {
//                                datas!![2].appPush = false
//                                datas!![2].smsPush = true
//                            }
//                            2 -> {
//                                datas!![2].appPush = true
//                                datas!![2].smsPush = false
//                            }
//                            3 -> {
//                                datas!![2].appPush = true
//                                datas!![2].smsPush = true
//                            }
//                        }
//
//                        notiObj = NotificationSetObj(datas!!)
//                        AppInitManager.getAcache().put("notification_set", Gson().toJson(notiObj))
//                        adapter?.notifyDataSetChanged()
//                    }
//
//                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//
//                    }
//
//                })
//
//    }
//
//
//    private fun setNotice(request: NoticeSetRequest) {
//        ApiClient.instance.service.setNotice(request)
//                .compose(NetworkScheduler.compose())
//                .bindUntilEvent(this, ActivityEvent.DESTROY)
//                .subscribe(object : ApiResponse<NoticeSetResponse>(this, false) {
//                    override fun businessFail(data: NoticeSetResponse) {
//
//                    }
//
//                    override fun businessSuccess(data: NoticeSetResponse) {
//                        notiObj?.datas = datas!!
//                        AppInitManager.getAcache().put("notification_set", Gson().toJson(notiObj))
//                    }
//
//                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//
//                    }
//
//                })
//
//    }
//
//
//    inner class ListViewAdapter(context: Context, datas: MutableList<NotificationSettingsObj>) : BaseAdapter() {
//        var mContext: Context = context
//        var datas: MutableList<NotificationSettingsObj> = datas
//
//        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//            var holder: MyViewHolder
//            var v: View
//            if (convertView == null) {
//                holder = MyViewHolder()
//                v = LayoutInflater.from(mContext).inflate(R.layout.item_notification_settings_view, parent, false)
//                holder.tv_settings_title = v.findViewById(R.id.tv_title)
//                holder.tv_settings_tip = v.findViewById(R.id.tv_tip)
//                holder.sb_app_push = v.findViewById(R.id.sb_app_push)
//                holder.sb_sms = v.findViewById(R.id.sb_sms)
//                v.tag = holder
//
//            } else {
//                v = convertView
//                holder = v.tag as MyViewHolder
//            }
//            holder.tv_settings_title.text = datas[position].title
//            holder.tv_settings_tip.text = datas[position].tip
//            holder.sb_app_push.isChecked = datas[position].appPush
//            holder.sb_sms.isChecked = datas[position].smsPush
//
//
//            when (position) {
//                0 -> {
//                    holder.sb_app_push.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.capitalNotice = 3
//                                }
//                                false -> {
//                                    request.capitalNotice = 2
//                                }
//                            }
//
//                            datas[position].appPush = true
//                        } else {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.capitalNotice = 1
//                                }
//                                false -> {
//                                    request.capitalNotice = 0
//                                }
//                            }
//                            datas[position].appPush = false
//                        }
//
//                        setNotice(request)
//                    }
//
//                    holder.sb_sms.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.capitalNotice = 3
//                                }
//                                false -> {
//                                    request.capitalNotice = 1
//                                }
//                            }
//                            datas[position].smsPush = true
//                        } else {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.capitalNotice = 2
//                                }
//                                false -> {
//                                    request.capitalNotice = 0
//                                }
//                            }
//
//                            datas[position].smsPush = false
//                        }
//
//                        setNotice(request)
//                    }
//                }
//
//                1 -> {
//                    holder.sb_app_push.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.securityNotice = 3
//                                }
//                                false -> {
//                                    request.securityNotice = 2
//                                }
//                            }
//                            datas[position].appPush = true
//                        } else {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.securityNotice = 1
//                                }
//                                false -> {
//                                    request.securityNotice = 0
//                                }
//                            }
//                            datas[position].appPush = false
//                        }
//
//                        setNotice(request)
//
//                    }
//
//                    holder.sb_sms.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.securityNotice = 3
//                                }
//                                false -> {
//                                    request.securityNotice = 1
//                                }
//                            }
//                            datas[position].smsPush = true
//                        } else {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.securityNotice = 2
//                                }
//                                false -> {
//                                    request.securityNotice = 0
//                                }
//                            }
//
//                            datas[position].smsPush = false
//                        }
//
//                        setNotice(request)
//                    }
//                }
//
//
//                2 -> {
//                    holder.sb_app_push.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.promotionNotice = 3
//                                }
//                                false -> {
//                                    request.promotionNotice = 2
//                                }
//                            }
//                            datas[position].appPush = true
//                        } else {
//                            when (holder.sb_sms.isChecked) {
//                                true -> {
//                                    request.promotionNotice = 1
//                                }
//                                false -> {
//                                    request.promotionNotice = 0
//                                }
//                            }
//                            datas[position].appPush = false
//                        }
//
//                        setNotice(request)
//                    }
//
//                    holder.sb_sms.setOnCheckedChangeListener { view, isChecked ->
//                        val request = NoticeSetRequest()
//                        if (isChecked) {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.promotionNotice = 3
//                                }
//                                false -> {
//                                    request.promotionNotice = 1
//                                }
//                            }
//                            datas[position].smsPush = true
//                        } else {
//                            when (holder.sb_app_push.isChecked) {
//                                true -> {
//                                    request.promotionNotice = 2
//                                }
//                                false -> {
//                                    request.promotionNotice = 0
//                                }
//                            }
//                            datas[position].smsPush = false
//                        }
//
//                        setNotice(request)
//                    }
//                }
//
//            }
//
//            return v
//        }
//
//        override fun getItem(p0: Int): Any {
//            return datas[p0]
//        }
//
//        override fun getItemId(p0: Int): Long {
//            return p0.toLong()
//        }
//
//        override fun getCount(): Int {
//            return datas.size
//        }
//
//        inner class MyViewHolder {
//            lateinit var tv_settings_title: TextView
//            lateinit var tv_settings_tip: TextView
//            lateinit var sb_app_push: SwitchButton
//            lateinit var sb_sms: SwitchButton
//        }
//    }


}