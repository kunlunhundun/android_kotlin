package com.ultimate.ag.a03.activity

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.RadioGroup
import android.widget.TextView
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.fragment.OderListFragment
import com.ultimate.ag.a03.util.StatusBarUtil

import kotlinx.android.synthetic.main.activity_tradding_record.*


/**
 * Created by ward.y on 2018/2/23.
 * 交易记录页面
 */
class TradingRecordActivity : BaseToolBarActivity() {

    override fun initListener() {
        getActionView()?.setOnClickListener {
            showPopupWindow()
        }
    }

    var fragments: MutableList<OderListFragment>? = null
    var titles = arrayOf("充值", "提现", "洗码", "转账", "红利", "小金库", "账变", "积分", "电游")
    var callBack: IFilterCallBack? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_tradding_record
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        StatusBarUtil.StatusBarLightMode(this)
        setBackground(R.color.white)
        setTile(getString(R.string.trading_record_page_title))
        setActionIcon(R.mipmap.icon_filter)
        isShowBack(true)

    }


    override fun initData() {
        val index = intent.getIntExtra("index", 1)

        fragments = arrayListOf()
        tabs.tabMode = TabLayout.MODE_SCROLLABLE
        titles.forEach {
            tabs.addTab(tabs.newTab().setText(it))
        }

        titles.forEach {
            val fragment = OderListFragment()
            val bundle = Bundle()
            bundle.putString("type", it)
            if (index == 3 || index == 5) {//从本月红利和本月洗码进入，默认显示30天交易记录
                bundle.putInt("lastDays", 30)
            }
            fragment.arguments = bundle
            fragments?.add(fragment)

        }

        viewPager.adapter = ContentAdapter(supportFragmentManager)
        viewPager.currentItem = (index - 1)
        tabs.setupWithViewPager(viewPager)
    }

    /**
     * 内容页的适配器
     */
    private inner class ContentAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

        val fm = fm

        override fun getPageTitle(position: Int): CharSequence {
            return titles[position]
        }

        override fun getItem(position: Int): Fragment {
            return fragments!![position]
        }

        override fun getCount(): Int {
            return fragments!!.size
        }

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val fragment = super.instantiateItem(container, position) as Fragment
            fm.beginTransaction().show(fragment).commit()
            return fragment
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            val fragment = fragments!![position]
            fm.beginTransaction().hide(fragment).commit()

        }

    }

    var mCurrentLastDays: Int? = -1

    private fun showPopupWindow() {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.view_popup_window_order_record, null)
        val cancel: TextView = view.findViewById(R.id.tv_cancel)
        val sure: TextView = view.findViewById(R.id.tv_ok)
        val rg: RadioGroup = view.findViewById(R.id.rg)

        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        popupWindow.isOutsideTouchable = true
//        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style_drop

//        rg.setOnCheckedChangeListener { _, i ->
//
//
//
//        }

        mCurrentLastDays = fragments?.get(viewPager.currentItem)?.mLastDays

        when (mCurrentLastDays) {
            3 -> rg.check(R.id.rb_3)
            7 -> rg.check(R.id.rb_7)
            30 -> rg.check(R.id.rb_30)
            else -> rg.check(R.id.rb_3)
        }
        popupWindow.showAsDropDown(tool_bar, 0, 0)
        view_bg.visibility = View.VISIBLE
        popupWindow.setOnDismissListener { view_bg.visibility = View.GONE }
        cancel.setOnClickListener {
            popupWindow.dismiss()
            mCurrentLastDays = -1
        }
        sure.setOnClickListener {
            when (rg.checkedRadioButtonId) {

                R.id.rb_3 -> {
                    mCurrentLastDays = 3
                }
                R.id.rb_7 -> {
                    mCurrentLastDays = 7
                }
                R.id.rb_30 -> {
                    mCurrentLastDays = 30
                }
            }

            popupWindow.dismiss()
            if (callBack != null) {
                callBack?.callBack(mCurrentLastDays ?: 3)
                setActionIcon(R.mipmap.icon_filter_selected)
            }

        }


    }

    interface IFilterCallBack {
        fun callBack(lastDays: Int)
    }

    fun setFilterListener(listener: IFilterCallBack) {
        callBack = listener
    }

    fun resetCurrentIndex() {
        mCurrentLastDays = 3
    }

}




