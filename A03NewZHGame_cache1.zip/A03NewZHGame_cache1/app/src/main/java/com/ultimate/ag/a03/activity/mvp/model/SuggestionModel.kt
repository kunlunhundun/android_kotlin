package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.SuggestRequest
import com.ultimate.ag.a03.data.response.SuggestionResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler

class SuggestionModel : IModel {

    /**
     * 发送返券建议
     */
    fun createSuggest(request: SuggestRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<SuggestionResponse>) {
        ApiClient.instance.service.createSuggest(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<SuggestionResponse>() {
                    override fun businessFail(data: SuggestionResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun businessSuccess(data: SuggestionResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}