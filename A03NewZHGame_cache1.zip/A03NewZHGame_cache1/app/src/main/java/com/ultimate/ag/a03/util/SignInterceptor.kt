package com.ultimate.ag.a03.util

import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import common.util.sign.SignUtils
import okhttp3.Interceptor
import okhttp3.Response
import okio.Buffer
import java.io.EOFException
import java.io.IOException
import java.nio.charset.Charset

/**
 * @Creat by ward 2018/10/29
 */
class SignInterceptor : Interceptor {

    // Used to load the 'native-lib' library on application startup.
//    init {
//        System.loadLibrary("SignIdentifier");
//    }
//
//    /**
//     * A native method that is implemented by the 'SignIdentifier' native library,
//     * which is packaged with this application.
//     */
//    external fun getSign(src: String, qid: String, key: String): String

    var mModifyAppId: Boolean = false

    constructor() {
    }
    constructor(modifyAppId:Boolean) {
        mModifyAppId = modifyAppId
    }



    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {

        var appId =  ProjectUtils.APPID
        if (mModifyAppId) {
            appId = "A03H501"
        }

        var request = chain.request()

        SignInterceptor
        val requestBody = request.body()
        val hasRequestBody = requestBody != null

        if (hasRequestBody) {
            val buffer = Buffer()
            requestBody!!.writeTo(buffer)


            if (isPlaintext(buffer)) {
                val qid = Utils.getUUID()
                val requestBodyStr = buffer.readUtf8()
                request = request.newBuilder()
                        .addHeader("token", Utils.getToken())
                        .addHeader("qid", qid)
                        .addHeader("pid", ProjectUtils.PID)
                        .addHeader("appId", appId)
                        .addHeader("v", ProjectUtils.GATEWAY_VERSION)
                        .addHeader("domainName", ConfigUtils.DOMAIN_NAME)
                        .addHeader("parentId", ConfigUtils.parentId)
                        .addHeader("deviceId", DeviceInfo.getDeviceId())
                        .addHeader("sign", SignUtils.getSign(getSrcStr(requestBodyStr, qid), qid, Utils.getSignKey()))
//                        .addHeader("sign", Utils.getSign(request.url().toString(), requestBodyStr, qid))
                        .build()
            }

        }

        val response: Response
        try {
            response = chain.proceed(request)
        } catch (e: Exception) {
            LogUtils.e("<-- HTTP FAILED: $e")
            throw e
        }

        return response
    }

    fun getSrcStr(requestBodyStr: String, qid: String): String {
        return requestBodyStr + "${qid}" + "${ProjectUtils.APPID}" + "${ProjectUtils.GATEWAY_VERSION}" +
                "${ConfigUtils.DOMAIN_NAME}" + "${Utils.getToken()}" + "${ConfigUtils.parentId}" +
                "${DeviceInfo.getDeviceId()}"
    }


    companion object {
        private val UTF8 = Charset.forName("UTF-8")
        internal fun isPlaintext(buffer: Buffer): Boolean {
            try {
                val prefix = Buffer()
                val byteCount = if (buffer.size() < 64) buffer.size() else 64
                buffer.copyTo(prefix, 0, byteCount)
                for (i in 0..15) {
                    if (prefix.exhausted()) {
                        break
                    }
                    val codePoint = prefix.readUtf8CodePoint()
                    if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                        return false
                    }
                }
                return true
            } catch (e: EOFException) {
                return false // Truncated UTF-8 sequence.
            }

        }
    }

}
