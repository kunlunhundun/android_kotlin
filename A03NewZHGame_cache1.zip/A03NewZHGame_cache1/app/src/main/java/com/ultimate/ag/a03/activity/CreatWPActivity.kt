package com.ultimate.ag.a03.activity

import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.text.TextUtils
import android.view.View
import com.google.gson.Gson
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.response.CreatWPResponse
import com.ultimate.ag.a03.data.response.RechargePromoResponse
import com.ultimate.ag.a03.hybride.BrowserActivity
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.util.Utils
import kotlinx.android.synthetic.main.activity_proposal.*

class CreatWPActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proposal)
        init()
    }

    private fun init() {
        fl_wash_list.visibility = View.GONE
        val amount = intent.getStringExtra("money")
        val tag = intent.getIntExtra("tag", -1)
        if (tag == 0 && !TextUtils.isEmpty(amount)) {
            textView.text = "提现请求成功"
            textView4.text = "预计10分钟到账，成功后将会受到系统通知"
            val data = Gson().fromJson(amount, CreatWPResponse.Body::class.java)
            if (data.type==1){
                textView2.text = "提现金额 BTC ${data.amount!!}"
            }else{
                textView2.text = "提现金额 ${Utils.formatMoney(data.amount!!)}"
            }

        } else if (tag == 1 && !TextUtils.isEmpty(amount)) {
            textView.text = "已提交充值订单"
            textView4.text = "预计10分钟到账，成功后将会受到系统通知"
            textView2.text = "充值金额 ¥${Utils.formatMoney(amount)}"
            val rechargePromo =  AppInitManager.getAcache().getAsString("promo")
            if (!TextUtils.isEmpty(rechargePromo)){
                val promo = Gson().fromJson(rechargePromo,RechargePromoResponse::class.java)
                if (null!=promo?.body?.DEPOSIT_BANNER_2){
                    tv_promo.text = Html.fromHtml(promo.body.DEPOSIT_BANNER_2)
                    ll_promo.setOnClickListener {
                        val intent = Intent(this@CreatWPActivity, BrowserActivity::class.java)
                        intent.putExtra(BrowserActivity.PARAM_URL, "${ProjectUtils.mAssetsWebUrl}${promo?.body?.DEPOSIT_BANNER_2_LINK}")
                        intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
                        startActivity(intent)
                    }

                    ll_promo.visibility = View.VISIBLE
                }

            }
        }
        textView3.setOnClickListener({
            closeDisplay()
        })
    }


    override fun initListener() {

    }

    override fun initData() {
        textView5.setOnClickListener {
            val tag = intent.getIntExtra("tag", -1)
            var intent = Intent()
            intent.setClass(this@CreatWPActivity, TradingRecordActivity::class.java)
            if (tag == 1) {
                intent.putExtra("index", 1)
            } else if (tag == 0) {
                intent.putExtra("index", 2)
            }
            startActivity(intent)
            closeDisplay()

        }
    }

    private fun closeDisplay() {
       MyApplication.instance?.activityListManager?.killAllExclude(MainActivity::class.java)
        finish()
    }

    override fun onBackPressed() {
        closeDisplay()
    }
}