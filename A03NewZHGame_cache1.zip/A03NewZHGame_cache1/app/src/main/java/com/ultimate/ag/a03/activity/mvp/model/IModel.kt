package com.ultimate.ag.a03.activity.mvp.model

/**
 * Imodel 基类
 */
interface IModel


