package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.UsernameRegisterRequest
import com.ultimate.ag.a03.data.response.UserNameRegisterResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler

/**
 * 注册界面Model
 */
class RegisterModel : IModel {

    fun usernameRegister(request: UsernameRegisterRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<UserNameRegisterResponse>) {

        ApiClient.instance.service.usernameRegister(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<UserNameRegisterResponse>() {

                    override fun businessFail(data: UserNameRegisterResponse) {
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: UserNameRegisterResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}

