/*
 * Tencent is pleased to support the open source community by making VasSonic available.
 *
 * Copyright (C) 2017 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 *
 * https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 *
 *
 */

package com.ultimate.ag.a03.hybride

import android.annotation.TargetApi
import android.graphics.Bitmap
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.tencent.sonic.sdk.SonicEngine
import com.tencent.sonic.sdk.SonicSession
import com.tencent.sonic.sdk.SonicSessionConfig
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.MyApplication.Companion.gameResult
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.fragment.BaseFragment
import com.ultimate.ag.a03.util.CommonCallback
import com.ultimate.ag.a03.util.LogUtils
import kotlinx.android.synthetic.main.fragment_ag.*

/**
 * Sonic WebActivity
 * @author Ward.Y
 */

open class BrowserFragment : BaseFragment() {
    override fun getContentViewId(): Int {
        return R.layout.fragment_browser
    }

    override fun initListener() {

    }


    private var sonicSession: SonicSession? = null
    private var sonicSessionClient: SonicSessionClientImpl? = null
    var mUrl: String? = null
    private lateinit var rootView: View
    private var mCallback = BrowserCallback()

    companion object {
        const val PARAM_MODE_SONIC = 1
        const val PARAM_MODE_DEAFAULT = 0

    }


    override fun initData() {

    }

    open fun initClient(url: String) {
        initClient(url, PARAM_MODE_DEAFAULT)
    }


    open fun initClient(url: String, mode: Int) {
        checkActivityAttached()
        mUrl = url
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)

        if (mode == BrowserActivity.PARAM_MODE_SONIC) {
            sonicSessionClient = SonicSessionClientImpl()
            val sessionConfigBuilder = SonicSessionConfig.Builder()
            sessionConfigBuilder.setSupportLocalServer(true)
            sonicSession = SonicEngine.getInstance().createSession(url!!, sessionConfigBuilder.build())
            if (null != sonicSession) {
                sonicSession!!.bindClient(sonicSessionClient)
            } else {
                LogUtils.e("create sonic session fail!")
            }
        }

        initView()
    }

    override fun initView() {


        // init webview
        ag_web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                LogUtils.d("onPageStarted" + url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                LogUtils.d("onPageFinished" + url)
                if (sonicSession != null) {
                    sonicSession!!.sessionClient.pageFinish(url)
                }
            }

            @TargetApi(21)
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return shouldInterceptRequest(view, request.url.toString())
            }

            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
//                return if (sonicSession?.sessionClient?.requestResource(url) != null) {
//                    sonicSession?.sessionClient?.requestResource(url) as WebResourceResponse
//                } else null
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {

                return super.shouldOverrideUrlLoading(view, url)
            }
        }

        ag_web.removeJavascriptInterface("searchBoxJavaBridge_")
        ag_web.addJavascriptInterface(SonicJavaScriptInterface(sonicSessionClient, activity, mCallback), "discover")

        if (sonicSessionClient != null) {
            sonicSessionClient?.bindWebView(ag_web)
            sonicSessionClient?.clientReady()
        } else { // default mode
            ag_web.loadUrl(mUrl)
        }
    }


//    override fun onResume() {
//        super.onResume()
//        if (ag_web != null) {
//            Log.e("AGQJSTATUS", "onResume-555")
//            ag_web.onResume()
//        }
//
//    }

    override fun onStop() {
        super.onStop()
        if (ag_web != null) {
            if (gameResult == MyApplication.AGQJGameResult.TO_LOBBY_SUCCESS) {
                Log.e("AGQJSTATUS", "onPause-666")
                ag_web.onPause()
            }
        }

    }

    override fun onPause() {
        super.onPause()
        if (ag_web != null) {
            if(gameResult == MyApplication.AGQJGameResult.TO_LOBBY_SUCCESS){
                Log.e("AGQJSTATUS", "onPause-777")
                ag_web.onPause()
            }
        }

    }

    override fun onDestroy() {
        if (null != sonicSession) {
            sonicSession?.destroy()
            sonicSession = null
        }
        if (ag_web != null) {
            Log.e("AGQJSTATUS", "destroy-888")
            ag_web.destroy()
        }

        super.onDestroy()
    }

    inner class BrowserCallback : CommonCallback {

        override fun onCalled() {
        }
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        if (!isVisibleToUser) {
            if (null != ag_web && gameResult == MyApplication.AGQJGameResult.TO_LOBBY_SUCCESS) {
                Log.e("AGQJSTATUS", "onPause-999")
                ag_web.onPause()
            }

        } else {
            if (null != ag_web) {
                Log.e("AGQJSTATUS", "onResume-101010")
                ag_web.onResume()
            }
        }
    }
}
