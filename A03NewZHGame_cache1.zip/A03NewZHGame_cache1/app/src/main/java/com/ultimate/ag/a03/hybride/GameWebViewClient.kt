package com.ultimate.ag.a03.hybride

import android.annotation.TargetApi
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.text.TextUtils
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import com.ultimate.ag.a03.net.LoadingDialog
import com.ultimate.ag.a03.util.LogUtils

class GameWebViewClient(activity: Activity) : BaseWebViewClient(activity) {

    override fun onPageStarted(view: WebView?, url: String, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        //进游戏白屏时加载loading
        LogUtils.e("onPageStarted " + url)
        LoadingDialog.show(mActivity)
    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        LoadingDialog.cancel()

    }

    @TargetApi(21)
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        LogUtils.d("shouldInterceptRequest " + request.url.toString())
        return shouldInterceptRequest(view, request.url.toString())
    }

    override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
        return null
    }

    override fun shouldOverrideUrlLoading(webview: WebView?, url: String?): Boolean {
        if (!TextUtils.isEmpty(url)) {
            LogUtils.d("shouldOverrideUrlLoading " + url)
            when (url) {

            //竖屏
                "https://localhost/portrait.html" -> {
                    mActivity?.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                    return true
                }
            //横屏
                "https://localhost/landscape.html" -> {
                    mActivity?.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
                    return true
                }
            //传感器切换横竖屏
                "https://localhost/sensor.html" -> {
                    mActivity?.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR)
                    return true
                }
            //网络掉线
                "https://localhost/disconnect.html" -> {
                    return true
                }

            }

//            if (url!!.contains("logout")) {
//                mActivity.finish()
//            }
        }
        return super.shouldOverrideUrlLoading(webview, url)
    }

}