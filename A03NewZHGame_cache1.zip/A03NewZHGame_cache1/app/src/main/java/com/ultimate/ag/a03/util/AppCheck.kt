package com.ultimate.ag.a03.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.ultimate.ag.a03.MyApplication
import java.net.URLEncoder

/**
 * Author:Javan.W
 * Time:2018/11/1
 * Description:This is AppCheck
 */
object AppCheck {

    val isInstallqq: Boolean
        get() = checkAppInstall("com.tencent.mobileqq")

    val isInstallwx: Boolean
        get() = checkAppInstall("com.tencent.mm")

    val isInstallJD: Boolean
        get() = checkAppInstall("com.jingdong.app.mall")

    val isInstallalipay: Boolean
        get() {
            val uri = Uri.parse("alipays://platformapi/startApp")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            val componentName = intent.resolveActivity(MyApplication.instance?.getPackageManager())
            return componentName != null
        }

    val isInstallWeibo: Boolean
        get() = checkAppInstall("com.sina.weibo")

    /**
     * 判断APP是否安装
     *
     * @param packageName
     * @return
     */
    private fun checkAppInstall(packageName: String): Boolean {
        val packageManager = MyApplication.instance?.getPackageManager()
        val pinfo = packageManager?.getInstalledPackages(0)
        if (pinfo != null) {
            for (i in pinfo!!.indices) {
                val pn = pinfo!!.get(i).packageName
                if (pn == packageName) {
                    return true
                }
            }
        }
        return false
    }

    fun startWeixin(context: Context): Boolean {
        if (isInstallwx) {
            val intent = Intent(Intent.ACTION_MAIN)
            val cmp = ComponentName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI")
            intent.addCategory(Intent.CATEGORY_LAUNCHER)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.component = cmp
            context.startActivity(intent)
            return true
        }
        ToastUtils.show("打开失败，请检查你是否已安装该应用")
        return false
    }

    fun startAliPay(context: Context): Boolean {
        if (isInstallalipay) {
            val intent = Intent(Intent.ACTION_MAIN)
            val cmp = ComponentName("com.eg.android.AlipayGphone", "com.eg.android.AlipayGphone.AlipayLogin")
            intent.addCategory(Intent.CATEGORY_LAUNCHER)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.component = cmp
            context.startActivity(intent)
            return true
        }
        return false
    }

    fun startQqPay(context: Context): Boolean {
        if (isInstallqq) {
            val intent = Intent(Intent.ACTION_MAIN)
            val cmp = ComponentName("com.tencent.mobileqq", "com.tencent.mobileqq.activity.SplashActivity")
            intent.addCategory(Intent.CATEGORY_LAUNCHER)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.component = cmp
            context.startActivity(intent)
            return true
        }
        ToastUtils.show("打开失败，请检查你是否已安装该应用")
        return false
    }

    fun startWeibo(context: Context, content: String) : Boolean {
        if (isInstallWeibo) {
            var intent =  Intent()
            intent.setAction(Intent.ACTION_VIEW)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.setData(Uri.parse("sinaweibo://sendweibo?content=" + URLEncoder.encode(content)))
            context.startActivity(intent)
            return true
        }
        ToastUtils.show("打开失败，请检查你是否已安装该应用")
        return false
    }

}
