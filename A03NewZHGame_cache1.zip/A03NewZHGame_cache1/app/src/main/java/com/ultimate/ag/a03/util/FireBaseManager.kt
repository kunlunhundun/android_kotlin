package com.ultimate.ag.a03.util

import android.os.Bundle

import com.google.firebase.analytics.FirebaseAnalytics
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.database.DataBaseHelper

class FireBaseManager {

    private var mFirebaseAnalytics: FirebaseAnalytics? = null

    var mLastPageName: String? = null


    companion object {


        val instance: FireBaseManager by lazy { FireBaseManager() }

        val PAGE_EVENT = "page"   //页面进入和离开

        val BTN_CLICK_EVENT = "btnClick" //按钮点击

        val VIEW_SWIFT_EVENT = "viewSwift"//页面滑动

        val APP_START_EVENT = "appstart"//页面滑动

        val EVENT_TYPE = "event_type"//事件类型：1.页面进入和离开 2.按钮点击 3.页面滑动

        val ACTION = "action"//in（进入页面）  out（离开页面）

        val PAGE_NAME = "page_name"//进入或离开的页面名称

        val LASTPAGE = "lastPage"//进入页面时，上一个页面的名称

        val BTN_NAME = "btn_name"//按钮名称

        val TIME = "time"//手机本地时间 yyyy-MM-dd HH:mm:ss:SSSS

        val USER_NAME = "user_name"//用户名

        val DEVICE = "device"//手机设备类型 如 iPhone8plus

        val DEVICE_ID = "device_id"//手机设备类型 如 iPhone8plus

        val SYSTEM_VERSION = "system_version"//手机系统版本 如 iOS11.0

        val APP_VERSION = "app_version"//app版本号 如1.0

        val NET_WORK = "net_work"//网络状态 ，供参考  获取不到可以为空

        val EXTRA = "extra" //额外信息，默认尽可能用其他字段满足需求，留给后续版本更新兼容

        val PAGE_IN = "in"

        val PAGE_OUT = "out"

    }

    private constructor() {
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(MyApplication.getinstance().applicationContext)
    }


    fun logPageEvent(pageName: String, action: String) {
        logPageEvent(pageName, action, null)
    }

    fun logPageEvent(pageName: String, action: String, extra: Bundle?) {
        val bundle = Bundle()
        bundle.putString(EVENT_TYPE, PAGE_EVENT)
        bundle.putString(ACTION, action)
        bundle.putString(PAGE_NAME, pageName)
        bundle.putString(LASTPAGE, mLastPageName)
        bundle.putString(TIME, Utils.getCurentTime("yyyy-MM-dd HH:mm:ss:SSSS"))
        bundle.putString(USER_NAME, ConfigUtils.loginName)
        bundle.putString(DEVICE, "${DeviceInfo.getPhoneModel()}")
        bundle.putString(DEVICE_ID, DeviceInfo.getDeviceId())
        bundle.putString(SYSTEM_VERSION, DeviceInfo.getSDKVersion())
        bundle.putString(APP_VERSION, Utils.getVersion())
        bundle.putBundle(EXTRA, extra)
        mFirebaseAnalytics?.logEvent(pageName, bundle)
        //记录下当前页面名称，供下个页面进入事件使用
        mLastPageName = pageName
    }

    fun logBtnCLickEvent(btnName: String) {
        logBtnCLickEvent(btnName, null)
    }

    fun logBtnCLickEvent(btnName: String, extra: Bundle?) {
        val bundle = Bundle()
        bundle.putString(EVENT_TYPE, BTN_CLICK_EVENT)
        bundle.putString(BTN_NAME, btnName)
        bundle.putString(TIME, Utils.getCurentTime("yyyy-MM-dd HH:mm:ss:SSSS"))
        bundle.putString(USER_NAME, ConfigUtils.loginName)
        bundle.putString(DEVICE, "android_${DeviceInfo.getPhoneModel()}")
        bundle.putString(DEVICE_ID, DeviceInfo.getDeviceId())
        bundle.putString(SYSTEM_VERSION, DeviceInfo.getSDKVersion())
        bundle.putString(APP_VERSION, Utils.getVersion())
        bundle.putBundle(EXTRA, extra)
        mFirebaseAnalytics?.logEvent(btnName, bundle)
    }

    fun logViewSwiftEvent(viewName: String) {
        logViewSwiftEvent(viewName, null)
    }

    fun logViewSwiftEvent(viewName: String, extra: Bundle?) {
        val bundle = Bundle()
        bundle.putString(EVENT_TYPE, VIEW_SWIFT_EVENT)
        bundle.putString(TIME, Utils.getCurentTime("yyyy-MM-dd HH:mm:ss:SSSS"))
        bundle.putString(USER_NAME, ConfigUtils.loginName)
        bundle.putString(DEVICE, "android_${DeviceInfo.getPhoneModel()}")
        bundle.putString(DEVICE_ID, DeviceInfo.getDeviceId())
        bundle.putString(SYSTEM_VERSION, DeviceInfo.getSDKVersion())
        bundle.putString(APP_VERSION, Utils.getVersion())
        bundle.putString(PAGE_NAME, viewName)
        bundle.putBundle(EXTRA, extra)
        mFirebaseAnalytics?.logEvent(viewName, bundle)
    }

    fun logAppStartEvent() {
        logAppStartEvent(null)
    }

    fun logAppStartEvent(extra: Bundle?) {
        val bundle = Bundle()
        bundle.putString(EVENT_TYPE, APP_START_EVENT)
        bundle.putString(TIME, Utils.getCurentTime("yyyy-MM-dd HH:mm:ss:SSSS"))
        bundle.putString(USER_NAME, ConfigUtils.loginName)
        bundle.putString(DEVICE, "android_${DeviceInfo.getPhoneModel()}")
        bundle.putString(DEVICE_ID, DeviceInfo.getDeviceId())
        bundle.putString(SYSTEM_VERSION, DeviceInfo.getSDKVersion())
        bundle.putString(APP_VERSION, Utils.getVersion())
        bundle.putBundle(EXTRA, null)
        mFirebaseAnalytics?.logEvent(APP_START_EVENT, bundle)
    }

    /**
     * 检测是否第一次安装app
     * 第一次安装app出发google分析firstOpen事件
     */
    fun coverAppInstall() {

        val appInstall = DataBaseHelper.getAppInstall()
        if ("already" != appInstall?.state) {

            DataBaseHelper.updateAppInstall("already")
            val deviceId = Utils.getIMEI()
            val packageCode = ConfigUtils.parentId
            val params = Bundle()
            params.putString("packageCode", packageCode)
            params.putString("deviceId", deviceId)
            mFirebaseAnalytics?.logEvent("firstOpen", params)
        }
    }

}
