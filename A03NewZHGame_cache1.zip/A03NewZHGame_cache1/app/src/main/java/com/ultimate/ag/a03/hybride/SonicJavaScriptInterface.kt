/*
 * Tencent is pleased to support the open source community by making VasSonic available.
 *
 * Copyright (C) 2017 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 *
 * https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 *
 *
 */

package com.ultimate.ag.a03.hybride


import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import android.webkit.JavascriptInterface
import com.google.gson.Gson
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.activity.*
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.request.H5Request
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.LoadingDialog
import com.ultimate.ag.a03.util.*
import com.ultimate.ag.a03.view.CommonDialog
import com.ultimate.ag.a03.view.ShareToFriendsDialog
import common.util.sign.SignUtils
import org.json.JSONObject

/**
 * Sonic javaScript Interface (Android API Level >= 17)
 */

class SonicJavaScriptInterface(private val sessionClient: SonicSessionClientImpl?, private val
activity: Activity?, private val callback: CommonCallback) {


    //Webview传递参数标签
    val RECHARGE = 1
    val PLAYGAME = 2
    val MESSAGE = 3
    val REBATE = 4
    val REGISTER = 5
    val KEFU = 6
    val CLOSE = 7
    val CARDBIND = 8 //绑卡
    val FUNDPWD = 9
    val PHONEBIND = 10  //绑定手机号
    val WITHDRAW = 11 //提现
    val TRANSCATION = 12 //交易记录
    val WEBVIEW_CLOSE = 21
    val SHOWLOADING = 15
    val HIDELOADING = 16
    val PROFILEDETAIL = 18
    val WEBVIEWCLOSE = 21 //关闭webview
    val WEBVIEW = 20  //打开新的页面
    val POINTEXCHANGE = 25  //积分兑换
    val PHONECALL = 26  //拨打电话
    val AGGAME = 30  //跳转AG旗舰
    var SHARE_MYINCOME = 40 //分享-我的收入
    var SHARE_INVITE = 41 //分享-立即邀请

    @JavascriptInterface
    fun getDiffData() {
        // the callback function of demo page is hardcode as 'getDiffDataCallback'
        getDiffData2("getDiffDataCallback")
    }

    @JavascriptInterface
    fun getDiffData2(jsCallbackFunc: String) {
        sessionClient?.getDiffData { resultData ->
            val callbackRunnable = Runnable {
                val jsCode = "javascript:" + jsCallbackFunc + "('" + toJsString(resultData) + "')"
                sessionClient.webView.loadUrl(jsCode)
            }
            if (Looper.getMainLooper() == Looper.myLooper()) {
                callbackRunnable.run()
            } else {
                Handler(Looper.getMainLooper()).post(callbackRunnable)
            }
        }
    }


    private fun toJsString(value: String?): String {
        if (value == null) {
            return "null"
        }
        val out = StringBuilder(1024)
        var i = 0
        val length = value.length
        while (i < length) {
            val c = value[i]


            when (c) {
                '"', '\\', '/' -> out.append('\\').append(c)

                '\t' -> out.append("\\t")

                '\b' -> out.append("\\b")

                '\n' -> out.append("\\n")

                '\r' -> out.append("\\r")

                '\u000C' -> out.append("\\f")

                else -> if (c.toInt() <= 0x1F) {
                    out.append(String.format("\\u%04x", c.toInt()))
                } else {
                    out.append(c)
                }
            }
            i++
        }
        return out.toString()
    }

    @JavascriptInterface
    fun firebaseAnalytics(tag_id: String) {
        FireBaseManager.instance.logBtnCLickEvent(tag_id)
    }

    /**
     * js调用方法
     */
    @JavascriptInterface
    fun jumpPage(tag: Int, url: String) {

        if (TextUtils.isEmpty(ConfigUtils.token) || ConfigUtils.currentUserType == ConfigUtils.USER_TYPE_TRY) {
            when (tag) {
                REGISTER -> {
                }
                CLOSE -> {
                }
                WEBVIEW -> {
                }
                WEBVIEW_CLOSE -> {
                }
                KEFU -> {
                }
                MESSAGE -> {
                }
                SHOWLOADING -> {
                }
                HIDELOADING -> {
                }
                else -> {
                    createAdDialog(CommonDialog.TYPE_LOGIN)
                    return
                }
            }

        }

        when (tag) {

            WEBVIEWCLOSE ->
                //关闭webview
                callback.onCalled()
            WEBVIEW -> {
                //跳转webview
                val intent = Intent()
                intent.setClass(activity, BrowserActivity::class.java)
                val pageUrl = if (url.startsWith("http://") || url.startsWith("https://")) {
                    url
                } else {
                    "${ProjectUtils.mAssetsWebUrl}$url"
                }

                intent.putExtra(BrowserActivity.PARAM_URL, pageUrl)
                activity?.startActivity(intent)
            }
            POINTEXCHANGE -> {
                //跳转积分兑换界面
                activity?.startActivity(Intent(activity, PointExchangeActivity::class.java))

            }
            PHONECALL -> {
                //打电话弹窗
                var intent = Intent(Intent.ACTION_DIAL)
                var data = Uri.parse("tel:$url")
                intent.data = data
                activity?.startActivity(intent)
            }
        }
        if (tag == SHARE_INVITE && activity is AppCompatActivity) {
            ShareToFriendsDialog().show((activity as AppCompatActivity).supportFragmentManager, "")
            return
        }
        val intent = Intent()
        when (tag) {
            PLAYGAME -> {
                MainActivity.changeTag = "game"
                AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)
            }

            AGGAME -> {
                MainActivity.changeTag = "ag"
                AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)

            }
            RECHARGE -> {
                intent.setClass(activity, RechargeActivity::class.java)

            }
            MESSAGE -> {
                intent.setClass(activity, MessageCenterActivity::class.java)
            }
            REBATE -> {
                intent.setClass(activity, WashingCodeActivity::class.java)
            }
            REGISTER -> {
                intent.setClass(activity, RegisterActivity::class.java)
            }
            CLOSE -> {
                callback.onCalled()
                return
            }
            WEBVIEW -> {
                intent.setClass(activity, BrowserActivity::class.java)
                intent.putExtra("url", url)
            }
            WEBVIEW_CLOSE -> {
                callback.onCalled()
                return
            }
            KEFU -> {

                Utils.goOnlineCustomerService(activity as BrowserActivity)
                return
            }

            CARDBIND -> {
                when {
                    !ConfigUtils.isBindMobile -> {
                        intent.setClass(activity, BindMobilePhoneGuideActivity::class.java)
                    }
                    (TextUtils.isEmpty(ConfigUtils.realName)) -> intent.setClass(activity, CompleteProfileActivity::class.java)
                    else -> intent.setClass(activity, AddBankCardActivity::class.java)
                }
                intent.putExtra("addCard", true)
            }

            PHONEBIND -> {
                intent.setClass(activity, BindMobilePhoneGuideActivity::class.java)
            }

            WITHDRAW -> {
                when {
                    !ConfigUtils.isBindMobile -> {
                        intent.setClass(activity, BindMobilePhoneGuideActivity::class.java)
                    }
                    (TextUtils.isEmpty(ConfigUtils.realName)) -> intent.setClass(activity, CompleteProfileActivity::class.java)
                    else -> intent.setClass(activity, WithdrawDepositActivity::class.java)
                }
                intent.putExtra("addCard", true)
            }


            TRANSCATION -> {
                intent.setClass(activity, TradingRecordActivity::class.java)
                if (!TextUtils.isEmpty(url)) {
                    intent.putExtra("index", url.toInt() + 1)
                }
            }

            SHOWLOADING -> {
                LoadingDialog.show(activity as BrowserActivity)
            }
            HIDELOADING -> {
                LoadingDialog.cancel()
            }

            PROFILEDETAIL -> {
                intent.setClass(activity, ProfileDetailActivity::class.java)
            }
            SHARE_MYINCOME -> {
                intent.setClass(activity, MyIncomeActivity::class.java)
            }
        }
        (activity as BaseActivity).goToPage(intent)
    }


    @JavascriptInterface
    fun getAuthToken(): String {
        LogUtils.d("getAuthToken")
        val qid = Utils.getUUID()
        val request = H5Request()
        request.qid = qid
        request.sign = Utils.getH5Sign(qid)
        return Gson().toJson(request)
    }

    @JavascriptInterface
    fun getDynamicAuthToken(requesBody: String): String {
        val qid = Utils.getUUID()
        val request = H5Request()
        var bodyJson = JSONObject(requesBody)
//        if (bodyJson.has("mobileNo")) {
//            //手机号去除反斜杠
//            var mobileNo = bodyJson.getString("mobileNo")
//            bodyJson.put("mobileNo", mobileNo.replace("\\\\".toRegex(), ""))
//        }
        bodyJson.put("productId", ProjectUtils.PID)
        bodyJson.put("loginName", ConfigUtils.loginName)
        var srcStr = bodyJson.toString().replace("\\", "") + "${qid}" +
                "${ProjectUtils.APPID}" + "${ProjectUtils.GATEWAY_VERSION}" + "${ConfigUtils.DOMAIN_NAME}" +
                "${Utils.getToken()}" + "${ConfigUtils.parentId}" + "${DeviceInfo.getDeviceId()}"
        var sign = SignUtils.getSign(srcStr, qid, Utils.getSignKey())
        request.sign = sign
        request.qid = qid
        LogUtils.d("getDynamicAuthToken:srcStr=" + srcStr)
        LogUtils.d(" token=" + Gson().toJson(request))
        return Gson().toJson(request)
    }

    private fun createAdDialog(type: Int) {
        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, type)
        val dialog = CommonDialog()
        dialog?.arguments = bundle
        dialog?.show((activity as BrowserActivity).supportFragmentManager, "ad")
    }
}
