package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.MyPromoRequest
import com.ultimate.ag.a03.data.response.MyPromoResponse
import com.ultimate.ag.a03.net.*

class MyPromoModel : IModel {

    /**
     * 请求我的红利
     */
    fun getMyPromo(requst: MyPromoRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<MyPromoResponse>) {
        ApiClient.instance.frontService.getMyPromo(requst)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<MyPromoResponse>() {
                    override fun businessFail(data: MyPromoResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: MyPromoResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}