package com.ultimate.ag.a03.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.animation.AnimationUtils
import com.androidkun.xtablayout.XTabLayout
import com.ivi.skynet.statistics.StatisticsManager
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.activity.mvp.BaseMvpActivity
import com.ultimate.ag.a03.activity.mvp.model.RegisterModel
import com.ultimate.ag.a03.activity.mvp.presenter.BasePresenter
import com.ultimate.ag.a03.activity.mvp.presenter.RegisterPresenter
import com.ultimate.ag.a03.activity.mvp.view.RegisterView
import com.ultimate.ag.a03.adapter.RegisterFragmentViewPagerAdapter
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.fragment.LazyLoadFragment
import com.ultimate.ag.a03.fragment.PhoneRegisterFragment
import com.ultimate.ag.a03.fragment.UsernameRegisterFragment
import com.ultimate.ag.a03.util.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.fragment_register_phone.*
import kotlinx.android.synthetic.main.fragment_register_username.*
import kotlinx.android.synthetic.main.tool_bar_view2.*

class RegisterActivity : BaseToolBarActivity() {

    val mPhoneRegisterFragment = PhoneRegisterFragment()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StatusBarUtil.StatusBarLightMode(this)
        setContentView(R.layout.activity_register)
        initFragment()
        AndroidWorkaround.assistActivity(findViewById(android.R.id.content))
    }


    override fun getLayoutId(): Int {
        return R.layout.activity_register
    }

    override fun initData() {

    }

    override fun initListener() {

        toolbar_title.setText(R.string.title_register)
        toolbar_icon.setOnClickListener({ finish() })

        activity_register_tv_submit.setOnClickListener {

         //   StatisticsManager.getRegProcedureControl().proceturePoint("phonesignin_nextbutton","访问","其他","其他指标","访问", emptyMap())

            //限制频繁点击
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            mPhoneRegisterFragment.mobileRegister()

        }

    }

     /**
      * 初始化fragment
      */

    fun initFragment(){

         val fragmentTransaction = supportFragmentManager.beginTransaction()
         fragmentTransaction.add(R.id.fl_container, mPhoneRegisterFragment)
         fragmentTransaction.commitAllowingStateLoss()

     }

     /**
      * 设置下一步按钮可点击
      */
     fun setClickable() {
         activity_register_tv_submit.setTextColor(resources.getColor(R.color.them_text_color))
         activity_register_tv_submit.setBackgroundResource(R.drawable.bg_button_next_bottom)
         activity_register_tv_submit.isClickable = true
     }

     /**
      * 设置下一步按钮不可点击
      */
     fun setUnclickable() {
         activity_register_tv_submit.setTextColor(resources.getColor(R.color.bg_hint))
         activity_register_tv_submit.setBackgroundResource(R.drawable.bg_button_next_bottom_disable)
         activity_register_tv_submit.isClickable = false
     }

     fun goSuccess(phoneNum:String) {

         KeyBoardUtils.closeKeybord(this)
         val animation = AnimationUtils.loadAnimation(this@RegisterActivity, R.anim.popupwindow_show_anim)
         tv_success_tip.startAnimation(animation)
         tv_success_tip.visibility = View.VISIBLE
         val handler = Handler()
         val runnable = Runnable {
             val intent = Intent()
             if (phoneNum.length > 1) {
                 intent.putExtra(IntentConstant.REGISTER_ACCOUNT, ConfigUtils.loginName)
                 intent.putExtra(IntentConstant.REGISTER_PHONENUM, phoneNum)
             }else{
                 intent.putExtra(IntentConstant.REGISTER_ACCOUNT, ConfigUtils.loginName)
             }
             intent.setClass(this@RegisterActivity, MainActivity::class.java)
             intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
             intent.putExtra("usertype", ConfigUtils.USER_TYPE_NEW)
             goToPage(intent)
             finish()
         }
         handler.postDelayed(runnable, 2000)
    }


}
