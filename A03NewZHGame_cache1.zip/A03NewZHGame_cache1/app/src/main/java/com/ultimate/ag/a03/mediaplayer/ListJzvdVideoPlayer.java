package com.ultimate.ag.a03.mediaplayer;

import android.content.Context;
import android.util.AttributeSet;

import cn.jzvd.JzvdStd;

public class ListJzvdVideoPlayer extends JzvdStd {
    public ListJzvdVideoPlayer(Context context) {
        super(context);
    }

    public ListJzvdVideoPlayer(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    @Override
    public void startWindowTiny() {

    }
}
