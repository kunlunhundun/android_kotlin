package com.ultimate.ag.a03.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.content.LocalBroadcastManager
import android.text.TextUtils
import android.util.Log

import com.mylhyl.acp.Acp
import com.mylhyl.acp.AcpListener
import com.mylhyl.acp.AcpOptions
import com.ultimate.ag.a03.MyApplication

import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * @author Javan.W
 * @date 2019/3/11
 * @Description
 */
object ImageUtil {

    fun snapShotScreen(activity: Activity) : String {
        var bitmap:Bitmap? = snapShotWithStatusBar(activity) ?: return ""
        return saveImageToGallery(activity, bitmap!!, false)
    }

    private fun snapShotWithStatusBar(activity: Activity): Bitmap? {
        var bitMap: Bitmap? = null
        try {
            val decorView = activity.window.decorView
            decorView.isDrawingCacheEnabled = true
            decorView.buildDrawingCache()
            val bmp = decorView.drawingCache
            val width = activity?.windowManager.defaultDisplay.width
            val height = activity?.windowManager.defaultDisplay.height
            bitMap = Bitmap.createBitmap(bmp, 0, 0, width, height)
            decorView.destroyDrawingCache()
        } catch (var6: Throwable) {
            var6.printStackTrace()
        }
        return bitMap
    }

    //保存文件到指定路径
    fun saveImageToGallery(context: Context, bmp: Bitmap, cover: Boolean): String {
        val sb = StringBuilder()
        //首先请求权限
        Acp.getInstance(context).request(AcpOptions.Builder().setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE).setDeniedMessage("当前应用缺少拨打内存卡使用权限，不能屏幕截图。\n\n请点击\"设置\"-\"权限\"-打开所需权限。\n\n最后点击两次后退按钮，即可返回。").setRationalMessage("保存屏幕截图需要获取内存卡的使用权限，请允许！").build(), object : AcpListener {
            override fun onGranted() {
                val path = saveImage(bmp, cover)
                if (!TextUtils.isEmpty(path)) {
                    sb.append(path)
                }
            }

            override fun onDenied(permissions: List<String>) {
                //ToastUtils.toastError("权限被拒绝");
            }
        })
        return sb.toString()
    }

    //保存文件到指定路径
    fun saveImage(bmp: Bitmap, cover: Boolean): String? {
        // 首先保存图片
        val storePath = Environment.getExternalStorageDirectory().absolutePath + File.separator + "huanya"
        val appDir = File(storePath)
        if (!appDir.exists()) {
            val mkdir = appDir.mkdir()
            Log.e("mkdir", mkdir.toString() + "")
        }
        val fileName: String
        if (cover) {
            fileName = "screen" + ".jpg"
        } else {
            fileName = System.currentTimeMillis().toString() + ".jpg"
        }

        val file = File(appDir, fileName)
        try {
            val fos = FileOutputStream(file)
            //通过io流的方式来压缩保存图片
            val isSuccess = bmp.compress(Bitmap.CompressFormat.JPEG, 80, fos)
            fos.flush()
            fos.close()

            //把文件插入到系统图库
            MediaStore.Images.Media.insertImage(MyApplication.instance?.getContentResolver(), file.getAbsolutePath(), fileName, null);

            //保存图片后发送广播通知更新数据库
            var uri:Uri = Uri.fromFile(file)
            LocalBroadcastManager.getInstance(MyApplication.instance!!.baseContext).sendBroadcast(Intent (Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
            if (isSuccess) {
                return file.getAbsolutePath();
            } else {
                return null
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return null
    }
}
