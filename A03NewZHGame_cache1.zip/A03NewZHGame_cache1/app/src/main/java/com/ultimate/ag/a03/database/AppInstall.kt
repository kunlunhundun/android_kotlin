package com.ultimate.ag.a03.database

import org.litepal.crud.DataSupport

/**
 * Created by ethan on 2018/7/25.
 */

class AppInstall : DataSupport() {
    var state: String? = null
}