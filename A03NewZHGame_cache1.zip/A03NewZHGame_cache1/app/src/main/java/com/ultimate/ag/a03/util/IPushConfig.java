package com.ultimate.ag.a03.util;

import android.text.TextUtils;

import com.rea.push.config.PushConfig;

import com.ultimate.ag.a03.BuildConfig;
import com.ultimate.ag.a03.R;
import com.ultimate.ag.a03.config.ConfigUtils;
import com.ultimate.ag.a03.config.ProjectUtils;

import static com.rea.push.utils.Cons.NOTIFY;
import static com.ultimate.ag.a03.config.ConfigUtils.MODEL_NATIVAL_TEST;
import static com.ultimate.ag.a03.config.ConfigUtils.MODEL_RUNTIME;
import static com.ultimate.ag.a03.config.ConfigUtils.MODEL_RUNTIME_TEST;


/**
 * author: Rea.X
 * date: 2017/4/11.
 */

public class IPushConfig extends PushConfig {
    private static final String RUNTIME_TEST_IP = "115.84.241.212";
    private static final int RUNTIME_TEST_PORT = 8090;
    private static final String RUNTIME_IP = "202.83.195.101";
    private static final int RUNTIME_PORT = 28721;

    @Override
    public String getIP() {
        switch (ConfigUtils.MODEL) {
            case MODEL_RUNTIME:
                return RUNTIME_IP;
            case MODEL_RUNTIME_TEST:
                return RUNTIME_TEST_IP;
            case MODEL_NATIVAL_TEST:
                return "10.71.12.107";
        }
        return RUNTIME_IP;
    }

    @Override
    public int getPort() {
        switch (ConfigUtils.MODEL) {
            case MODEL_RUNTIME:
                return RUNTIME_PORT;
            case MODEL_RUNTIME_TEST:
                return RUNTIME_TEST_PORT;
            case MODEL_NATIVAL_TEST:
                return RUNTIME_TEST_PORT;
        }
        return RUNTIME_PORT;
    }

    @Override
    public long getHeartBeatTime() {
        switch (ConfigUtils.MODEL) {
            case MODEL_RUNTIME:
                return 30 * 1000;
            case MODEL_RUNTIME_TEST:
                return 10 * 1000;
            case MODEL_NATIVAL_TEST:
                return 10 * 1000;
        }
        return 30 * 1000;
    }

    @Override
    public String getCustomerId() {
        if ( TextUtils.isEmpty(ConfigUtils.INSTANCE.getCustomerId())) return null;
        return ConfigUtils.INSTANCE.getCustomerId();
    }

    @Override
    public String getProgectId() {
        return ProjectUtils.PUSH_CODE;
    }

    @Override
    public int configPushModel() {
        return NOTIFY;
    }

    @Override
    public int getAppIcon() {
        return R.mipmap.ic_launcher;
    }

    @Override
    public boolean openPush() {
        return true;
    }

    @Override
    public boolean showLog() {
        return BuildConfig.DEBUG;
    }
}
