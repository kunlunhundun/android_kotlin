package com.ultimate.ag.a03.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.util.StatusBarUtil
import kotlinx.android.synthetic.main.activity_guide_make_money.*

class GuideMakeMoneyActivity : BaseToolBarActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        StatusBarUtil.StatusBarLightMode(this)
        setTile("选择环亚立即赚钱")
        setBackground(R.color.white)
        isShowBack(true)
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_guide_make_money
    }

    override fun initData() {

    }

    override fun initListener() {

        btn_submit.setOnClickListener {

        }

    }


}
