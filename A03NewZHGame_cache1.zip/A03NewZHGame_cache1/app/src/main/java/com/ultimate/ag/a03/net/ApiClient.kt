package com.ultimate.ag.a03.net

import android.text.TextUtils
import android.util.Log
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.database.DataBaseHelper
import com.ultimate.ag.a03.util.SSLSocketFactoryUtil
import com.ultimate.ag.a03.util.SignInterceptor
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit
import android.R.id.message
import com.networkbench.agent.impl.instrumentation.okhttp2.NBSOkHttp2Instrumentation.body
import okhttp3.*
import okio.BufferedSink
import okio.Utf8
import org.litepal.crud.DataSupport.isExist
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.charset.Charset


class ApiClient private constructor() {

    private val TAG = "ApiClient"
    //短缓存有效期为10分钟
    private val CACHE_STALE_SHORT = 60 * 3
    //长缓存有效期为7天
    private val CACHE_STALE_LONG = 60 * 60 * 24 * 7

    var baseUrl = ConfigUtils.runGateUrl
    var frontUrl = ConfigUtils.frontUrl
    private var addUrl = ConfigUtils.addUrl
    lateinit var service: ApiService
    lateinit var frontService: ApiService
    lateinit var dataService: ApiService
    lateinit var addurlService: ApiService
    lateinit var sdkService: ApiService
    lateinit var h5Service:ApiService

    private object Holder {
        val INSTANCE = ApiClient()
    }

    companion object {
        val instance by lazy { Holder.INSTANCE }
    }


    fun init() {
        val urlData = DataBaseHelper.getUrl()
        if (!TextUtils.isEmpty(urlData?.url)) {
            baseUrl = "${urlData?.url!!}/"
        } else {
            urlData?.url = baseUrl
            urlData?.saveOrUpdate("urlId = ?", "1")
            baseUrl = "$baseUrl/"
        }

        if (!TextUtils.isEmpty(urlData?.frontUrl)) {
            frontUrl = "${urlData?.frontUrl!!}/"
        } else {
            urlData?.frontUrl = frontUrl
            urlData?.saveOrUpdate("urlId = ?", "1")
            frontUrl = "$frontUrl/"
        }

        if (!TextUtils.isEmpty(urlData?.addUrl)) {
            addUrl = "${urlData?.addUrl!!}/"
        } else {
            urlData?.addUrl = addUrl
            urlData?.saveOrUpdate("urlId = ?", "1")
            addUrl = "$addUrl/"
        }


        var simulateResponseInterceptor = SimulateResponseInterceptor()
        NetApiInterceptorList.init()

        val cache = Cache(File(MyApplication.getinstance().externalCacheDir, "File_AGQJ"), 10 * 1024 * 1024)
        val mOkHttpClient = OkHttpClient.Builder()
                .cache(cache)
                .retryOnConnectionFailure(false)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .addNetworkInterceptor(HttpLoggingInterceptor().setLevel(
//                        if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
//                        else HttpLoggingInterceptor.Level.NONE
                                HttpLoggingInterceptor.Level.BODY
                ))
                .sslSocketFactory(SSLSocketFactoryUtil.createSSLSocketFactory())
                .addNetworkInterceptor(rewriteCacheControlInterceptor)
                .addInterceptor(baseInterceptor)
                .addInterceptor(simulateResponseInterceptor)
                .addInterceptor(SignInterceptor())
                .build()


        val retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()

        service = retrofit.create(ApiService::class.java)


        //新特性网关
        val frontRetrofit = Retrofit.Builder()
                .baseUrl(frontUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()
        frontService = frontRetrofit.create(ApiService::class.java)

        val baseDataUrl = ConfigUtils.baseDataUrl

        val dataRetrofit = Retrofit.Builder()
                .baseUrl(baseDataUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()
        dataService = dataRetrofit.create(ApiService::class.java)

        val addRetrofit = Retrofit.Builder()
                .baseUrl(addUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()
        addurlService = addRetrofit.create(ApiService::class.java)


        val mOkHttpClientH5 = OkHttpClient.Builder()
                .cache(cache)
                .retryOnConnectionFailure(false)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .addNetworkInterceptor(HttpLoggingInterceptor().setLevel(
                        HttpLoggingInterceptor.Level.BODY
                ))
                .sslSocketFactory(SSLSocketFactoryUtil.createSSLSocketFactory())
                .addNetworkInterceptor(rewriteCacheControlInterceptor)
                .addInterceptor(baseInterceptor)
                .addInterceptor(SignInterceptor(true))
                .build()

        val retrofitH5 = Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClientH5)
                .build()
        h5Service = retrofitH5.create(ApiService::class.java)


    }


    /**
     * 获取缓存
     */
    private var baseInterceptor: Interceptor = Interceptor { chain ->
        var request = chain.request()
        if (!NetWorkUtil.isNetWorkConnected()) {
            /**
             * 离线缓存控制  总的缓存时间=在线缓存时间+设置离线缓存时间
             */

            val tempCacheControl = CacheControl.Builder()
                    .onlyIfCached()
                    .maxStale(CACHE_STALE_LONG, TimeUnit.SECONDS)
                    .build()
            request = request.newBuilder()
                    .cacheControl(tempCacheControl)
                    .build()
            Log.i(TAG, "intercept:no network ")
        }
        chain.proceed(request)
    }

    private var rewriteCacheControlInterceptor: Interceptor = Interceptor { chain ->
        val request = chain.request()
        val originalResponse = chain.proceed(request)

        originalResponse.newBuilder()
                .removeHeader("Pragma")// 清除头信息，因为服务器如果不支持，会返回一些干扰信息，不清除下面无法生效
                .removeHeader("Cache-Control")
                .header("Cache-Control", "public, max-age=$CACHE_STALE_SHORT")
                .build()
    }


    //模拟响应拦截器
    private inner class SimulateResponseInterceptor : Interceptor {

        override fun intercept(chain: Interceptor.Chain): Response {
            val request = chain.request()
            var url = request.url()
            var parameter:RequestBody? =  request.body()

            val buffer:okio.Buffer = okio.Buffer()
            parameter?.writeTo(buffer)
            var charset:Charset? = Charsets.UTF_8

            var contentType = parameter?.contentType()
            if (contentType != null) {
                var tempCharset = Charset.forName("UTF-8")
                charset = contentType?.charset(tempCharset)
            }
            var parameterStr = buffer.readString(charset)

            val apiName = NetApiInterceptorList.isExist(url.toString(),parameterStr)
            if (apiName != null) {
                val responseContent = NetApiInterceptorList.getVisualResponseByApi(apiName) ?: ""
                return  Response.Builder().code(200)
                        .message("成功")
                        .body(ResponseBody.create(MediaType.parse("UTF-8"),responseContent))
                        .protocol(Protocol.HTTP_1_0)
                        .request(request)
                        .build()
            }
            else{
                return  Response.Builder().code(400)
                        .message("失败")
                        .body(ResponseBody.create(MediaType.parse("UTF-8"),""))
                        .request(request)
                        .protocol(Protocol.HTTP_1_0)
                        .build()
            }
            return chain.proceed(request)
        }

    }

    object  NetApiInterceptorList {

        var apiResponseMap:HashMap<String,String> = HashMap()
        var keyParameterS:MutableList<String> = mutableListOf()

        @JvmStatic
        fun isExist(apiName:String,parameter:String?) : String? {

            var keyName = apiName
            if ( apiName.contains(SIMULATEAPI_QUERYBYKEYLIST) || apiName.contains(SIMULATEAPI_QUERYIMAGELIST) ){
                keyParameterS.forEach {
                   if (parameter?.contains(it) == true) {
                       keyName = it
                   }
                }
            }

            apiResponseMap.forEach {
                if (keyName.contains(it.key)) {
                    return it.key
                }
            }
            return null
        }

        @JvmStatic
        fun getVisualResponseByApi(apiName:String):String? {


            return apiResponseMap.get(apiName)
        }
        fun init(){

            keyParameterS.add(SIMULATEAPI_GAMEPLATFORMS_QUERYBYKEYLIST)
            keyParameterS.add(SIMULATEAPI_TITLE_QUERYBYKEYLIST)
            keyParameterS.add(SIMULATEAPI_LIMITREDVALUE_QUERYBYKEYLIST)
            keyParameterS.add(SIMULATEAPI_APPHOMETYPIC_QUERYIMAGELIST)


            apiResponseMap.put(SIMULATEAPI_SENDCODE,"{\"body\":{\"expire\":900,\"messageId\":\"8b2f64129b6f48f0b2ce336cfe798b8b\",\"mobileNo\":\"13********9\"},\"head\":{\"cost\":715,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_LOGINBYMOBILENO,"{\"body\":{\"avatar\":\"http://a03slotimage.qcyhmv.com/static/A03P/_default/__static/__images/headshot/1.png\",\"beforeLoginDate\":\"2019-06-25 17:00:11\",\"customerId\":\"1021821170\",\"customerType\":1,\"loginName\":\"fmob5356\",\"mobileNo\":\"13********9\",\"newWalletFlag\":0,\"noLoginDays\":1,\"starLevel\":0,\"starLevelName\":\"LV0 新手上路\",\"token\":\"b8ed8afa022743179646059f26323319\"},\"head\":{\"cost\":322,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")

            apiResponseMap.put(SIMULATEAPI_GETBYLOGINNAME,"{\"body\":{\"avatar\":\"http://a03slotimage.qcyhmv.com/static/A03P/_default/__static/__images/headshot/ag26.png\",\"bankCardNum\":0,\"birthday\":\"1995-01-30\",\"blackFlag\":0,\"btcNum\":0,\"clubLevel\":\"1\",\"customerId\":\"1021576157\",\"customerType\":1,\"depositLevel\":\"12\",\"gender\":\"M\",\"integral\":\"\",\"lastLoginDate\":\"2019-06-29 15:16:17\",\"loginDate\":\"2019-06-29 15:18:12\",\"loginName\":\"fqwe2\",\"loginNameFlag\":0,\"mobileNo\":\"13********8\",\"mobileNoBind\":1,\"mobileNoMd5\":\"f97fffd57d2014d5a30c12a2475bd584\",\"newWalletFlag\":0,\"promoAmountByMonth\":0,\"realName\":\"**y\",\"rebatedAmountByMonth\":0,\"registDate\":\"2018-10-26 17:39:02\",\"starLevel\":7,\"starLevelName\":\"VIP7 天生赢家\"},\"head\":{\"cost\":248,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_HOMEBEST,"{\"body\":{\"hotGames\":[{\"gameType\":\"BAC\",\"gameCode\":\"003\",\"gameTypeLogo\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/44f04dfaaa4bec697ca2ad6d630c00d2.png\"},{\"gameType\":\"ROU\",\"gameCode\":\"003\",\"gameTypeLogo\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/b8277663f3d98eaadadb4f375488cfff.png\"},{\"gameType\":\"SHB\",\"gameCode\":\"003\",\"gameTypeLogo\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/b8277663f3d98eaadadb4f375488cfff.png\"},{\"gameType\":\"6\",\"gameCode\":\"026\",\"gameTypeLogo\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/b8277663f3d98eaadadb4f375488cfff.png\"},{\"gameType\":\"BAC\",\"gameCode\":\"064\",\"gameTypeLogo\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/e8060a61ded1f5132555713fe32f5cf8.png\"}],\"withdrawTimeCost\":\"02分56秒\",\"topPlayers\":[{\"billTime\":\"2019-06-25 14:05:03\",\"gameType\":\"百家乐\",\"loginName\":\"****03\",\"me\":false,\"platform\":\"AG旗舰\",\"profitAmount\":100000000.00},{\"billTime\":\"2019-06-25 13:52:56\",\"gameType\":\"百家乐\",\"loginName\":\"****02\",\"me\":false,\"platform\":\"AG旗舰\",\"profitAmount\":10000000.00}],\"pendingWithdrawCount\":0,\"totalPromoAmount\":548540.87,\"bannerImages\":[{\"image\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/b0a29091ee02e7bacf9831e1d9d54182.jpg\",\"link\":\"http://m.a03f.com/BaccaratMasters\"},{\"image\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/2cf616051f0778d9761b6802e9a2a6e1.jpg\",\"link\":\"http://m.a03f.com/BaccaratMasters\"},{\"image\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/ac77a946706c680ac33c4a5036e3d810.jpg\",\"link\":\"app/mybonus\"},{\"image\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/434d34a78eaa7afb70d0ceb04850c501.jpg\",\"link\":\"/events/AGJBS\"}]},\"head\":{\"cost\":1521,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_GETBALANCE,"{\"body\":{\"balance\":0,\"localBalance\":0,\"minWithdrawAmount\":100,\"platformBalances\":[{\"balance\":0,\"platformCode\":\"003\",\"platformName\":\"AG旗舰厅\",\"sortNo\":1},{\"balance\":0,\"platformCode\":\"026\",\"platformName\":\"AG国际厅\",\"sortNo\":2},{\"balance\":0,\"platformCode\":\"036\",\"platformName\":\"AG现场厅\",\"sortNo\":3},{\"balance\":0,\"platformCode\":\"031\",\"platformName\":\"沙巴体育厅\",\"sortNo\":5},{\"balance\":0,\"platformCode\":\"017\",\"platformName\":\"BBIN电游厅\",\"sortNo\":6},{\"balance\":0,\"platformCode\":\"051\",\"platformName\":\"BSG电游厅\",\"sortNo\":7},{\"balance\":0,\"platformCode\":\"035\",\"platformName\":\"MG厅\",\"sortNo\":8},{\"balance\":0,\"platformCode\":\"027\",\"platformName\":\"TTG电游厅\",\"sortNo\":9},{\"balance\":0,\"platformCode\":\"064\",\"platformName\":\"AS电游城\",\"sortNo\":10},{\"balance\":0,\"platformCode\":\"052\",\"platformName\":\"PNG厅\",\"sortNo\":11},{\"balance\":0,\"platformCode\":\"067\",\"platformName\":\"PP厅\",\"sortNo\":12},{\"balance\":0,\"platformCode\":\"039\",\"platformName\":\"PT电游\",\"sortNo\":13},{\"balance\":0,\"platformCode\":\"065\",\"platformName\":\"NT厅\",\"sortNo\":14}],\"platformTotalBalance\":0,\"tlbinCredit\":0,\"withdrawBal\":0,\"yebAmount\":0,\"yebInterest\":0},\"head\":{\"cost\":255,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_UPGRADE,"{\"body\":{\"flag\":0},\"head\":{\"cost\":25,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_HOMEGAME,"{\"body\":{\"highGames\":[{\"gameDesc\":\"\",\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"reelrush_mobile_html_sw\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames/nt/reelrush_mobile_html_sw.png\",\"gameImageBig\":\"\",\"gameLastAmount\":\"\",\"gameLastDate\":\"2019-01-14 17:06:29\",\"gameName\":\"翻转卷轴\",\"gameNameEn\":\"Reel Rush™\",\"gameSupplier\":\"NT\",\"gameType\":1,\"isFavorite\":0,\"isFeature\":0,\"isHot\":0,\"isNew\":1,\"isPool\":0,\"isRecommend\":1,\"isUpHot\":0,\"payLine\":3125,\"platformCode\":\"065\",\"platformName\":\"NT\",\"playerType\":0,\"popularity\":0,\"preferenceType\":0,\"searchRecFlag\":0,\"tipsName\":\"\",\"tryFlag\":1},{\"gameDesc\":\"\",\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"bookofdead\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames/png/bookofdead.png\",\"gameImageBig\":\"\",\"gameLastAmount\":\"\",\"gameLastDate\":\"2019-01-14 17:06:29\",\"gameName\":\"亡灵书\",\"gameNameEn\":\"Book of Dead\",\"gameSupplier\":\"PNG\",\"gameType\":1,\"isFavorite\":0,\"isFeature\":0,\"isHot\":0,\"isNew\":0,\"isPool\":0,\"isRecommend\":0,\"isUpHot\":0,\"payLine\":10,\"platformCode\":\"052\",\"platformName\":\"PNG\",\"playerType\":0,\"popularity\":0,\"preferenceType\":0,\"searchRecFlag\":0,\"tipsName\":\"\",\"tryFlag\":1},{\"gameDesc\":\"\",\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"shangrila_mobile_html_sw\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames/nt/shangrila_mobile_html_sw.jpg\",\"gameImageBig\":\"\",\"gameLastAmount\":\"\",\"gameLastDate\":\"2019-01-14 17:06:29\",\"gameName\":\"香格里拉传奇\",\"gameNameEn\":\"The Legend of Shangri-La\",\"gameSupplier\":\"NT\",\"gameType\":1,\"isFavorite\":0,\"isFeature\":0,\"isHot\":0,\"isNew\":0,\"isPool\":0,\"isRecommend\":0,\"isUpHot\":0,\"payLine\":30,\"platformCode\":\"065\",\"platformName\":\"NT\",\"playerType\":0,\"popularity\":0,\"preferenceType\":0,\"searchRecFlag\":0,\"tipsName\":\"\",\"tryFlag\":1},{\"gameDesc\":\"\",\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"68778\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames/mg/68778.png\",\"gameImageBig\":\"\",\"gameLastAmount\":\"\",\"gameLastDate\":\"2019-01-14 17:06:29\",\"gameName\":\"宝石迷阵\",\"gameNameEn\":\"Reel Gems\",\"gameSupplier\":\"MG\",\"gameType\":1,\"isFavorite\":0,\"isFeature\":0,\"isHot\":0,\"isNew\":0,\"isPool\":0,\"isRecommend\":0,\"isUpHot\":0,\"payLine\":243,\"platformCode\":\"035\",\"platformName\":\"MG\",\"playerType\":0,\"popularity\":0,\"preferenceType\":0,\"searchRecFlag\":0,\"tipsName\":\"\",\"tryFlag\":1}],\"dyAppDownUrl\":\"https://m.agwin1.com/dyapp.htm\",\"bannerImages\":[{\"image\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/b0a29091ee02e7bacf9831e1d9d54182.jpg\",\"link\":\"/events/SC100\"}]},\"head\":{\"cost\":15,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_QUERYGAMELIST,"{\"body\":{\"data\":[{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"AG_FISH_6\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//ag/6.png\",\"gameName\":\"AG捕鱼王\",\"gameType\":6,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":0,\"platformCode\":\"026\",\"platformName\":\"AG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":0,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"456_455_457\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//bs/456_455_457.png\",\"gameName\":\"海底沉宝\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":30,\"platformCode\":\"051\",\"platformName\":\"BSG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"484_483_485\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//bs/484_483_485.png\",\"gameName\":\"两小无猜\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":30,\"platformCode\":\"051\",\"platformName\":\"BSG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"50192\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//mg/50192.png\",\"gameName\":\"东方珍兽\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":243,\"platformCode\":\"035\",\"platformName\":\"MG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"46810\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//mg/46810.png\",\"gameName\":\"比基尼派对\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":243,\"platformCode\":\"035\",\"platformName\":\"MG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"45539\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//mg/45539.png\",\"gameName\":\"篮球巨星\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":243,\"platformCode\":\"035\",\"platformName\":\"MG\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":0,\"serverGameId\":\"\",\"tryFlag\":1,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"ct\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//pt/ct.png\",\"gameName\":\"船长的宝藏\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":9,\"platformCode\":\"039\",\"platformName\":\"PT\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":0,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"gos\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//pt/gos.png\",\"gameName\":\"金色之旅\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":5,\"platformCode\":\"039\",\"platformName\":\"PT\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":1,\"serverGameId\":\"\",\"tryFlag\":0,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"hk\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//pt/hk.png\",\"gameName\":\"高速公路之王\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":10,\"platformCode\":\"039\",\"platformName\":\"PT\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":0,\"serverGameId\":\"\",\"tryFlag\":0,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"whk\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//pt/whk.png\",\"gameName\":\"白狮\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":40,\"platformCode\":\"039\",\"platformName\":\"PT\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":0,\"serverGameId\":\"\",\"tryFlag\":0,\"typeUrl\":\"\"},{\"exCode\":\"\",\"flag\":1,\"gameFree\":0,\"gameHotValue\":\"\",\"gameId\":\"zcjb\",\"gameImage\":\"https://a03slotmobileimage.qcyhmv.com/static/A03SLOTSM/_default/__static/_wms/_l/electronicgames//pt/zcjb.png\",\"gameName\":\"招财进宝\",\"gameType\":1,\"hotFlag\":0,\"isFavorite\":0,\"isUpHot\":0,\"jackpotId\":\"\",\"newFlag\":0,\"payLine\":9,\"platformCode\":\"039\",\"platformName\":\"PT\",\"playerType\":0,\"poolFlag\":0,\"popularity\":0,\"preferenceFlag\":0,\"recommendFlag\":0,\"serverGameId\":\"\",\"tryFlag\":0,\"typeUrl\":\"\"}],\"pageNo\":1,\"pageSize\":12,\"totalPage\":7,\"totalRow\":81},\"head\":{\"cost\":5,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_QUERYSPORTS,"{\"body\":[{\"competition\":\"英格兰超级联赛\",\"concedePoints\":\";0.75\",\"concedeType\":\"0\",\"effectiveDateEnd\":\"2019-08-15 02:59:59\",\"effectiveDateStart\":\"2019-06-23 00:00:00\",\"hostGuest\":\"0.97;;0.84\",\"id\":\"11180\",\"matchTime\":\"2019-08-15 03:00:00\",\"team1\":\"利物浦 \",\"team1Id\":\"5201\",\"team1Url\":\"https://a03image.cufbank.com/static/A03P/_default/__static/_wms//sport/39be7d2296adfc09a215aed069519b2e.png\",\"team2\":\"切尔西\",\"team2Id\":\"5320\",\"team2Url\":\"https://a03image.qcyhmv.com/static/A03P/_default/__static/_wms/sport/09eadd3f9328bc8b75ad9c22770fabf7.png\"},{\"competition\":\"英格兰超级联赛\",\"concedePoints\":\";1.75\",\"concedeType\":\"1\",\"effectiveDateEnd\":\"2019-08-10 19:40:59\",\"effectiveDateStart\":\"2019-06-18 00:00:00\",\"hostGuest\":\"0.84;;1.02\",\"id\":\"11081\",\"matchTime\":\"2019-08-10 19:30:00\",\"team1\":\"西汉姆联队\",\"team1Id\":\"5305\",\"team1Url\":\"https://a03image.qcyhmv.com/static/A03P/_default/__static/_wms/sport/141ef881eae6c1356d7cd69d45fa006b.png\",\"team2\":\"曼联\",\"team2Id\":\"5300\",\"team2Url\":\"https://a03image.cufbank.com/static/A03P/_default/__static/_wms/sport/0a44fdb4425c6559feca3d2d23081cf1.png\"},{\"competition\":\"英格兰超级联赛\",\"concedePoints\":\";2.25\",\"concedeType\":\"0\",\"effectiveDateEnd\":\"2019-08-10 02:59:59\",\"effectiveDateStart\":\"2019-06-24 00:00:00\",\"hostGuest\":\"1.14;;18.00\",\"id\":\"11220\",\"matchTime\":\"2019-08-10 03:00:00\",\"team1\":\"利物浦 \",\"team1Id\":\"5201\",\"team1Url\":\"https://a03image.cufbank.com/static/A03P/_default/__static/_wms//sport/39be7d2296adfc09a215aed069519b2e.png\",\"team2\":\"诺维奇\",\"team2Id\":\"5314\",\"team2Url\":\"https://a03image.qcyhmv.com/static/A03P/_default/__static/_wms/sport/7ce8c6e84cf419c76369b8e232396ea6.png\"},{\"competition\":\"美洲杯\",\"concedePoints\":\";0-0.5\",\"concedeType\":\"1\",\"effectiveDateEnd\":\"2019-06-30 07:00:00\",\"effectiveDateStart\":\"2019-06-26 00:00:00\",\"hostGuest\":\"0.9;;0.9\",\"id\":\"11240\",\"matchTime\":\"2019-06-30 07:00:00\",\"team1\":\"海地\",\"team1Id\":\"4937\",\"team1Url\":\"https://a03image.cufbank.com/static/A03P/_default/__static/_wms/sport/haidi.png\",\"team2\":\"加拿大\",\"team2Id\":\"4955\",\"team2Url\":\"https://a03image.cufbank.com/static/A03P/_default/__static/_wms/sport/jianada.png\"}],\"head\":{\"cost\":5,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_GAMEPLATFORMS_QUERYBYKEYLIST,"{\"body\":{\"gamePlatforms\":\"AG,TTG,MG,PT,BSG,PNG,NT,PP\"},\"head\":{\"cost\":29,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_TITLE_QUERYBYKEYLIST,"{\"body\":{\"title\":[{\"articleType\":1,\"id\":10,\"sortNo\":1,\"tagId\":66,\"tagName\":\"捕鱼王\"},{\"articleType\":1,\"id\":37,\"sortNo\":1,\"tagId\":93,\"tagName\":\"体育\"},{\"articleType\":1,\"id\":35,\"sortNo\":1,\"tagId\":92,\"tagName\":\"低调\"},{\"articleType\":1,\"id\":34,\"sortNo\":1,\"tagId\":91,\"tagName\":\"奢华\"},{\"articleType\":1,\"id\":33,\"sortNo\":1,\"tagId\":90,\"tagName\":\"轮盘\"},{\"articleType\":1,\"id\":32,\"sortNo\":1,\"tagId\":87,\"tagName\":\"高端\"},{\"articleType\":1,\"id\":30,\"sortNo\":1,\"tagId\":85,\"tagName\":\"博彩科技\"},{\"articleType\":2,\"id\":20,\"sortNo\":1,\"tagId\":67,\"tagName\":\"赞助\"},{\"articleType\":1,\"id\":11,\"sortNo\":2,\"tagId\":65,\"tagName\":\"百家乐\"},{\"articleType\":2,\"id\":21,\"sortNo\":2,\"tagId\":68,\"tagName\":\"展会\"},{\"articleType\":2,\"id\":22,\"sortNo\":3,\"tagId\":69,\"tagName\":\"投资\"},{\"articleType\":1,\"id\":12,\"sortNo\":3,\"tagId\":73,\"tagName\":\"赌神故事\"},{\"articleType\":2,\"id\":23,\"sortNo\":4,\"tagId\":70,\"tagName\":\"公益\"},{\"articleType\":1,\"id\":13,\"sortNo\":4,\"tagId\":74,\"tagName\":\"电子游戏\"},{\"articleType\":2,\"id\":24,\"sortNo\":5,\"tagId\":71,\"tagName\":\"平台\"},{\"articleType\":1,\"id\":14,\"sortNo\":5,\"tagId\":75,\"tagName\":\"赌场\"},{\"articleType\":2,\"id\":25,\"sortNo\":6,\"tagId\":72,\"tagName\":\"赛事\"},{\"articleType\":1,\"id\":15,\"sortNo\":6,\"tagId\":76,\"tagName\":\"德州扑克\"},{\"articleType\":1,\"id\":16,\"sortNo\":7,\"tagId\":77,\"tagName\":\"彩票\"},{\"articleType\":1,\"id\":19,\"sortNo\":10,\"tagId\":80,\"tagName\":\"用户反馈\"},{\"articleType\":1,\"id\":26,\"sortNo\":11,\"tagId\":82,\"tagName\":\"博彩心理\"},{\"articleType\":1,\"id\":27,\"sortNo\":12,\"tagId\":83,\"tagName\":\"足球\"},{\"articleType\":1,\"id\":28,\"sortNo\":13,\"tagId\":81,\"tagName\":\"博彩概率\"},{\"articleType\":1,\"id\":29,\"sortNo\":14,\"tagId\":84,\"tagName\":\"财富自由\"}]},\"head\":{\"cost\":33,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_LIMITREDVALUE_QUERYBYKEYLIST,"{\"body\":{\"limitRedValue\":\"20-50000\"},\"head\":{\"cost\":340,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_APPHOMETYPIC_QUERYIMAGELIST,"{\"body\":{\"domainName\":\"https://a03mobileimage.qcyhmv.com\",\"imageGroups\":{\"APP_HOME_TY_PIC\":[{\"host\":\"\",\"imgCode\":\"足球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/zuqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":0},{\"host\":\"\",\"imgCode\":\"篮球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/lanqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":1},{\"host\":\"\",\"imgCode\":\"电竞\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/dianjing.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":2},{\"host\":\"\",\"imgCode\":\"网球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/wangqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":3},{\"host\":\"\",\"imgCode\":\"F1赛车\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/saishi.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":4},{\"host\":\"\",\"imgCode\":\"拳击\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/quanji.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":5},{\"host\":\"\",\"imgCode\":\"排球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/pingpangqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":6},{\"host\":\"\",\"imgCode\":\"台球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/taiqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":7},{\"host\":\"\",\"imgCode\":\"飞镖\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/feibiao.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":8},{\"host\":\"\",\"imgCode\":\"高尔夫\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/gaoerfu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":9},{\"host\":\"\",\"imgCode\":\"乒乓球\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/pingpangqiu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":10},{\"host\":\"\",\"imgCode\":\"滑雪\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/huaxue.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"2\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":11},{\"host\":\"\",\"imgCode\":\"环亚赛事\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/center.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"1\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":100},{\"host\":\"\",\"imgCode\":\"沙巴体育\",\"imgExUrl\":\"\",\"imgUrl\":\"https://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hyapptybanner/shabatiyu.jpg\",\"linkParam\":{\"gameCode\":\"0000\",\"type\":\"3\"},\"linkType\":3,\"linkUrl\":\"\",\"sortNo\":101}]}},\"head\":{\"cost\":66,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_HOMEOTHER,"{\"body\":[{\"appDesc\":\"6分钟1期，高效快速游戏\",\"appDownUrl\":\"https://www.aggameapp.com/lottery.jsp?pd=ZkEwM2U=\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/f1eb020cfd1461c510325c2d4640bc59.png\",\"appName\":\"AG快乐彩\",\"appSize\":\"\",\"id\":2,\"supportPlatformFlag\":0},{\"appDesc\":\"百家乐，炸金花，晒宝，轮盘\",\"appDownUrl\":\"https://www.aggameapp.com/webnew/home.html?pd=ZkEwM2U=\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/2894175e6bbaa244afa83f71c4539e70.png\",\"appName\":\"AG旗舰厅\",\"appSize\":\"\",\"id\":4,\"supportPlatformFlag\":0},{\"appDesc\":\"百家乐，斗牛，21点，牛牛\",\"appDownUrl\":\"https://agmbet.com/v1/\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/3df793e175ee1c0f75df81b17952c500.png\",\"appName\":\"AG国际厅\",\"appSize\":\"\",\"id\":5,\"supportPlatformFlag\":0},{\"appDesc\":\"菲律宾实地赌厅，如临现场\",\"appDownUrl\":\"https://a03.game888.app/\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/c8125f4d09cc0e9349ffb4d594475ee1.png\",\"appName\":\"AG实地赌厅\",\"appSize\":\"\",\"id\":6,\"supportPlatformFlag\":0},{\"appDesc\":\"每周最低30万元jackpot大奖\",\"appDownUrl\":\"https://m.agwin1.com/download_pt.htm\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/31f845ab93d3648784bb609b07e05047.png\",\"appName\":\"PT电游\",\"appSize\":\"\",\"id\":7,\"supportPlatformFlag\":0},{\"appDesc\":\"经典老虎机，超热游戏平台\",\"appDownUrl\":\"https://m.agwin1.com/download_mg.htm\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/21acea9f8efd6e02c4aedeeceee4c6d2.png\",\"appName\":\"MG电游\",\"appSize\":\"\",\"id\":8,\"supportPlatformFlag\":0},{\"appDesc\":\"海量电子游戏，一网打尽\",\"appDownUrl\":\"https://m.agwin1.com/dyapp.htm\",\"appImage\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/fb5f7b476c127807bade40d0731a3bc5.png\",\"appName\":\"环亚电游\",\"appSize\":\"\",\"id\":14,\"supportPlatformFlag\":0}],\"head\":{\"cost\":111,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_GETNOTICE,"{\"body\":{\"data\":[{\"content\":\"测试11111111111111111111111111111111111111111\",\"id\":1006315,\"publishDate\":\"2019-01-25 15:36:45\",\"title\":\"测试1\",\"topFlag\":\"1\"},{\"content\":\"测试222222222222222222222222\",\"id\":1031020,\"publishDate\":\"2019-03-13 13:09:38\",\"title\":\"测试2\",\"topFlag\":\"0\"},{\"content\":\"hfhjgghkjgkjg\",\"id\":1006168,\"publishDate\":\"2019-01-15 15:01:57\",\"title\":\"网关升级及开发调试测试数据准备\",\"topFlag\":\"0\"},{\"content\":\"您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!您存款，手续费我来给!\",\"id\":1006039,\"publishDate\":\"2019-01-11 11:17:11\",\"title\":\"您存款，手续费我来给!\",\"topFlag\":\"0\"},{\"content\":\"30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择30%开户红利任您选择\",\"id\":1006038,\"publishDate\":\"2019-01-11 11:16:38\",\"title\":\"30%开户红利任您选择\",\"topFlag\":\"0\"},{\"content\":\"环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划环亚积分奖励计划\",\"id\":1006037,\"publishDate\":\"2019-01-11 11:16:09\",\"title\":\"环亚积分奖励计划\",\"topFlag\":\"0\"},{\"content\":\"特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶特惠厅1.2%洗码 无上限封顶\",\"id\":1006035,\"publishDate\":\"2019-01-11 11:14:34\",\"title\":\"特惠厅1.2%洗码 无上限封顶\",\"topFlag\":\"0\"},{\"content\":\"周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠周五大放送，体验新洗码优惠\",\"id\":1006034,\"publishDate\":\"2019-01-11 11:12:54\",\"title\":\"周五大放送，体验新洗码优惠！！\",\"topFlag\":\"0\"}]},\"head\":{\"cost\":15,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_GETASSISTANT,"{\"body\":{\"faqs\":[{\"content\":\"我们提供多种便捷和安全的充值方式，您可以选择一种您喜欢的充值方式。\\r\\n1.\\t银行卡转账：请您登录账号以后点击‘我的’-‘充值’，再选择【银行卡转账】，按照提示输入充值金额和付款人姓名，提交后会出现订单确认的提示以及收款银行（可点击更换），接着点击确认按钮，并将收款账号信息复制粘贴到您的个人网银页面、手机银行进行支付，支付成功后额度实时到账。或者您也可以选择于ATM机现金转账，通过ATM机存款则需联系客服备注方可添加到账。\\r\\n2.\\t网银在线支付：请您登录账号以后点击‘我的’-‘充值’，再选择【网银在线支付】，按界面要求填写您所需入款的金额并选取您要使用的网上银行，即可连线到银行端进行充值操作，按照银行支付流程，进行在线充值，支付成功后刷新您的额度，即可查看到金额。（支持多家银行付款，要开通网银方可使用）\\r\\n3.\\t扫码支付：请您登录账号以后点击‘我的’-‘充值’，再选择【扫码支付】，按界面要求填写您所需入款的金额并选取您要使用的支付方式  如：京东扫码、银联扫码、QQ扫码。提交后即可获取二维码进行扫码支付，支付实时到账，无需联系客服。\\r\\n4.\\t支付宝转账、微信转账：请您登录账号以后点击‘我的’-‘充值’，再选择【支付宝转账】、【微信转账】，按照提示输入充值金额和付款人姓名，提交后会出现订单确认的提示以及收款银行（可点击更换），接着点击确认按钮，并将收款账号信息复制粘贴到您的支付宝或微信以进行支付。支付成功后额度实时到账，无需联系客服。\",\"faqType\":1,\"id\":20,\"title\":\"如何充值\"},{\"content\":\"您可以通过网银转账、手机银行、ATM柜员机、银行柜台、电话转账、支付宝或者微信支付等方式进行存款，如果您是属于银行转账存款的话，银行是会收取您汇款手续费的，如果您是使用网银在线支付存款的话，则无任何存款手续费。\",\"faqType\":1,\"id\":21,\"title\":\"充值收取手续费吗\"},{\"content\":\"由于我们是菲律宾合法注册的网站，受当地政府监管及“反洗钱法”的约束，您存款不投注是无法申请取款的,提款前只需您的有效投注额达到存款金额的1倍流水即可提款。\",\"faqType\":2,\"id\":22,\"title\":\"游戏余额能提现吗\"},{\"content\":\"通过此环亚手机客户端操作，最低取款金额为100元，单日提款无上限封顶。\",\"faqType\":2,\"id\":23,\"title\":\"提现是否有限额要求\"},{\"content\":\"单日提款限额内的取款申请：银行工作时间(周一至周五9:00-17:00）1小时内到账；其它非银行工作时间，600万内的取款2小时内到账，如高于600万的部分，最晚于次日11:00前到账，单日取款无上限封顶。\",\"faqType\":2,\"id\":24,\"title\":\"余额提现可以多久到账\"},{\"content\":\"洗码是指会员下注有效投注额的退水。洗码不论输赢，只要是有投注有输赢就有退水，「有效投注额*相应的星级比率＝洗码优惠金额」。\\r\\n举例：假如您是网站2星级会员。真人娱乐本周有效投注额为100000,就可以享受100000×0.005=500元的洗码优惠。只要单厅5元就可自助结算即刻到账，未达到结算要求的洗码会在周一16点前统一添加到会员账号。\",\"faqType\":3,\"id\":34,\"title\":\"什么是洗码，怎么计算的\"},{\"content\":\"环亚娱乐洗码优惠，只要单厅达到5元即可自助结算即刻到账，未达到要求的洗码会在周一16点前统一添加到会员账号。\",\"faqType\":3,\"id\":35,\"title\":\"洗码结算到账时间\"}]},\"head\":{\"cost\":15,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")


            apiResponseMap.put(SIMULATEAPI_QUERYARTICLES,"{\"body\":[{\"abstractName\":\"作为一个有赌场经验的人 攻略酱可是真真正正的赌场老手\",\"articleId\":96,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/b80ec67871e292a1fe05e1ab937dd0d7.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"攻略酱\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/unionpay.png\",\"publishDate\":\"2018-11-13 04:31:38\",\"readNum\":33,\"sortNo\":0,\"tagList\":\"赌神故事,赌场,博彩概率\",\"titleName\":\"谈谈赌博一：下注的经验\"},{\"abstractName\":\"Asia Gambing2月2日再度受邀到英国参与ICE Totally Gambing2016博彩博览会，今年的参展主题是“Gambing the Asia Way ”\",\"articleId\":44,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/misc/history_09.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":2,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2016-02-17 23:07:04\",\"readNum\":0,\"sortNo\":0,\"tagList\":\"展会\",\"titleName\":\"AG再度受邀远赴英国参与ICE博彩博览会\"},{\"abstractName\":\"\",\"articleId\":56,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/480p_AG888CutTheRibbon.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":1,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2014-09-18 09:37:48\",\"readNum\":0,\"sortNo\":0,\"tagList\":\"平台\",\"titleName\":\"AG贵宾会剪彩仪式\"},{\"abstractName\":\"海王星国际与ag环亚游戏进行战略重组并正式更名为“AG环亚娱乐”。 AG环亚娱乐将线下资源和网络资源完美整合，为玩家打造一站式网投， 电投，现场投注等多元化娱乐体验\",\"articleId\":55,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03P/_default/__static/_wms/_l/_promo/ag-news-56.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2014-07-11 09:36:15\",\"readNum\":1,\"sortNo\":0,\"tagList\":\"平台\",\"titleName\":\"海王星国际正式更名为“AG环亚娱乐”\"},{\"abstractName\":\"英国的菠菜行业在全世界都是出于领先地位，好赌的英国也是全球合法化菠菜行业最早的国家之一，菠菜行业在英国经过多年的发展，已经成为英国经济性支柱产业，英国菠菜公司在世界上享有极高的声誉。\",\"articleId\":91,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/9d646561fcd887856aa6bb57c1e918a5.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"文字妹\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/1e90fc9140afc513ec7307681b18b71e.png\",\"publishDate\":\"2018-11-07 02:12:00\",\"readNum\":8,\"sortNo\":0,\"tagList\":\"赌场,足球\",\"titleName\":\"英国菠菜行业玩起新把戏！\"},{\"abstractName\":\"很多看似不相关的事物背后却有着千丝万缕的关系，比如今天故事的主角——酒鬼与赌徒。\",\"articleId\":88,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/d155f18c7e838b5e8c26504964cb1432.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"文字妹\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/1e90fc9140afc513ec7307681b18b71e.png\",\"publishDate\":\"2018-11-06 10:11:22\",\"readNum\":6,\"sortNo\":0,\"tagList\":\"赌场,博彩概率,财富自由,博彩科技\",\"titleName\":\"从酒鬼失足到赌徒破产，如何挽救？\"},{\"abstractName\":\"杜特尔特：愿提升到更高层次友谊。：中菲关系今年应提升，XI今年11月份将对菲律宾进行国事访问。那要如何提升菲律宾房产投资？\",\"articleId\":87,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/b9467505e270037077bc59420792bb92.jpeg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"文字妹\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/1e90fc9140afc513ec7307681b18b71e.png\",\"publishDate\":\"2018-11-04 18:07:43\",\"readNum\":16,\"sortNo\":0,\"tagList\":\"用户反馈,财富自由,博彩科技,高端\",\"titleName\":\"不用拼爹，菲律宾马尼拉海外房产投资成高端\"},{\"abstractName\":\"小伙玩老虎机年赚1亿，只因数学好...\",\"articleId\":52,\"articleType\":1,\"bannerTopUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/470d9829143296d585e85e12ecb99f02.jpg\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/470d9829143296d585e85e12ecb99f02.jpg\",\"flag\":1,\"isBanner\":1,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"文字妹\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/1e90fc9140afc513ec7307681b18b71e.png\",\"publishDate\":\"2018-11-03 04:36:38\",\"readNum\":38,\"sortNo\":0,\"tagList\":\"电子游戏,博彩科技,高端\",\"titleName\":\"小伙玩老虎机年赚1亿，只因数学好...\"},{\"abstractName\":\"AG强势进军欧洲市场，亮相2018伦敦ICE博彩展 AG首度携手战略合作伙伴Amazing Gaming，为欧洲博彩市场诞生的全新品牌，亮相英国伦敦ICE博彩展\",\"articleId\":37,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/360p_Asia Gaming at ICE Totally Gaming 2017.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":3,\"linkUrl\":\"https://m.ag88158.com/promo_bacarat_competition.htm\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-10-31 17:55:24\",\"readNum\":16,\"sortNo\":0,\"tagList\":\"展会\",\"titleName\":\"2018伦敦ICE博彩展\"},{\"abstractName\":\"福利院纪录片\",\"articleId\":8,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/480p_WelfareHouse.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":1,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2013-10-23 13:43:46\",\"readNum\":2,\"sortNo\":0,\"tagList\":\"公益\",\"titleName\":\"福利院纪录片\"},{\"abstractName\":\"环亚和业界享有盛名的波音平台签约， 平台提供多元网络娱乐服 务和游戏商品开发，无论是在运动博弈、真人视讯、电子游戏、 桌上游戏皆有丰富的选择。\",\"articleId\":43,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03P/_default/__static/_wms/_l/_promo/ag-news-67.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2012-10-11 07:00:36\",\"readNum\":3,\"sortNo\":0,\"tagList\":\"平台\",\"titleName\":\"AG环亚娱乐与BBIN签约\"},{\"abstractName\":\"赌场里还有其他各种各样的游戏。在赌场的两侧，还摆着每个赌场里都必不可少的老虎机。一台台老虎机屏幕上的游戏画面五颜六色，各不相同，闪着耀眼的亮光。比起那些赌桌，老虎机算是赌场里“投资额”最小的游戏了。\",\"articleId\":50,\"articleType\":1,\"bannerTopUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/56594c9a3fb8c90c4f7e473bb4b902d9.jpeg\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/56594c9a3fb8c90c4f7e473bb4b902d9.jpeg\",\"flag\":1,\"isBanner\":1,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"攻略酱\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/unionpay.png\",\"publishDate\":\"2018-09-23 19:43:03\",\"readNum\":20,\"sortNo\":0,\"tagList\":\"赌神故事,赌场,博彩概率,轮盘\",\"titleName\":\"学点数学：小游戏也有大陷阱\"},{\"abstractName\":\"16个犯人，狱官让他们聚在一起，给每个人戴上一顶红色或蓝色的帽子。每个人都能看到另外15个人的帽子而看不见自己的帽子。\",\"articleId\":20,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/21a33a4cf53d7ca956240f04b7551c91.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"交易门\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/jdpay.png\",\"publishDate\":\"2018-09-19 10:23:10\",\"readNum\":9,\"sortNo\":0,\"tagList\":\"赌神故事,博彩概率\",\"titleName\":\"做一个有头脑的赌徒\"},{\"abstractName\":\"Asia gaming作为引领业界的真人视讯游戏供应商，从来不忘与时俱进，开拓创新。最近又取得突破性发展，现隆重推出最新欧洲真人娱乐城。这一跨出亚洲迈向世界的重要力作，标志着Asia gaming一个新的里程碑。\",\"articleId\":29,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/misc/20180917.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"https://m.ag88158.com/promo_agin_europe.htm\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-09-02 23:33:38\",\"readNum\":7,\"sortNo\":0,\"tagList\":\"平台\",\"titleName\":\"AG国际——欧洲厅隆重上线\"},{\"abstractName\":\"\",\"articleId\":54,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/480p_AsiaGamingWelcomeToOurEuropesLiveCasino.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":1,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-09-02 09:12:34\",\"readNum\":2,\"sortNo\":0,\"tagList\":\"平台\",\"titleName\":\"AG国际——欧洲厅隆重上线\"},{\"abstractName\":\"首先声明：我不是赌神;我现在没有打败百家乐;我现在成功的打败了我自己;我目前是在盈利中。您可能会有这样的疑问：没打败百家乐敢在这里说你会赢钱?\",\"articleId\":19,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/huati/ad30a41e8114489f96a0845bc2074351.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"交易门\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/jdpay.png\",\"publishDate\":\"2018-08-17 11:33:17\",\"readNum\":20,\"sortNo\":0,\"tagList\":\"赌神故事,百家乐\",\"titleName\":\"我的故事心得---玩百家乐我是这样赢钱的\"},{\"abstractName\":\"\",\"articleId\":85,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/480p_AGAsiaGamingMasterTournamentIsBack.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":3,\"linkUrl\":\"\",\"nickName\":\"攻略酱\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/unionpay.png\",\"publishDate\":\"2018-07-11 17:40:20\",\"readNum\":8,\"sortNo\":0,\"tagList\":\"赌神故事,赌场,博彩心理,博彩概率\",\"titleName\":\"你和一千万只差一个赌神大赛\"},{\"abstractName\":\"长期比赛活动，让您每天都能与不同的参赛者竞技较量，大展身手！每日15点整及21点整各两场赛事，在指定的时间内只需要在AG旗舰厅的任意百家乐游戏中满足5000有效投注额或者通过100元的报名方式即可参赛。马上进入到AG旗舰厅查看详细规则，AG奖金正等着您来赢取！\",\"articleId\":34,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/misc/20180820001.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"https://m.ag88158.com/promo_ag_match_common2.htm\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-06-24 09:33:40\",\"readNum\":2,\"sortNo\":0,\"tagList\":\"赛事\",\"titleName\":\"AG旗舰百家乐常态赛  AG百战称王\"},{\"abstractName\":\"环亚娱乐与您一起狂欢世界杯！在AG旗舰厅投注，单注有效投注额达200即可获得球卡！获得千万大奖，走过路过不能错过！\",\"articleId\":33,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/misc/20180608002.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"https://m.ag88158.com/promo_worldcup_carnival.htm\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-06-21 09:24:34\",\"readNum\":4,\"sortNo\":0,\"tagList\":\"赛事\",\"titleName\":\"AG旗舰厅世界杯狂欢节\"},{\"abstractName\":\"真的可以通过数学方法提高赌博中赢的几率吗？   当然可以  半年以来，每天的英镑赌注量，只有0.1%-1%才是利润，倒是没有一天无利润）  最核心的原理是：算概率要算得比其他玩家更准（或者比赌场更准）。\",\"articleId\":12,\"articleType\":1,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/25044dc1fe29c71ba8ecee4089347d29.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"\",\"nickName\":\"交易门\",\"pictureUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/dasheng/app/jdpay.png\",\"publishDate\":\"2018-06-16 02:10:35\",\"readNum\":17,\"sortNo\":0,\"tagList\":\"博彩概率\",\"titleName\":\"真的可以通过数学方法提高赌博中赢的几率吗？\"},{\"abstractName\":\"今年，环亚与Asia Gaming联手出击，以'汇聚实力  精彩创新' 为主题共同参展。集合专属电子游戏供应商—XIN Gaming，专属街机游戏供应商—YOPLAY，以及Asia Gaming旗下休闲类游戏—'捕鱼王'为一体，加上彰显实力的酒店实体娱乐场尊尚服务，呈现环亚与Asia Gaming多元化博娱业务发展趋势。\",\"articleId\":35,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://a03mobileimage.qcyhmv.com/static/A03M/_default/__static/__images/misc/20180516.jpg\",\"flag\":1,\"isBanner\":0,\"layoutType\":0,\"linkUrl\":\"https://m.ag88158.com/promo_macao_exhibition.htm\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-05-23 17:36:43\",\"readNum\":3,\"sortNo\":0,\"tagList\":\"赞助\",\"titleName\":\"环亚携手Asia Gaming参加2018亚洲国际博彩娱乐站\"},{\"abstractName\":\"2018亚洲国际博彩娱乐展\",\"articleId\":2,\"articleType\":2,\"bannerTopUrl\":\"\",\"bannerUrl\":\"http://vod.yzbabyu.com/applications/A03/streams/_definst_/360p_Asia Gaming at G2E Asia 2018.mp4\",\"flag\":1,\"isBanner\":0,\"layoutType\":1,\"linkUrl\":\"\",\"nickName\":\"\",\"pictureUrl\":\"\",\"publishDate\":\"2018-05-11 13:38:41\",\"readNum\":0,\"sortNo\":0,\"tagList\":\"展会\",\"titleName\":\"2018亚洲国际博彩娱乐展\"}],\"head\":{\"cost\":77,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_LETTERQUERY,"{\"body\":{\"data\":[{\"content\":\"尊敬的用户，为了您的帐户安全，建议您绑定手机号以及定期修改密码，如有问题请联系在线客服或拨打免费电话400-1200-966\",\"createDate\":\"2019-06-25 13:41:29\",\"flag\":0,\"id\":\"6239914\",\"title\":\"欢迎您加入环亚娱乐\"},{\"content\":\"首次最低充值100元即可享受最高3888元首存礼金！如需申请请点击「我的红利」进行申请或联系在线客服\",\"createDate\":\"2019-06-25 13:41:29\",\"flag\":0,\"id\":\"6239915\",\"title\":\"网站优惠\"}],\"pageNo\":1,\"pageSize\":10,\"totalPage\":1,\"totalRow\":2},\"head\":{\"cost\":106,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")

            apiResponseMap.put(SIMULATEAPI_VIPSQUERYXMRATE,"{\"body\":{\"CPXmRate\":\"0\",\"DYXmRate\":\"0\",\"ZRXmRate\":\"0\",\"TYXmRate\":\"0\",\"travelFLBY\":\"菲律宾游,不符合条件\",\"bonusJJLJ\":\"不符合条件\",\"revateYLFL\":\"不符合条件\"},\"head\":{\"cost\":184,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_QUERYVIPPREMIUMS,"{\"body\":{\"currentLevelName\":\"\",\"nextLevelId\":1,\"betCount\":\"1\",\"nextLevelDesc\":\"【有效投注额】一周1-100000\",\"currentLevelId\":0,\"nextLevelName\":\"\"},\"head\":{\"cost\":532,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")

            apiResponseMap.put(SIMULATEAPI_MYPROMO,"{\"body\":{\"myPromoList\":[{\"abstractText\":\"AG旗舰厅将与6月1日开始推出长期锦标赛活动‘百战称王’，场场万元，日日来战，万元头奖天天抢。进入AG旗舰大厅即可查看详情，赶紧前来挑战赢奖金吧！\",\"beginDate\":\"2018年06月02日\",\"configId\":63,\"defaultValue\":\"4\",\"endDate\":\"2041年07月11日\",\"imgTip\":\"真人\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/_l/_promo/promo-30f552d77a7f64ff9b604cd44d16a50d8.jpg\",\"isTop\":0,\"linkUrl\":\"/events/AGJBS\",\"promoCode\":\"AGJBS\",\"promoFlag\":1,\"promoKind\":4,\"title\":\"AG旗舰厅常态赛\"},{\"abstractText\":\"活动期间首存即可申请开矿，最高获得2888元矿藏收益\",\"beginDate\":\"2018年11月02日\",\"configId\":69,\"endDate\":\"2041年07月11日\",\"imgTip\":\"电游\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/newappbanner/b0a29091ee02e7bacf9831e1d9d54182.jpg\",\"isTop\":0,\"linkUrl\":\"/events/SC100\",\"promoCode\":\"SC100\",\"promoFlag\":1,\"promoKind\":1,\"title\":\"首存100%送\"},{\"abstractText\":\"AG88生日礼金+10倍奖励为你庆生！为感谢您对网站长期的支持，在特殊的日子里，让我们为您送上一份特别的生日礼物，祝愿您好运常相伴，财源滚滚来！\",\"beginDate\":\"2018年10月31日\",\"configId\":56,\"endDate\":\"2041年07月11日\",\"imgTip\":\"app专享\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/7b1359ab42c89111377af6205c978cab.png\",\"isTop\":0,\"linkUrl\":\"/events/SRLJ\",\"promoCode\":\"SRLJ\",\"promoFlag\":1,\"promoKind\":3,\"title\":\"AG生日礼金十倍奖励为您庆生\"},{\"abstractText\":\"首存时间满一年以上会员，年年可领取高额周年礼金，最高888元！\",\"beginDate\":\"2018年10月30日\",\"configId\":60,\"endDate\":\"2041年07月11日\",\"imgTip\":\"app专享\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/cd4542d1407b43cc9b54bd87d2f00028.png\",\"isTop\":0,\"linkUrl\":\"/events/LHYZN\",\"promoCode\":\"LHYZN\",\"promoFlag\":1,\"promoKind\":3,\"title\":\"周年礼金\"},{\"abstractText\":\"充值、投注 双重积分无限送，随兴兑换 欢乐共享\",\"beginDate\":\"2018年10月28日\",\"configId\":54,\"endDate\":\"2041年07月11日\",\"imgTip\":\"app专享\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/6f0d51897ab17aaf2b7317222d6109c0.png\",\"isTop\":0,\"linkUrl\":\"/events/JFYH\",\"promoCode\":\"JFYH\",\"promoFlag\":1,\"promoKind\":3,\"title\":\"双重积分无限送\"},{\"abstractText\":\"周末逆袭狂欢节，满血复活赢大奖，礼金最高1898 想发就发\",\"beginDate\":\"2018年10月25日\",\"configId\":64,\"endDate\":\"2041年07月11日\",\"imgTip\":\"电游\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/0be15050c055ad13581f96b75aa831bf.png\",\"isTop\":0,\"linkUrl\":\"/events/FHLJYH\",\"promoCode\":\"FHLJYH\",\"promoFlag\":1,\"promoKind\":3,\"title\":\"复活礼金优惠\"},{\"abstractText\":\"凡真钱注册会员升级为网站的会员都可以终身享受会员等级对应的返回比例，真人娱乐最高0.9%\",\"beginDate\":\"2018年10月24日\",\"configId\":59,\"endDate\":\"2041年07月11日\",\"imgTip\":\"真人\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/242b0ec6e37575acf683055e00768646.png\",\"isTop\":1,\"linkUrl\":\"/events/XMFYH\",\"promoCode\":\"XMFYH\",\"promoFlag\":1,\"promoKind\":2,\"title\":\"周周0.9%超高返水\"},{\"abstractText\":\"环亚娱乐特将每月8号设为会员，会员日当天全网会员尽享受红包现金惊喜，力度空前，钜惠来袭！\",\"beginDate\":\"2018年10月23日\",\"configId\":55,\"endDate\":\"2041年07月11日\",\"imgTip\":\"app专享\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/014359eb7cd97e0a95bb9a345428c047.png\",\"isTop\":1,\"linkUrl\":\"/events/HYHB\",\"promoCode\":\"HYHB\",\"promoFlag\":1,\"promoKind\":3,\"title\":\"环亚会员特惠\"},{\"abstractText\":\"英雄集结，协力爆机，大奖无限，只在环亚\",\"beginDate\":\"2018年10月01日\",\"configId\":61,\"endDate\":\"2041年07月11日\",\"imgTip\":\"电游\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/_l/_promo/promo-8.jpg\",\"isTop\":0,\"linkUrl\":\"/events/QMXM\",\"promoCode\":\"QMXM\",\"promoFlag\":1,\"promoKind\":2,\"title\":\"老虎机全民1.2%洗码\"},{\"abstractText\":\"活动期间在AG旗舰厅投注，单笔最低200元及以上，连赢至少7局则有机会可获得最高100万奖金！奖金无上限！连赢13局可参与连赢争霸赛，百万奖金非你莫属！\",\"beginDate\":\"2018年09月12日\",\"configId\":70,\"defaultValue\":\"4\",\"endDate\":\"2018年09月27日\",\"imgTip\":\"结束\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/aedd3204fd4549c8d688ca7508635dd8.png\",\"isTop\":0,\"linkUrl\":\"/events/XAGQJLYS\",\"promoCode\":\"XAGQJLYS\",\"promoFlag\":2,\"promoKind\":4,\"title\":\"AG旗舰连赢赛 千万奖金等你赢\"},{\"abstractText\":\"2星级及以上会员，存款100元及以上后，根据星级获得随机奖励，并可参与博饼翻倍活动，随机有1～5倍，美金月饼，阳澄湖大闸蟹等你拿！机会只有一次，错过等明年！\",\"beginDate\":\"2018年09月24日\",\"configId\":65,\"defaultValue\":\"4\",\"endDate\":\"2018年09月26日\",\"imgTip\":\"结束\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/9ca8e1a6075ef7622829c43cf994248b.png\",\"isTop\":0,\"linkUrl\":\"/events/ZQBB\",\"promoCode\":\"ZQBB\",\"promoFlag\":2,\"promoKind\":4,\"title\":\"中秋聚环亚 博饼夺百万\"},{\"abstractText\":\"累积存款500元即获得一次踢球机会，射门成功则有机会获得最高3,888元进球金，每日9000个名额，射完为止\",\"beginDate\":\"2018年08月16日\",\"configId\":66,\"defaultValue\":\"4\",\"endDate\":\"2018年08月29日\",\"imgTip\":\"结束\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/dszh/0bae89c14a5d1bfa53808d2d875e0d44.png\",\"isTop\":0,\"linkUrl\":\"/events/DQDZ\",\"promoCode\":\"DQDZ\",\"promoFlag\":2,\"promoKind\":4,\"title\":\"点球大战\"},{\"abstractText\":\"双重好礼，千万奖金。勇闯玛莎拉蒂138玩豪车！\",\"beginDate\":\"2017年06月20日\",\"configId\":67,\"defaultValue\":\"4\",\"endDate\":\"2017年07月11日\",\"imgTip\":\"结束\",\"imgUrl\":\"https://a03slotmobileimage.qcyhmv.com/static/A03M/_default/__static/_wms/hongli/139b656aedbbe6f86bd0c04b2d49e4fd.jpg\",\"isTop\":0,\"linkUrl\":\"/events/AGQJLYS\",\"promoCode\":\"AGQJLYS\",\"promoFlag\":2,\"promoKind\":4,\"title\":\"AG旗舰连赢争霸赛\"}]},\"head\":{\"cost\":99,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_QUERYPAYWAYSV3,"{\"body\":{\"payTypeList\":[{\"payType\":21,\"payTypeIcon\":\"paytype21.png\",\"payTypeName\":\"银联WAP\"},{\"payType\":15,\"payTypeIcon\":\"paytype15.png\",\"payTypeName\":\"银联扫码\"},{\"payType\":9,\"payTypeIcon\":\"paytype9.png\",\"payTypeName\":\"支付宝WAP\"},{\"payType\":5,\"payTypeIcon\":\"paytype5.png\",\"payTypeTip\":\"zaky很帅zaky很帅zaky很帅\",\"payTypeName\":\"支付宝扫码\"},{\"payType\":8,\"payTypeIcon\":\"paytype8.png\",\"payTypeName\":\"微信WAP\"},{\"payType\":27,\"payTypeIcon\":\"paytype27.png\",\"payTypeName\":\"云闪付\"},{\"payType\":100,\"payTypeIcon\":\"paytype90.png\",\"payTypeName\":\"银行卡币商\"},{\"payType\":90,\"payTypeIcon\":\"paytype90.png\",\"payTypeName\":\"银行卡转账\"},{\"payType\":92,\"payTypeIcon\":\"paytype92.png\",\"payTypeName\":\"支付宝转账\"},{\"payType\":101,\"payTypeIcon\":\"paytype91.png\",\"payTypeName\":\"微信币商\"},{\"payType\":102,\"payTypeIcon\":\"paytype92.png\",\"payTypeName\":\"支付宝币商\"},{\"payType\":19,\"payTypeIcon\":\"paytype19.png\",\"payTypeName\":\"网银快捷支付MOB\"},{\"payType\":91,\"payTypeIcon\":\"paytype91.png\",\"payTypeName\":\"微信转账\"},{\"payType\":17,\"payTypeIcon\":\"paytype17.png\",\"payTypeName\":\"京东WAP\"},{\"payType\":16,\"payTypeIcon\":\"paytype16.png\",\"payTypeName\":\"京东扫码\"},{\"payType\":1,\"payTypeIcon\":\"paytype1.png\",\"payTypeName\":\"网银在线支付\"},{\"payType\":11,\"payTypeIcon\":\"paytype11.png\",\"payTypeName\":\"QQWAP\"},{\"payType\":7,\"payTypeIcon\":\"paytype7.png\",\"payTypeName\":\"QQ扫码\"},{\"payType\":20,\"payTypeIcon\":\"paytype20.png\",\"payTypeName\":\"比特币\"},{\"payType\":23,\"payTypeIcon\":\"paytype23.png\",\"payTypeName\":\"微信条码\"}]},\"head\":{\"cost\":708,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")
            apiResponseMap.put(SIMULATEAPI_QUERYONLINEBANKS,"{\"body\":{\"amountType\":{\"fix\":0,\"amounts\":[200,500,1000,2000]},\"bankList\":[],\"maxAmount\":2000,\"minAmount\":150,\"netEarn\":0,\"payid\":\"306\"},\"head\":{\"cost\":222,\"errCode\":\"0000\",\"errMsg\":\"操作成功\"}}")

        }

        const val SIMULATEAPI_SENDCODE = "sms/sendCode"
        const val SIMULATEAPI_LOGINBYMOBILENO = "customer/loginByMobileNo"
        const val SIMULATEAPI_GETBYLOGINNAME = "customer/getByLoginName"
        const val SIMULATEAPI_HOMEBEST = "_extra_/a03/home/best"
        const val SIMULATEAPI_FINDPROMODATAS = "_extra_/a03/findPromoDatas"
        const val SIMULATEAPI_GETBALANCE  = "_glaxy_a03_/customer/getBalance"
        const val SIMULATEAPI_UPGRADE  = "_glaxy_a03_/upgrade"
        const val SIMULATEAPI_QUERYSPORTS   = "_glaxy_a03_/_extra_/a03/querySports"
        const val SIMULATEAPI_QUERYBYKEYLIST   = "_glaxy_a03_/_extra_/a03/queryByKeyList"
        const val SIMULATEAPI_GAMEPLATFORMS_QUERYBYKEYLIST   = "gamePlatforms"
        const val SIMULATEAPI_HOMEGAME  = "home/game"
        const val SIMULATEAPI_QUERYGAMELIST  = "queryGameList"
        const val SIMULATEAPI_TITLE_QUERYBYKEYLIST   = "title"
        const val SIMULATEAPI_LIMITREDVALUE_QUERYBYKEYLIST   = "limitRedValue"

        const val SIMULATEAPI_QUERYIMAGELIST   = "_glaxy_a03_/_extra_/a03/queryImageList"
        const val SIMULATEAPI_APPHOMETYPIC_QUERYIMAGELIST   =  "APP_HOME_TY_PIC"
        const val SIMULATEAPI_HOMEOTHER   = "_glaxy_a03_/_extra_/a03/home/other"
        const val SIMULATEAPI_GETNOTICE =   "_glaxy_a03_/message/getNotice"
        const val SIMULATEAPI_GETASSISTANT   = "_glaxy_a03_/message/getAssistant"

        const val SIMULATEAPI_QUERYARTICLES  = "article/queryArticles"

        const val SIMULATEAPI_LETTERQUERY   = "_glaxy_a03_/letter/query"
        const val SIMULATEAPI_VIPSQUERYXMRATE  = "_glaxy_a03_/_extra_/a03/vips/queryXMRate"
        const val SIMULATEAPI_QUERYVIPPREMIUMS  = "queryVipPremiums"
        const val SIMULATEAPI_MYPROMO = "a03MyPromo"

        const val SIMULATEAPI_QUERYPAYWAYSV3  = "queryPayWaysV3"
        const val SIMULATEAPI_QUERYONLINEBANKS = "queryOnlineBanks"


    }





}
