package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.*
import com.ultimate.ag.a03.net.*

class VipPrivilegeModel : IModel {

    /**
     * 获取账户余额
     */
    fun getBalance(request: GetBalanceRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<GetBalanceResponse>) {
        ApiClient.instance.service.getBalance(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetBalanceResponse>(activity!!, false) {
                    override fun businessFail(data: GetBalanceResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: GetBalanceResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }


    /**
     * 获取VIP特享信息
     */
    fun getVipPremiums(request: VipPremiumsRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<VipPremiumsReponse>) {
        ApiClient.instance.frontService.queryVipPremiums(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<VipPremiumsReponse>() {
                    override fun businessFail(data: VipPremiumsReponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: VipPremiumsReponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 获取VIP洗码比例
     */
    fun getXMRate(request: XMRateRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<XMRateResponse>) {
        ApiClient.instance.frontService.queryXMRate(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<XMRateResponse>() {
                    override fun businessFail(data: XMRateResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: XMRateResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }


    /**
     * 领取VIP特享
     */
    fun getPromotions(request: PromotionsRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<PromotionsResponse>) {
        ApiClient.instance.frontService.queryPromotions(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<PromotionsResponse>() {
                    override fun businessFail(data: PromotionsResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: PromotionsResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 菲律宾游报名
     */
    fun queryApplys(request: TravelRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<TravelResponse>) {
        ApiClient.instance.frontService.queryApplys(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<TravelResponse>() {
                    override fun businessFail(data: TravelResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: TravelResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }

                })
    }

    /**
     * 菲律宾游报名
     */
    fun insertApplyVisits(request: VipVisitRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<VipVisitResponse>) {
        ApiClient.instance.frontService.insertApplyVisits(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<VipVisitResponse>() {
                    override fun businessFail(data: VipVisitResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: VipVisitResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 电话回拨
     */
    fun mobileCall(request: VipVisitRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<VipVisitResponse>) {
//        ApiClient.instance.service.mobileCall(request)
        ApiClient.instance.frontService.insertApplyVisits(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<VipVisitResponse>() {
                    override fun businessFail(data: VipVisitResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: VipVisitResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 查询晋级礼金,盈利返利,菲律宾游状态
     */
    fun viewPromotionsStatus(request: PromotionsStatusRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<PromotionsStatusResponse>) {
        ApiClient.instance.frontService.viewPromotionsStatus(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .safeSubscribe(object : ApiMvpResponse<PromotionsStatusResponse>() {
                    override fun businessFail(data: PromotionsStatusResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: PromotionsStatusResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}