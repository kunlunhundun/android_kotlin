package com.ultimate.ag.a03.database

import android.text.TextUtils
import com.ultimate.ag.a03.config.ConfigUtils
import org.litepal.LitePal
import org.litepal.crud.DataSupport


/**
 * Created by ward.y on 2018/4/2.
 */
object DataBaseHelper {

    @JvmStatic
    fun creatDataBase() {
        LitePal.getDatabase()
    }


    @JvmStatic
    fun getUrl(): UrlData? {
        var urlData = DataSupport.findFirst(UrlData::class.java)
        return if (urlData != null) {
            urlData
        } else {
            when(ConfigUtils.MODEL){
                ConfigUtils.MODEL_RUNTIME ->ConfigUtils.baseUrl = ConfigUtils.runUrl
                ConfigUtils.MODEL_RUNTIME_TEST ->ConfigUtils.baseUrl = ConfigUtils.testGateUrl
                ConfigUtils.MODEL_NATIVAL_TEST ->ConfigUtils.baseUrl = ConfigUtils.testUrl
            }
            val urlData = UrlData()
            urlData.url = ConfigUtils.runGateUrl
            urlData.frontUrl = ConfigUtils.frontUrl
            urlData.domain = ConfigUtils.baseUrl!!.split("//")[1].split("/")[0]
            ConfigUtils.DOMAIN_NAME = urlData.domain!!
            urlData.addUrl = ConfigUtils.addUrl
            urlData.saveOrUpdate("urlId = ?", "1")
            urlData
        }

    }

    @JvmStatic
    fun updateUrl(url: String) {
        ConfigUtils.baseUrl = url
        val urlData = UrlData()
        urlData.url = ConfigUtils.runGateUrl
        urlData.frontUrl = ConfigUtils.frontUrl
        if (url.contains("//")) {
            urlData.domain = ConfigUtils.baseUrl.split("//")[1]
            ConfigUtils.DOMAIN_NAME = urlData.domain!!
        }

        urlData.saveOrUpdate("urlId = ?", "1")
    }

    @JvmStatic
    fun updateAddUrl(url: String) {
        val urlData = UrlData()
        urlData.addUrl = url
        urlData.saveOrUpdate("urlId = ?", "1")
    }




    @JvmStatic
    fun getWashCode(loginName: String): WashCodeRecord? {
        var records = DataSupport.where("loginName =?", loginName).find(WashCodeRecord::class.java)
        return if (records != null && !records.isEmpty()) {
            records[0]
        } else {
            null
        }
    }

    @JvmStatic
    fun updataOneTime() {
        val washCodeRecord = WashCodeRecord()
        washCodeRecord.loginName = ConfigUtils.loginName
        washCodeRecord.firstTime = 1
        washCodeRecord.saveOrUpdate("loginName=?", ConfigUtils.loginName)
    }

    @JvmStatic
    fun updataBankOneTime() {
        val washCodeRecord = WashCodeRecord()
        washCodeRecord.loginName = ConfigUtils.loginName
        washCodeRecord.bankfirstTime = 1
        washCodeRecord.saveOrUpdate("loginName=?", ConfigUtils.loginName)
    }

    @JvmStatic
    fun updateTowTime() {
        val washCodeRecord = WashCodeRecord()
        washCodeRecord.loginName = ConfigUtils.loginName
        washCodeRecord.firstTime = 2
        washCodeRecord.saveOrUpdate("loginName=?", ConfigUtils.loginName)
    }


    @JvmStatic
    fun getLockStatus(token: String): LockRecord? {

        var records = DataSupport.where("token =?", token).find(LockRecord::class.java)

        return if (records != null && !records.isEmpty()) {
            records[0]
        } else {
            val lockRecord = LockRecord()
            lockRecord.fingerPrint = false
            lockRecord.gestureLock = false
            lockRecord.token = ConfigUtils.loginName
            lockRecord.saveOrUpdate("token = ?", ConfigUtils.loginName)
            lockRecord
        }
    }

    /**
     * app是否第一次安装
     */
    @JvmStatic
    fun updateAppInstall(state: String) {
        val appData = AppInstall()
        appData.state = state
        appData.saveOrUpdate("state = ?", state)
    }

    @JvmStatic
    fun getAppInstall(): AppInstall? {
//        var appData = DataSupport.where("loginName =?", loginName).find(WashCodeRecord::class.java)
        var appData = DataSupport.findFirst(AppInstall::class.java)
        return if (appData != null) {
            appData
        } else {
            null
        }
    }

    /**
     * H5 Version update
     */
    @JvmStatic
    fun updateH5Version(ver: String, md5: String) {
        var h5Version = DataSupport.findFirst(H5Version::class.java)
        if (null == h5Version) {
            h5Version = H5Version()
        }
        h5Version.version = ver
        h5Version.md5 = md5
        h5Version.save()
    }


    /**
     * H5 Version getinstance
     */
    @JvmStatic
    fun getH5Version(): H5Version {
        if (null == DataSupport.findFirst(H5Version::class.java)) {
            updateH5Version("30", "")
        }
        return DataSupport.findFirst(H5Version::class.java)
    }


}