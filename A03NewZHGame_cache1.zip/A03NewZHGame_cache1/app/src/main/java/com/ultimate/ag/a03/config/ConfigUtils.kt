package com.ultimate.ag.a03.config

import android.util.Base64
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.data.InfoObject
import com.ultimate.ag.a03.data.request.AutoLoginRequest
import com.ultimate.ag.a03.data.request.GetH5TokenByAppRequest
import com.ultimate.ag.a03.data.response.AutoLoginResponse
import com.ultimate.ag.a03.data.response.GetDeviceIdResponse
import com.ultimate.ag.a03.data.response.GetH5TokenByAppResponse
import com.ultimate.ag.a03.database.DataBaseHelper
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler

/**
 * Created by ward.y on 2018/2/23.
 */
object ConfigUtils {
    const val testUrl = "http://www.pt-gateway.com"//本地测试环境
    const val runUrl = "https://www.hygame03.com"//运营环境
    const val testGateUrl = "http://m3.hwx22.com"//运营测试环境

    const val MODEL_RUNTIME = 3
    const val MODEL_RUNTIME_TEST = 2
    const val MODEL_NATIVAL_TEST = 1
    //TODO 运行的时候修改此变量为需要的环境即可，提交代码的时候，务必改成BuildConfig.MODEL
    //TODO 提交代码的时候，务必改成BuildConfig.MODEL
    //TODO 提交代码的时候，务必改成BuildConfig.MODEL
    //TODO 提交代码的时候，务必改成BuildConfig.MODEL
    const val MODEL = BuildConfig.MODEL

    var baseUrl = ""
        set(value) {
            field = value
            runGateUrl = "$field/_glaxy_a03_"
            frontUrl = "$field/_glaxy_a03_/_extra_"
        }

    var baseDataUrl = "https://gather.neptuneapi.com:9443"
        get() {
            val baseUrl = ApiClient.instance.baseUrl
            if (baseUrl.contains(testUrl)) {
                return "http://10.66.72.97:8082"
            } else if (baseUrl.contains(testGateUrl)) {
                return "http://testgather.bawinx.com"
            } else if (baseUrl.contains(runUrl)) {
                return "https://gather.neptuneapi.com:9443"
            }
            return "https://gather.neptuneapi.com:9443"
        }


    //TODO 这里为了调试先把测试连接放在正式环境的变量下,调试完即改回
    var runGateUrl = ""
    //新特性网关
    var frontUrl = ""
    const val addUrl = "http://addr.neptuneapi.com:8888"
    const val TingYunKey = "a26d2c6b5aa54bd8a83967d8a00d7e96"

    const val USER_TYPE_TRY = 0
    const val USER_TYPE_OLD = 2

    const val USER_TYPE_NEW = 1
    const val USER_TYPE_USERNAME_NEW = 2
    var bankCardCounts = 0
    var mobileNo: String? = null
    var loginTime: String? = null
    var avatar: String? = null
    var bankCardNum: Int = 0
    var btcNum: Int = 0
    var parentId = ""
    var isBindMobile = false
    var showNavigation = true
    var isAGLobby = false
    var isTable = false
    var changeAccountTime: Long = 0

    @JvmStatic
    var sessionId = ""

    @JvmStatic
    var deviceIdInfo: GetDeviceIdResponse? = null

    var lastLoginDate: String? = null

    var loginDate: String? = null

    var registDate: String? = null

    var starLevel: Int = 0
    var depositLevel: Int = 0
    var promoTime: Int = 0
        set(value) {
            var time = MyApplication.getinstance().mAcach.getAsString("PROMOTIME")
            if (time != null && time.isNotEmpty()) {
                field = time.toInt()
            }
        }


    var networkError = false
    var loginName: String? = null
        set(value) {
            field = value
            if (currentUserType != USER_TYPE_TRY) {
                MyApplication.getinstance().mAcach.put("loginName", field)
            }
        }
        get() {
            if (field == null) {
                field = MyApplication.getinstance().mAcach.getAsString("loginName")
            }
            return field
        }


    var token: String? = null
        set(value) {
            field = value
            MyApplication.getinstance().mAcach.put("webtoken", field ?: "")
        }

    var realName: String? = null
    var customerId: String? = null
        set(value) {
            field = value
            MyApplication.getinstance().mAcach.put("customerId", field)
        }

    var currentUserType: Int = USER_TYPE_TRY

    var NOticeTag = false

    var info: String? = ""
        set(value) {
            field = value
            val x = String(Base64.decode(ConfigUtils.info, Base64.DEFAULT))
            val info = Gson().fromJson(x, InfoObject::class.java)
            ConfigUtils.key = info.u2token
//            if (TextUtils.isEmpty(AppInitManager.getAcache().getAsString("token"))){
            ConfigUtils.token = info.token
//            }

//            LogUtils.e(ConfigUtils.token!!+"------token")
        }

    var webInfo: String? = null
    var publicKey: String = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSu2AZPdT2Fqpqxctx3EbnRuuYdBxFZDYG7MASIgw/DFl3P9FAp7S9WaQjdM1NmgBDgvfUWx1xj72LNz4EP4Euh9EESKceNCeoE4M8ZP4ENUQX0nDMbpmIG3/JCI8B5Iv2FKj2q0gGbE0WsLdrYDzFXTYbZKRJSbMMjHT3HtKD/wIDAQAB"

    var key: String? = null
        set(value) {
            field = value
            MyApplication.getinstance().mAcach.put("key", field)
        }
        get() {
            if (field == null) {
                field = MyApplication.getinstance().mAcach.getAsString("key")
            }
            return field
        }

    var DOMAIN_NAME = ""
        get() {
            if (field == "") {
                val urlData = DataBaseHelper.getUrl()
                field = urlData?.domain!!

            }
            return field
        }

    var isTryPlayer: Boolean = true

    val GAME_PAYLINES: String? = "GAME_PAYLINES"
    val GAME_PLATFORM_CODES: String? = "GAME_PLATFORM_CODES"
    val GAME_TABS: String? = "GAME_TABS"

    val GAME_SEARCH_REQUEST_CODE: Int = 1001
    val GAME_SEARCH_HISTORY: String? = "GAME_SEARCH_HISTORY"
    val TOPIC_TITLE_DATA: String? = "TOPIC_TITLE_DATA"
    val TOPIC_ARTICLE_TYPE: Int = 1
    val STRENGTH_ARTICLE_TYPE: Int = 2
    var verifyCode: String? = null
    val PARAM_AVATAR_URL: String? = "param_avatar_url"
    val PARAM_ORDER_DETAIL: String = "param_order_detail"
    val UPGRADE_DATA: String = "UPGRADE_DATA"
    val RECHARGE_COMPELET: Int = 2000
    var isH5Ready = false

    var h5WebToken:String? = null

}