package com.ultimate.ag.a03

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.support.multidex.MultiDexApplication
import android.util.Log
import android.widget.FrameLayout
import android.widget.RelativeLayout
import android.widget.Toast
import com.bumptech.glide.Glide
import com.ivi.library.statistics.ThreeStatisticsManager
import com.rea.push.helper.PushHelper
import com.ultimate.ag.a03.activity.AGActivity
import com.ultimate.ag.a03.activity.FirstPageActivity
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.data.MessgeNotifyObject
import com.ultimate.ag.a03.database.DataBaseHelper
import com.ultimate.ag.a03.hybride.MyWebView
import com.ultimate.ag.a03.manager.ActivityListManager
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.util.ACache
import com.ultimate.ag.a03.util.Utils
import com.ultimate.ag.a03.view.ItemAgWebView


/**
 * Created by ward.y on 2018/3/10.
 */
class MyApplication : MultiDexApplication(), ComponentCallbacks2 {
    lateinit var activityListManager: ActivityListManager
    lateinit var mAcach: ACache

    var agWebViewGame : ItemAgWebView? = null
    var fl_container : FrameLayout? = null

    companion object {
        var instance: MyApplication? = null
        var webviewUUID: String? = null
        var gameResult:AGQJGameResult?= AGQJGameResult.WAIT
        fun getinstance() = instance!!
        val messgeNotifyObject = MessgeNotifyObject()
    }

    //AGQJ游戏当前状态
    enum class AGQJGameResult{
        WAIT,
        TO_LOBBY_SUCCESS,
        DISCONNECT
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        val curProcess = getProcessName(this, android.os.Process.myPid())
        if (!getPackageName().equals(curProcess)) {
            return
        }
        Utils.startEvent(getString(R.string.three_statistics_init))
        AppInitManager.initApp(this)
       // ThreeStatisticsManager.init(this, "A03", ConfigUtils.loginName)
        val appInstall = DataBaseHelper.getAppInstall()
        if ("already" != appInstall?.state) {
            ConfigUtils.token = ""
            ConfigUtils.loginName = ""
            AppInitManager.getAcache().remove("newAdUrl")
            AppInitManager.getAcache().remove("adLink")
        }

    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)

        Log.d("MemoryLeak", "$level   onTrimMemory")
        if (level == ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            Glide.get(this).clearMemory()
        }
        Glide.get(this).trimMemory(level)

    }

    override fun onLowMemory() {
        super.onLowMemory()
        Log.d("MemoryLeak", "onLowMemory")
        Glide.get(this).clearMemory()
    }

    open fun loginOut() {
        ConfigUtils.loginName = ""
        ConfigUtils.realName = ""
        ConfigUtils.token = ""
        ConfigUtils.isBindMobile = false
        ConfigUtils.mobileNo = ""
        ConfigUtils.customerId = ""
        //清除缓存本地用户组
        if (MyApplication.getinstance().mAcach.getAsString("loginArr") != null) {
            MyApplication.getinstance().mAcach.put("loginArr", "")
        }
        //清除token
        Utils.clearToken()
        Toast.makeText(this, "您已于别处登录，请重新登录", Toast.LENGTH_LONG).show()
        val intent = Intent(this, FirstPageActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        PushHelper.restartService(MyApplication.instance)
    }

    fun getProcessName(cxt: Context, pid: Int): String? {
        val am = cxt.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningApps = am!!.getRunningAppProcesses() ?: return null
        for (procInfo in runningApps) {
            if (procInfo.pid === pid) {
                return procInfo.processName
            }
        }
        return null
    }

}