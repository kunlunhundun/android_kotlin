package com.ultimate.ag.a03.fingerprint;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.wangnan.library.GestureLockThumbnailView;
import com.wangnan.library.GestureLockView;
import com.wangnan.library.listener.OnGestureLockListener;
import com.wangnan.library.painter.AliPayPainter;

import com.ultimate.ag.a03.R;
import com.ultimate.ag.a03.activity.FirstPageActivity;
import com.ultimate.ag.a03.activity.LoginActivity;
import com.ultimate.ag.a03.activity.MainActivity;
import com.ultimate.ag.a03.activity.UnlockDetailActivity;
import com.ultimate.ag.a03.config.ConfigUtils;
import com.ultimate.ag.a03.database.DataBaseHelper;
import com.ultimate.ag.a03.database.LockRecord;
import com.ultimate.ag.a03.util.StatusBarUtil;
import com.ultimate.ag.a03.view.CommonDialog;
import com.ultimate.ag.a03.view.CustomDialogView;


/**
 * Created by ward.y on 2018/4/13.
 */

public class CommonFragment extends DialogFragment implements View.OnClickListener,
        OnGestureLockListener, DialogInterface.OnDismissListener {

    public static final String TYPE = "type";    //指纹 or gesture

    public static final int FINGERPRINT = 1;
    public static final int GESTURE_SET = 2;
    public static final int GESTURE_SET_CONFIRM = 3;
    public static final int GESTURE_UNLOCK = 4;
    public static final int GESTURE_OFF = 5;
    private int count = 3;

    public int getType() {
        return type;
    }

    private int type = 0;

    private TextView mTextViewHint;
    private GestureLockThumbnailView gestureLockThumbnailView;
    private GestureLockView gestureLockView;
    private TextView tv_tip, toolbar_title;
    Vibrator vibrator;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // 使用不带Theme的构造器, 获得的dialog边框距离屏幕仍有几毫米的缝隙。
        Dialog dialog = new Dialog(getActivity(), R.style.BottomDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // 设置Content前设定
        vibrator = (Vibrator) getActivity().getSystemService(Service.VIBRATOR_SERVICE);
        Bundle bundle = getArguments();

        if (bundle != null) {
            type = bundle.getInt(TYPE, 1);
            switch (type) {
                case FINGERPRINT:
                    dialog.setContentView(R.layout.fragment_finger);
                    initFingerView(dialog);
                    break;
                case GESTURE_SET:
                case GESTURE_SET_CONFIRM:
                case GESTURE_OFF:
                    dialog.setContentView(R.layout.fragment_gesture_unlock);
                    initGestureView(dialog);
                    break;
                case GESTURE_UNLOCK:
                    dialog.setContentView(R.layout.fragment_gesture_unlock_login);
                    initGestureLoginView(dialog);
                    break;

            }
        } else {
            dialog.setContentView(R.layout.fragment_finger);
            initFingerView(dialog);
        }


        dialog.setCanceledOnTouchOutside(true); // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        final Window window = dialog.getWindow();
        setTranslucentStatus(window);
        window.setWindowAnimations(R.style.MyPopupWindow_anim_style);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        final WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT; // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT; // 宽度持平
        lp.gravity = Gravity.CENTER;
        window.setAttributes(lp);


        return dialog;
    }

    private void initFingerView(Dialog dialog) {
        dialog.findViewById(R.id.btn_cancel).setOnClickListener(this);
        mTextViewHint = dialog.findViewById(R.id.tv_hint);
    }


    private void initGestureView(Dialog dialog) {
        gestureLockThumbnailView = dialog.findViewById(R.id.gltv);
        gestureLockView = dialog.findViewById(R.id.gl_locker);
        tv_tip = dialog.findViewById(R.id.tv_tip);
        toolbar_title = dialog.findViewById(R.id.toolbar_title);
        dialog.findViewById(R.id.toolbar_icon).setOnClickListener(this);
        dialog.findViewById(R.id.tv_relogin).setOnClickListener(this);
        gestureLockView.setPainter(new AliPayPainter());
        gestureLockView.setGestureLockListener(this);
        switch (getType()) {
            case GESTURE_SET:
                setTv_tip(getString(R.string.unlock_activity_draw_gesture));
                dialog.findViewById(R.id.tv_relogin).setVisibility(View.GONE);
                break;
            case GESTURE_SET_CONFIRM:
                dialog.findViewById(R.id.tv_relogin).setVisibility(View.GONE);
                setTv_tip(getString(R.string.unlock_activity_draw_gesture_again));
                break;
            case GESTURE_UNLOCK:
                gestureLockThumbnailView.setVisibility(View.INVISIBLE);
                setTv_tip(getString(R.string.unlock_activity_gesture_unlock));
                setTitle(getString(R.string.unlock_activity_unlock_gesture));
                break;
            case GESTURE_OFF:
                gestureLockThumbnailView.setVisibility(View.INVISIBLE);
                setTitle(getString(R.string.unlock_activity_unlock_gesture));
                setTv_tip(getString(R.string.unlock_activity_gesture_unlock));
                break;
        }

    }


    private void initGestureLoginView(Dialog dialog) {

        gestureLockView = dialog.findViewById(R.id.gl_locker);
        tv_tip = dialog.findViewById(R.id.tv_tip);
        gestureLockView.setPainter(new AliPayPainter());
        gestureLockView.setGestureLockListener(this);
        setTv_tip("");
        dialog.findViewById(R.id.tv_forget).setOnClickListener(this);
        dialog.findViewById(R.id.tv_change).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                dismiss();
                break;
            case R.id.toolbar_icon:
                dismiss();
                break;
            case R.id.btn_cancel:
                dismiss();
                break;
            case R.id.tv_forget: {
                final CustomDialogView dialog = new CustomDialogView(getActivity());
                dialog.showCustomViewDialog(0f);
                dialog.setTitle(getString(R.string.unlock_activity_unlock_forget_tip));
                dialog.setBtnCancelOnclick(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.setBtnOkOnclick(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        updateStatus(false);
                        updatePWD("");
                        dialog.dismiss();
                        ConfigUtils.INSTANCE.setLoginName("");
                        ConfigUtils.INSTANCE.setRealName("");
                        ConfigUtils.INSTANCE.setToken("");
                        ConfigUtils.INSTANCE.setMobileNo("");
                        ConfigUtils.INSTANCE.setBindMobile(false);
                        Intent intent = new Intent(getActivity(), FirstPageActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent
                                .FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        dismiss();
                    }
                });

                dialog.setBtnRight(getString(R.string.unlock_activity_unlock_pwd));
            }
            break;
            case R.id.tv_relogin: {
                final CustomDialogView dialog = new CustomDialogView(getActivity());
                dialog.showCustomViewDialog(0f);
                dialog.setTitle(getString(R.string.unlock_activity_unlock_forget_tip));
                dialog.setBtnCancelOnclick(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.setBtnOkOnclick(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        updateStatus(false);
                        updatePWD("");
                        dialog.dismiss();
                        ConfigUtils.INSTANCE.setLoginName("");
                        ConfigUtils.INSTANCE.setRealName("");
                        ConfigUtils.INSTANCE.setToken("");
                        ConfigUtils.INSTANCE.setMobileNo("");
                        ConfigUtils.INSTANCE.setBindMobile(false);
                        Intent intent = new Intent(getActivity(), FirstPageActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent
                                .FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        dismiss();
                    }
                });
                dialog.setBtnRight(getString(R.string.unlock_activity_unlock_pwd));
            }

            break;

            case R.id.tv_change: {

                Intent intent = new Intent(getActivity(), FirstPageActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);

            }

            break;
        }
    }

    /**
     * 指纹错误提示
     */

    public boolean setTextHint() {
        if (mTextViewHint != null) {
            mTextViewHint.setText("指纹识别失败，请重试！");
            mTextViewHint.setTextColor(getResources().getColor(R.color.colorAccent));
            Animation shake = AnimationUtils.loadAnimation(getActivity(), R.anim.text_shake);
            mTextViewHint.startAnimation(shake);
            return true;
        }
        return false;
    }

    public void setTv_tip(String tip) {
        tv_tip.setTextColor(0xFF999999);
        tv_tip.setText(tip);
    }

    public void setTitle(String title) {

        toolbar_title.setText(title);
    }

    public void setError_tip(String tip) {
        tv_tip.setTextColor(getResources().getColor(R.color.colorAccent));
        tv_tip.setText(tip);
        Animation shake = AnimationUtils.loadAnimation(getActivity(), R.anim.text_shake);
        tv_tip.startAnimation(shake);
        vibrator.vibrate(600);
    }

    @Override
    public void onStarted() {

    }

    @Override
    public void onProgress(String progress) {
        if (null != gestureLockThumbnailView) {
            gestureLockThumbnailView.setThumbnailView(progress, 0xFF8095FF);
        }

    }

    @SuppressLint("StringFormatInvalid")
    @Override
    public void onComplete(String result) {
        switch (getType()) {
            case GESTURE_SET:
                if (gestureLockView.getmPressPoints().size() < 5) {
                    gestureLockView.showErrorStatus(1500);
                    setError_tip(getString(R.string.unlock_activity_draw_gesture_too_simple));
                    return;
                }
                updatePWD(result);
                gestureLockView.clearView();
                setTv_tip(getString(R.string.unlock_activity_draw_gesture_again));
                type = GESTURE_SET_CONFIRM;
                break;
            case GESTURE_SET_CONFIRM:
                if (result.equalsIgnoreCase(DataBaseHelper.INSTANCE.getLockStatus(ConfigUtils
                        .INSTANCE.getLoginName()).getGestureLockPwd())) {
                    updateStatus(true);
                    dismiss();
                    ((UnlockDetailActivity) getActivity()).showToast(UnlockDetailActivity
                            .Companion.getTYPE_GESTURE_ON());
                } else {
                    gestureLockView.showErrorStatus(2000);
                    setError_tip(getString(R.string.unlock_activity_gesture_unlock_failure));
                }
                break;
            case GESTURE_UNLOCK:
                if (result.equalsIgnoreCase(DataBaseHelper.INSTANCE.getLockStatus(ConfigUtils
                        .INSTANCE.getLoginName()).getGestureLockPwd())) {
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                    getActivity().finish();
                } else {
                    if (count > 0) {
                        gestureLockView.showErrorStatus(2000);
                        setError_tip(String.format(getString(R.string
                                .unlock_activity_gesture_unlock_error), count));
                        count--;
                    } else {
                        gestureLockView.showErrorStatus(2000);
                        setError_tip(getString(R.string
                                .unlock_activity_gesture_unlock_error_need_login));
                        showNeedLogin();
                    }

                }
                break;
            case GESTURE_OFF:
                if (result.equalsIgnoreCase(DataBaseHelper.INSTANCE.getLockStatus(ConfigUtils
                        .INSTANCE.getLoginName()).getGestureLockPwd())) {
                    updateStatus(false);
                    updatePWD("");
                    dismiss();
                    ((UnlockDetailActivity) getActivity()).showToast(UnlockDetailActivity
                            .Companion.getTYPE_GESTURE_OFF());
                } else {
                    if (count > 0) {
                        gestureLockView.showErrorStatus(2000);
                        setError_tip(String.format(getString(R.string
                                .unlock_activity_gesture_unlock_error), count));
                        count--;
                    } else {
                        Intent intent = new Intent(getActivity(), LoginActivity.class);
                        startActivity(intent);
                        getActivity().finish();
                    }

                }
                break;
        }
    }


    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        final Activity activity = getActivity();
        if (activity instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) activity).onDismiss(dialog);
        }
    }


    private void updateStatus(boolean status) {
        LockRecord record = new LockRecord();
        record.setToken(ConfigUtils.INSTANCE.getLoginName());
        record.setGestureLock(status);
        record.saveOrUpdate("token=?", record.getToken());
    }

    private void updatePWD(String pwd) {
        LockRecord record = new LockRecord();
        record.setToken(ConfigUtils.INSTANCE.getLoginName());
        record.setGestureLockPwd(pwd);
        record.saveOrUpdate("token=?", record.getToken());
    }


    private void showNeedLogin() {
        Bundle bundle = new Bundle();
        bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_2);
        CommonDialog dialog = new CommonDialog();
        dialog.setArguments(bundle);
        dialog.show(getFragmentManager(), "dialog");
        dialog.getBtn_ok().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quit();
            }
        });

    }


    //
    private void setTranslucentStatus(Window window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        StatusBarUtil.INSTANCE.StatusBarLightMode(window);
    }


    private void quit() {
        updateStatus(false);
        updatePWD("");
        ConfigUtils.INSTANCE.setLoginName("");
        ConfigUtils.INSTANCE.setRealName("");
        ConfigUtils.INSTANCE.setToken("");
        ConfigUtils.INSTANCE.setMobileNo("");
        ConfigUtils.INSTANCE.setBindMobile(false);

        Intent intent = new Intent(getActivity(), FirstPageActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

    }
}


