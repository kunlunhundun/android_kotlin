package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.ModifyLimitRedRequest
import com.ultimate.ag.a03.data.request.RedLimitedRequest
import com.ultimate.ag.a03.data.response.ModifyLimitRedResponse
import com.ultimate.ag.a03.data.response.RedLimitedResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler

class ChangeLimitModel : IModel {

    /**
     * 修改限红
     */
    fun modifyLimitRed(request: ModifyLimitRedRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<ModifyLimitRedResponse>) {
        ApiClient.instance.service.modifyLimitRed(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<ModifyLimitRedResponse>() {
                    override fun businessFail(data: ModifyLimitRedResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: ModifyLimitRedResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 获取当前限红
     */
    fun getRedLimited(request: RedLimitedRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<RedLimitedResponse>) {
        ApiClient.instance.frontService.queryByKeyList2(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .subscribe(object : ApiMvpResponse<RedLimitedResponse>() {
                    override fun businessFail(data: RedLimitedResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: RedLimitedResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }

                })
    }
}