package com.ultimate.ag.a03.hybride

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.support.annotation.RequiresApi
import android.text.TextUtils
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.ultimate.ag.a03.activity.MainActivity
import com.ultimate.ag.a03.database.DataBaseHelper
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.LoadingDialog
import com.ultimate.ag.a03.util.LogUtils
import com.ultimate.ag.a03.util.ToastUtils
import java.net.URISyntaxException

open class BaseWebViewClient(activity: Activity) : WebViewClient() {

    var mActivity = activity


    override fun onPageStarted(view: WebView?, url: String, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)

    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)

    }


    override fun shouldOverrideUrlLoading(webview: WebView?, url: String?): Boolean {

        if (TextUtils.isEmpty(url)) {
            return false
        }
        try {
            //处理intent协议
            if (url!!.startsWith("intent://")) {
                val intent: Intent
                try {
                    intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    intent.addCategory("android.intent.category.BROWSABLE")
                    intent.component = null
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
                        intent.selector = null
                    }
                    val resolves = mActivity.getPackageManager().queryIntentActivities(intent, 0)
                    if (resolves.size > 0) {
                        mActivity.startActivityIfNeeded(intent, -1)
                    }
                    return true
                } catch (e: URISyntaxException) {
                    e.printStackTrace()
                }

            }
            if (url.startsWith("hyzh://game/agqj")) {
                MainActivity.changeTag = "ag"
                AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)
                return true
            }
            // 处理自定义scheme协议
            if (!url.startsWith("http")) {
                try {
                    // 以下固定写法
                    val intent = Intent(Intent.ACTION_VIEW,
                            Uri.parse(url))
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    mActivity.startActivity(intent)
                } catch (e: Exception) {
                    // 防止没有安装的情况
                    e.printStackTrace()
                    ToastUtils.show("您所打开的第三方App未安装！")
                }

                return true
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        val uri = Uri.parse(url) ?: return false

        if ((url ?: "").contains("BaccaratMasters")) {
            return super.shouldOverrideUrlLoading(webview, url)
        }
        //点击回退键
        if (DataBaseHelper.getUrl()?.domain?.equals(uri.host) == true) {
            webview?.reload()
            mActivity.finish()
            return true
        }
        return super.shouldOverrideUrlLoading(webview, url)
    }

}