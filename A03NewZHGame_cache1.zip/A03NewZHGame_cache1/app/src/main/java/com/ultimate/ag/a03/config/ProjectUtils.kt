package com.ultimate.ag.a03.config

import android.os.Environment
import android.text.TextUtils
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.MyApplication

object ProjectUtils {

    const val PID = "A03"
    const val APPID = "A03DS01"
    const val APP_CODE = "f"
    const val APP_VERSION = BuildConfig.VERSION_NAME // 请求的app版本号
    const val GATEWAY_VERSION = "2.3.0" // 请求的网关版本号
    // 判断是否进入app，false表示进入h5马甲包判断流程, true 表示进入主包
    const val isNormalApp = true


    const val PUSH_CODE = "A03_HYZH"
    const val ABC_GAME_CODE = "A03003"
    const val EGAME_CODE = "A03027"
    const val SPORT_GAME_CODE = "A03031"
    const val BB_SPORT_GAME_CODE = "A03017"
    const val SPORT_GAME_CODE_HUANYA = "A03062" // 环亚
    val mAssetsWebUrl = "file://${MyApplication.getinstance().externalCacheDir}/a03/zh/web/index.html#"
    val webFiieRoute = "${MyApplication.getinstance().externalCacheDir}/a03/zh"
    val oldWebFiieRoute = "${Environment.getExternalStorageDirectory().path}/a03/zh"

    const val FILE_PROVIDER = "${BuildConfig.APPLICATION_ID}.fileprovider"
    //TODO 测试环境使用jay的地址
//    var mAssetsWebUrl = "file:///android_asset/web/index.html#"
    //        var mAssetsWebUrl = "http://10.71.66.146:1024/#"
    val type_error_empty: Int = 1
    val type_error_lenth: Int = 2
    val type_error_formate: Int = 3
    val type_success: Int = 4

    @JvmStatic
    fun checkPwdAvailable(pwd: String): Int {
        return if (!TextUtils.isEmpty(pwd)) {
            if (pwd.trim().length in (8..16)) {
                val r1 = Regex("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9a-zA-Z]{8,16}$")
                if (r1.matches(pwd)) {
                    type_success
                } else {
                    type_error_formate
                }

            } else {
                type_error_lenth
            }
        } else {
            type_error_empty
        }
    }

    @JvmStatic
    fun checkPTPwdAvailable(pwd: String): Int {
        return if (!TextUtils.isEmpty(pwd)) {
            if (pwd.trim().length in (8..16)) {
                val r1 = Regex("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9a-zA-Z]{8,16}$")
                if (r1.matches(pwd)) {
                    type_success
                } else {
                    type_error_formate
                }

            } else {
                type_error_lenth
            }
        } else {
            type_error_empty
        }
    }


    @JvmStatic
    fun checkUserNameAvailable(pwd: String): Int {

        return if (!TextUtils.isEmpty(pwd)) {
            if (pwd.trim().length in (5..11)) {
                val r1 = Regex("^[0-9a-zA-Z]{5,11}$")
//                val r1 = Regex("^(?![0-9]+\$)(?![a-zA-Z]+\$)[0-9a-zA-Z]{5,11}$")

                if (!(pwd.trim().startsWith("F") || pwd.trim().startsWith("f"))) {
                    return type_error_formate
                }

                if (r1.matches(pwd)) {
                    type_success
                } else {
                    type_error_formate
                }

            } else {
                type_error_lenth
            }
        } else {
            type_error_empty
        }
    }

    /**
     * 原来客户端注册的会员用户名是不带f限制4-15位
     */
    @JvmStatic
    fun checkOldUserNameAvailable(pwd: String): Int {

        return if (!TextUtils.isEmpty(pwd)) {
            if (pwd.trim().length in (5..15)) {

                if (!pwd.trim().startsWith("f")) {
                    return type_error_formate
                }

                val r1 = Regex("^[0-9a-zA-Z]{5,15}$")
                if (r1.matches(pwd)) {
                    type_success
                } else {
                    type_error_formate
                }

            } else {
                type_error_lenth
            }
        } else {
            type_error_empty
        }
    }


}