/*
 * Tencent is pleased to support the open source community by making VasSonic available.
 *
 * Copyright (C) 2017 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 *
 * https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 *
 *
 */

package com.ultimate.ag.a03.hybride

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.Environment
import android.text.TextUtils
import android.view.View
import android.view.WindowManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast
import com.tencent.sonic.sdk.SonicEngine
import com.tencent.sonic.sdk.SonicSession
import com.tencent.sonic.sdk.SonicSessionConfig
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.activity.BaseToolBarActivity
import com.ultimate.ag.a03.util.*
import com.ultimate.ag.a03.view.ActionRulesDialog
import com.vector.update_app.UpdateAppBean
import com.vector.update_app.UpdateAppManager
import com.vector.update_app.service.DownloadService
import kotlinx.android.synthetic.main.activity_browser.*
import java.io.File




/**
 * Sonic WebActivity
 * @author Ward.Y
 */

open class BrowserActivity : BaseToolBarActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_browser
    }


    private var sonicSession: SonicSession? = null
    private var sonicSessionClient: SonicSessionClientImpl? = null
    var mUrl: String? = null
    var mTitleName: String? = null
    private var mode: Int? = null
    private var isFullScreen: Boolean = false
    private var isShowActionBar: Boolean = false
    private var isSupportZoom: Boolean = false
    private var mCallback = BrowserCallback()
    private var mHtmlContent: String? = null
    var mAudioManager: AudioManager? = null
    var isPause = false

    companion object {
        const val PARAM_URL = "param_url"
        const val PARAM_HTML_CONTENT = "param_html_content"
        const val PARAM_MODE = "mode"
        const val PARAM_FULL_SCREEN = "full_screen"
        const val PARAM_SHOW_ACTION_BAR = "show_action_bar"
        const val PARAM_TITLE_NAME = "title_name"
        const val PARAM_SUPPORT_ZOOM = "param_support_zoom"
        const val PARAM_MODE_SONIC = 1
        const val PARAM_MODE_DEAFAULT = 0

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        mUrl = intent.getStringExtra(PARAM_URL)
        mTitleName = intent.getStringExtra(PARAM_TITLE_NAME)
        setTile(mTitleName ?: "")
        mHtmlContent = intent.getStringExtra(PARAM_HTML_CONTENT)
        mode = intent.getIntExtra(PARAM_MODE, PARAM_MODE_DEAFAULT)
        isSupportZoom = intent.getBooleanExtra(PARAM_SUPPORT_ZOOM, false)
        isFullScreen = intent.getBooleanExtra(PARAM_FULL_SCREEN, false)
        isShowActionBar = intent.getBooleanExtra(PARAM_SHOW_ACTION_BAR, false)
        if (TextUtils.isEmpty(mUrl) && TextUtils.isEmpty(mHtmlContent)) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)

        if (mode == PARAM_MODE_SONIC) {
            sonicSessionClient = SonicSessionClientImpl()
            val sessionConfigBuilder = SonicSessionConfig.Builder()
            sessionConfigBuilder.setSupportLocalServer(true)
            sonicSession = SonicEngine.getInstance().createSession(mUrl!!, sessionConfigBuilder.build())
            if (null != sonicSession) {
                sonicSession!!.bindClient(sonicSessionClient)
            } else {
                LogUtils.e("create sonic session fail!")
            }
        }

        if (isFullScreen) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            val statusBarHeight = StatusBarUtil.getStatusBarHeight(this)
            findViewById<View>(android.R.id.content).setPadding(0, statusBarHeight, 0, 0)
        }

        if (isShowActionBar) {
            tool_bar.visibility = View.VISIBLE
        }

        if (isSupportZoom) {
            webview.settings.setSupportZoom(true)
            webview.settings.builtInZoomControls = true
            webview.settings.displayZoomControls = false
        }
        showRightTitle()
        StatusBarUtil.StatusBarLightMode(this)

        mAudioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        super.onSaveInstanceState(outState)
        webview.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
        super.onRestoreInstanceState(savedInstanceState)
        webview.restoreState(savedInstanceState)
    }

    private fun showRightTitle(){
        var rightTitleType = intent.getIntExtra(IntentConstant.WEBVIEW_RIGHT_TITLE_TYPE, 0)
        if (rightTitleType == 1) {
            setActionText("活动规则")
            getActionView()?.setOnClickListener {
                ActionRulesDialog().show(supportFragmentManager, "")
            }
        }
    }

    @SuppressLint("AddJavascriptInterface")
    override fun initData() {

        // init webview
        webview.settings.allowFileAccess = true
        //设置监听web tit
        webview.webChromeClient = object : WebChromeClient() {

            override fun onReceivedTitle(view: WebView?, title: String) {
                super.onReceivedTitle(view, title)
                if (mTitleName != null) {
                    setTile(mTitleName ?: "")
                } else {
                    setTile(title)
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                Toast.makeText(this@BrowserActivity, message, Toast.LENGTH_SHORT).show()
                result!!.cancel()
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {

                progress.progress = newProgress
                if (newProgress==100){
                    progress.visibility =View.GONE
                    progress.progress = 0
                }
                super.onProgressChanged(view, newProgress)
            }

        }

        webview.webViewClient = BaseWebViewClient(this)
        webview.removeJavascriptInterface("searchBoxJavaBridge_")
        webview.addJavascriptInterface(SonicJavaScriptInterface(sonicSessionClient, this, mCallback), "discover")

        if (TextUtils.isEmpty(mHtmlContent)) {
            //加载网址
            if (sonicSessionClient != null) {
                sonicSessionClient?.bindWebView(webview)
                sonicSessionClient?.clientReady()
            } else { // default mode
                webview.loadUrl(mUrl)
                LogUtils.d("weburl-------->>>>>>>$mUrl")
            }
        } else {
            //加载Html文本
            webview.settings.defaultTextEncodingName = "UTF -8"
//            webView.loadData(mHtmlContent, "text/html", "UTF-8")
            webview.loadData(mHtmlContent, "text/html; charset=UTF-8", null)
        }

    }

    override fun initListener() {
        webview.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            downLoadApp(url)

        }
    }


    override fun onPause() {
        super.onPause()
        isPause = true
        if (webview != null) {
            webview.onPause()
        }

    }

    override fun onResume() {
        super.onResume()
        if (webview != null) {
            webview.onResume()
        }

        isPause = false
    }

    override fun onDestroy() {
        if (null != sonicSession) {
            sonicSession?.destroy()
            sonicSession = null
        }
        super.onDestroy()
        if (webview != null) {
            webview.destroy()
        }

        mAudioManager?.abandonAudioFocus(audioFocusChangeListener)
    }

    inner class BrowserCallback : CommonCallback {

        override fun onCalled() {
            finish()
        }
    }

    private fun downLoadApp(mDyAppDownUrl: String) {
        if (!TextUtils.isEmpty(mDyAppDownUrl)) {
            val updateAppBean = UpdateAppBean()

            //设置 apk 的下载地址
            updateAppBean.apkFileUrl = mDyAppDownUrl
            var path: String? = ""
            if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED || !Environment.isExternalStorageRemovable()) {
                try {
                    path = baseContext.externalCacheDir?.absolutePath
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (TextUtils.isEmpty(path)) {
                    path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                }
            } else {
                path = baseContext.cacheDir?.absolutePath
            }

            //设置apk 的保存路径
            updateAppBean.targetPath = path
            //实现网络接口，只实现下载就可以
            updateAppBean.httpManager = UpdateAppHttpUtil()
            updateAppBean.dismissNotificationProgress(true)
//
//            UpdateAppManager.download(baseContext, updateAppBean, null)

            UpdateAppManager.download(this, updateAppBean, object : DownloadService.DownloadCallback {

                override fun onStart() {
                    HProgressDialogUtils.showHorizontalProgressDialog(this@BrowserActivity,
                            "${webview.title}下载中", false)
                }

                override fun onProgress(progress: Float, totalSize: Long) {
                    HProgressDialogUtils.setProgress(Math.round(progress * 100))

                }

                override fun setMax(totalSize: Long) {
                }

                override fun onFinish(file: File): Boolean {
                    HProgressDialogUtils.cancel()
                    return true
                }

                override fun onError(msg: String) {
                    HProgressDialogUtils.cancel()
                }

                override fun onInstallAppAndAppOnForeground(file: File): Boolean {
                    return false
                }
            })

        }
    }

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        if (isPause && focusChange == AudioManager.AUDIOFOCUS_LOSS) {
            requestAudioFocus()
        }
    }

    private fun requestAudioFocus() {
        val result = mAudioManager?.requestAudioFocus(audioFocusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {

        }

    }
}
