package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.ModifyLimitRedResponse
import com.ultimate.ag.a03.data.response.RedLimitedResponse

interface ChangeLimitView: IBaseView{

    /**
     * 修改限红成功
     */
    fun modifyLimitRedSuccess(data: ModifyLimitRedResponse)

    /**
     * 修改限红失败
     */
    fun modifyLimitRedFail(data: ModifyLimitRedResponse)

    /**
     * 显示当前限红
     */
    fun showRedLimited(data: RedLimitedResponse)
}