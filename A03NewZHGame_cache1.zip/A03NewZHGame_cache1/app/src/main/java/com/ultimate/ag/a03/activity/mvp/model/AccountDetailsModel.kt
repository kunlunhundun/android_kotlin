package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.request.BQBanksRequest
import com.ultimate.ag.a03.data.request.BalanceRequest
import com.ultimate.ag.a03.data.request.ToGameRequest
import com.ultimate.ag.a03.data.request.ToLocalRequest
import com.ultimate.ag.a03.data.response.BQBanksResponse
import com.ultimate.ag.a03.data.response.BalanceResponse
import com.ultimate.ag.a03.data.response.ToGameResponse
import com.ultimate.ag.a03.data.response.ToLocalResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler

class AccountDetailsModel: IModel{

    /**
     * 获取账户明细界面当前余额
     */
    fun getBalance(request: BalanceRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<BalanceResponse>){
        ApiClient.instance.service.getBalance(request)
                .bindUntilEvent(activity,ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<BalanceResponse>(){
                    override fun businessFail(data: BalanceResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: BalanceResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }


    /**
     * PT转账
     */
    fun transferToGame(request: ToGameRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<ToGameResponse>) {
        ApiClient.instance.service.transferToGame(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<ToGameResponse>() {
                    override fun businessFail(data: ToGameResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: ToGameResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 转账至本地
     */
    fun transferToLocal(request: ToLocalRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<ToLocalResponse>) {
        ApiClient.instance.service.transferToLocal(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<ToLocalResponse>() {
                    override fun businessFail(data: ToLocalResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: ToLocalResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 最后一次转账记录
     */
    fun queryBQBanks(request: BQBanksRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<BQBanksResponse>) {
        ApiClient.instance.service.queryBQBanks(request)
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<BQBanksResponse>() {
                    override fun businessFail(data: BQBanksResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: BQBanksResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }
}