package com.ultimate.ag.a03.activity

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.GlideDrawable
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.data.BankCardObj
import com.ultimate.ag.a03.data.request.CardManagerRequest
import com.ultimate.ag.a03.data.request.CreatMPRequest
import com.ultimate.ag.a03.data.request.GetBalanceRequest
import com.ultimate.ag.a03.data.response.CardManagerResponse
import com.ultimate.ag.a03.data.response.CreatWPResponse
import com.ultimate.ag.a03.data.response.GetBalanceResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.*
import com.ultimate.ag.a03.view.CommonDialog
import com.ultimate.ag.a03.view.StopUseBTCDialog
import kotlinx.android.synthetic.main.activity_withdraw_deposit.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper
import java.lang.Exception
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Created by ward.y on 2018/2/23.
 * 提现页面
 */
class WithdrawDepositActivity : BaseToolBarActivity(), TextWatcher {
    var datas: GetBalanceResponse? = null
    var beforeText: String? = null
    var btcRate: String? = null
    override fun afterTextChanged(p0: Editable?) {
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        beforeText = p0.toString()
    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        if (datas == null) {
            return
        }

        var withDrawBal: Double = datas?.body?.withdrawBal?.toDouble() ?: 0.00
        var inputAmountValue = if (et_recharge_amount.text.toString() == "") {
            0.00
        } else {
            et_recharge_amount.text.toString().toDouble()
        }

        if (0.00 == withDrawBal) {
            et_recharge_amount.text.clear()
            ToastUtils.show("您现在没有可提现余额")
        } else {
            when {
//                TextUtils.isEmpty(et_recharge_amount.text.toString()) -> tv_display_btb.text = ""
                inputAmountValue > withDrawBal -> {
                    et_recharge_amount.setText(beforeText)
                    et_recharge_amount.setSelection(beforeText!!.length - 1)
                    ToastUtils.show("超出可提现余额")
                }
//                inputAmountValue == 0.00 -> {
//                    et_recharge_amount.setText("")
//                    return
//                }

                tv_display_btb.visibility == View.VISIBLE -> {
                    tv_btc_tip.text = "约等于 ${BigDecimal(inputAmountValue).divide(BigDecimal(btcRate), 8, BigDecimal.ROUND_DOWN)} BTC"
                }
//                else -> {
//                    if (tv_display_btb.visibility == View.VISIBLE && null != btcRate && btcRate!!.toFloat() > 0f) {
//                        tv_display_btb.text = "约等于 ${BigDecimal(BigDecimal(et_recharge_amount.text.toString()).toDouble().div(btcRate!!.toDouble())).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()} BTC"
//                    }
//                }
            }
        }
    }

    lateinit var list: MutableList<BankCardObj>
    var accountId: String? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_withdraw_deposit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidWorkaround.assistActivity(findViewById(android.R.id.content))
        StatusBarUtil.StatusBarLightMode(this)
        setTile(getString(R.string.withdraw_deposit_page_title))
        setBackground(R.color.white)
        isShowBack(true)
        OverScrollDecoratorHelper.setUpOverScroll(sv_withdraw_deposit)
        et_recharge_amount.addTextChangedListener(this)
        list = mutableListOf()

        getBalance()
        if (!ConfigUtils.isBindMobile) {
            goToPage(Intent(this, BindMobilePhoneGuideActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        requestCardMsg()
    }

    /**
     * 获取用户账户金额
     */
    private fun getBalance() {
        val request = GetBalanceRequest()
        ApiClient.instance.service.getBalance(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetBalanceResponse>(this, true) {
                    override fun businessFail(data: GetBalanceResponse) {

                    }

                    override fun businessSuccess(data: GetBalanceResponse) {
                        datas = data
                        tv_balance.text = Utils.formatMoney(data.body?.withdrawBal!!)
                        et_recharge_amount.hint = String.format(getString(R.string.withdraw_deposit_page_input), data.body?.minWithdrawAmount?.toInt())
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }


    private fun requestCardMsg() {
        val request = CardManagerRequest()
        ApiClient.instance.service.cardManager(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.PAUSE)
                .subscribe(object : ApiResponse<CardManagerResponse>(this, false) {
                    override fun businessFail(data: CardManagerResponse) {
                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()
                    }

                    override fun businessSuccess(data: CardManagerResponse) {
                        if (data.body.accounts.size < 1) {

                            val intent = if (TextUtils.isEmpty(ConfigUtils.realName)) {
                                Intent(this@WithdrawDepositActivity, CompleteProfileActivity::class.java)
                            } else {
                                Intent(this@WithdrawDepositActivity, AddBankCardActivity::class.java)
                            }
                            startActivity(intent)
                            finish()
                        } else {
                            list.clear()
                            accountId = data?.body?.accounts?.get(0)?.accountId
                            btcRate = data.body.btcRate?.setScale(8, RoundingMode.HALF_UP)?.stripTrailingZeros()?.toPlainString()
                            list = data?.body?.accounts!!
                            var accountNo = data.body!!.accounts[0].accountNo
                            var banckNo = accountNo.substring(accountNo.length - 4)
                            var bankType = data.body!!.accounts[0].accountType
                            var msg = "尾号$banckNo $bankType"
                            var bankName = data.body!!.accounts[0].bankName

                            if ("BTC" == (bankType) && (data?.body?.accounts?.get(0)?.flag == "1")) {
                                tv_display_btb.visibility = View.VISIBLE
                                tv_display_btb.text = "比特币当前汇率 $btcRate"
                                tv_btc_tip.visibility = View.VISIBLE
                            } else {
                                tv_display_btb.visibility = View.GONE
                                tv_btc_tip.visibility = View.GONE
                            }

                            if (data.body?.accounts[0].flag == "0") {
                                tv_pay_other_way.visibility = View.VISIBLE
                                tv_bank_name.setTextColor(Color.parseColor("#999999"))
                                tv_next.setBackgroundResource(R.drawable.bg_button_next_disable)
                                tv_next.setTextColor(Color.parseColor("#cccccc"))
                                tv_next.isClickable = false
                            }

                            tv_bank_name.text = bankName
                            tv_bank_name_des.text = msg
                            Glide.with(baseContext).load(data.body!!.accounts[0].bankIcon).listener(object : RequestListener<String, GlideDrawable> {
                                override fun onException(e: Exception?, model: String?, target: Target<GlideDrawable>?, isFirstResource: Boolean): Boolean {
                                    return false
                                }

                                override fun onResourceReady(resource: GlideDrawable?, model: String?, target: Target<GlideDrawable>?, isFromMemoryCache: Boolean, isFirstResource: Boolean): Boolean {
                                    return if (data.body?.accounts[0].flag == "0") {
                                        resource!!.mutate().alpha = 100
                                        iv_card.setImageDrawable(resource)
                                        true
                                    } else {
                                        false
                                    }


                                }

                            })
                                    .placeholder(R.mipmap.blank_card_icon)
                                    .error(R.mipmap.blank_card_icon)
                                    .into(iv_card)
                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }

    override fun initListener() {

        tv_all.setOnClickListener {
            datas?.body?.let {
                var withdrawBal: Double = it.withdrawBal?.toDouble() ?: 0.0
                var minWithdrawAmount: Double = it.minWithdrawAmount?.toDouble() ?: 0.0
                if (withdrawBal < minWithdrawAmount) {
                    ToastUtils.show("最小提现金额为${minWithdrawAmount}")
                } else {
                    et_recharge_amount.setText("${it.withdrawBal}")
                }
            }

        }

        iv_withdraw_info.setOnClickListener {
            val bundle = Bundle()
            bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_WITHDRAW_TIP)
            val dialog = CommonDialog()
            dialog.arguments = bundle
            dialog.show(supportFragmentManager, "debug")
        }

        rl_bank_account.setOnClickListener { showpopupWindow(rl_bank_account) }

        rl_with_draw_preview.setOnClickListener {
            createAdDialog()
        }
    }

    private fun createAdDialog(): CommonDialog {

        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_WITHDRAW_PREVIEW)
        val dialog = CommonDialog()
        dialog?.arguments = bundle
        dialog?.show(supportFragmentManager, "dialog")
        return dialog
    }

    override fun initData() {

        tv_next.setOnClickListener(View.OnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@OnClickListener
            }
            KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext)

            if (accountId == null) {
                Toast.makeText(this, "网络请求失败", Toast.LENGTH_LONG).show()
                return@OnClickListener
            }
            if (TextUtils.isEmpty(et_recharge_amount.text.toString())) {
                Toast.makeText(this, "金额不能为空", Toast.LENGTH_LONG).show()
                return@OnClickListener
            }

            var data = CreatMPRequest()
            data.accountId = accountId
            data.amount = BigDecimal(et_recharge_amount.text.toString())
            request(data)
        })
    }


    private fun request(data: CreatMPRequest) {
        ApiClient.instance.service.creatWithdrawalsProposal(data)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatWPResponse>(this, true) {
                    override fun businessFail(data: CreatWPResponse) {

                        when (data.head.errCode) {
                            "WS_304817" -> {
                                var intent = Intent()
                                intent.setClass(this@WithdrawDepositActivity, TradingRecordActivity::class.java)
                                intent.putExtra("index", 2)
                                startActivity(intent)
                            }

                        }

                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()

                    }

                    override fun businessSuccess(data: CreatWPResponse) {
                        var intent = Intent()
                        intent.putExtra("money", Gson().toJson(data.body))
                        intent.putExtra("tag", 0)
                        intent.setClass(this@WithdrawDepositActivity, CreatWPActivity::class.java)
                        startActivity(intent)
                        finish()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        Toast.makeText(baseContext, apiErrorModel.message, Toast.LENGTH_LONG).show()
                    }

                })
    }

    private fun showpopupWindow(v: View) {
        KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext)
        val layoutInflater = LayoutInflater.from(this@WithdrawDepositActivity)
        val view = layoutInflater.inflate(R.layout.popup_window_bank_card_selected_view, null)
        val close: ImageView = view.findViewById(R.id.iv_close)
        val manager: TextView = view.findViewById(R.id.tv_card_manager)
        val title: TextView = view.findViewById(R.id.tv_title)
        val listview: ListView = view.findViewById(R.id.lv_bank_card)

        title.text = "选择收款方式"
        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(this, 300f), true)
        // 如果不设置PopupWindow的背景，无论是点击外部区域还是Back键都无法dismiss弹框
        popupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        popupWindow.isOutsideTouchable = true
        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style

        listview.adapter = ListViewAdapter(this@WithdrawDepositActivity, list)
        val footer: View = LayoutInflater.from(this).inflate(R.layout.bottom_bank_card_list_view, null)
        footer.setOnClickListener(View.OnClickListener {
            var intent = Intent()
            intent.setClass(this, AddBankCardActivity::class.java)
            startActivityForResult(intent, 2)
            popupWindow.dismiss()
        })
        manager.setOnClickListener(View.OnClickListener {
            var intent = Intent()
            intent.setClass(this, CardManagerActivity::class.java)
            startActivity(intent)
            popupWindow.dismiss()
        })

        if (list.size < 4) {
            listview.addFooterView(footer, null, false)
        }

        listview.setOnItemClickListener { _, _, i, _ ->

            if (list[i]?.flag == "0") {
                popupWindow.dismiss()
                var dialog = StopUseBTCDialog()
                dialog.show(fragmentManager, "22")
                return@setOnItemClickListener
            }
            accountId = list[i]?.accountId
            Glide.with(baseContext).load(list[i].bankIcon)
                    .placeholder(R.mipmap.blank_card_icon)
                    .error(R.mipmap.blank_card_icon)
                    .into(iv_card)
            tv_bank_name.text = list[i].bankName
            var accountNo = list[i].accountNo
            var banckNo = accountNo.substring(accountNo.length - 4)
            var bankType = list[i].accountType
            var msg = "尾号$banckNo $bankType"
            tv_bank_name_des.text = msg

            if ("BTC" == (list[i]?.accountType) && (list[i]?.flag == "1")) {
                tv_display_btb.visibility = View.VISIBLE
                tv_btc_tip.visibility = View.VISIBLE
                tv_display_btb.text = "比特币当前汇率 $btcRate"
                et_recharge_amount.hint = "请输入"
                datas?.body?.withdrawBal?.let {
                    tv_btc_tip.text = "最多可提现 ${it.divide(BigDecimal(btcRate), 8, BigDecimal.ROUND_DOWN)} BTC"
                }

            } else {
                et_recharge_amount.hint = String.format(getString(R.string.withdraw_deposit_page_input), datas?.body?.minWithdrawAmount?.toInt())
                tv_all.setTextColor(resources.getColor(R.color.color_7c86e9))
                tv_display_btb.visibility = View.GONE
                tv_btc_tip.visibility = View.GONE
            }

            if (tv_pay_other_way.visibility == View.VISIBLE) {
                tv_bank_name.setTextColor(Color.parseColor("#333333"))
                tv_next.setBackgroundResource(R.drawable.bg_button_next)
                tv_next.setTextColor(resources.getColor(R.color.them_text_color))
                tv_next.isClickable = true
            }


            popupWindow.dismiss()
            tv_pay_other_way.visibility = View.GONE
        }

        // PopupWindow弹出位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)

        view_bg.visibility = View.VISIBLE
        popupWindow.setOnDismissListener { view_bg.visibility = View.GONE }
        close.setOnClickListener { popupWindow.dismiss() }

    }

    inner class ListViewAdapter(context: Context, data: MutableList<BankCardObj>) : BaseAdapter() {
        var mContext: Context = context
        var data: MutableList<BankCardObj> = data
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var holder: MyViewHolder
            var v: View
            if (convertView == null) {
                holder = MyViewHolder()
                v = LayoutInflater.from(mContext).inflate(R.layout.item_list_bank_card_view, parent, false)
                holder.iv_icon = v.findViewById(R.id.iv_icon)
                holder.tv_bank_name = v.findViewById(R.id.tv_bank_name)
                holder.tv_bank_card_des = v.findViewById(R.id.tv_bank_card_des)
                holder.line = v.findViewById(R.id.line)
                holder.tempeStop = v.findViewById(R.id.tv_tempe_stop)
                v.tag = holder

            } else {
                v = convertView
                holder = v.tag as MyViewHolder
            }

            Glide.with(baseContext).load(data[position].bankIcon).listener(object : RequestListener<String, GlideDrawable> {
                override fun onException(e: Exception?, model: String?, target: Target<GlideDrawable>?, isFirstResource: Boolean): Boolean {
                    return false
                }

                override fun onResourceReady(resource: GlideDrawable?, model: String?, target: Target<GlideDrawable>?, isFromMemoryCache: Boolean, isFirstResource: Boolean): Boolean {
                    return if (data[position].flag == "0") {
                        resource!!.mutate().alpha = 100
                        holder.iv_icon.setImageDrawable(resource)
                        true
                    } else {
                        false
                    }


                }

            })
                    .placeholder(R.mipmap.blank_card_icon)
                    .error(R.mipmap.blank_card_icon)
                    .into(holder.iv_icon)

            if (data[position].flag == "0") {
                holder.tempeStop.visibility = View.VISIBLE
                if (data[position].accountType == "BTC") {
                    holder.tempeStop.text = "维护中"
                }
                holder.tv_bank_name.setTextColor(Color.parseColor("#999999"))

            } else {
                holder.tv_bank_name.setTextColor(Color.parseColor("#333333"))
                holder.tempeStop.visibility = View.GONE
            }
            holder.tv_bank_name.text = data[position].bankName
            var accountNo = data[position].accountNo
            var banckNo = accountNo.substring(accountNo.length - 4)
            var bankType = data[position].accountType
            var msg = "尾号$banckNo $bankType"
            holder.tv_bank_card_des.text = msg
            return v
        }

        override fun getItem(p0: Int): Any {
            return data[p0]
        }

        override fun getItemId(p0: Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return data.size
        }

        inner class MyViewHolder {
            lateinit var iv_icon: ImageView
            lateinit var tv_bank_name: TextView
            lateinit var tv_bank_card_des: TextView
            lateinit var line: TextView
            lateinit var tempeStop: TextView
        }
    }
}