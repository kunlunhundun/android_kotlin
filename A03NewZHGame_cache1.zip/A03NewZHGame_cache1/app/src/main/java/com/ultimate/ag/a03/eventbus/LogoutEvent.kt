package com.ultimate.ag.a03.eventbus

/**
 * @author Javan.W
 * @date   2019/3/25
 * @Description 退出登录
 */
class LogoutEvent {
}