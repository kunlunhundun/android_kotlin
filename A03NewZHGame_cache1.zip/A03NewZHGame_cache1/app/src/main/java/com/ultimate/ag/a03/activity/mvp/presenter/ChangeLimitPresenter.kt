package com.ultimate.ag.a03.activity.mvp.presenter

import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.ChangeLimitModel
import com.ultimate.ag.a03.activity.mvp.view.ChangeLimitView
import com.ultimate.ag.a03.data.request.ModifyLimitRedRequest
import com.ultimate.ag.a03.data.request.RedLimitedRequest
import com.ultimate.ag.a03.data.response.ModifyLimitRedResponse
import com.ultimate.ag.a03.data.response.RedLimitedResponse
import com.ultimate.ag.a03.net.ApiErrorModel

class ChangeLimitPresenter : BasePresenter<ChangeLimitView, ChangeLimitModel>() {

    /**
     * 修改限红
     */
    fun modifyLimitRed(request: ModifyLimitRedRequest){
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.modifyLimitRed(request,view!!.getRxActivity(), object : MvpCallback<ModifyLimitRedResponse>{
            override fun onSuccess(data: ModifyLimitRedResponse) {
                if (!isViewAttached)
                    return

                view?.modifyLimitRedSuccess(data)
            }

            override fun onBusinessFail(data: ModifyLimitRedResponse) {

                if (!isViewAttached)
                    return

                view?.modifyLimitRedFail(data)
            }

            override fun onFail(model: ApiErrorModel) {

                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {

                if (isViewAttached)
                    view?.cancelLoading()
            }

        })

    }


    /**
     * 查看限红
     */
    fun getLimitRed(request: RedLimitedRequest){
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.getRedLimited(request,view!!.getRxActivity(), object : MvpCallback<RedLimitedResponse>{
            override fun onSuccess(data: RedLimitedResponse) {
                if (!isViewAttached)
                    return

                view?.showRedLimited(data)
            }

            override fun onBusinessFail(data: RedLimitedResponse) {

                if (!isViewAttached)
                    return

                view?.showToast(data.head.errMsg!!)
            }

            override fun onFail(model: ApiErrorModel) {

                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {

                if (isViewAttached)
                    view?.cancelLoading()
            }

        })

    }
}