package com.ultimate.ag.a03.activity.mvp.presenter

import com.google.gson.Gson
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.ChoicenessModel
import com.ultimate.ag.a03.activity.mvp.view.ChoicenessView
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.data.request.GetOnlineNumRequest
import com.ultimate.ag.a03.data.request.HomeBestRequest
import com.ultimate.ag.a03.data.request.InGameRequest
import com.ultimate.ag.a03.data.request.PromoDataRequest
import com.ultimate.ag.a03.data.response.GetOnlineNumResponse
import com.ultimate.ag.a03.data.response.HomeBestResponse
import com.ultimate.ag.a03.data.response.InGameResponse
import com.ultimate.ag.a03.data.response.PromoDataResponse
import com.ultimate.ag.a03.net.ApiErrorModel
import java.util.*

class ChoicenessPresenter : BasePresenter<ChoicenessView, ChoicenessModel>() {

    var promoShowed = 0 //0: 不需要展示  1: 需要展示未展示  2: 已展示
    var vipShowed = 0 //0: 不需要展示  1: 需要展示未展示  2: 已展示


    fun showData() {
        var dataString = MyApplication.instance!!.mAcach.getAsString("homeBest")
        if (null != dataString) {
            var data = Gson().fromJson<HomeBestResponse>(dataString, HomeBestResponse::class.java)
            view?.showBanner(data.body.bannerImages)
            view?.showTotalPromoAmount(data.body.totalPromoAmount)
            view?.showHotGames(data.body.hotGames)
            view?.initHotGamesListener(data.body.hotGames)
            view?.showTopPlayers(data.body.topPlayers)
            view?.showithdrawState(data.body.withdrawTimeCost, data.body.pendingWithdrawCount)
        }
    }


    /**
     * 获取数据
     */
    fun getData(request: HomeBestRequest) {
        if (!isViewAttached)
            return
        model?.getNetData(request, view!!.getRxActivity(), object : MvpCallback<HomeBestResponse> {
            override fun onSuccess(data: HomeBestResponse) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(true)
                MyApplication.getinstance().mAcach.put("homeBest", Gson().toJson(data))
                view?.showBanner(data.body.bannerImages)
                view?.showTotalPromoAmount(data.body.totalPromoAmount)
                view?.showHotGames(data.body.hotGames)
                view?.initHotGamesListener(data.body.hotGames)
                view?.showTopPlayers(data.body.topPlayers)
                view?.showithdrawState(data.body.withdrawTimeCost, data.body.pendingWithdrawCount)

            }

            override fun onBusinessFail(data: HomeBestResponse) {

                if (!isViewAttached)
                    return
                view?.finishRefresh(false)
                view?.getDataFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)

                view?.finishRefresh(false)
            }

            override fun complete() {

                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * 进入游戏
     */
    fun inGame(request: InGameRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.inGameNet(request, view!!.getRxActivity(), object : MvpCallback<InGameResponse> {
            override fun onSuccess(data: InGameResponse) {

                if (!isViewAttached)
                    return

                view?.startGame(data.body!!.url)
            }

            override fun onBusinessFail(data: InGameResponse) {
                if (!isViewAttached)
                    return

                view?.inGameFail(data)
            }

            override fun onFail(model: ApiErrorModel) {

                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 获取在线游戏人数
     */
    fun getOnlineNumber(request: GetOnlineNumRequest) {
        if (!isViewAttached)
            return
        model?.getOnlineNumber(request, view!!.getRxActivity(), object : MvpCallback<GetOnlineNumResponse> {
            override fun onSuccess(data: GetOnlineNumResponse) {

                if (!isViewAttached)
                    return
                view?.setOnlineNumber(data)
            }

            override fun onBusinessFail(data: GetOnlineNumResponse) {
                if (!isViewAttached)
                    return
                view?.hideOnlineNumber()
            }

            override fun onFail(model: ApiErrorModel) {

                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }


    /**
     * 获取每日红利
     */
    fun getPromaData(request: PromoDataRequest) {
        if (!isViewAttached)
            return
        model?.getPromoDatas(request, view!!.getRxActivity(), object : MvpCallback<PromoDataResponse> {
            override fun onSuccess(data: PromoDataResponse) {

                if (!isViewAttached)
                    return

                var time = Date().day
                if (ConfigUtils.promoTime != time) {
                    ConfigUtils.promoTime = time
                    MyApplication.getinstance().mAcach.put("PROMOTIME", time.toString())
                    if (data.body.promoList!!.isNotEmpty())
                        promoShowed = 1

                    if (data.body.promoVipList!!.isNotEmpty())
                        vipShowed = 1
                }
            }

            override fun onBusinessFail(data: PromoDataResponse) {
                if (!isViewAttached)
                    return
//                view?.showToast(data.head.errMsg!!)
            }

            override fun onFail(model: ApiErrorModel) {

//                if (isViewAttached)
//                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * 控制是否显示领取红利弹窗
     */
    fun getPromoShowed() {
        if (promoShowed == 1) {
            promoShowed = 2
            view?.showPromoDialog()
        } else if (vipShowed == 1) {
            vipShowed = 2
            view?.showVipDialog()
        }
    }
}