package com.ultimate.ag.a03.activity.mvp.presenter

import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.RegisterModel
import com.ultimate.ag.a03.activity.mvp.view.RegisterView
import com.ultimate.ag.a03.data.request.UsernameRegisterRequest
import com.ultimate.ag.a03.data.response.UserNameRegisterResponse
import com.ultimate.ag.a03.net.ApiErrorModel

/**
 * 注册presenter
 */
class RegisterPresenter : BasePresenter<RegisterView, RegisterModel>() {


    /**
     * 用户名注册
     */
    fun usernameRegister(request: UsernameRegisterRequest) {

        if (!isViewAttached)
            return

        view?.showLoading()

        model?.usernameRegister(request, view!!.getRxActivity(), object : MvpCallback<UserNameRegisterResponse> {
            override fun onSuccess(data: UserNameRegisterResponse) {

                if (!isViewAttached)
                    return

                view?.registerSucess()
            }

            override fun onBusinessFail(data: UserNameRegisterResponse) {

                if (!isViewAttached)
                    return

                when (data.head.errCode) {
                    "WS_201713" -> {
                        view?.alreadyRegistered()
                    }
                    else -> {
                        view?.registerFail()
                    }
                }
            }

            override fun onFail(model: ApiErrorModel) {

                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {

                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }
}