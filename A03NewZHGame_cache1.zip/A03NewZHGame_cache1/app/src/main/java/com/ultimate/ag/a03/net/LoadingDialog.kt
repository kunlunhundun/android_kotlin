package com.ultimate.ag.a03.net

import android.app.Activity
import android.app.Dialog
import android.widget.ImageView
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.util.FrameAnimation
import java.lang.ref.WeakReference

object LoadingDialog {
    private var dialog: Dialog? = null
    var mActivity: WeakReference<Activity>? = null
    fun show(activity: Activity?) {

        if (dialog?.isShowing ?: false) {
            return
        }

        cancel()
        mActivity = WeakReference<Activity>(activity)
        if (mActivity == null) {
            return
        }
        dialog = Dialog(mActivity?.get(), R.style.LoadingDialog)
        dialog?.setContentView(R.layout.dialog_loading)
        dialog?.setCancelable(true)
        dialog?.setCanceledOnTouchOutside(false)
        if (!(mActivity?.get()?.isFinishing ?: true)) {
            dialog?.show()
        }
        val animationIV = dialog?.findViewById<ImageView>(R.id.iv_loading)
        FrameAnimation(animationIV!!, getRes(), 40, true)
    }

    fun cancel() {
        dialog?.dismiss()
        mActivity = null
    }

    /**
     * 获取需要播放的动画资源
     */
    private fun getRes(): IntArray {
        val typedArray = mActivity?.get()?.resources!!.obtainTypedArray(R.array.loading)
        val len = typedArray.length()
        val resId = IntArray(len)
        for (i in 0 until len) {
            resId[i] = typedArray.getResourceId(i, -1)
        }
        typedArray.recycle()
        return resId
    }
}
