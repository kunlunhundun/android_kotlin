package com.ultimate.ag.a03.net

import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.data.response.BaseResponseObject
import com.ultimate.ag.a03.util.LogUtils
import io.reactivex.Observer
import io.reactivex.disposables.Disposable
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

abstract class ApiMvpResponse<T : BaseResponseObject> : Observer<T> {

    abstract fun businessFail(data: T)
    abstract fun businessSuccess(data: T)
    abstract fun failure(statusCode: Int, apiErrorModel: ApiErrorModel)

    override fun onSubscribe(d: Disposable) {


    }

    override fun onNext(t: T) {

        when (t.head.errCode) {
            "0000" -> {
                businessSuccess(t)
            }
            "GW_890206" -> {
                MyApplication.getinstance().loginOut()
            }
            "GW_890203" -> {
                MyApplication.getinstance().loginOut()
            }
            else -> {
                businessFail(t)
            }
        }

    }

    override fun onComplete() {


    }

    override fun onError(e: Throwable) {


        if (e is HttpException) {
            val apiErrorModel: ApiErrorModel = when (e.code()) {
                ApiErrorType.INTERNAL_SERVER_ERROR.code ->
                    ApiErrorType.INTERNAL_SERVER_ERROR.getApiErrorModel(MyApplication.getinstance().baseContext)
                ApiErrorType.BAD_GATEWAY.code ->
                    ApiErrorType.BAD_GATEWAY.getApiErrorModel(MyApplication.getinstance().baseContext)
                ApiErrorType.NOT_FOUND.code ->
                    ApiErrorType.NOT_FOUND.getApiErrorModel(MyApplication.getinstance().baseContext)
                ApiErrorType.NETWORK_NOT_CONNECT.code ->
                    ApiErrorType.NETWORK_NOT_CONNECT.getApiErrorModel(MyApplication.getinstance().baseContext)
                else -> otherError(e)

            }
            failure(e.code(), apiErrorModel)
            return
        }

        val apiErrorType: ApiErrorType = when (e) {
            is UnknownHostException -> ApiErrorType.UNKNOWN_HOST_EXCEPTION
            is ConnectException -> ApiErrorType.NETWORK_NOT_CONNECT
            is SocketTimeoutException -> ApiErrorType.CONNECTION_TIMEOUT
            else -> {
                ApiErrorType.UNEXPECTED_ERROR
            }
        }
        //未知错误打印错误日志
        if (apiErrorType == ApiErrorType.UNEXPECTED_ERROR) {
            LogUtils.e("${e.cause}")
            LogUtils.e("${e.message}")
            e.stackTrace.forEach {
                LogUtils.e("${it}")
            }
        }

        failure(apiErrorType.code, apiErrorType.getApiErrorModel(MyApplication.getinstance().baseContext))
    }

    private fun otherError(e: HttpException) = ApiErrorModel(e.code(), e.message())

}
