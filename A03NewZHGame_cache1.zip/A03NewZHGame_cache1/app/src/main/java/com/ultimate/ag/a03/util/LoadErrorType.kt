
package com.ultimate.ag.a03.util

import android.content.Context
import android.support.annotation.StringRes
import com.ultimate.ag.a03.R

import com.ultimate.ag.a03.data.LoadErrorModel

enum class LoadErrorType(val code: Int, @param: StringRes private val messageId: Int,var icon:Int) {
    DATA_EMPTY(0, R.string.load_error_empty,R.mipmap.error_general),
    MSG_DATA_EMPTY(0, R.string.load_error_msg_empty, R.mipmap.notice_empty),
    GO_RECHARGE(1, R.string.load_error_go_recharge, R.mipmap.error_general),
    NOT_FOUND(2, R.string.not_found,R.mipmap.error_general),
    NET_ERROR(3, R.string.load_error_net_error, R.mipmap.error_general),
    IS_LOADING(4, R.string.load_error_is_loading,R.mipmap.error_loding),
    TIME_OUT(5, R.string.load_error_is_time_out, R.mipmap.error_general),
    GAME_DATA_EMPTY(6, R.string.load_error_game_empty, R.mipmap.search_empty);




    fun getLoadErrorModel(context: Context): LoadErrorModel {
        return LoadErrorModel(code, context.getString(messageId),icon)
    }
}
