package com.ultimate.ag.a03.util

import android.content.Context
import android.os.AsyncTask
import android.text.TextUtils
import android.util.Log
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.database.DataBaseHelper
import java.io.*
import java.math.BigDecimal
import java.net.MalformedURLException
import java.net.URL
import java.net.URLConnection

// 文件下载的url 保存路径 out
class DownLoaderTask : AsyncTask<Void, Int, Long> {
    private val TAG = "WARDY|DownLoaderTask"
    private var mUrl: URL? = null
    private var mFile: File? = null
    private var mProgress = 0
    private var mOutputStream: ProgressReportingOutputStream? = null
    private var mInputStream: InputStream? = null
    private var mContext: Context? = null
    private var mTypeStr: String? = null
    private var mVersion: String? = null
    private var mLength: Int? = null
    private var md5: String? = null
    private var out: String? = null

    constructor(url: String, out: String, context: Context?, typeStr: String, version: String,
                md5: String?) : super() {
        if (context != null) {
            mContext = context
            mTypeStr = typeStr
            mVersion = version
            this.md5 = md5
            this.out = out
        }

        try {
            mUrl = URL(url)
            mFile = File(out, mTypeStr)

            Log.d(TAG, "out=" + out + ", name=" + mTypeStr + ",mUrl.getFile()=" + mUrl!!.file)
        } catch (e: MalformedURLException) {
            e.printStackTrace()
        }
    }


    constructor(input: InputStream, out: String, context: Context?, typeStr: String, version: String) : super() {
        if (context != null) {
            mContext = context
            mTypeStr = typeStr
            mInputStream = input
            mVersion = version
            this.out = out
        }

        try {
            mFile = File(out, mTypeStr)
            Log.d(TAG, "out=$out, name=$mTypeStr")
        } catch (e: MalformedURLException) {
            e.printStackTrace()
        }
    }


    override fun onPreExecute() {
        // TODO Auto-generated method stub
    }

    override fun doInBackground(vararg params: Void): Long? {
        // TODO Auto-generated method stub

        return if (mUrl != null) {
            Log.d(TAG, "下载h5包")
            download()
        } else {
            Log.d(TAG, "copy本地h5包")
            assetCopy()
        }
    }

    private fun onProgressUpdate(vararg values: Int) {
        // TODO Auto-generated method stub
    }

    //下载保存后执行
    override fun onPostExecute(result: Long?) {
        // TODO Auto-generated method stub
        if (isCancelled)
            return
        if (TextUtils.isEmpty(md5)) {
            //解压
            val task = ZipExtractorTask(ProjectUtils.webFiieRoute + mTypeStr, ProjectUtils.webFiieRoute + "/web", mContext, true)
            task.execute()
            DataBaseHelper.updateH5Version(mVersion!!, Utils.getFileMD5(mFile!!)!!)
        } else {
            if (Utils.getFileMD5(mFile!!) == md5) {
                DataBaseHelper.updateH5Version(mVersion!!, md5!!)
                //解压
                val task = ZipExtractorTask(ProjectUtils.webFiieRoute + mTypeStr, ProjectUtils.webFiieRoute + "/web", mContext, true)
                task.execute()
            }

        }

//        Log.d(TAG, "mVersion=" + DataBaseHelper.getH5Version().version + ", h5Md5=" + Utils.getFileMD5(mFile!!) + "====" + md5)
    }

    private fun download(): Long {
        var connection: URLConnection? = null
        var bytesCopied = 0
        try {
            connection = mUrl!!.openConnection()
            mLength = connection!!.contentLength
            if (mFile!!.exists() && md5 == Utils.getFileMD5(mFile!!)) {
                Log.d(TAG, "file " + mFile!!.name + " already exits!!")
                return 1L
            } else {
                if (!mFile!!.parentFile.exists()) {
                    mFile!!.parentFile.mkdirs()
                }
            }
            mOutputStream = ProgressReportingOutputStream(mFile!!)
            publishProgress(0, mLength)
            bytesCopied = copy(connection.getInputStream(), mOutputStream!!)
            if (bytesCopied != mLength && mLength != -1) {
                Log.e(TAG, "Download incomplete bytesCopied=$bytesCopied, length$mLength")
            }
            mOutputStream!!.close()
        } catch (e: IOException) {
            //下载链接有问题，用原来的H5版本
            ConfigUtils.isH5Ready = true
            e.printStackTrace()
        }

        return bytesCopied.toLong()
    }


    private fun assetCopy(): Long {
        var bytesCopied = 0
        try {
            mLength = mInputStream!!.available()
            if (mFile!!.exists()) {
                Log.d(TAG, "file " + mFile!!.name + " already exits!!")
                return 1L
            } else {
                if (!mFile!!.parentFile.exists()) {
                    mFile!!.parentFile.mkdirs()
                }
            }
            mOutputStream = ProgressReportingOutputStream(mFile!!)
            publishProgress(0, mLength)
            bytesCopied = copy(mInputStream!!, mOutputStream!!)
            if (bytesCopied != mLength && mLength != -1) {
                Log.d(TAG, "Download incomplete bytesCopied=$bytesCopied, length$mLength")
            }
            mOutputStream!!.close()
            mInputStream!!.close()
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        }

        return bytesCopied.toLong()
    }


    private fun copy(input: InputStream, output: OutputStream): Int {
        val buffer = ByteArray(1024 * 8)
        val inp = BufferedInputStream(input, 1024 * 8)
        val out = BufferedOutputStream(output, 1024 * 8)
        var count = 0
        var n = 0
        try {
            n = inp.read(buffer, 0, 1024 * 8)
            while (n != -1) {
                out.write(buffer, 0, n)
                count += n
                n = inp.read(buffer, 0, 1024 * 8)
            }
            out.flush()
        } catch (e: IOException) {
            // TODO Auto-generated catch block
            e.printStackTrace()
        } finally {
            try {
                out.close()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }

            try {
                inp.close()
            } catch (e: IOException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }

        }
        return count
    }

    private inner class ProgressReportingOutputStream @Throws(FileNotFoundException::class)
    constructor(file: File)// TODO Auto-generated constructor stub
        : FileOutputStream(file) {

        @Throws(IOException::class)
        override fun write(buffer: ByteArray, byteOffset: Int, byteCount: Int) {
            // TODO Auto-generated method stub
            super.write(buffer, byteOffset, byteCount)
            mProgress += byteCount
            publishProgress(mProgress)
        }

    }


    fun needUpdate(): Boolean {
        val h5Version = DataBaseHelper.getH5Version()
        val needUpdate = !(mFile!!.exists() && h5Version.md5!! == md5) || BigDecimal(h5Version.version) < BigDecimal(mVersion)
//        ConfigUtils.isH5Ready = !needUpdate
        if (needUpdate) {
            mTypeStr = "/${File(mUrl!!.file).name}"
            try {
                mFile = File(out, mTypeStr)
                Log.d(TAG, "out=$out, name= $mTypeStr")
            } catch (e: MalformedURLException) {
                e.printStackTrace()
            }
        }
        return needUpdate

    }


    fun isFirst(): Boolean {
        val h5Version = DataBaseHelper.getH5Version()
        Log.d(TAG, "oldVersion=${h5Version.version}, newVersion= $mVersion")
        val needUpdate = !(mFile!!.exists() && mFile!!.listFiles().isNotEmpty()) || BigDecimal(h5Version.version) < BigDecimal(mVersion)
        ConfigUtils.isH5Ready = !needUpdate
        if (needUpdate) {
            mTypeStr = "$mTypeStr.zip"
            try {
                mFile = File(out, mTypeStr)
                Log.d(TAG, "out=$out, name= $mTypeStr")
            } catch (e: MalformedURLException) {
                e.printStackTrace()
            }
        }
        return needUpdate

    }
}
