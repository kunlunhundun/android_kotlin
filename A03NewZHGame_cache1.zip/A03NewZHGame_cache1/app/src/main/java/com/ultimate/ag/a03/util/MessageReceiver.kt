package com.ultimate.ag.a03.util

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Vibrator
import com.rea.commonUtils.log.LogUtil
import com.rea.push.utils.Cons
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.activity.SplashPageActivity
import com.ultimate.ag.a03.config.ConfigUtils

class MessageReceiver : BroadcastReceiver() {
    var mContext: Context? = null
    private lateinit var vibrator: Vibrator
    private lateinit var notificationManager: NotificationManager
    override fun onReceive(context: Context?, intent: Intent?) {
        vibrator = context?.getSystemService(Service.VIBRATOR_SERVICE) as Vibrator
        notificationManager = context?.getSystemService(Service.NOTIFICATION_SERVICE) as NotificationManager
        val action = intent?.action
        mContext = context
        LogUtil.e("接收到广播：：：：" + action!!)
        when (action) {

            Cons.ACTION_MESSAGE -> {
                LogUtil.e("接收到了message")
                dealMessage(intent, action)
            }
            Cons.ACTION_CLICK -> {
                dealMessage(intent, action)
            }


        }


    }


    private fun dealMessage(intent: Intent?, type: String) {
        val id = intent?.getStringExtra("id")
        val title = intent?.getStringExtra("title")
        val content = intent?.getStringExtra("content")
        val url = intent?.getStringExtra("url")
        val jumptype = intent?.getStringExtra("type")
//        LogUtil.e("接收到了notify"+id+"|"+title+"|"+content+"|"+url+"|"+type)
        when (type) {
            Cons.ACTION_CLICK -> {
                ConfigUtils.NOticeTag = true
                val intent = Intent(mContext, SplashPageActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                mContext?.startActivity(intent)


            }

            Cons.ACTION_MESSAGE -> {
                vibrator.vibrate(500)
                val notification = Notification()
                notification.defaults = Notification.DEFAULT_SOUND
                notificationManager.notify(1, notification)

                MyApplication.messgeNotifyObject.update()
            }
        }

    }


}