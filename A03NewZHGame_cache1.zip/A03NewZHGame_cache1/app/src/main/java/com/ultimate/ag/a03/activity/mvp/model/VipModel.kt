package com.ultimate.ag.a03.activity.mvp.model

class VipModel: IModel{



}