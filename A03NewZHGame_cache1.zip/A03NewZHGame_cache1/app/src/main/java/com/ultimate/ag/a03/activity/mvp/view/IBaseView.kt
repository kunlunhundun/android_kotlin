package com.ultimate.ag.a03.activity.mvp.view

import android.content.Context
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.components.support.RxFragment

interface IBaseView {

    fun showToast(message: String)

    fun showToast(id: Int)

    fun initView()

    fun initListener()

    fun getContext(): Context

    fun getRxActivity(): RxAppCompatActivity

    fun getRxFragment(): RxFragment?

    fun showLoading()

    fun cancelLoading()
}