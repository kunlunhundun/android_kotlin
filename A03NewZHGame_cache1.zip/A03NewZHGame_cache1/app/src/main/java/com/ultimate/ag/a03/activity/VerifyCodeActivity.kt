package com.ultimate.ag.a03.activity

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.text.TextUtils
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.data.AccountObj
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.*
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.*
import com.ultimate.ag.a03.view.CustomDialogView
import kotlinx.android.synthetic.main.activity_verify_code.*
import org.json.JSONArray
import java.text.SimpleDateFormat

class VerifyCodeActivity : BaseToolBarActivity() {

    private var addAccount = false  //是否添加账号

    //屏幕高度

    private var showError = false
    private lateinit var phoneNum: String
    private var validateId: String? = null
    private var referralCode: String? = null
    private lateinit var messageId: String
    private lateinit var mCode: String
    private var expire: Int = 0
    private var timer: CountDownTimer? = null
    private var mValidateId: String? = null


    companion object {
        const val TYPE_CHANGE = 0
        const val TYPE_BIND = 1
        const val TYPE_REGISTER = 2
        const val TYPE_LOGIN = 3
        const val TYPE_FORGET_PASSWORD = 4
        const val TYPE_UNBIND_PHONE = 5
        const val TYPE_BIND_CARD = 6
        const val TYPE_UNACTIVITY_PHONE = 7
    }

    var type = TYPE_REGISTER

    override fun initData() {

        addAccount = intent.getBooleanExtra("addAccount", false)
        phoneNum = intent.getStringExtra("phone_num")
        validateId = intent.getStringExtra("validateId")
        if (intent.hasExtra("nvitation_num")) {
            referralCode = intent.getStringExtra("nvitation_num")
        }
        type = intent.getIntExtra("type", TYPE_REGISTER)
        expire = intent.getIntExtra("expire", 60)
        messageId = intent.getStringExtra("messageId")
        tv_verify_tip.text = String.format(getString(R.string.bind_mobile_phone_activity_verify_tip), phoneNum)
        initTimer(60)?.start()
    }

    override fun initListener() {
        vc_code.setOnCompleteListener {
            when (type) {
                TYPE_BIND -> {
                    bindMobileNo(it)
                }

                TYPE_BIND_CARD -> {
                    bindMobileNo(it)
                }

                TYPE_REGISTER -> {
                    verifySmsCode(1, it)
                }
                TYPE_LOGIN -> {
                    verifySmsCode(2, it)
                }
                TYPE_FORGET_PASSWORD -> {
                    verifySmsCode(4, it)
                }
                TYPE_UNBIND_PHONE -> {
                    verifySmsCode(5, it)
                }

                TYPE_CHANGE -> {
                    unBindPhone(it)
                }
                TYPE_UNACTIVITY_PHONE -> {
                    verifySmsCode(10, it)
                }
            }

        }

        bt_retry.setOnClickListener {
            resendVerifyCode()
            vc_code.clear()

        }

        content.addOnLayoutChangeListener(this)

    }

    private fun unActivityPhone(code: String?) {
        val request = UnActivityPhoneRequest()
        ApiClient.instance.service.unActivityPhone(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<UnAcitivityPhoneResponse>(this, false) {

                    override fun businessFail(data: UnAcitivityPhoneResponse) {
                        when (data.head.errCode) {
                            "WS_307038" -> {
                                tv_success_tip.text = "短信验证通过"
                                showMessage()
                                gotoSetNewPassWord(code)
                            }
                        }
                    }

                    override fun businessSuccess(data: UnAcitivityPhoneResponse) {
                        goSuccess()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }

    private fun gotoSetNewPassWord(code: String?) {
        val intent = Intent(this@VerifyCodeActivity, SetNewPasswordActivity::class.java)
        intent.putExtra("isFromUnActivity", true)
        intent.putExtra("validateId", mValidateId)
        intent.putExtra("messageId", messageId)
        intent.putExtra("smsCode", code)
        intent.putExtra("type", 1)
        goToPage(intent)
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_verify_code
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StatusBarUtil.StatusBarLightMode(this)
        setTile("")
        setBackground(R.color.white)
        isShowBack(true)
        setBackListener(View.OnClickListener {
            showBackDialog()
        })

        KeyBoardUtils.openKeybord(et_no_use, baseContext)
    }


    private fun showError(error: String) {
        var errorText = error
        rl_verify_error.visibility = View.VISIBLE
        if (error.contains("^")) {
            errorText = error.split("^")[1]
        }
        tv_tip.text = errorText
        vc_code.showError()
        showError = true

        Handler().postDelayed({
            rl_verify_error.visibility = View.GONE
            tv_tip.text = ""
            showError = false
        }, 3000)
    }

    private fun showError() {
        rl_verify_error.visibility = View.VISIBLE
        vc_code.showError()
        showError = true
    }

    private fun mobileRegister(code: String) {

        val request = MobileRegisterRequest()
        request.messageId = messageId
        request.smsCode = code
        request.referralCode = referralCode
        request.validateId = mValidateId
        ApiClient.instance.service.mobileRegister(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<MobileRegisterResponse>(this, false) {
                    override fun businessFail(data: MobileRegisterResponse) {
//                        coverPointRequest("c_authentication", "c_Landing_Register_msg", "c_authentication"
//                                , getData("1", data.head.errMsg!!, ""))
                        when (data.head.errCode) {
                            "GW_800503" -> {
                                showPhoneNumberUsedDialog(code)
                            }

                            "GW_800518" -> {
                                showHasRegisterDialog(code)
                            }
                            else -> showError(data.head.errMsg!!)
                        }

                    }

                    override fun businessSuccess(data: MobileRegisterResponse) {
//                        coverPointRequest("c_authentication", "c_Landing_Register_msg", "c_Home"
//                                , getData("0", data.head.errMsg!!, ""))
                        //获取登录时间
                        var currentTime = System.currentTimeMillis()
                        var timeNow = SimpleDateFormat("yyyy-MM-dd").format(currentTime)
                        ConfigUtils.token = data.body.token
                        ConfigUtils.loginName = data.body.loginName
                        ConfigUtils.customerId = data.body?.customerId
                        ConfigUtils.currentUserType = ConfigUtils.USER_TYPE_OLD
                        ConfigUtils.loginTime = timeNow
                        rl_verify_error.visibility = View.GONE
                        AppInitManager.getAcache().put("loginType", "0")
                        goSuccess()
//                        mobileLogin(code)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//                        Toast.makeText(this@VerifyCodeActivity,apiErrorModel.message,Toast.LENGTH_LONG).show()
                        showError(apiErrorModel.message)
                    }

                })

    }

    private fun mobileLogin(code: String) {
        val request = MobileLoginRequest()
        request.messageId = messageId
        request.smsCode = code
        request.validateId = mValidateId
        ApiClient.instance.service.loginByMobileNo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<MobileLoginResponse>(this) {
                    override fun businessFail(data: MobileLoginResponse) {
                        when (data.head.errCode) {
                            "GW_800501" -> {
                                showNeedRegisterDialog(code)
                            }
                            "GW_800517" -> {
                                showCantPhoneLoginDialog()
                            }

                            "GW_800507" -> {
                                showaLoginErroDialog()
                            }

                            else -> {
//                                Toast.makeText(this@VerifyCodeActivity,data.head.errMsg,Toast.LENGTH_LONG).show()
                                showError(data.head.errMsg!!)
                            }
                        }
//                        coverPointRequest("c_authentication", "c_Landing_Login_msg", "c_authentication", getData("1", data?.head?.errMsg!!, ""))
                    }

                    override fun businessSuccess(data: MobileLoginResponse) {
//                        coverPointRequest("c_authentication", "c_Landing_Login_msg", "c_Home", getData("0", data?.head?.errMsg!!, data?.body?.starLevel.toString()))
                        //获取登录时间
                        var currentTime = System.currentTimeMillis()
                        var timeNow = SimpleDateFormat("yyyy-MM-dd").format(currentTime)
                        ConfigUtils.token = data.body?.token
                        ConfigUtils.loginName = data.body?.loginName
                        ConfigUtils.customerId = data.body?.customerId
                        ConfigUtils.currentUserType = ConfigUtils.USER_TYPE_OLD
                        ConfigUtils.loginTime = timeNow
                        //因为json储存字符串字段不能带"/"字符,所以做一步转义
                        ConfigUtils.avatar = data.body?.avatar?.substring(7)?.replace("/", "forjson", false)

                        if (addAccount) {

                            var account = AccountObj()
                            account.username = ConfigUtils.loginName
                            account.token = ConfigUtils.token
                            account.customerId = ConfigUtils.customerId
                            account.loginTime = ConfigUtils.loginTime
                            account.userPicture = ConfigUtils.avatar
                            //有缓存取出用户组
                            var loginArr = JSONArray(MyApplication.getinstance().mAcach.getAsString("loginArr"))
                            loginArr.put(JSONArray().put(account)[0].toString())
                            MyApplication.getinstance().mAcach.put("loginArr", loginArr.toString())
                        }

                        rl_verify_error.visibility = View.GONE
                        AppInitManager.getAcache().put("loginType", "0")
                        goSuccess()
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }

    private fun showCloseAccountNotice() {
        val dialog = CustomDialogView(this@VerifyCodeActivity)
        dialog.showCustomViewDialog(200f)
        dialog.setTitle("您的账号已注销，请联系客服处理\n")
        dialog.setBtnRight("确定")
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
        })

        dialog.setBtnOkOnclick(View.OnClickListener {
            dialog.dismiss()
            Utils.goOnlineCustomerService(this@VerifyCodeActivity)
        })
    }

    private fun verifySmsCode(use: Int, code: String) {
        val request = VerifySmsCodeRequest()
        request.messageId = messageId
        request.smsCode = code
        request.loginName = if (use == 1 || use == 2) "" else ConfigUtils.loginName
        request.use = use

        ApiClient.instance.service.verifySmsCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<VerifySmsCodeResponse>(this) {
                    override fun businessFail(data: VerifySmsCodeResponse) {
                        Toast.makeText(this@VerifyCodeActivity, data.head.errMsg, Toast.LENGTH_LONG).show()
                        showError(data.head.errMsg!!)
                    }

                    override fun businessSuccess(data: VerifySmsCodeResponse) {
                        mValidateId = data?.body.validateId
                        if (use == 1) {
                            mobileRegister(code)
                        } else if (use == 2) {
                            mobileLogin(code)
                        } else if (use == 6) {
                            goToPage(Intent(this@VerifyCodeActivity, BindMobilePhoneActivity::class.java))
                        } else if (use == 10) {//激活账号设置新密码重新调用激活接口
                            unActivityPhone(code)
                        } else {
                            rl_verify_error.visibility = View.GONE
                            mCode = code
                            goSuccess()
                        }
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }

    private fun bindMobileNo(code: String) {
        val request = BindMobileRequest()
        request.messageId = messageId
        request.smsCode = code
        ApiClient.instance.service.bindMobileNoV2(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<BindMobileResponse>(this) {
                    override fun businessFail(data: BindMobileResponse) {
//                        Toast.makeText(this@VerifyCodeActivity,data.head.errMsg,Toast.LENGTH_LONG).show()
                        showError(data.head.errMsg!!)
                    }

                    override fun businessSuccess(data: BindMobileResponse) {
                        rl_verify_error.visibility = View.GONE
                        ConfigUtils.isBindMobile = true
                        goSuccess()
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }


    private fun unBindPhone(code: String) {
        val request = UnBindPhoneRequest()
        request.smsCode = code
        request.messageId = messageId
        ApiClient.instance.service.reBindMobileNoV2(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<UnBindPhoneResponse>(this, true) {
                    override fun businessFail(data: UnBindPhoneResponse) {
//                        Toast.makeText(baseContext,data.head.errMsg,Toast.LENGTH_LONG).show()
                        showError(data.head.errMsg!!)
                    }

                    override fun businessSuccess(data: UnBindPhoneResponse) {
                        goSuccess()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//                        Toast.makeText(baseContext,apiErrorModel.message,Toast.LENGTH_LONG).show()
                        showError(apiErrorModel.message)
                    }

                })

    }


    private fun initTimer(time: Long): CountDownTimer? {
        tv_verify_countdown.visibility = View.VISIBLE
        bt_retry.visibility = View.GONE
        timer = object : CountDownTimer(time * 1000, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                tv_verify_countdown.text = String.format(getString(R.string.bind_mobile_phone_activity_wait_tip), millisUntilFinished / 1000)
            }

            override fun onFinish() {
                tv_verify_countdown.visibility = View.GONE
                bt_retry.visibility = View.VISIBLE

            }
        }

        return timer
    }

    private fun showBackDialog() {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(200f)
        dialog.setTitle(getString(R.string.bind_mobile_phone_activity_verify_back_tip))
        dialog.setBtnLeft(getString(R.string.bind_mobile_phone_activity_verify_back_wait))
        dialog.setBtnRight(getString(R.string.bind_mobile_phone_activity_verify_back_sure))
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            finish()
            dialog.dismiss()

        })
    }

    private fun showPhoneNumberUsedDialog(code: String) {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(200f)
        dialog.setTitle(getString(R.string.phone_register_activity_already_register))
        dialog.setBtnLeft(getString(R.string.phone_register_activity_back))
        dialog.setBtnRight(getString(R.string.phone_register_activity_login))
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
            finish()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            type = TYPE_LOGIN
            dialog.dismiss()
            mobileLogin(code)
        })
    }

    private fun showaLoginErroDialog() {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(0f)
        dialog.setTitle(getString(R.string.mobile_login_fail_title))
        dialog.setContente(getString(R.string.mobile_login_fail_tip))
        dialog.setBtnLeft(getString(R.string.username_login_fail_cancel))
        dialog.setBtnRight(getString(R.string.username_login))
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
            finish()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            finish()
            dialog.dismiss()
            val intent = Intent(this@VerifyCodeActivity, LoginActivity::class.java)
            startActivity(intent)

        })
    }

    private fun showNeedRegisterDialog(code: String) {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(0f)
        dialog.setTitle(getString(R.string.mobile_login_need_register_tip))
        dialog.setBtnLeft(getString(R.string.mobile_login_need_register_back))
        dialog.setBtnRight(getString(R.string.mobile_login_need_register_register))
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
            finish()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            type = TYPE_REGISTER
            dialog.dismiss()
            mobileRegister(code)
        })
    }

    private fun showCantPhoneLoginDialog() {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(0f)
        dialog.setTitle("无法通过手机号登录")
        dialog.setContente("该手机号绑定的账户尚未开启手机号登录请您尝试通过用户名登录")
        dialog.setBtnLeft(getString(R.string.mobile_login_need_register_back))
        dialog.setBtnRight("用户名登录")
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
            finish()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            dialog.dismiss()
            goToPage(Intent(this, LoginActivity::class.java))
        })
    }

    private fun showHasRegisterDialog(code: String) {
        val dialog = CustomDialogView(this)
        dialog.showCustomViewDialog(0f)
        dialog.setTitle("该手机号已经注册，您是否要登录对应的游戏账号？")
        dialog.setBtnLeft(getString(R.string.mobile_login_need_register_back))
        dialog.setBtnRight("登录")
        dialog.setBtnCancelOnclick(View.OnClickListener {
            dialog.dismiss()
            finish()
        })
        dialog.setBtnOkOnclick(View.OnClickListener {
            dialog.dismiss()
            mobileLogin(code)
        })
    }

    private fun goSuccess() {
        KeyBoardUtils.closeKeybord1(et_no_use, baseContext)
        when (type) {
            TYPE_LOGIN -> {
                tv_success_tip.text = getText(R.string.username_login_success_tip)
                showMessage()
            }
            TYPE_FORGET_PASSWORD -> {
                tv_success_tip.text = getText(R.string.set_new_password_verify_success)
                showMessage()
            }
            TYPE_BIND -> {
                tv_success_tip.text = getText(R.string.bind_mobile_phone_activity_bind_success_tip)
                showMessage()
            }

            TYPE_BIND_CARD -> {
                tv_success_tip.text = getText(R.string.bind_mobile_phone_activity_bind_success_tip)
                showMessage()
            }
            TYPE_REGISTER -> {
                tv_success_tip.text = getText(R.string.tv_tip)
                showMessage()
            }

            TYPE_UNBIND_PHONE -> {
//                tv_success_tip.text = getText(R.string.username_unbind_success)
            }

            TYPE_CHANGE -> {
                tv_success_tip.text = getText(R.string.username_rebind_success)
                showMessage()
            }
            TYPE_UNACTIVITY_PHONE -> {
                tv_success_tip.text = "关闭手机号登录成功"
                showMessage()
            }
        }


        val handler = Handler()
        val runnable = Runnable {
            val intent = Intent()
            when (type) {
                TYPE_REGISTER -> {
                    intent.putExtra(IntentConstant.REGISTER_ACCOUNT, ConfigUtils.loginName)
                    intent.putExtra(IntentConstant.REGISTER_PHONENUM, phoneNum)
                    intent.setClass(this@VerifyCodeActivity, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    intent.putExtra("usertype", ConfigUtils.USER_TYPE_NEW)
                    goToPage(intent)
                    finish()
                }
                TYPE_FORGET_PASSWORD -> {
                    intent.setClass(this@VerifyCodeActivity, SetNewPasswordActivity::class.java)
                    intent.putExtra("messageId", messageId)
                    intent.putExtra("smsCode", mCode)
                    intent.putExtra("validateId", mValidateId)
                    intent.putExtra("type", 2)
                    goToPage(intent)
                    finish()
                }
                TYPE_BIND -> {
                    AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)
                    if (TextUtils.isEmpty(ConfigUtils.realName)) {
                        intent.setClass(this@VerifyCodeActivity, CompleteProfileActivity::class.java)
                        goToPage(intent)
                    }
                    finish()
                }

                TYPE_UNBIND_PHONE -> {
                    intent.setClass(this@VerifyCodeActivity, BindMobilePhoneActivity::class.java)
                    intent.putExtra("title", getString(R.string.bind_mobile_phone_activity_bind_new_phone))
                    goToPage(intent)
                    finish()
                }
                TYPE_CHANGE -> {
                    AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)

                    finish()
                }

                TYPE_BIND_CARD -> {
                    when {
                        TextUtils.isEmpty(ConfigUtils.realName) -> {
                            intent.setClass(this@VerifyCodeActivity, CompleteProfileActivity::class.java)
                            goToPage(intent)

                        }

                        ConfigUtils.bankCardCounts == 0 -> {
                            intent.setClass(this@VerifyCodeActivity, AddBankCardActivity::class.java)
                            goToPage(intent)
                        }
                    }
                    AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)

                    finish()


                }
                TYPE_UNACTIVITY_PHONE -> {
                    AppInitManager.getActivityListManager().killAll()
                    goToPage(Intent(this@VerifyCodeActivity, LoginActivity::class.java))
                }

                else -> {
                    intent.setClass(this@VerifyCodeActivity, MainActivity::class.java)
                    goToPage(intent)
                    finish()
                }
            }

        }
        handler.postDelayed(runnable, 2000)
    }


    private fun showMessage() {
        val animation = AnimationUtils.loadAnimation(this@VerifyCodeActivity, R.anim.popupwindow_show_anim)
        tv_success_tip.startAnimation(animation)
        tv_success_tip.visibility = View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        content.addOnLayoutChangeListener(this)
    }

    override fun onBackPressed() {
        showBackDialog()

    }

    override fun onLayoutChange(p0: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {
        if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight) && showError) {

            rl_verify_error.visibility = View.VISIBLE

        } else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight) && showError) {
            rl_verify_error.visibility = View.VISIBLE

        }
    }


    private fun resendVerifyCode() {
        val request = SendSmsRequest()

        request.mobileNo = RSATool.encode(phoneNum.replace(" ", ""))
//        request.mobileNo= DESUtil.encrypt("13812694149")
        when (type) {
            TYPE_CHANGE -> {
                request.loginName = ConfigUtils.loginName
                request.use = "5"
                sendCode(request)
            }
            TYPE_BIND -> {
                if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {
                    request.use = "3"
                    request.loginName = ConfigUtils.loginName
                    sendCode(request)
                } else {
                    sendVerifyCode("3")
                }

            }

            TYPE_LOGIN -> {
                request.use = "2"
                sendCode(request)
            }
            TYPE_REGISTER -> {
                request.use = "1"
                sendCode(request)
            }

            TYPE_FORGET_PASSWORD -> {
                sendPost()
            }

            TYPE_UNBIND_PHONE -> {
                sendVerifyCode("5")
            }


            TYPE_BIND_CARD -> {
                if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {
                    request.use = "3"
                    sendCode(request)
                } else {
                    sendVerifyCode("3")
                }
            }
        }


    }


    private fun sendCode(request: SendSmsRequest) {
        ApiClient.instance.service.sendCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this) {
                    override fun businessFail(data: SendSmsResponse) {
                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        messageId = data.body?.messageId!!
                        initTimer(60)?.start()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        Toast.makeText(baseContext, apiErrorModel.message, Toast.LENGTH_LONG).show()
                    }

                })

    }

    private fun sendPost() {
//        var request = PreModifyPwdBySmsCodeRequest()
//
//        request.loginName = ConfigUtils.loginName
//        request.realName = ConfigUtils.realName
//
//        ApiClient.instance.service.preModifyPwdBySmsCode(request)
//                .compose(NetworkScheduler.compose())
//                .bindUntilEvent(this, ActivityEvent.DESTROY)
//                .subscribe(object : ApiResponse<PreModifyPwdBySmsCodeResponse>(this, true) {
//                    override fun businessFail(data: PreModifyPwdBySmsCodeResponse) {
//                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()
//                    }
//
//                    override fun businessSuccess(data: PreModifyPwdBySmsCodeResponse) {
//                        messageId = data?.body?.messageId!!
//                        initTimer(60)?.start()
//                    }
//
//
//                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//                        Toast.makeText(baseContext, apiErrorModel.message, Toast.LENGTH_LONG).show()
//                    }
//
//                })

        val sendSmsRequest = SendCodeByLoginNameRequest()
        sendSmsRequest.validateId = validateId
//        sendSmsRequest.loginName = ConfigUtils.loginName
        sendSmsRequest.use = "4"
        ApiClient.instance.service.sendCodeByLoginName(sendSmsRequest)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this, true) {
                    override fun businessFail(data: SendSmsResponse) {
                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        messageId = data?.body?.messageId!!
                        initTimer(60)?.start()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        Toast.makeText(baseContext, apiErrorModel.message, Toast.LENGTH_LONG).show()
                    }

                })

    }


    private fun sendVerifyCode(use: String) {
        val request = SendCodeByLoginNameRequest()
        request.use = use
        ApiClient.instance.service.sendCodeByLoginName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this) {
                    override fun businessFail(data: SendSmsResponse) {
                        Toast.makeText(baseContext, data.head.errMsg, Toast.LENGTH_LONG).show()
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        messageId = data?.body?.messageId!!
                        initTimer(60)?.start()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        Toast.makeText(baseContext, apiErrorModel.message, Toast.LENGTH_LONG).show()
                    }

                })

    }


    override fun onPause() {
        super.onPause()
        KeyBoardUtils.closeKeybord1(et_no_use, baseContext)
    }

    override fun onStop() {
        super.onStop()
        KeyBoardUtils.closeKeybord1(et_no_use, baseContext)
    }
}
