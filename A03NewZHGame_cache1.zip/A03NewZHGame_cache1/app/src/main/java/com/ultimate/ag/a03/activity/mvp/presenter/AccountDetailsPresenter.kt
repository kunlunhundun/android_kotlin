package com.ultimate.ag.a03.activity.mvp.presenter

import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.AccountDetailsModel
import com.ultimate.ag.a03.activity.mvp.view.AccountDetailsView
import com.ultimate.ag.a03.data.request.BQBanksRequest
import com.ultimate.ag.a03.data.request.BalanceRequest
import com.ultimate.ag.a03.data.request.ToGameRequest
import com.ultimate.ag.a03.data.request.ToLocalRequest
import com.ultimate.ag.a03.data.response.BQBanksResponse
import com.ultimate.ag.a03.data.response.BalanceResponse
import com.ultimate.ag.a03.data.response.ToGameResponse
import com.ultimate.ag.a03.data.response.ToLocalResponse
import com.ultimate.ag.a03.net.ApiErrorModel

class AccountDetailsPresenter : BasePresenter<AccountDetailsView, AccountDetailsModel>() {

    /**
     * 获取余额信息
     */
    fun getBalance(request: BalanceRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.getBalance(request, view!!.getRxActivity(), object : MvpCallback<BalanceResponse> {
            override fun onSuccess(data: BalanceResponse) {
                if (!isViewAttached)
                    return
                view?.showBalance(data)
            }

            override fun onBusinessFail(data: BalanceResponse) {
                if (!isViewAttached)
                    return

                view?.getBalanceFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * PT转账
     */
    fun transferToGame(request: ToGameRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.transferToGame(request, view!!.getRxActivity(), object : MvpCallback<ToGameResponse> {
            override fun onSuccess(data: ToGameResponse) {
                if (!isViewAttached)
                    return
                view?.transferToGameSuccess()
            }

            override fun onBusinessFail(data: ToGameResponse) {
                if (!isViewAttached)
                    return

                view?.transferToGameFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * 转账至本地
     */
    fun transferToLocal(request: ToLocalRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.transferToLocal(request, view!!.getRxActivity(), object : MvpCallback<ToLocalResponse> {
            override fun onSuccess(data: ToLocalResponse) {
                if (!isViewAttached)
                    return
                view?.transferToLocalSuccess()
            }

            override fun onBusinessFail(data: ToLocalResponse) {
                if (!isViewAttached)
                    return

                view?.transferToLocalFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * 最后一次交易记录
     */
    fun queryBQBanks(request: BQBanksRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.queryBQBanks(request, view!!.getRxActivity(), object : MvpCallback<BQBanksResponse> {
            override fun onSuccess(data: BQBanksResponse) {
                if (!isViewAttached)
                    return
                view?.setLastTrasfer(data)
            }

            override fun onBusinessFail(data: BQBanksResponse) {
                if (!isViewAttached)
                    return
                view?.getLastTrasferFial(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }
}