package com.ultimate.ag.a03.activity.mvp.presenter

import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.MyPromoModel
import com.ultimate.ag.a03.activity.mvp.view.MyPromoView
import com.ultimate.ag.a03.data.request.MyPromoRequest
import com.ultimate.ag.a03.data.response.MyPromoResponse
import com.ultimate.ag.a03.net.ApiErrorModel

class MyPromoPresenter : BasePresenter<MyPromoView, MyPromoModel>() {

    /**
     * 获取我的红利
     */
    fun getMyPromo(request: MyPromoRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()

        model?.getMyPromo(request, view!!.getRxActivity(), object : MvpCallback<MyPromoResponse> {
            override fun onSuccess(data: MyPromoResponse) {
                if (!isViewAttached)
                    return

                if (data != null) {

                    view?.initHeadView()
                    view?.collatePromoData(data)
                    view?.showMyPromo(data)
                }
            }

            override fun onBusinessFail(data: MyPromoResponse) {
                if (!isViewAttached)
                    return

                view?.getMyPromoFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (isViewAttached)
                    view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }
}