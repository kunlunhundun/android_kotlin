package com.ultimate.ag.a03.activity.mvp.presenter

import com.google.gson.Gson
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.activity.mvp.model.SportsModel
import com.ultimate.ag.a03.activity.mvp.view.SportsView
import com.ultimate.ag.a03.data.request.InGameRequest
import com.ultimate.ag.a03.data.request.SportsPicturesRequest
import com.ultimate.ag.a03.data.request.SportsRequest
import com.ultimate.ag.a03.data.response.InGameResponse
import com.ultimate.ag.a03.data.response.SportsPicturesResponse
import com.ultimate.ag.a03.data.response.SportsResponse
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.ApiErrorModel

class SportsPresenter : BasePresenter<SportsView, SportsModel>() {

    fun showSportsData(){
        var dataString = AppInitManager.getAcache().getAsString("sportData")
        if (dataString!=null){
            val data = Gson().fromJson(dataString,SportsResponse::class.java)
            view?.showSports(data.body!!)
        }

        var pictureString = AppInitManager.getAcache().getAsString("sportsPictures")
        if (pictureString!=null){
            val data = Gson().fromJson(pictureString,SportsPicturesResponse::class.java)
            view?.showSportsPictures(data.body.sportsPictures)
        }
    }

    /**
     * 获取体育数据
     */
    fun getSportsData(request: SportsRequest) {

        if (!isViewAttached)
            return

//        view?.showLoading()
        model?.getNetData(request, view!!.getRxActivity(), object : MvpCallback<SportsResponse> {
            override fun onSuccess(data: SportsResponse) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(true)
                if (data.body != null) {

                    AppInitManager.getAcache().put("sportData",Gson().toJson(data))
                    view?.showSports(data.body)
                }
            }

            override fun onBusinessFail(data: SportsResponse) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(false)
                view?.getSportsFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return
                view?.finishRefresh(false)
                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })
    }

    /**
     * 获取体育图片
     */
    fun getSportsPictures(request: SportsPicturesRequest) {
        if (!isViewAttached)
            return

//        view?.showLoading()
        model?.getSportsPictureData(request, view!!.getRxActivity(), object : MvpCallback<SportsPicturesResponse> {
            override fun onSuccess(data: SportsPicturesResponse) {
                if (!isViewAttached)
                    return

                if (data.body.sportsPictures != null) {
                    AppInitManager.getAcache().put("sportsPictures",Gson().toJson(data))
                    view?.showSportsPictures(data.body.sportsPictures)
                }
            }

            override fun onBusinessFail(data: SportsPicturesResponse) {
                if (!isViewAttached)
                    return

                view?.getSportsPicturesFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }

        })
    }

    /**
     * 点击获取沙巴体育链接
     */
    fun inGame(request: InGameRequest){
        if (!isViewAttached)
            return

        view?.showLoading()
        model?.getGameAdress(request,view!!.getRxActivity(), object : MvpCallback<InGameResponse>{
            override fun onSuccess(data: InGameResponse) {
                if (!isViewAttached)
                    return

                if (data.body != null){
                    view?.inSabaGame(data)
                }
            }

            override fun onBusinessFail(data: InGameResponse) {
                if (!isViewAttached)
                    return

                view?.getSportsAdressFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })


    }

    /**
     * 点击获取沙巴体育链接
     */
    fun inBBGame(request: InGameRequest) {
        if (!isViewAttached)
            return

        view?.showLoading()
        model?.getGameAdress(request, view!!.getRxActivity(), object : MvpCallback<InGameResponse> {
            override fun onSuccess(data: InGameResponse) {
                if (!isViewAttached)
                    return

                if (data.body != null) {
                    view?.inBBGame(data)
                }
            }

            override fun onBusinessFail(data: InGameResponse) {
                if (!isViewAttached)
                    return

                view?.getSportsAdressFail(data)
            }

            override fun onFail(model: ApiErrorModel) {
                if (!isViewAttached)
                    return

                view?.showToast(model.message)
            }

            override fun complete() {
                if (isViewAttached)
                    view?.cancelLoading()
            }
        })


    }
}