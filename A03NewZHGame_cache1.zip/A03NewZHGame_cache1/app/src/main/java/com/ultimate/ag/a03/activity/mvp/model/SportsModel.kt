package com.ultimate.ag.a03.activity.mvp.model

import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.activity.mvp.MvpCallback
import com.ultimate.ag.a03.data.TagItem
import com.ultimate.ag.a03.data.request.CoverPointRequest
import com.ultimate.ag.a03.data.request.InGameRequest
import com.ultimate.ag.a03.data.request.SportsPicturesRequest
import com.ultimate.ag.a03.data.request.SportsRequest
import com.ultimate.ag.a03.data.response.InGameResponse
import com.ultimate.ag.a03.data.response.SportsPicturesResponse
import com.ultimate.ag.a03.data.response.SportsResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.Utils

class SportsModel : IModel {

    /**
     * 获取体育竞猜界面数据
     */
    fun getNetData(request: SportsRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<SportsResponse>) {
        ApiClient.instance.frontService.athleticContest(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .subscribe(object : ApiMvpResponse<SportsResponse>() {
                    override fun businessFail(data: SportsResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: SportsResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }
                })
    }

    /**
     * 获取体育图片数据
     */
    fun getSportsPictureData(request: SportsPicturesRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<SportsPicturesResponse>) {
        ApiClient.instance.frontService.queryByKeyList(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .subscribe(object : ApiMvpResponse<SportsPicturesResponse>() {
                    override fun businessFail(data: SportsPicturesResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: SportsPicturesResponse) {
                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }

                })
    }

    var mProcedureId: String = ""

    /**
     * 获取沙巴体育链接
     */
    fun getGameAdress(request: InGameRequest, activity: RxAppCompatActivity, mvpCallback: MvpCallback<InGameResponse>) {
        val tagItem = TagItem("logingame_click", "请求游戏url", "游戏", "进游戏", "页面操作指标")
        mProcedureId = Utils.getProcedureId("EnterGameProcedure")
        val coverData = CoverPointRequest.Data()
        Utils.setGameCoverData(request, coverData)
        Utils.coverPointRequest(tagItem, "MainActivity", "SportsFragment", mProcedureId, coverData)

        ApiClient.instance.service.inGame(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(activity, ActivityEvent.DESTROY)
                .subscribe(object : ApiMvpResponse<InGameResponse>() {
                    override fun businessFail(data: InGameResponse) {
                        mvpCallback.complete()
                        mvpCallback.onBusinessFail(data)
                    }

                    override fun businessSuccess(data: InGameResponse) {

                        val tagItem = TagItem("logingame_show", "加载游戏url", "游戏", "其他", "页面操作指标")
                        Utils.coverPointRequest(tagItem, "MainActivity", "SportsFragment", mProcedureId, coverData)

                        mvpCallback.complete()
                        mvpCallback.onSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        mvpCallback.complete()
                        mvpCallback.onFail(apiErrorModel)
                    }

                })
    }
}