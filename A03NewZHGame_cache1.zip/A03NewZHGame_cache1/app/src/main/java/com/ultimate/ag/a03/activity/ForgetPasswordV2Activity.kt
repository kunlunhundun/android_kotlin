package com.ultimate.ag.a03.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ScrollView
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.response.GenerateCodeResponse
import com.ultimate.ag.a03.data.response.SendSmsResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import kotlinx.android.synthetic.main.view_custom_input.view.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

import android.text.TextWatcher
import android.text.style.BulletSpan
import android.util.Log
import android.widget.Toast
import com.ultimate.ag.a03.util.*
import com.ultimate.ag.a03.util.Utils.isPhoneNumberValid
import kotlinx.android.synthetic.main.activity_forget_password.content
import kotlinx.android.synthetic.main.activity_forget_password.ct_username
import kotlinx.android.synthetic.main.activity_forget_password.ct_verification_code
import kotlinx.android.synthetic.main.activity_forget_password.fl_verification_code
import kotlinx.android.synthetic.main.activity_forget_password.forget_password_form
import kotlinx.android.synthetic.main.activity_forget_password.iv_verification_code
import kotlinx.android.synthetic.main.activity_forget_password.rl_verify_error
import kotlinx.android.synthetic.main.activity_forget_password.tv_submit
import kotlinx.android.synthetic.main.activity_forget_password.tv_tip
import kotlinx.android.synthetic.main.activity_forget_passwordv2.*
import kotlinx.android.synthetic.main.activity_forget_passwordv2.tv_send_code

import com.ultimate.ag.a03.data.response.PreForgetPwdByMobileNoResponse
import com.ultimate.ag.a03.data.SamePhoneLoginName
import com.ultimate.ag.a03.view.CustomDialogView
import java.io.Serializable
import com.ultimate.ag.a03.activity.RegisterActivity
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.VerifySmsCodeResponse
import com.ultimate.ag.a03.view.AutoCaseTransformationMethod


class ForgetPasswordV2Activity : BaseToolBarActivity() {
    private var showSoftKeyboad = false

    var phoneNum: String? = null //要找回密码的手机号
    var phoneMessageId: String? = null //请求短信返回的messageId


    var captchaId: String? = null
    var validateId: String? = null

    var messageId: String? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_forget_passwordv2
    }

    override fun initData() {
        ct_username?.setAutoCaseTransformationMethod(AutoCaseTransformationMethod())
        getGenerateCode()
    }

    override fun initListener() {
        OverScrollDecoratorHelper.setUpOverScroll(forget_password_form)
        tv_submit.setOnClickListener {
            onClickSubmit()
        }

        iv_verification_code.setOnClickListener {
            getGenerateCode()
        }

        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService(this)
        }

        //监测文字输入 首字母数字视为手机号 长度11  首字母字母视为账号，长度15
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun afterTextChanged(s: Editable) {
                if (s.count() > 0){
                    if (s.first().isDigit()) {
                        ct_username.postDelayed({
                            Utils.limitLetterOrDigit(ct_username.getEditText(), 11)
                        }, 1000)

                        fl_verification_code.visibility = View.GONE
                        fl_verification_code_for_phone.visibility = View.VISIBLE

                        if (s.count()==11){
                            if (tv_send_code.text.toString().equals("获取验证码") || tv_send_code.text.toString().equals("重新发送验证码")){
                                tv_send_code.setBackgroundResource(R.drawable.bg_button_sendcode)
                                tv_send_code.isEnabled = true
                            }
                        }else{
                            tv_send_code.setBackgroundResource(R.drawable.bg_button_sendcode_disable)
                            tv_send_code.isEnabled = false
                        }
                    }else{
                        ct_username.postDelayed({
                            Utils.limitLetterOrDigit(ct_username.getEditText(), 15)
                        }, 1000)

                        fl_verification_code.visibility = View.VISIBLE
                        fl_verification_code_for_phone.visibility = View.GONE
                    }
                }else{
                    fl_verification_code.visibility = View.GONE
                    fl_verification_code_for_phone.visibility = View.GONE
                }

            }

        }
        ct_username.et_input.addTextChangedListener(textWatcher)

        tv_send_code.setOnClickListener {
            val phoneNumText = ct_username.getEditTextContent().trim()
            if (!isPhoneNumberValid(phoneNumText)) {
                ToastUtils.show("手机号无效")
                return@setOnClickListener
            }

            tv_send_code.isEnabled = false
            initTimer(60)?.start()
            val request = SendSmsRequest()
            request.use = "2"
            request.loginName = ConfigUtils.loginName
            request.mobileNo = RSATool.encode(phoneNumText)
            ApiClient.instance.service.sendCode(request)
                    .compose(NetworkScheduler.compose())
                    .bindUntilEvent(this, ActivityEvent.DESTROY)
                    .subscribe(object : ApiResponse<SendSmsResponse>(this) {
                        override fun businessFail(data: SendSmsResponse) {
                            ToastUtils.show("" + data.head.errCode)
                        }

                        override fun businessSuccess(data: SendSmsResponse) {
                            phoneNum = phoneNumText //记住发短信的手机号
                            phoneMessageId = data.body.messageId
                            ToastUtils.show("发送验证码成功")
                        }

                        override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                            ToastUtils.show("" + apiErrorModel.message)
                        }

                    })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidWorkaround.assistActivity(findViewById(android.R.id.content))
        // Set up the login form.
        StatusBarUtil.StatusBarLightMode(this)
        setTile("")
        isShowBack(true)
        setActionText("联系客服")
        content.addOnLayoutChangeListener(this)

    }

    private fun onClickSubmit() {
        ct_username.hideError()

        val text = ct_username.getEditTextContent().trim()
        if (text.first().isDigit()){
            //通过手机号找回
            if (text.count() != 11){
                ToastUtils.show("请输入手机号")
                return
            }
            if (tv_send_code.text.isNullOrEmpty()){
                ToastUtils.show("请输入短信验证码")
                return
            }

            validatePhoneCodeRequest()
        }else{
            //通过用户名找回
            if (!Utils.isUsernameCorrect(ct_username, false)) {
                ToastUtils.show("用户名格式有误")
                return
            }

            //输入图形验证码阶段
            if (fl_verification_code.visibility == View.VISIBLE){
                if (ct_verification_code_for_account.getEditTextContent().trim().isNullOrEmpty()){
                    ToastUtils.show("请输入图形验证码")
                    return
                 }

                validateRequest()
            }

            //输入手机验证码阶段
            if (fl_sms_code_for_account.visibility == View.VISIBLE) {
                if (ct_sms_code_for_account.getEditTextContent().trim().isNullOrEmpty()){
                    ToastUtils.show("请输入手机验证码")
                    return
                }

                verifySmsCodeForAccount()
            }


        }

    }

    private fun isUserNameValid(username: String): Int {
        return ProjectUtils.checkOldUserNameAvailable(username)
    }

    private fun validatePhoneCodeRequest(){
        val preForgetPswPhone = PreFogetPwdByMobileNoRequest()
        preForgetPswPhone.messageId = phoneMessageId
        val text = ct_username.getEditTextContent().trim()
        preForgetPswPhone.phone = RSATool.encode(text)
        preForgetPswPhone.smsCode = ct_sms_code_for_phone.getEditTextContent().trim()
        preForgetPswPhone.use = "2"
        ApiClient.instance.service.preForgetPwdByMobileNo(preForgetPswPhone)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<PreForgetPwdByMobileNoResponse>(this, true) {
                    override fun businessFail(data: PreForgetPwdByMobileNoResponse) {
                        getGenerateCode()
                        ct_sms_code_for_phone.setEditText("")
                        when (data.head.errCode) {
                            "GW_801511" -> {
                                //手机号没有注册过 （"errMsg":"手机号码有误，禁止登陆"）
                                val dialog = CustomDialogView(this@ForgetPasswordV2Activity)
                                dialog.showCustomViewDialog(200f)
//                                dialog.setTitle(getString(R.string.home_choiceness_tv_promo_title))
                                dialog.setDes(getString(R.string.forget_password_phone_unregister_des))
                                dialog.setBtnLeft(getString(R.string.forget_password_phone_unregister_back))
                                dialog.setBtnRight(getString(R.string.forget_password_phone_unregister_regist))
                                dialog.setBtnCancelOnclick(View.OnClickListener {
                                    dialog.dismiss()
                                })
                                dialog.setBtnOkOnclick(View.OnClickListener {
                                    dialog.dismiss()
                                    gotoRegist()
                                })
                            }
                            else -> {
                                ToastUtils.show("" + data.head.errMsg)
                            }
                        }
                    }

                    override fun businessSuccess(data: PreForgetPwdByMobileNoResponse) {
                        val intent = Intent(this@ForgetPasswordV2Activity, ForgetPasswordSetNewPswActivity::class.java)
                        intent.putExtra("validateId", data.body.validateId)
                        intent.putExtra("messageId", phoneMessageId)
                        intent.putExtra("smsCode", preForgetPswPhone.smsCode)
                        intent.putExtra("type", 2)
                        intent.putExtra("use", 2)
                        var array :MutableList<SamePhoneLoginName> = mutableListOf()
                        data.body.samePhoneLoginNames?.forEachIndexed { index, item ->
                            if (index < 10) {
                                array.add(item)
                            }
                        }
                        intent.putExtra("accounts",array as Serializable)
                        goToPage(intent)
                        goToPage(intent)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ToastUtils.show(apiErrorModel.message)
                    }

                })

    }

    private fun gotoRegist() {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }

    private fun validateRequest() {
        val sendSmsRequest = SendCodeByLoginNameRequest()
//        sendSmsRequest.validateId = validateId
        sendSmsRequest.captchaCode = ct_verification_code_for_account.getEditTextContent().trim()
        sendSmsRequest.captchaId = captchaId
        sendSmsRequest.loginName = ct_username.getEditTextContent().trim()
//        sendSmsRequest.realName = "我我"
        sendSmsRequest.use = "4"
        ApiClient.instance.service.sendCodeByLoginName(sendSmsRequest)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this, true) {
                    override fun businessFail(data: SendSmsResponse) {
                        getGenerateCode()
//                        ct_verification_code_for_account.setEditText("")
                        when (data.head.errCode) {
//                            "480001" -> {
//                                ct_verification_code.showError(R.string.error_invalid_verification_code)
//                                ct_verification_code.requestFocus()
//                            }
//
//                            "GW_800703" -> {
//                                ct_true_name.showError(data.head.errMsg)
//                                ct_true_name.requestFocus()
//                            }
//                            "GW_800301" -> {
//                                showCustomerService()
//                            }
//                            else -> {
//                                ct_username.showError(data.head.errMsg)
//                                ct_username.requestFocus()
//                            }

                        }
                        ToastUtils.show("" + data.head.errMsg)
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        messageId = data.body.messageId

                        //请求短信码成功，修改UI
                        ct_username.setUnEditable() //用户名改为不可编辑
                        fl_verification_code.visibility = View.GONE
                        ll_bind_phone_view.visibility = View.VISIBLE
                        tv_bind_phone.text = data.body.mobileNo
                        fl_sms_code_for_account.visibility = View.VISIBLE
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//                        showError(apiErrorModel.message)
                        getGenerateCode()
                    }

                })

    }

    private fun verifySmsCodeForAccount() {
        val request = VerifySmsCodeRequest()
        request.messageId = messageId
        request.smsCode = ct_sms_code_for_account.getEditTextContent().trim()
        request.loginName = ct_username.getEditTextContent().trim()
        request.use = 4

        ApiClient.instance.service.verifySmsCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<VerifySmsCodeResponse>(this) {
                    override fun businessFail(data: VerifySmsCodeResponse) {
                        Toast.makeText(this@ForgetPasswordV2Activity, data.head.errMsg, Toast.LENGTH_LONG).show()
                        showError(data.head.errMsg!!)
                    }

                    override fun businessSuccess(data: VerifySmsCodeResponse) {
                        val intent = Intent(this@ForgetPasswordV2Activity, ForgetPasswordSetNewPswActivity::class.java)
                        intent.putExtra("validateId", data.body.validateId)
                        intent.putExtra("messageId", messageId)
                        intent.putExtra("smsCode",ct_sms_code_for_account.getEditTextContent().trim())
                        intent.putExtra("type", 2)
                        intent.putExtra("fromAccount", ct_username.getEditTextContent().trim())
                        goToPage(intent)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }

    private fun getGenerateCode() {
        val request = GenerateCodeRequest()
        request.use = "3"
        ApiClient.instance.service.generateCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GenerateCodeResponse>(this, true) {
                    override fun businessFail(data: GenerateCodeResponse) {
                        showError(data.head.errMsg)
                    }

                    override fun businessSuccess(data: GenerateCodeResponse) {
                        captchaId = data.body.captchaId
                        iv_verification_code.setImageBitmap(Utils.stringToBitmap(data.body.image))

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }


    override fun onLayoutChange(p0: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {
        if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight)) {
            tv_submit.visibility = View.VISIBLE

//            if (ct_verification_code.getEditText().isFocused) {
//                forget_password_form.fullScroll(ScrollView.FOCUS_DOWN)
//                ct_verification_code.requestFocus()
//            }
//
//            if (rl_verify_error.visibility != View.VISIBLE) {
//                tv_submit.visibility = View.VISIBLE
//            }

//            forget_password_form.smoothScrollBy(0, Dip2PixleUtil.dp2px(this, 100f))
//            showSoftKeyboad = true


        } else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight)) {
            tv_submit.visibility = View.INVISIBLE
//            showSoftKeyboad = false

        }
    }


    private fun showError(error: String?) {
        tv_submit.visibility = View.GONE
        val animation = AnimationUtils.loadAnimation(this@ForgetPasswordV2Activity, R.anim.popupwindow_show_anim)
        rl_verify_error.startAnimation(animation)
        rl_verify_error.visibility = View.VISIBLE
        tv_tip.text = error

        val handler = Handler()
        val runnable = Runnable {
            rl_verify_error.visibility = View.GONE
            tv_tip.text = ""
            tv_submit.visibility = View.VISIBLE
        }
        handler.postDelayed(runnable, 2000)
    }


    private var timer: CountDownTimer? = null
    private fun initTimer(time: Long): CountDownTimer? {
        timer = object : CountDownTimer(time * 1000, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                tv_send_code.text = String.format(getString(R.string.bind_mobile_phone_activity_wait_tip), millisUntilFinished / 1000)
                tv_send_code.setBackgroundResource(R.drawable.bg_button_sendcode_disable)
                tv_send_code.isEnabled = false
            }

            override fun onFinish() {
                tv_send_code.setBackgroundResource(R.drawable.bg_button_sendcode)
                tv_send_code.setTextColor(resources.getColor(R.color.white))
                tv_send_code.text = "重新发送验证码"
                tv_send_code.isEnabled = true
            }
        }

        return timer
    }

}
