package com.ultimate.ag.a03.util

interface CommonCallback{

    fun onCalled()
}