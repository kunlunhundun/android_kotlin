package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.MyPromoResponse

interface MyPromoView: IBaseView{

    /**
     * 整理我的红利数据
     */
    fun collatePromoData(data: MyPromoResponse)

    /**
     * 初始化头部布局
     */
    fun initHeadView()

    /**
     * 展示我的红利数据
     */
    fun showMyPromo(data: MyPromoResponse)

    /**
     * 获取我的红利数据失败
     */
    fun getMyPromoFail(data: MyPromoResponse)

    /**
     * tag选中触发方法
     */
    fun tagChoosed(tag : Int)
}