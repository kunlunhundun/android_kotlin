package com.ultimate.ag.a03.database

import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class H5Version : DataSupport() {
    var version: String? = null
    var md5: String? = null
}