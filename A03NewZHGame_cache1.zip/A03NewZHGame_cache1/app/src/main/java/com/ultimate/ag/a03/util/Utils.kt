package com.ultimate.ag.a03.util


import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.support.annotation.RequiresApi
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.telephony.TelephonyManager
import android.text.InputFilter
import android.text.TextUtils
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import com.github.dfqin.grantor.PermissionsUtil
import com.goldarmor.live800lib.live800sdk.manager.LIVManager
import com.goldarmor.live800lib.live800sdk.request.LIVUserInfo
import com.google.gson.Gson
import com.gyf.barlibrary.ImmersionBar
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ivi.library.statistics.models.T3sAppAgqjBean
import com.ivi.library.statistics.models.T3sAppPageBean
//import com.ivi.utils.LogUtil
import com.ultimate.ag.a03.BuildConfig
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.MyApplication.Companion.gameResult
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.activity.RegisterSucceedActivity
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.TagItem
import com.ultimate.ag.a03.data.request.CoverPointRequest
import com.ultimate.ag.a03.data.request.InGameRequest
import com.ultimate.ag.a03.data.response.CoverPointResponse
import com.ultimate.ag.a03.hybride.MyWebView
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiMvpResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.view.CommonDialog
import com.ultimate.ag.a03.view.CustomInputTextView
import com.vector.update_app.UpdateAppBean
import com.vector.update_app.UpdateAppManager
import com.vector.update_app.service.DownloadService
import com.vector.update_app.utils.AppUpdateUtils
import common.util.sign.SignUtils
import kotlinx.android.synthetic.main.fragment_register_username.*
import kotlinx.android.synthetic.main.view_custom_input.view.*
import okhttp3.HttpUrl
import java.io.File
import java.io.FileInputStream
import java.math.BigDecimal
import java.net.NetworkInterface
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by ward.y on 2018/2/23.
 */
object Utils {

    fun setGameCoverData(request: InGameRequest, coverData: CoverPointRequest.Data): CoverPointRequest.Data {
        var game_id: String = if (request.gameId != null) {
            request.gameId ?: ""
        } else if (request.gameType != null) {
            request.gameType ?: ""
        } else {
            ""
        }

        val dimension = mutableMapOf<String, String?>()
        dimension.put("game_id", game_id)
        dimension.put("platform", request.gameCode)
        coverData.game_id = game_id
        coverData.platform = request.gameCode ?: ""
        coverData.event_dimension = dimension
        return coverData
    }

    /**
     * @param tagItem 事件对象
     * @param referer 跳轉前頁面
     *@param pageUrl 跳轉後頁面
     */
    @JvmStatic
    fun coverPointRequest(tagitem: TagItem, referer: String, pageUrl: String, procedureId: String) {
        val data = CoverPointRequest.Data()
        data.tag_name = tagitem.tag_name
        data.tag_type = tagitem.tag_type
        data.tag_action = tagitem.tag_action
        data.tag_index = tagitem.tag_index
        data.procedure_id = procedureId
        this.coverPointRequest(tagitem, referer, pageUrl, procedureId, data)
    }

    /**
     * 获取流程ID 生成規則：{productId}_{split(app_id,’.’)[2]}_{流程名}_{timestamp:13码}_{亂數11碼}
     */
    @JvmStatic
    fun getProcedureId(procedureName: String): String {
        return if (TextUtils.isEmpty(procedureName)) "" else "A03_A03zhapp_${procedureName}_${System.currentTimeMillis()}_${Utils.getRandomID(11)}"
    }

    /**
     * @param tagItem 事件对象
     * @param referer 跳轉前頁面
     *@param pageUrl 跳轉後頁面
     *@param data 动态参数
     */
    fun coverPointRequest(tagitem: TagItem, referer: String, pageUrl: String, procedureId: String, data: CoverPointRequest.Data) {
        var requestBody = CoverPointRequest()
        requestBody.tag_id = tagitem.tag_id
        requestBody.referer = referer
        requestBody.page_url = pageUrl
        data.procedure_id = procedureId
        data.tag_action = tagitem.tag_action
        data.tag_name = tagitem.tag_name
        data.tag_type = tagitem.tag_type
        data.tag_index = tagitem.tag_index
        requestBody.data = Gson().toJson(data)
        ApiClient.instance.dataService.coverPointMessage(requestBody)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiMvpResponse<CoverPointResponse>() {
                    override fun businessFail(data: CoverPointResponse) {

                    }

                    override fun businessSuccess(data: CoverPointResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })

    }

    fun isPhoneNumberValid(phoneNumber: String): Boolean {
        return phoneNumber.length == 11 && Utils.formatPhoneNumber(phoneNumber) == 0
    }

    fun callPhone(context: Context, phoneNum: String) {
        val intent = Intent(Intent.ACTION_CALL)
        intent.setData(Uri.parse("tel:" + phoneNum))
        context.startActivity(intent)
    }

    /**
     * 得到几天前的时间
     * @param d
     * @param day
     * @return
     */
    fun getDateBefore(d: Date, day: Int): Date {
        val now = Calendar.getInstance()
        now.time = d
        now.set(Calendar.DATE, now.get(Calendar.DATE) - day)
        now.set(Calendar.HOUR_OF_DAY, 0)
        now.set(Calendar.MINUTE, 0)
        now.set(Calendar.SECOND, 0)
        return now.time
    }

    /**
     * 得到几天后的时间
     * @param d
     * @param day
     * @return
     */
    fun getDateAfter(d: Date, day: Int): Date {
        val now = Calendar.getInstance()
        now.time = d
        now.set(Calendar.DATE, now.get(Calendar.DATE) + day)
        now.set(Calendar.HOUR_OF_DAY, 0)
        now.set(Calendar.MINUTE, 0)
        now.set(Calendar.SECOND, 0)
        return now.time
    }

    @JvmStatic
    fun downLoadApp(context: Context, url: String?) {

        Utils.downLoadApp(context, url, true)
    }

    @JvmStatic
    fun downLoadApp(context: Context, url: String?, cancelAble: Boolean) {

        if (TextUtils.isEmpty(url) || HttpUrl.parse(url) == null) {
            return
        }

        val updateAppBean = UpdateAppBean()

        //设置 apk 的下载地址
        updateAppBean.apkFileUrl = url
        var path: String? = ""
        if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED || !Environment.isExternalStorageRemovable()) {
            try {
                path = context?.externalCacheDir?.absolutePath
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (TextUtils.isEmpty(path)) {
                path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
            }
        } else {
            path = context?.cacheDir?.absolutePath
        }

        //设置apk 的保存路径
        updateAppBean.targetPath = path
        //实现网络接口，只实现下载就可以
        updateAppBean.httpManager = UpdateAppHttpUtil()
        UpdateAppManager.download(context, updateAppBean, object : DownloadService.DownloadCallback {

            override fun onStart() {
                HProgressDialogUtils.showHorizontalProgressDialog(context, "下载进度", false)
                HProgressDialogUtils.setCancleAble(cancelAble)
            }

            override fun onProgress(progress: Float, totalSize: Long) {
                HProgressDialogUtils.setProgress(Math.round(progress * 100))

            }

            override fun setMax(totalSize: Long) {
            }

            override fun onFinish(file: File): Boolean {
                HProgressDialogUtils.cancel()
                AppUpdateUtils.installApp(context, file)
                return false
            }

            override fun onError(msg: String) {
                HProgressDialogUtils.cancel()
            }

            override fun onInstallAppAndAppOnForeground(file: File): Boolean {
                return false
            }
        })
    }

    /**
     * 获取版本号
     * @return 当前应用的版本号
     */
    @JvmStatic
    fun getVersion(): String {
        return try {
            val manager = MyApplication.instance!!.packageManager
            val info = manager.getPackageInfo(MyApplication.instance!!.packageName, 0)
            val version = info.versionName
            version
        } catch (e: Exception) {
            e.printStackTrace()
            "1.0.0"
        }
    }

    /**
     * 获取版本号
     * @return 当前应用的版本号
     */
    @JvmStatic
    fun getVersionCode(): Int {
        return try {
            val manager = MyApplication.instance!!.packageManager
            val info = manager.getPackageInfo(MyApplication.instance!!.packageName, 0)
            val version = info.versionCode
            version
        } catch (e: Exception) {
            e.printStackTrace()
            12
        }
    }

    /**
     * 获取当前时区ID
     * @return 当前时区ID
     */
    @JvmStatic
    fun getTimeZoneID(): String {
        var tz = TimeZone.getDefault()
        return tz.id.toString()
    }

    /**
     * @return 获取当前的格式化日期比如 2018-03-01 12:23:35
     */
    @JvmStatic
    fun getCurentTime(): String {
        return try {
            System.currentTimeMillis().toString()
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    /**
     * @return 获取当前的格式化日期比如 2018-03-01 12:23:35
     */
    @JvmStatic
    fun getCurentTime(pattern: String): String {
        return try {
            val simpleDateFormat = SimpleDateFormat(pattern)
            simpleDateFormat.format(Date())
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }



    @JvmStatic
    fun getTwoDayHours(dateStr:String):String{

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var dayHours = ""
        try {

            val mDate =  dateFormat.parse(dateStr)
            val currentDate = Date()
            var dValueDay = (currentDate.time - mDate.time) /(24*60*60*1000)
            if (dValueDay == 0L) {
                dValueDay = (currentDate.time - mDate.time) /(60*60*1000)

                if (dValueDay == 0L) {
                    dayHours =  "1小时内"
                }else{
                    dayHours =  "$dValueDay"+"小时前"
                }
            }else{
                val month = dValueDay/30
                if (month > 0 ) {
                    if ( month > 12) {
                        val year = month/12
                        dayHours = "$year" + "年前"
                    }else{
                        dayHours = "$month" + "月前"
                    }
                }else{
                    dayHours =  "$dValueDay"+"天前"
                }
            }

        }catch ( e : Exception) {

        }
        return dayHours
    }

    /**
     * 返回一个时间+6位的随机数
     */
    @JvmStatic
    fun getRandomStr() : String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val dateStr = dateFormat.format(Date())
        var random = (Math.random()*9+1)*1000
        return dateStr + (random.toString())
    }

    /**
     * @return 手机运营商
     */

    @SuppressLint("MissingPermission", "HardwareIds")
    @JvmStatic
    fun getNetFirm(): String {
        var providersName: String? = null

        var IMSI: String? = null
        if (getTelephonyManager()?.subscriberId == null) {
            Log.d("====---===", "    " + getTelephonyManager()?.subscriberId)
            return "无运行商"
        } else {
            IMSI = getTelephonyManager()!!.subscriberId
        }
        if (TextUtils.isEmpty(IMSI)) {
            Log.d("====---===", "    " + getTelephonyManager())
            return "无运行商"
        }
        if (IMSI.startsWith("46000") || IMSI.startsWith("46002")) {
            providersName = "中国移动"
        } else if (IMSI.startsWith("46001")) {
            providersName = "中国联通"
        } else if (IMSI.startsWith("46003")) {
            providersName = "中国电信"
        }
        return providersName.toString()
    }

    @JvmStatic
    fun getSimCode(): String? {
        return getTelephonyManager()?.simSerialNumber
    }


    @JvmStatic
    fun getSimUserCode(): String? {
        return getTelephonyManager()?.subscriberId
    }

    @JvmStatic
    fun getCountry(): String? {
        return MyApplication.getinstance().baseContext.resources.configuration.locale.country
    }

    @JvmStatic
    fun getPhoneNumber(number: String): String {
        val sb = StringBuilder()
        val charArray = number.toCharArray()

        charArray.forEachIndexed { index, c ->
            if (index in 1..12) {
                if (index < 4 && index % 3 == 0) {
                    sb.append(" $c")
                } else if ((index - 3) % 4 == 0) {
                    sb.append(" $c")
                } else {
                    sb.append(c)
                }


            } else {
                sb.append(c)
            }

        }
        return sb.toString()
    }

    private var sTelephonyManager: TelephonyManager? = null

    @JvmStatic
    private fun getTelephonyManager(): TelephonyManager? {

        if (PermissionsUtil.hasPermission(MyApplication.getinstance().applicationContext, Manifest.permission.READ_PHONE_STATE)) {
            if (sTelephonyManager == null) {
                sTelephonyManager = MyApplication.instance!!.getSystemService(
                        Context.TELEPHONY_SERVICE) as TelephonyManager?
            }
        }

        return sTelephonyManager
    }


    @JvmStatic
    fun getUqid(): String {
        var temp = StringBuffer()
        if (null != getTelephonyManager()) {
            val imei = sTelephonyManager?.deviceId
            if (imei != null) {
                temp.append(imei)
            }
        }
        if (!TextUtils.isEmpty(getMacAddr())) {
            temp.append(getMacAddr())
        }

        return md5Encode(temp.toString())
    }

    /**
     * 获取设备IMEI码
     */
    @JvmStatic
    fun getIMEI(): String {
        val tm = getTelephonyManager()!!.deviceId
        if (tm == null) {
            return " "
        } else {
            return tm
        }
    }

    private fun getMacAddr(): String {
        try {
            val all = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (nif in all) {
                if (!nif.name.equals("wlan0", ignoreCase = true)) continue

                val macBytes = nif.hardwareAddress ?: return ""

                val res1 = StringBuilder()
                for (b in macBytes) {
                    res1.append(String.format("%02X:", b))
                }

                if (res1.length > 0) {
                    res1.deleteCharAt(res1.length - 1)
                }
                return res1.toString()
            }
        } catch (ex: Exception) {
        }

        return "02:00:00:00:00:00"
    }


    @JvmStatic
    // a integer to xx:xx:xx
    fun secToTime(time: Long): String {
        var timeStr: String? = null
        var hour: Long
        var minute: Long
        var second: Long
        if (time <= 0)
            return "00:00"
        else {
            minute = time / 60
            if (minute < 60) {
                second = time % 60
                timeStr = unitFormat(minute) + ":" + unitFormat(second)
            } else {
                hour = minute / 60
                if (hour > 99)
                    return "99:59:59"
                minute %= 60
                second = time - hour * 3600 - minute * 60
                timeStr = unitFormat(hour) + ":" + unitFormat(minute) + ":" + unitFormat(second)
            }
        }
        return timeStr
    }

    private fun unitFormat(i: Long): String {

        return if (i in 0..9)
            "0$i"
        else
            "" + i
    }

    @JvmStatic
    fun checkStringUsername(string: String): Boolean {
        val r1 = Regex("^[0-9a-zA-Z]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkStringChinese(string: String): Boolean {
        val r1 = Regex("^(\\*|[\\u4e00-\\u9fa5])[\\u4e00-\\u9fa5]{0,}$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkStringFullChinese(string: String): Boolean {
        val r1 = Regex("^[，,·.。0-9a-zA-Z\\u4e00-\\u9fa5]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkRealName(string: String): Boolean {
        val r1 = Regex("^[，,·.。a-zA-Z \\u4e00-\\u9fa5]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkMessage(string: String): Boolean {
        val r1 = Regex("^[，,·.。a-zA-Z0-9\\u4e00-\\u9fa5]{1,16}$")
        return r1.matches(string)
    }

//
//    @JvmStatic
//    fun checkUserNameAvailable(pwd: String): Int {
//        var type = 0
//        type = if (!TextUtils.isEmpty(pwd)) {
//            if (pwd.trim().length in (4..9)) {
//                val r1 = Regex("^[0-9a-z]{4,9}$")
//                if (r1.matches(pwd)) {
//                    type_success
//                } else {
//                    type_error_formate
//                }
//
//            } else {
//                type_error_lenth
//            }
//        } else {
//            type_error_empty
//        }
//
//        return type
//    }

    fun formatPhoneNumber(phoneNumber: String): Int {
        var result = 0
        result = if (!TextUtils.isEmpty(phoneNumber)) {
            if (phoneNumber.trim().length == 11) {
                val r1 = Regex("^1(1|2|3|4|5|6|7|8|9)\\d{9}$")
                val r2 = Regex("^9(2|8)\\d{9}$")
                if (r1.matches(phoneNumber) || r2.matches(phoneNumber)) {
                    0
                } else {
                    1
                }

            } else {
                1
            }

        } else {
            1
        }
        return result
    }

    fun formatSpecialRegistNumber(phoneNumber: String):Boolean{

        if (!TextUtils.isEmpty(phoneNumber)) {

            if (phoneNumber.trim().length == 11) {
                val r1 = Regex("^1(6|7)(0|1|9)\\d{8}$")
                if (r1.matches(phoneNumber) == true){ //注册的时候排除169 170 171
                   return true
                }
            }
        }
        return  false
    }


    @JvmStatic
    fun md5Encode(password: String): String {
        try {
            val instance: MessageDigest = MessageDigest.getInstance("MD5")//获取md5加密对象
            val digest: ByteArray = instance.digest(password.toByteArray())//对字符串加密，返回字节数组
            var sb = StringBuffer()
            for (b in digest) {
                var i: Int = b.toInt() and 0xff//获取低八位有效值
                var hexString = Integer.toHexString(i)//将整数转化为16进制
                if (hexString.length < 2) {
                    hexString = "0$hexString"//如果是一位的话，补0
                }
                sb.append(hexString)
            }
            return sb.toString()

        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }

        return ""
    }

    /**
     * 弹窗
     */
    @JvmStatic
    fun createDialog(supportFragmentManager: FragmentManager, type: Int) {

        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, type)
        val dialog = CommonDialog()
        dialog?.arguments = bundle
        dialog?.show(supportFragmentManager, "login")
    }

    @JvmStatic
    fun paramSort(map: MutableMap<String, Any?>): String {
        var stringBuffer = StringBuffer("")

        map.forEach {
            stringBuffer.append(it.key)
            stringBuffer.append("=")
            stringBuffer.append(it.value)
        }
        return stringBuffer.append(ConfigUtils.key).toString()
    }

    @JvmStatic
    fun stringSort(string: String): String {
        var stringBuffer = StringBuffer("")
        val x = stringBuffer.append(string).toString()
        val charArray = x.toCharArray()
        Arrays.sort(charArray)
        val sorted = String(charArray)


        return sorted
    }

    @JvmStatic

    lateinit var uuid: String

    fun getUUID(): String {
        uuid = UUID.randomUUID().toString().replace("-", "")
        return uuid
    }

    @JvmStatic
    fun getSign(url: String, uuid: String, qid: String): String {

        return if (url.endsWith("welcome") || url.endsWith("upgrade")) {
            getWelcomSign(stringSort(uuid), qid)

        } else if (!TextUtils.isEmpty(ConfigUtils.key)) {
            getNormalSign(stringSort(uuid), qid)

        } else if (!TextUtils.isEmpty(ConfigUtils.info)) {
            ConfigUtils.info = ConfigUtils.info
            getNormalSign(stringSort(uuid), qid)


        } else if (!TextUtils.isEmpty(ACache.get(MyApplication.getinstance().baseContext).getAsString("info"))) {
            ConfigUtils.info = ACache.get(MyApplication.getinstance().baseContext).getAsString("info")
            getNormalSign(stringSort(uuid), qid)

        } else {
            ""
        }
    }

    private fun getNormalSign(sort: String, qid: String): String {
        if (TextUtils.isEmpty(ConfigUtils.token)) {
            Utils.getToken()
        }

        val sign = "$sort$qid${ProjectUtils.APPID}${ProjectUtils.GATEWAY_VERSION}${ConfigUtils.DOMAIN_NAME}${ConfigUtils.token}${ConfigUtils.parentId}${DeviceInfo.getDeviceId()}${(ConfigUtils.key).toString()}"
//        LogUtils.e(sign)
        return md5Encode(sign)

    }

    private fun getWelcomSign(sort: String, qid: String): String {
        val sign = if (!TextUtils.isEmpty(ConfigUtils.token)) {
            "$sort$qid${ProjectUtils.APPID}${ProjectUtils.GATEWAY_VERSION}${ConfigUtils.DOMAIN_NAME}${ConfigUtils.token}${ConfigUtils.parentId}${DeviceInfo.getDeviceId()}"
        } else {
            "$sort$qid${ProjectUtils.APPID}${ProjectUtils.GATEWAY_VERSION}${ConfigUtils.DOMAIN_NAME}${ConfigUtils.parentId}${DeviceInfo.getDeviceId()}"
        }

//        LogUtils.e(sign)
        return md5Encode(sign)
    }

    @JvmStatic
    fun getH5Sign(qid: String): String {
//        LogUtils.e("$qid      ${ConfigUtils.key}")
        val sign = stringSort("$qid${ConfigUtils.key}")
//        LogUtils.e(sign+"******sign")
        return md5Encode(sign)
    }

    @JvmStatic
    fun getNewH5Sign(qid: String): String {
//        LogUtils.e("$qid      ${ConfigUtils.key}")
//        var srcStr = "${qid}" + "${ProjectUtils.APPID}" + "${BuildConfig.VERSION_NAME}" +
//                "${ConfigUtils.DOMAIN_NAME}" + "${Utils.getToken()}" + "${ConfigUtils.parentId}" +
//                "${DeviceInfo.getDeviceId()}"
//        val src = stringSort("$qid${ConfigUtils.key?:""}")
        val src = "${qid}0"
        val sign = SignUtils.getSign(src, qid, getSignKey())
        return sign
    }

    /**
     * 本地环境key返回1，运测和运营返回0
     */
    @JvmStatic
    fun getSignKey(): String {
        return if (ApiClient.instance.baseUrl.contains(ConfigUtils.testUrl)) "1" else "0"
    }

    @JvmStatic
    fun stringToBitmap(string: String?): Bitmap? {
        var bitmap: Bitmap? = null
        try {
            val input = Base64.decode(string, Base64.DEFAULT)
            bitmap = BitmapFactory.decodeByteArray(input, 0, input.size)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return bitmap
    }

    /**
     * 生成随机数当作getItemID
     * n ： 需要的长度
     *
     * @return
     */
    @JvmStatic
    fun getRandomID(n: Int): String {
        var randomID = ""
        val random = Random()
        for (i in 0 until n) {
            val str = if (random.nextInt(2) % 2 == 0) "num" else "char"
            if ("char".equals(str, ignoreCase = true)) { // 产生字母
                val nextInt = if (random.nextInt(2) % 2 == 0) 65 else 97
                // System.out.println(nextInt + "!!!!"); 1,0,1,1,1,0,0
                randomID += (nextInt + random.nextInt(26)).toChar()
            } else if ("num".equals(str, ignoreCase = true)) { // 产生数字
                randomID += random.nextInt(10).toString()
            }
        }
        return randomID
    }

    @JvmStatic
    fun getToken(): String {
        var token = ""
        if (!TextUtils.isEmpty(ConfigUtils.token)) {
            token = ConfigUtils.token!!
//            LogUtils.e("-----"+token)
        } else if (!TextUtils.isEmpty(AppInitManager.getAcache().getAsString("webtoken"))) {
            ConfigUtils.token = AppInitManager.getAcache().getAsString("webtoken")
            token = ConfigUtils.token!!
//            LogUtils.e("******"+token)
        }
        return token
    }


    @JvmStatic
    fun clearToken() {
        AppInitManager.getAcache().put("webtoken", "")
        AppInitManager.getAcache().put("token", "")
    }

    /**
     * 格式化账户金额显示
     * @amount 金额
     */

    @JvmStatic
    fun formatMoney(amount: String?): String {
        var temp = StringBuffer()
        if (!TextUtils.isEmpty(amount)) {
            return formatMoney(amount!!.toFloat(), false)
        }
        return temp.append("0.00").toString()
    }

    /**
     * 获取生日
     * @amount 金额
     */
    @JvmStatic
    fun getAgeByBirth(birthday: Date): Int {
        var age = 0
        try {
            val now = Calendar.getInstance()
            now.time = Date()// 当前时间

            val birth = Calendar.getInstance()
            birth.time = birthday

            if (birth.after(now)) {//如果传入的时间，在当前时间的后面，返回0岁
                age = 0
            } else {
                age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
                if (now.get(Calendar.DAY_OF_YEAR) > birth.get(Calendar.DAY_OF_YEAR)) {
                    age += 1
                }
            }
            return age
        } catch (e: Exception) {//兼容性更强,异常后返回数据
            return 0
        }

    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: Float): String {
        var temp = StringBuffer()
        val decimalFormat = DecimalFormat(".00")
        var p = decimalFormat.format(amount)
        when {
            amount == 0f -> {
                temp.append("0")
                temp.append(p)
            }
            (amount < 1.0f && amount > 0f) -> {
                temp.append("0")
                temp.append(p)
            }
            (amount > 0f && amount < 1000.0f) -> temp.append(p)
            amount < 0f -> {
                when {
                    amount > -1000 -> {
                        temp.append(p)
                    }
                    else -> {
                        p = p.replaceFirst("-", "")
                        val txt = p.split(".")
                        var charArray = txt[0].toCharArray()
                        charArray.reverse()
                        charArray.forEachIndexed { index, c ->
                            if (index % 3 == 0 && index != 0) {
                                temp.insert(0, "$c,")
                            } else {
                                temp.insert(0, c)
                            }
                        }

                        temp.insert(0, "-")
                        temp.append(".${txt[1]}")
                    }
                }
            }
            else -> {
                val txt = p.split(".")
                var charArray = txt[0].toCharArray()
                charArray.reverse()
                charArray.forEachIndexed { index, c ->
                    if (index % 3 == 0 && index != 0) {
                        temp.insert(0, "$c,")
                    } else {
                        temp.insert(0, c)
                    }
                }

                temp.append(".${txt[1]}")
            }
        }



        return "¥ $temp"
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: BigDecimal): String {
        var temp = StringBuffer()
        val decimalFormat = DecimalFormat(".00")
        var p = decimalFormat.format(amount)
        when {
            amount.toFloat() == 0.00f -> {
                temp.append("0")
                temp.append(p)
            }
            (amount < BigDecimal(1.00) && amount > BigDecimal(0.00)) -> {
                temp.append("0")
                temp.append(p)
            }
            (amount > BigDecimal(0.00) && amount < BigDecimal(1000.00)) -> temp.append(p)
            amount < BigDecimal(0.00) -> {
                when {
                    amount > BigDecimal(-1000.00) -> {
                        temp.append(p)
                    }
                    else -> {
                        p = p.replaceFirst("-", "")
                        val txt = p.split(".")
                        var charArray = txt[0].toCharArray()
                        charArray.reverse()
                        charArray.forEachIndexed { index, c ->
                            if (index % 3 == 0 && index != 0) {
                                temp.insert(0, "$c,")
                            } else {
                                temp.insert(0, c)
                            }
                        }

                        temp.insert(0, "-")
                        temp.append(".${txt[1]}")
                    }
                }
            }
            else -> {
                val txt = p.split(".")
                var charArray = txt[0].toCharArray()
                charArray.reverse()
                charArray.forEachIndexed { index, c ->
                    if (index % 3 == 0 && index != 0) {
                        temp.insert(0, "$c,")
                    } else {
                        temp.insert(0, c)
                    }
                }

                temp.append(".${txt[1]}")
            }
        }



        return "¥ $temp"
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: Float, hasLabel: Boolean): String {
        return if (!hasLabel) formatMoney(amount).replaceFirst("¥ ", "") else formatMoney(amount)
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: BigDecimal, hasLabel: Boolean): String {
        return if (!hasLabel) formatMoney(amount).replaceFirst("¥ ", "") else formatMoney(amount)
    }

    /**
     * 获取当前的网络状态 ：没有网络-0：WIFI网络1：4G网络-4：3G网络-3：2G网络-2
     * 自定义
     *
     * @param context
     * @return
     */
    fun getAPNType(context: Context): Int {
        //结果返回值
        var netType = 0
        //获取手机所有连接管理对象
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        //获取NetworkInfo对象
        val networkInfo = manager.activeNetworkInfo ?: return netType
        //NetworkInfo对象为空 则代表没有网络
        //否则 NetworkInfo对象不为空 则获取该networkInfo的类型
        val nType = networkInfo.type
        if (nType == ConnectivityManager.TYPE_WIFI) {
            //WIFI
            netType = 1
        } else if (nType == ConnectivityManager.TYPE_MOBILE) {
            val nSubType = networkInfo.subtype
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            //3G   联通的3G为UMTS或HSDPA 电信的3G为EVDO
            if (nSubType == TelephonyManager.NETWORK_TYPE_LTE && !telephonyManager.isNetworkRoaming) {
                netType = 4
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_UMTS
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_0 && !telephonyManager.isNetworkRoaming) {
                netType = 3
                //2G 移动和联通的2G为GPRS或EGDE，电信的2G为CDMA
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_GPRS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EDGE
                    || nSubType == TelephonyManager.NETWORK_TYPE_CDMA && !telephonyManager.isNetworkRoaming) {
                netType = 2
            } else {
                netType = 2
            }
        }
        return netType
    }

    //使用的网络类型
    @JvmStatic
    fun getAPNTypeString(): String {
        val context = MyApplication.instance
        val type = getAPNType(context!!)
        return when (type) {
            0 -> context.getString(R.string.hybrid_net_no)
            1 -> context.getString(R.string.hybrid_net_wifi)
            2 -> context.getString(R.string.hybrid_net_2g)
            3 -> context.getString(R.string.hybrid_net_3g)
            4 -> context.getString(R.string.hybrid_net_4g)
            else -> context.getString(R.string.hybrid_net_unkonw)
        }
    }

    @JvmStatic
    fun formatBankNumber(number: String): String {
        val sb = StringBuilder()
        val charArray = number.toCharArray()

        charArray.forEachIndexed { index, c ->
            if (index > 0 && index % 4 == 0) {
                sb.append(" $c")
            } else {
                sb.append(c)
            }

        }
        return sb.toString()
    }


    @JvmStatic
    fun goOnlineCustomerService(activity: Activity) {
        val userInfo = LIVUserInfo()
//        userInfo.loginName = ConfigUtils.loginName
        userInfo.userId = ConfigUtils.customerId
        val configID = when (ProjectUtils.PID) {

            "A03" -> {
                if (ConfigUtils.starLevel!!.toInt() > 5) "3" else "5"
            }
            else -> {
                if (ConfigUtils.starLevel!!.toInt() > 5) "3" else "5"
            }
        }

        LIVManager.getInstance().setAuthorities(ProjectUtils.FILE_PROVIDER)
        LIVManager.getInstance().startService(activity, userInfo, "", configID)

    }

    private var lastClickTime: Long = 0
    @JvmStatic
    fun isFastDoubleClick(): Boolean {
        val time = System.currentTimeMillis()
        val timeD = time - lastClickTime
        if (timeD in 1..1499) {
            return true
        }
        lastClickTime = time
        return false
    }


    @JvmStatic
    fun getImei(): String {
        var temp = StringBuffer()
        if (null != getTelephonyManager()) {
            val imei = sTelephonyManager?.deviceId
            if (imei != null) {
                temp.append(imei)
            }
        }
        return temp.toString()
    }

    fun getFileMD5(file: File): String? {
        if (!file.isFile) {
            return null
        }
        var digest: MessageDigest? = null
        var inp: FileInputStream? = null
        val buffer = ByteArray(1024)
        var len: Int
        try {
            digest = MessageDigest.getInstance("MD5")
            inp = FileInputStream(file)
            len = inp.read(buffer, 0, 1024)
            while (len != -1) {
                digest!!.update(buffer, 0, len)
                len = inp.read(buffer, 0, 1024)
            }
            inp!!.close()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return bytesToHexString(digest!!.digest())
    }


    fun bytesToHexString(src: ByteArray?): String? {
        val stringBuilder = StringBuilder("")
        if (src == null || src.isEmpty()) {
            return null
        }
        for (i in src.indices) {
            val v = src[i].toInt() and 0xFF
            val hv = Integer.toHexString(v)
            if (hv.length < 2) {
                stringBuilder.append(0)
            }
            stringBuilder.append(hv)
        }
        return stringBuilder.toString()
    }


    /**
     * 修改钱显示格式
     */
    @JvmStatic
    fun getMoneyType(str: String): String {

        val length = str.length
        var number: String

        number = when {
            length > 9 -> " ¥" + str.subSequence(0, (length - 9)) + "," + str.subSequence((length - 9), (length - 6)) + "," + str.subSequence((length - 6), length)
            length > 6 -> " ¥" + str.subSequence(0, (length - 6)) + "," + str.subSequence((length - 6), length)
            else -> " ¥$str"
        }

        return number
    }

    /**
     * 注册成功跳转
     */
    fun registerSucceed(activity: FragmentActivity, intent: Intent): Boolean {
        if (intent == null) return false
        var account: String? = intent.getStringExtra(IntentConstant.REGISTER_ACCOUNT)
        var phontNum: String? = intent.getStringExtra(IntentConstant.REGISTER_PHONENUM)
        if (account.isNullOrEmpty()) return false
        var regIntent = Intent(activity, RegisterSucceedActivity::class.java)
        regIntent.putExtra(IntentConstant.REGISTER_ACCOUNT, account)
        if (!phontNum.isNullOrEmpty()) {
            regIntent.putExtra(IntentConstant.REGISTER_PHONENUM, phontNum)
        } else {
            // 用户名注册则弹出绑定手机号对话框
            Utils.createDialog(activity.supportFragmentManager, CommonDialog.TYPE_BIND_PHONE)
        }
        activity.startActivity(regIntent)
        return true
    }

    /**
     * 限制输入框无法输入空格、中文字符、特殊符号
     */
    fun limitLetterOrDigit(editText: EditText?) {
        editText?.filters = arrayOf(InputFilter { charSequence, i, i1, spanned, i2, i3 ->
            if (!TextUtils.isEmpty(charSequence) && !Character.isLetterOrDigit(charSequence[i])) {
                ""
            } else null
        })
    }

    fun limitLetterOrDigit(editText: EditText?, contentLenght: Int?) {
        editText?.filters = arrayOf(InputFilter { charSequence, i, i1, spanned, i2, i3 ->
            if (!TextUtils.isEmpty(charSequence) && !Character.isLetterOrDigit(charSequence[i])) {
                ""
            } else null
        }, InputFilter.LengthFilter(contentLenght!!))
    }


    ///////////////////////////////////////////////////////////////3S
    internal var eventMap = HashMap<String, Long>()

    @JvmStatic
    fun startEvent(key: String) {
        startEvent(key, 0)
    }

    var isFrist: Boolean = true
    @JvmStatic
    fun startEvent(key: String, time: Long) {
        eventMap[key] = if (time == 0L) System.currentTimeMillis() else time
        LogUtils.e("-------------->$isFrist")
        if (!isFrist && key == MyApplication.instance!!.getString(R.string.three_statistics_agqj_refresh)) {
            val bean = T3sAppAgqjBean()
            bean.time = System.currentTimeMillis().toString()
            bean.uuid = getWebviewUUID()
          //  ThreeStatisticsManager.onAgqjEvent(bean)
            eventMap.remove(key)
        }
        if (key == MyApplication.instance!!.getString(R.string.three_statistics_agqj_refresh)) {
            isFrist = false
        }
        if (key == MyApplication.instance!!.getString(R.string.three_statistics_agqj_preload)) {
            val bean = T3sAppAgqjBean()
            bean.time = System.currentTimeMillis().toString()
            bean.uuid = getWebviewUUID()
         //   ThreeStatisticsManager.onAgqjEvent(bean)
            eventMap.remove(key)
        }
        if (key == MyApplication.instance!!.getString(R.string.three_statistics_agqj_enter)) {
            val gameResult = gameResult
            if (gameResult === MyApplication.AGQJGameResult.DISCONNECT) {
                eventMap.remove(key)
                return
            }
            if (gameResult === MyApplication.AGQJGameResult.TO_LOBBY_SUCCESS) {
            } else {
                //等待状态
                val bean = T3sAppAgqjBean()
                bean.time = System.currentTimeMillis().toString()
                bean.uuid = getWebviewUUID()
             //  ThreeStatisticsManager.onAgqjEvent(bean)
                eventMap.remove(key)
            }
        }
    }

    @JvmStatic
    fun endEvent(key: String, errorMsg: String) {
        if (eventMap[key] != null) {
            val endtime = System.currentTimeMillis()
            val time = eventMap[key]
            var durationTime = endtime - time!!
            if (durationTime < 0) {
                durationTime = 0
            }
            if (key == MyApplication.instance!!.getString(R.string.three_statistics_init)) {
          //      ThreeStatisticsManager.onInitEvent(durationTime)
            }
            if (key == MyApplication.instance!!.getString(R.string.three_statistics_payment)) {
                val bean = T3sAppPageBean(durationTime, "PaymentPageLoad", errorMsg)
            //    ThreeStatisticsManager.onPageEvent(bean)
            }
            if (key == MyApplication.instance!!.getString(R.string.three_statistics_agqj_enter)) {
                val bean = T3sAppAgqjBean()
                bean.time = eventMap[key].toString()
                bean.rsptime = durationTime
                bean.isPreload = true
                bean.uuid = getWebviewUUID()
              //  ThreeStatisticsManager.onAgqjEvent(bean)
            }
            eventMap.remove(key)
        }
    }

    /**
     * 谷歌时间统计结束点
     * @param context
     * @param key
     */
    @JvmStatic
    fun endEvent(key: String) {
        endEvent(key, "")
    }

    @JvmStatic
    fun createUUID() {
        val gameWebView = MyWebView(MyApplication.instance!!)
        gameWebView.settings.javaScriptEnabled = true
        gameWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(webView: WebView?, s: String?): Boolean {
                try {
                    if (!TextUtils.isEmpty(s) && s!!.startsWith("http://app/agqj?uuid=")) {
                        val uri = Uri.parse(s)
                        MyApplication.webviewUUID = uri.getQueryParameters("uuid")[0]
                        Log.e("StatisticsManager->", "StatisticsManager->获取到UUID：：：：$MyApplication.webviewUUID")
                    }
                } catch (e: Throwable) {
                }

                return super.shouldOverrideUrlLoading(webView, s)
            }

            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                try {
                    var s = request?.url?.toString()
                    if (!TextUtils.isEmpty(s) && s!!.startsWith("http://app/agqj?uuid=")) {
                        val uri = Uri.parse(s)
                        MyApplication.webviewUUID = uri.getQueryParameters("uuid")[0]
                        Log.e("StatisticsManager->11", "StatisticsManager->获取到UUID：：：：$MyApplication.webviewUUID")
                    }
                } catch (e: Throwable) {
                }

                return super.shouldOverrideUrlLoading(view, request)
            }
        }
        gameWebView.loadUrl("file:///android_asset/3s.html")
    }

    @JvmStatic
    fun getWebviewUUID(): String? {
        return MyApplication.webviewUUID
    }

    //////////////////////////////////////////////////////////////////////////////////
    @JvmStatic
    fun immersionBar(statusBar: ImmersionBar, viewStatus: View) {
        immersionBar(statusBar, viewStatus, false)
    }

    @JvmStatic
    fun immersionBar(statusBar: ImmersionBar?, viewStatus: View?, isDarkFont: Boolean) {
        if (viewStatus == null || statusBar == null)
            return
        viewStatus.postDelayed({
            try {
                if (isDarkFont) {
                    statusBar.statusBarView(viewStatus).statusBarDarkFont(true).init()
                } else {
                    statusBar.statusBarView(viewStatus).init()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 50)
    }

    fun isUsernameCorrectForRegister(customView: CustomInputTextView): Boolean {
        var username = customView.et_input.text.toString().trim()
        if (TextUtils.isEmpty(username)) {
            customView.showError("请填写用户名")
            return false
        }
        if (!username.toLowerCase().startsWith("f")) {
            customView.showError("请输入以f开头5-11位数字或字母的组合")
            return false
        }
        if (username.length < 5) {
            customView.showError("用户名长度不够5位")
            return false
        }
        customView.hideError()
        return true
    }

    fun isUsernameCorrect(customView: CustomInputTextView, toast: Boolean): Boolean {
        var username = customView.et_input.text.toString().toLowerCase().trim()
        if (TextUtils.isEmpty(username)) {
            val msg = "请填写用户名"
            if (toast)
                ToastUtils.show(msg)
            else
                customView.showError(msg)
            return false
        }
        if (!username.startsWith("f")) {
            val msg = "请输入以f为开头的5-15位数字及字母或其组合"
            if (toast)
                ToastUtils.show(msg)
            else
                customView.showError(msg)
            return false
        }
        if (username.length < 5) {
            val msg = "用户名长度不够5位"
            if (toast)
                ToastUtils.show(msg)
            else
                customView.showError(msg)
            return false
        }
        customView.hideError()
        return true
    }

    fun isUsernameCorrectString(text:String,toast: Boolean): Boolean {
        var username = text.toLowerCase().trim()
        if (TextUtils.isEmpty(username)) {
            val msg = "请填写用户名"
            if (toast)
                ToastUtils.show(msg)
            return false
        }
        if (!username.startsWith("f")) {
            val msg = "请输入以f为开头的5-15位数字及字母或其组合"
            if (toast)
                ToastUtils.show(msg)
            return false
        }
        if (username.length < 5) {
            val msg = "用户名长度不够5位"
            if (toast)
                ToastUtils.show(msg)
            return false
        }
        return true
    }

    fun isUsernamePhoneCorrect(customView: CustomInputTextView, toast: Boolean): Boolean {
        var username = customView.et_input.text.toString().toLowerCase().trim()
        if (TextUtils.isEmpty(username)) {
            val msg = "请填写手机号或账号"
            if (toast)
                ToastUtils.show(msg)
            else
                customView.showError(msg)
            return false
        }
        if  (username.first().toString()== "1" ) {
            if (username.length == 11 && Utils.formatPhoneNumber(username) == 0){
                return true
            }else{
                val msg = "请输入正确的手机号码"
                if (toast)
                    ToastUtils.show(msg)
                else
                    customView.showError(msg)
                return false
            }
        }
        if (!username.startsWith("f")) {
            val msg = "请输入以f为开头的5-15位数字及字母或其组合"
            if (toast)
                ToastUtils.show(msg)
            else
                customView.showError(msg)
            return false
        }
        if ( username.startsWith("f")) {
            if (username.length < 5) {
                val msg = "用户名长度不够5位"
                if (toast)
                    ToastUtils.show(msg)
                else
                    customView.showError(msg)
                return false
            }
        }
        return true
    }

    /**
     * 判断密码是否正确*/
    fun isPasswordCorrect(customView: CustomInputTextView): Boolean {
        var password = customView.et_input.text.toString().trim()
        if (TextUtils.isEmpty(password) || password.length < 8) {
           // customView.showError("请输入8-16位数字及字母的组合密码")
            ToastUtils.show("请输入8-16位数字及字母的组合密码")
            return false
        }
        if (password.matches(Regex("^[0-9]{1,16}")) || password.matches(Regex("^[a-zA-Z]{1,16}"))) {
           // customView.showError("密码需使用数字及字母的组合")
            ToastUtils.show("密码需使用数字及字母的组合")
            return false
        }
      //  customView.hideError()
        return true
    }
}



