package com.ultimate.ag.a03.activity

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import com.gyf.barlibrary.ImmersionBar
import com.ivi.skynet.statistics.StatisticsManager
import com.ivi.skynet.statistics.config.StatisticsConfig
import com.ivi.skynet.statistics.models.StatisticsUserModel
import com.ivi.skynet.statistics.utils.Cons
import com.rea.push.helper.PushHelper
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.MyApplication
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.TagItem
import com.ultimate.ag.a03.data.request.*
import com.ultimate.ag.a03.data.response.*
import com.ultimate.ag.a03.database.DataBaseHelper
import com.ultimate.ag.a03.eventbus.LogoutEvent
import com.ultimate.ag.a03.hybride.BrowserActivity
import com.ultimate.ag.a03.manager.AppInitManager
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.FireBaseManager
import com.ultimate.ag.a03.util.IntentConstant
import com.ultimate.ag.a03.util.StatusBarUtil
import com.ultimate.ag.a03.util.Utils
import com.ultimate.ag.a03.view.CommonDialog
import com.ultimate.ag.a03.view.CustomDialogView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_ip_limit.*
import okhttp3.HttpUrl
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.*
import com.ultimate.ag.a03.data.request.AutoLoginRequest
import com.ultimate.ag.a03.data.request.GetH5TokenByAppRequest
import com.ultimate.ag.a03.data.response.AutoLoginResponse
import com.ultimate.ag.a03.data.response.GetH5TokenByAppResponse
import com.ultimate.ag.a03.fragment.*
import com.ultimate.ag.a03.view.ItemAgWebView
import kotlinx.android.synthetic.main.activity_account_details.*

class MainActivity : BaseActivity() {

    private var mGameFragment: GameFragment? = null
    private var mVipFragment: VipFragment? = null
    private var mDiscoverFragment: DiscoverFragment? = null
    private var mProfitFragment: ProfitFragment? = null
    private var mMyFragment: MyFragment? = null
    private var mode = 0
    private var SOURCE = ""
    private var mProcedureId = ""
    private var immersionBar: ImmersionBar? = null

    companion object {
        var changeTag: String? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = StatusBarUtil.StatusBarLightMode(this)
        setContentView(R.layout.activity_main)
        val tagItem = TagItem("homepage_begin", "开始加载首页", "访问", "其他", "页面操作指标")
        mProcedureId = Utils.getProcedureId("HomePageLoadProcedure")
        Utils.coverPointRequest(tagItem, "SplashActivity", "MainActivity", mProcedureId)
        //获取跳转来源
        if (intent.getStringExtra("SOURCE") != null) {
            SOURCE = intent.getStringExtra("SOURCE")
        }
        if (savedInstanceState == null) {
            defaultChildShow(supportFragmentManager.beginTransaction())
        }
        queryAreaLimit()
        if (ConfigUtils.currentUserType == ConfigUtils.USER_TYPE_TRY){
            preLoadAGGame()
        }
        else if (ConfigUtils.currentUserType == ConfigUtils.USER_TYPE_OLD  && !TextUtils.isEmpty(ConfigUtils.token) ) { //已经登录的
            getUserInfo()
            MyApplication.messgeNotifyObject.queryUnReadLetter()
            preLoadAGGame()
        } else if (!TextUtils.isEmpty(AppInitManager.getAcache().getAsString(getString(R.string.webtoken)))) {
            autoLogin()
            getUserInfo()
            MyApplication.messgeNotifyObject.queryUnReadLetter()

        }
        else {
            loginOut()
        }

        // 注册成功跳转
        Utils.registerSucceed(this, intent)

        immersionBar = ImmersionBar.with(this)
        EventBus.getDefault().register(this)


        val userModel = StatisticsUserModel()
        userModel.user_id = ConfigUtils.customerId
        userModel.star_level = ConfigUtils.starLevel.toString()
        userModel.before_login_date = ConfigUtils.lastLoginDate
        userModel.created_date = ConfigUtils.registDate
     //   StatisticsManager.login(userModel)
    }

    override fun onDestroy() {
        super.onDestroy()
        immersionBar?.destroy()
        EventBus.getDefault().unregister(this)
    }

    override fun initData() {
        if (ConfigUtils.NOticeTag) {
            ConfigUtils.NOticeTag = false
            val intent = Intent(this@MainActivity, NoticeCenterActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        //试玩账号显示注册toast
        if (ConfigUtils.currentUserType == ConfigUtils.USER_TYPE_TRY) {
            activity_main_rl_register_toast.visibility = View.VISIBLE
        } else {
            activity_main_rl_register_toast.visibility = View.GONE
        }

        if (changeTag != null) {
            if (changeTag == "game") {
                activity_main_navigation_game_lobby.performClick()
                changeTag = null
            } else if (changeTag == "ag") {
                activity_main_navigation_game_lobby.performClick()
                mGameFragment?.selectedAGTabs()
                changeTag = null
            }
        }

        val tagItem = TagItem("homepage_end", "结束加载首页", "访问", "其他", "页面操作指标")
        Utils.coverPointRequest(tagItem, "SplashActivity", "MainActivity", mProcedureId)

        //3秒埋点
       // StatisticsManager.getHomePageLoadProcedureControl().procetureStart("homepage","访问","其他","其他指标","开始加载首页","","")
       // StatisticsManager.getHomePageLoadProcedureControl().procetureEnd("homepage","访问","其他","其他指标","结束加载首页","","")
    }

    var firstTime = 0L

    private fun queryAreaLimit() {
        val request = QueryAreaLimitRequest()
        ApiClient.instance.service.areaLimit(request)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<QueryAreaLimitResponse>(this, false) {
                    override fun businessFail(data: QueryAreaLimitResponse) {
                        upgrade()
                    }

                    override fun businessSuccess(data: QueryAreaLimitResponse) {
                        val isShowIPLimit = null != data.body && data.body == "0"
                        if (isShowIPLimit) {
                            ip_limit_layout.visibility = View.VISIBLE
                        } else {
                            upgrade()
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        upgrade()
                    }
                })
    }


    private fun copyText(text: String) {
        // 从API11开始android推荐使用android.content.ClipboardManager
        // 为了兼容低版本我们这里使用旧版的android.text.ClipboardManager，虽然提示deprecated，但不影响使用。
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        // 将文本内容放到系统剪贴板里。
        cm.setText(text)
        Toast.makeText(this, "复制成功", Toast.LENGTH_LONG).show()
    }


    override fun initListener() {
        initNavigationListener()

        tv_connect_service.setOnClickListener {
            Utils.goOnlineCustomerService(this)
        }

        tv_phone.setOnClickListener {
            Utils.callPhone(this, "+639995168188")
        }
        tv_email.setOnClickListener {
            copyText("ag88cs@hotmail.com")
        }

        //注册按钮点击事件
        activity_main_btn_register.setOnClickListener {

            Utils.createDialog(supportFragmentManager, CommonDialog.TYPE_LOGIN)
        }
    }


    /**
     * 检查升级
     */
    private fun upgrade() {
        val localH5Version: Int? = DataBaseHelper.getH5Version()?.version?.toInt()
        val request = UpgradeRequest()
        request.h5V = localH5Version
        ApiClient.instance.service.upgrade(request)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<UpgradeResponse>(this, false) {
                    override fun businessFail(data: UpgradeResponse) {
                    }

                    override fun businessSuccess(data: UpgradeResponse) {
                        if (data.body?.flag != 0) {
                            showUpgradeDialog(data)
                        }
//                        val newH5Version: Int = data?.body?.h5VersionId ?: 0
//                        if (localH5Version == null || newH5Version > localH5Version) {
//                            if (!TextUtils.isEmpty(data?.body?.h5DownUrl)) {
//                                val downLoader = DownLoaderTask(data.body?.h5DownUrl!!
//                                        , ProjectUtils.webFiieRoute, baseContext, "/web", data?.body?.h5VersionId.toString(), data?.body?.h5Md5)
//                                if (downLoader.needUpdate()) {
//                                    downLoader.execute()
//                                } else {
//                                    downLoader.cancel(true)
//                                }
//                            }
//                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }


    /**
     * 显示升级弹窗
     */
    private fun showUpgradeDialog(data: UpgradeResponse) {
        val dialog = CustomDialogView(this)

        dialog.showCustomViewDialog(0f)
        val appDownUrl = data.body?.appDownUrl
        when (data.body?.flag) {
            1 -> {
                val lastUpdateTime = AppInitManager.getAcache().getAsString("last_update_time")
                val nowTime = Date().time
                if (lastUpdateTime != null && (nowTime - lastUpdateTime.toLong()) <= 48 * 60 * 60 * 1000) {
                    dialog.dismiss()
                } else {
                    AppInitManager.getAcache().put("last_update_time", "$nowTime")
                }
                dialog.setTitle(getString(R.string.settings_center_upgrade_title) + data.body?.versionCode)
                dialog.setContente(getString(R.string.settings_center_upgrade_content))
                dialog.setBtnLeft(getString(R.string.settings_center_upgrade_not))
                dialog.setBtnRight(getString(R.string.settings_center_upgrade_now))
                dialog.setBtnCancelOnclick(View.OnClickListener {
                    dialog.dismiss()

                })

                dialog.setBtnOkOnclick(View.OnClickListener {
                    dialog.dismiss()
                    if (TextUtils.isEmpty(appDownUrl) || HttpUrl.parse(appDownUrl) == null) {
                        Toast.makeText(baseContext, "应用更新失败！请联系客服", Toast.LENGTH_SHORT).show()
                        return@OnClickListener
                    }
                    Utils.downLoadApp(this, appDownUrl)
                })
            }

            2 -> {
                dialog.setTitle(getString(R.string.settings_center_upgrade_title_warn) + data.body?.versionCode)
                dialog.setContente(getString(R.string.settings_center_upgrade_content_warn))
                dialog.setBtnLeft(getString(R.string.settings_center_upgrade_exit))
                dialog.setBtnRight(getString(R.string.settings_center_upgrade_now))
                dialog.setBtnCancelOnclick(View.OnClickListener {
                    dialog.dismiss()
                    MyApplication.instance?.activityListManager?.exitApp()
                })


                dialog.setBtnOkOnclick(View.OnClickListener {
                    dialog.dismiss()
                    if (TextUtils.isEmpty(appDownUrl) || HttpUrl.parse(appDownUrl) == null) {
                        Toast.makeText(baseContext, "应用更新失败！请联系客服", Toast.LENGTH_SHORT).show()
                        return@OnClickListener
                    }
                    Utils.downLoadApp(this, appDownUrl,false)
                })
            }
        }

    }

    public var gameFragmentIsShowing:Boolean = true
    /**
     * 注册导航栏点击事件
     */
    private fun initNavigationListener() {
        activity_main_navigation_group_button.setOnCheckedChangeListener { _, i ->
            val ft = supportFragmentManager.beginTransaction()
            hideChildFragment(supportFragmentManager.beginTransaction())
            when (i) {
                R.id.activity_main_navigation_game_lobby -> {
                    gameFragmentIsShowing = true
                    if (mGameFragment == null) {
                        mGameFragment = GameFragment()
                        ft.add(R.id.activity_main_fl, mGameFragment)
                    } else {
                        ft.show(mGameFragment)
                    }
                    mode = StatusBarUtil.StatusBarLightMode(this)
                }

                R.id.activity_main_navigation_vip -> {
                    gameFragmentIsShowing = false
                    if (mVipFragment == null) {
                        mVipFragment = VipFragment()
                        ft.add(R.id.activity_main_fl, mVipFragment)
                    } else {
                        ft.show(mVipFragment)
                    }
                    mode = StatusBarUtil.StatusBarLightMode(this)
                }

                R.id.activity_main_navigation_discover -> {
                    gameFragmentIsShowing = false
                    FireBaseManager.instance.logBtnCLickEvent("find")
                    if (mDiscoverFragment == null) {
                        mDiscoverFragment = DiscoverFragment()
                        ft.add(R.id.activity_main_fl, mDiscoverFragment)
                    } else {
                        ft.show(mDiscoverFragment)
                    }
                    mode = StatusBarUtil.StatusBarLightMode(this)
                }

                R.id.activity_main_navigation_profit -> {

                    gameFragmentIsShowing = false
                    FireBaseManager.instance.logBtnCLickEvent("profit")
                    if (mProfitFragment == null) {
                        mProfitFragment = ProfitFragment()
                        ft.add(R.id.activity_main_fl, mProfitFragment)
                    } else {
                        ft.show(mProfitFragment)
                    }
                    mode = StatusBarUtil.StatusBarLightMode(this)

                }

                R.id.activity_main_navigation_my -> {
                    gameFragmentIsShowing = false
                    FireBaseManager.instance.logBtnCLickEvent("myhome")
                    if (ConfigUtils.currentUserType == ConfigUtils.USER_TYPE_TRY) {
                        Utils.createDialog(supportFragmentManager, CommonDialog.TYPE_LOGIN)
//                        goToPage(Intent().setClass(this@MainActivity, RegisterActivity::class.java))
                        if (null != mGameFragment && mGameFragment?.isVisible!!) {
                            activity_main_navigation_group_button.check(R.id.activity_main_navigation_game_lobby)
                        } else if (null != mVipFragment && mVipFragment?.isVisible!!) {
                            activity_main_navigation_group_button.check(R.id.activity_main_navigation_vip)
                        } else if (null != mDiscoverFragment && mDiscoverFragment?.isVisible!!) {
                            activity_main_navigation_group_button.check(R.id.activity_main_navigation_discover)
                        }else if (null != mProfitFragment && mProfitFragment?.isVisible!!) {
                            activity_main_navigation_group_button.check(R.id.activity_main_navigation_profit)
                        }

                    } else {
                        if (mMyFragment == null) {
                            mMyFragment = MyFragment()
                            ft.add(R.id.activity_main_fl, mMyFragment)
                        } else {
                            ft.show(mMyFragment)
                        }

                        StatusBarUtil.StatusBarDarkMode(this, mode)
                        StatusBarUtil.transparencyBar(this)
                    }
                }
            }
            ft.commit()
            mGameFragment?.ifNeedPauseGame(activity_main_navigation_game_lobby?.isChecked)
        }
    }

    /**
     * 预加载AG游戏
     */

    private fun preLoadAGGame(){

        var agWebViewGame = MyApplication.instance?.agWebViewGame
        if (agWebViewGame == null) {
            agWebViewGame = ItemAgWebView(null)
            agWebViewGame?.createView()
            MyApplication.instance?.agWebViewGame = agWebViewGame
        }else{
            agWebViewGame.inGame()
        }
        MyApplication.instance?.agWebViewGame = agWebViewGame

    }


    /***
     * childFragmet默认加载页面
     *
     * @param fragmentTransaction
     */
    private fun defaultChildShow(fragmentTransaction: FragmentTransaction) {
        hideChildFragment(fragmentTransaction)
        if (mGameFragment == null) {
            //如果是切换账号条转过来则直接切换到我的标签
            if (SOURCE == "CHANGEACCOUNT") {
                mMyFragment = MyFragment()
                fragmentTransaction.add(R.id.activity_main_fl, mMyFragment)
                activity_main_navigation_group_button.check(R.id.activity_main_navigation_my)
            } else {
                mGameFragment = GameFragment()
                fragmentTransaction.add(R.id.activity_main_fl, mGameFragment)
            }
        } else {
            if (SOURCE == "CHANGEACCOUNT") {
                fragmentTransaction.show(mMyFragment)

            } else {
                activity_main_navigation_group_button.check(R.id.activity_main_navigation_my)
            }
        }
    }

    /**
     * 隐藏全部fragment
     */
    private fun hideChildFragment(fragmentTransaction: FragmentTransaction) {
        if (mGameFragment != null) {
            fragmentTransaction.hide(mGameFragment)
        }
        if (mVipFragment != null) {
            fragmentTransaction.hide(mVipFragment)
        }
        if (mDiscoverFragment != null) {
            fragmentTransaction.hide(mDiscoverFragment)
        }
        if (mMyFragment != null) {
            fragmentTransaction.hide(mMyFragment)
        }
        if (mProfitFragment != null){
            fragmentTransaction.hide(mProfitFragment)
        }
        fragmentTransaction.commit()
    }


    override fun onBackPressed() {

        if (mDiscoverFragment?.onBackPressed() ?: false) {
            return
        }

        if (System.currentTimeMillis() - firstTime > 2000) {
            firstTime = System.currentTimeMillis()
            Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show()
        } else {
            System.exit(0)
        }
    }

    private fun getUserInfo() {
        val request = GetByLoginNameRequest()
        request.inclMobileNo = 1
        request.inclMobileNoBind = 1
        request.inclRealName = 1
        request.inclBankAccount = 1
        request.inclBtcAccount = 1
        request.inclVerifyCode = 1
        ApiClient.instance.service.getByLoginName(request)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<GetByLoginNameResponse>(this, false) {
                    override fun businessFail(data: GetByLoginNameResponse) {
                    }

                    override fun businessSuccess(data: GetByLoginNameResponse) {
                        ConfigUtils.mobileNo = data.body?.mobileNo
                        ConfigUtils.realName = data.body?.realName
                        ConfigUtils.verifyCode = data.body?.verifyCode
                        ConfigUtils.isBindMobile = (data.body?.mobileNoBind == 1)
                        ConfigUtils.starLevel = data.body?.starLevel ?: 0
                        ConfigUtils.depositLevel = data.body?.depositLevel ?: 0
                        ConfigUtils.bankCardCounts = data.body?.bankCardNum!!.plus(data.body?.btcNum)
                        ConfigUtils.lastLoginDate = data?.body?.lastLoginDate
                        ConfigUtils.loginDate = data?.body?.loginDate
                        ConfigUtils.registDate = data?.body?.registDate
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }

    /**
     * 自动登录
     */
    private fun autoLogin() {
        val request = AutoLoginRequest()
        request.loginName = ConfigUtils.loginName
        ApiClient.instance.service.autoLogin(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<AutoLoginResponse>(this, false) {
                    override fun businessFail(data: AutoLoginResponse) {
                        loginOut()
                    }

                    override fun businessSuccess(data: AutoLoginResponse) {
                        ConfigUtils.loginName = data.body?.loginName
                        ConfigUtils.customerId = data.body?.customerId
                        preLoadAGGame()
                        mMyFragment?.refreshUserInfo()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ConfigUtils.networkError = true
                    }
                })
    }


    private fun loginOut() {
        ConfigUtils.loginName = ""
        ConfigUtils.realName = ""
        ConfigUtils.token = ""
        ConfigUtils.isBindMobile = false
        ConfigUtils.mobileNo = ""
        ConfigUtils.customerId = ""

        //清除缓存本地用户组
        if (MyApplication.getinstance().mAcach.getAsString("loginArr") != null) {
            MyApplication.getinstance().mAcach.put("loginArr", "")
        }
        AppInitManager.getAcache().remove(getString(R.string.webtoken))
        Toast.makeText(this@MainActivity, "登录已过期，请重新登录", Toast.LENGTH_SHORT).show()
        val intent = Intent(this@MainActivity, FirstPageActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        PushHelper.restartService(MyApplication.instance)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (data != null) {
            Utils.registerSucceed(this, data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            val page = intent.getIntExtra(IntentConstant.MAIN_TAB_INDEX, -1)
            swichTabPage(page)
            val startShareFriends = intent.getBooleanExtra(IntentConstant.START_SHARE_FRIENDS, false)
            if (startShareFriends) {
                startShareFriendsPage()
            }
        }
    }

    /** 切换tab页*/
    fun swichTabPage(page : Int) {
        when (page) {
            0 -> activity_main_navigation_game_lobby.isChecked = true
            1 -> activity_main_navigation_vip.isChecked = true
            2 -> activity_main_navigation_discover.isChecked = true
            3 -> activity_main_navigation_my.isChecked = true
        }
    }

    fun startShareFriendsPage(){
        val intent = Intent()
        intent.putExtra(BrowserActivity.PARAM_URL, ProjectUtils.mAssetsWebUrl + "/share")
        intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
        intent.setClass(this, BrowserActivity::class.java)
        intent.putExtra(IntentConstant.WEBVIEW_RIGHT_TITLE_TYPE, 1)
        goToPage(intent)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onEvent(event : LogoutEvent) {
        startActivity(Intent(this, FirstPageActivity::class.java))
        finish()
    }
}
