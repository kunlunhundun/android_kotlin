package com.ultimate.ag.a03.activity.mvp.view

import com.ultimate.ag.a03.data.response.BQBanksResponse
import com.ultimate.ag.a03.data.response.BalanceResponse
import com.ultimate.ag.a03.data.response.ToGameResponse
import com.ultimate.ag.a03.data.response.ToLocalResponse

interface AccountDetailsView: IBaseView{

    /**
     * 展示账户余额信息
     */
    fun showBalance(data: BalanceResponse)

    /**
     * 获取余额信息失败
     */
    fun getBalanceFail(data: BalanceResponse)

    /**
     * PT转账成功
     */
    fun transferToGameSuccess()

    /**
     * PT转账失败
     */
    fun transferToGameFail(data: ToGameResponse)

    /**
     * 转账至本地成功
     */
    fun transferToLocalSuccess()

    /**
     * 转账至本地失败
     */
    fun transferToLocalFail(data: ToLocalResponse)

    /**
     * 设置最后一条交易
     */
    fun setLastTrasfer(data: BQBanksResponse)

    /**
     * 获取最后一条充值信息失败
     */
    fun getLastTrasferFial(data: BQBanksResponse)
}