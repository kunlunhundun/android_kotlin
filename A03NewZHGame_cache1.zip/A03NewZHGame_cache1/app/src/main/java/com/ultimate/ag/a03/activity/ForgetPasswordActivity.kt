package com.ultimate.ag.a03.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Html
import android.text.TextUtils
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ScrollView
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ultimate.ag.a03.R
import com.ultimate.ag.a03.config.ConfigUtils
import com.ultimate.ag.a03.config.ProjectUtils
import com.ultimate.ag.a03.data.request.GenerateCodeRequest
import com.ultimate.ag.a03.data.request.SendCodeByLoginNameRequest
import com.ultimate.ag.a03.data.request.ValidateCodeRequest
import com.ultimate.ag.a03.data.response.GenerateCodeResponse
import com.ultimate.ag.a03.data.response.SendSmsResponse
import com.ultimate.ag.a03.data.response.ValidateCodeResponse
import com.ultimate.ag.a03.net.ApiClient
import com.ultimate.ag.a03.net.ApiErrorModel
import com.ultimate.ag.a03.net.ApiResponse
import com.ultimate.ag.a03.net.NetworkScheduler
import com.ultimate.ag.a03.util.AndroidWorkaround
import com.ultimate.ag.a03.util.Dip2PixleUtil
import com.ultimate.ag.a03.util.StatusBarUtil
import com.ultimate.ag.a03.util.Utils
import kotlinx.android.synthetic.main.activity_forget_password.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class ForgetPasswordActivity : BaseToolBarActivity() {
    private var showSoftKeyboad = false
    var captchaId: String? = null
    var validateId: String? = null


    override fun getLayoutId(): Int {
        return R.layout.activity_forget_password
    }

    override fun initData() {
        getGenerateCode()
        ct_username.postDelayed({
            Utils.limitLetterOrDigit(ct_username.getEditText(), 15)
        }, 1000)

    }

    override fun initListener() {
        OverScrollDecoratorHelper.setUpOverScroll(forget_password_form)
        tv_submit.setOnClickListener {
            onClickSubmit()
        }


        iv_verification_code.setOnClickListener {
            getGenerateCode()
        }

        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidWorkaround.assistActivity(findViewById(android.R.id.content))
        // Set up the login form.
        StatusBarUtil.StatusBarLightMode(this)
        setTile("")
        isShowBack(true)
        setActionText("联系客服")
        content.addOnLayoutChangeListener(this)

    }

    private fun validateRequest() {
        if (Utils.isUsernameCorrect(ct_username, false)) {
            sendPost()
        }
    }

    private fun onClickSubmit() {
        ct_username.hideError()
        ct_true_name.hideError()
        ct_verification_code.hideError()
//        validateCode()
        validateRequest()
    }

    private fun isUserNameValid(username: String): Int {
        return ProjectUtils.checkOldUserNameAvailable(username)
    }


    private fun sendPost() {

        val sendSmsRequest = SendCodeByLoginNameRequest()
        if (TextUtils.isEmpty(ct_verification_code.getEditTextContent())) {
            ct_verification_code.showError(R.string.error_invalid_verification_code)
            ct_verification_code.requestFocus()
            return
        }
        sendSmsRequest.validateId = validateId
        sendSmsRequest.captchaCode = ct_verification_code.getEditTextContent()
        sendSmsRequest.captchaId = captchaId
        sendSmsRequest.loginName = ct_username.getEditTextContent().trim()
        sendSmsRequest.realName = ct_true_name.getEditTextContent().trim()
        sendSmsRequest.use = "4"
        ApiClient.instance.service.sendCodeByLoginName(sendSmsRequest)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this, true) {
                    override fun businessFail(data: SendSmsResponse) {
                        getGenerateCode()
                        ct_verification_code.setEditText("")
                        when (data.head.errCode) {
                            "480001" -> {
                                ct_verification_code.showError(R.string.error_invalid_verification_code)
                                ct_verification_code.requestFocus()
                            }

                            "GW_800703" -> {
                                ct_true_name.showError(data.head.errMsg)
                                ct_true_name.requestFocus()
                            }
                            "GW_800301" -> {
                                showCustomerService()
                            }
                            else -> {
                                ct_username.showError(data.head.errMsg)
                                ct_username.requestFocus()
                            }
                        }
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        goSuccess(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                        getGenerateCode()
                    }

                })

    }

    private fun goSuccess(data: SendSmsResponse) {
        val intent = Intent()
        intent.setClass(this@ForgetPasswordActivity, VerifyCodeActivity::class.java)
        intent.putExtra("type", VerifyCodeActivity.TYPE_FORGET_PASSWORD)
        intent.putExtra("phone_num", data.body.mobileNo)
        intent.putExtra("validateId", validateId)
        intent.putExtra("messageId", data.body.messageId)
        ConfigUtils.loginName = ct_username.getEditTextContent().trim()
        ConfigUtils.realName = ct_true_name.getEditTextContent().trim()
        startActivity(intent)
        finish()

    }


    private fun getGenerateCode() {
        val request = GenerateCodeRequest()
        request.use = "3"
        ApiClient.instance.service.generateCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GenerateCodeResponse>(this, true) {
                    override fun businessFail(data: GenerateCodeResponse) {
                        showError(data.head.errMsg)
                    }

                    override fun businessSuccess(data: GenerateCodeResponse) {
                        captchaId = data.body.captchaId
                        iv_verification_code.setImageBitmap(Utils.stringToBitmap(data.body.image))

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                    }

                })

    }


    private fun validateCode() {
        if (TextUtils.isEmpty(ct_verification_code.getEditTextContent())) {
            ct_verification_code.showError(R.string.error_invalid_verification_code)
            ct_verification_code.requestFocus()
            return
        }

        val request = ValidateCodeRequest()
        request.captcha = ct_verification_code.getEditTextContent()
        request.captchaId = captchaId
        request.loginName = ct_username.getEditTextContent().trim()
        request.realName = ct_true_name.getEditTextContent().trim()
        ApiClient.instance.service.customerValidate(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<ValidateCodeResponse>(this, true) {
                    override fun businessFail(data: ValidateCodeResponse) {
                        showError(data)
                    }

                    override fun businessSuccess(data: ValidateCodeResponse) {
                        validateId = data?.body?.validateId
                        if (!TextUtils.isEmpty(validateId)) {
                            validateRequest()
                        } else {
                            showError(data)
                        }

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        showError(apiErrorModel.message)
                        getGenerateCode()
                    }

                })

    }

    private fun showError(data: ValidateCodeResponse) {
        when (data?.head?.errCode) {
            "GW_800102" -> {
                getGenerateCode()
                ct_verification_code.showError(data?.head?.errMsg)
                ct_verification_code.requestFocus()
            }
            "GW_800705" -> {
                getGenerateCode()
                ct_true_name.showError(data?.head?.errMsg)
                ct_true_name.requestFocus()
            }
            "GW_890402" -> {
                getGenerateCode()
                ct_username.showError(data?.head?.errMsg)
                ct_username.requestFocus()
            }
        }
    }

    override fun onLayoutChange(p0: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {
        if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight)) {


            if (ct_verification_code.getEditText().isFocused) {
                forget_password_form.fullScroll(ScrollView.FOCUS_DOWN)
                ct_verification_code.requestFocus()
            }

            if (rl_verify_error.visibility != View.VISIBLE) {
                tv_submit.visibility = View.VISIBLE
            }

            forget_password_form.smoothScrollBy(0, Dip2PixleUtil.dp2px(this, 100f))
            showSoftKeyboad = true


        } else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight)) {
            tv_submit.visibility = View.INVISIBLE
            showSoftKeyboad = false

        }
    }


    private fun showError(error: String?) {
        tv_submit.visibility = View.GONE
        val animation = AnimationUtils.loadAnimation(this@ForgetPasswordActivity, R.anim.popupwindow_show_anim)
        rl_verify_error.startAnimation(animation)
        rl_verify_error.visibility = View.VISIBLE
        tv_tip.text = error

        val handler = Handler()
        val runnable = Runnable {
            rl_verify_error.visibility = View.GONE
            tv_tip.text = ""
            tv_submit.visibility = View.VISIBLE
        }
        handler.postDelayed(runnable, 2000)
    }


    private fun showCustomerService() {
        tv_submit.visibility = View.GONE
        val animation = AnimationUtils.loadAnimation(this@ForgetPasswordActivity, R.anim.popupwindow_show_anim)
        rl_verify_error.startAnimation(animation)
        rl_verify_error.visibility = View.VISIBLE
        tv_tip.visibility = View.GONE
        val tip = "<font size=\"2\" color=\"#666666\">" + getString(R.string.forget_password_page_connect_customer_service_des) + "</font><font size=\"2\" color=\"#8095FF\">" + getString(R.string.forget_password_page_connect_customer_service_help) + "</font>"
        iv_close.visibility = View.VISIBLE
        tv_tip_2.text = Html.fromHtml(tip)
        tv_tip_2.visibility = View.VISIBLE
        iv_close.setOnClickListener {
            rl_verify_error.visibility = View.GONE
            iv_close.visibility = View.GONE
            tv_tip_2.visibility = View.GONE
            if (showSoftKeyboad) {
                tv_submit.visibility = View.VISIBLE
            }

        }
        tv_tip_2.setOnClickListener {

            Utils.goOnlineCustomerService(this)
        }
        ct_true_name.visibility = View.GONE


    }


}
