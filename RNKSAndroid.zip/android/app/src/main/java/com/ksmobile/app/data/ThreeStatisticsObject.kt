package com.ksmobile.app.data

class ThreeStatisticsObject {

    var time1: Long = 0
        set(value) {
            field =value
            time2 = 0
            time3 =0
        }

    var time2: Long = 0
        set(value) {
            field = value

            time3 = if (time1 > 0){
                field.minus(time1)
            }else{
                0
            }


        }
    var time3: Long = 0


    fun reset(){
        time1 = 0
        time2 = 0
        time3 = 0
    }
}