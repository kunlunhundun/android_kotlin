package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.CreateBtcPaymentRequest
import com.ksmobile.app.data.response.CreatBtcResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_bind_bit_card.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class BindBitCardActivity : BaseToolBarActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_bind_bit_card
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.bind_bit_activity_title))

    }

    override fun initView() {

    }

    override fun onResume() {
        super.onResume()
        if (TextUtils.isEmpty(ConfigUtils.realName)) {
            ConfirmDialog.show(this)
            ConfirmDialog.setContent("您尚未完成个人资料认证，请认证后再操作")
            ConfirmDialog.setTitile("")
            ConfirmDialog.setCancelText("返回")
            ConfirmDialog.setSureText("去绑定")
            ConfirmDialog.setSureListener(View.OnClickListener {

                val intent = Intent(this, RealNameVerifyActivity::class.java)
                goToPage(intent)
                ConfirmDialog.dismiss()
            })

            ConfirmDialog.setCancelListener(View.OnClickListener {
                ConfirmDialog.dismiss()
                finish()
            })
        }
    }

    override fun initListener() {
        OverScrollDecoratorHelper.setUpOverScroll(sv_bind_bit)
        btn_commit.setOnClickListener {
            checkRequest()
        }

        et_bit_address.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                checkBtcAddress()
            }

        }

        et_bit_address_confirm.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                checkBtcConfirmAddress()
            }

        }

    }


    private fun checkBtcAddress(): Boolean {
        var cancle = false
        var error: String? = null

        when {
            et_bit_address.getEditTextContent().isEmpty() -> {
                error = getString(R.string.real_name_empty_tip)
                et_bit_address.showError(error)
                cancle = true
            }
            !Utils.checkBitWallet(et_bit_address.getEditTextContent()) -> {
                error = getString(R.string.real_name_formate_tip)
                et_bit_address.showError(error)
                cancle = true
            }

            et_bit_address.getEditTextContent().length < 26 -> {
                error = getString(R.string.real_name_formate_tip)
                et_bit_address.showError(error)
                cancle = true
            }


        }

        return cancle
    }


    private fun checkBtcConfirmAddress(): Boolean {
        var cancle = false
        var error: String? = null

        when {
            et_bit_address_confirm.getEditTextContent().isEmpty() -> {
                error = getString(R.string.real_name_empty_tip)
                et_bit_address_confirm.showError(error)
                cancle = true
            }
            et_bit_address_confirm.getEditTextContent().length < 26 -> {
                error = getString(R.string.real_name_formate_tip)
                et_bit_address_confirm.showError(error)
                cancle = true
            }

            et_bit_address_confirm.getEditTextContent() != et_bit_address.getEditTextContent() -> {
                error = "两次输入的比特币钱包地址不一致"
                et_bit_address_confirm.showError(error)
                cancle = true
            }
        }

        return cancle
    }


    private fun checkRequest() {


        if (checkBtcAddress() || checkBtcConfirmAddress()) {
        } else {
            addBtcWallet()
        }


    }


    private fun addBtcWallet() {
        val request = CreateBtcPaymentRequest()
        request.btcUrl = et_bit_address.getEditTextContent()
        ApiClient.instance.service.createBtc(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatBtcResponse>(this, true) {
                    override fun businessFail(data: CreatBtcResponse) {
                        when (data.head.errCode){
                            "WS_300833" ->{
                                NotifyDialog.show(this@BindBitCardActivity, "BTC钱包绑定数量已达上限，请删除后再试")
                                NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                                    override fun onHidden() {
                                        finish()
                                    }

                                })
                            }
                            else ->{
                                NotifyDialog.show(this@BindBitCardActivity, data.head.errMsg)
                            }
                        }


                    }

                    override fun businessSuccess(data: CreatBtcResponse) {
                        ConfigUtils.realName = data.body?.realName
                        NotifyDialog.show(this@BindBitCardActivity, "添加成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ToastUtils.show(apiErrorModel.message)
                    }

                })

    }


}