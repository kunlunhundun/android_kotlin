package com.ksmobile.app.data

data class SignObject (var sign:String,var deviceId:String,var domainName:String,var isNetWorkConnected:Boolean,var parentId:String)