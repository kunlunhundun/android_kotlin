package com.ksmobile.app.data.request



/**
 * Created by ward.y on 2018/3/19.
 */
class CardManagerRequest : BaseRequestObject() {

}
