package com.ksmobile.app.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.jxccp.lib.sip.util.SettingUtils;

import java.util.HashSet;

import com.ksmobile.app.R;

public class ConfigActivity extends AppCompatActivity implements View.OnClickListener {

    public static String AUDIOCODEC_CONFIG = "AUDIO_CODEC_CONFIG";
    public static String AUDIOCODEC_CONFIG_opus = "opus";
    public static String AUDIOCODEC_CONFIG_ISAC = "ISAC";
    public static String AUDIOCODEC_CONFIG_G722 = "G722";
    public static String AUDIOCODEC_CONFIG_ILBC = "ILBC";
    public static String AUDIOCODEC_CONFIG_PCMU = "PCMU";
    public static String AUDIOCODEC_CONFIG_PCMA = "PCMA";
    public static String AUDIOCODEC_CONFIG_CN = "CN";
    public static String AUDIO_AEC_CONFIG = "AUDIO_AEC_CONFIG";
    public static String AUDIO_NS_ONFIG = "AUDIO_NS_CONFIG";
    public static String AUDIO_AGC_CONFIG = "AUDIO_AGC_CONFIG";
    public String[] audioCodecArray = {AUDIOCODEC_CONFIG_opus, AUDIOCODEC_CONFIG_ISAC, AUDIOCODEC_CONFIG_G722, AUDIOCODEC_CONFIG_ILBC, AUDIOCODEC_CONFIG_PCMU, AUDIOCODEC_CONFIG_PCMA, AUDIOCODEC_CONFIG_CN};
    public String audioCodec;
    public boolean[] audioCodecCheckedItem;
    public boolean audioAecEnable;
    public boolean audioNsEnable;
    public boolean audioAgcEnable;

    public TextView mAudioCodecText;
    public TextView mAecEnableText;
    public TextView mNsEnableText;
    public TextView mAgcEnableText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        initData();
        initView();
    }

    public void initData() {
        //init audio codec
        audioCodec = SettingUtils.get(this, AUDIOCODEC_CONFIG, "");
        if (!audioCodec.isEmpty()) {
            HashSet<String> codecSet = new HashSet<String>();
            String[] codecs = audioCodec.split(",");
            for (int i = 0; i < codecs.length; i++) {
                codecSet.add(codecs[i]);
            }
            audioCodecCheckedItem = new boolean[]{codecSet.contains(AUDIOCODEC_CONFIG_opus),
                    codecSet.contains(AUDIOCODEC_CONFIG_ISAC),
                    codecSet.contains(AUDIOCODEC_CONFIG_G722),
                    codecSet.contains(AUDIOCODEC_CONFIG_ILBC),
                    codecSet.contains(AUDIOCODEC_CONFIG_PCMU),
                    codecSet.contains(AUDIOCODEC_CONFIG_PCMA),
                    codecSet.contains(AUDIOCODEC_CONFIG_CN)};
        } else {
            audioCodecCheckedItem = new boolean[]{true, true, true, true, true, true, true};
        }
        //aec ns agc
        audioAecEnable = SettingUtils.get(this, AUDIO_AEC_CONFIG, false);
        audioNsEnable = SettingUtils.get(this, AUDIO_NS_ONFIG, false);
        audioAgcEnable = SettingUtils.get(this, AUDIO_AGC_CONFIG, false);
    }

    public void initView() {
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("设置");
        }

        mAudioCodecText = findViewById(R.id.tv_audioCodec);
        mAecEnableText = findViewById(R.id.tv_aec_enable);
        mNsEnableText = findViewById(R.id.tv_ns_enable);
        mAgcEnableText = findViewById(R.id.tv_agc_enable);
        findViewById(R.id.config_audioCodec).setOnClickListener(this);
        findViewById(R.id.config_aec).setOnClickListener(this);
        findViewById(R.id.config_ns).setOnClickListener(this);
        findViewById(R.id.config_agc).setOnClickListener(this);

        setAudioCodecText();
        setAudioConfig();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish(); // back button
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setAudioCodecText() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < audioCodecCheckedItem.length; i++) {
            if (audioCodecCheckedItem[i]) {
                stringBuilder.append(audioCodecArray[i]).append(",");
            }
        }
        audioCodec = stringBuilder.toString();
        if (!audioCodec.isEmpty()) {
            audioCodec = audioCodec.substring(0, audioCodec.length() - 1);
        }
        mAudioCodecText.setText(audioCodec);
        SettingUtils.set(ConfigActivity.this, AUDIOCODEC_CONFIG, audioCodec);
    }

    public void setAudioConfig(){
        String aecString = audioAecEnable ? "打开" : "关闭";
        mAecEnableText.setText(aecString);
        String nsString = audioNsEnable ? "打开" : "关闭";
        mNsEnableText.setText(nsString);
        String agcString = audioAgcEnable ? "打开" : "关闭";
        mAgcEnableText.setText(agcString);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.config_audioCodec:
                showAudioCodec();
                break;
            case R.id.config_aec:
            case R.id.config_ns:
            case R.id.config_agc:
                showAudioConfig(view.getId());
                break;

        }
    }

    public void showAudioCodec() {
        boolean[] tempCheckidItem = new boolean[audioCodecCheckedItem.length];
        System.arraycopy(audioCodecCheckedItem, 0, tempCheckidItem, 0, audioCodecCheckedItem.length);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("音频编码");
        b.setMultiChoiceItems(audioCodecArray, tempCheckidItem, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                tempCheckidItem[i] = b;
            }
        });
        b.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                System.arraycopy(tempCheckidItem, 0, audioCodecCheckedItem, 0, audioCodecCheckedItem.length);
                setAudioCodecText();
            }
        });
        b.show();
    }

    public void showAudioConfig(int config) {
        String title = null;
        String message = null;
        String setting = null;
        switch (config){
            case R.id.config_aec:
                title = "AEC回声消除设置";
                message = "是否打开AEC回声消除";
                setting = AUDIO_AEC_CONFIG;
                break;
            case R.id.config_ns:
                title = "NS降噪设置";
                message = "是否打开NS降噪";
                setting = AUDIO_NS_ONFIG;
                break;
            case R.id.config_agc:
                title = "AGC自动增益设置";
                message = "是否打开AGC自动增益";
                setting = AUDIO_AGC_CONFIG;
                break;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(title);
        b.setMessage(message);
        String finalSetting = setting;
        b.setPositiveButton("打开", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                SettingUtils.set(ConfigActivity.this, finalSetting,true);
                audioAecEnable = SettingUtils.get(ConfigActivity.this, AUDIO_AEC_CONFIG, false);
                audioNsEnable = SettingUtils.get(ConfigActivity.this, AUDIO_NS_ONFIG, false);
                audioAgcEnable = SettingUtils.get(ConfigActivity.this, AUDIO_AGC_CONFIG, false);
                setAudioConfig();
            }
        });
        b.setNegativeButton("关闭", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                SettingUtils.set(ConfigActivity.this, finalSetting,false);
                audioAecEnable = SettingUtils.get(ConfigActivity.this, AUDIO_AEC_CONFIG, false);
                audioNsEnable = SettingUtils.get(ConfigActivity.this, AUDIO_NS_ONFIG, false);
                audioAgcEnable = SettingUtils.get(ConfigActivity.this, AUDIO_AGC_CONFIG, false);
                setAudioConfig();
            }
        });
        b.show();
    }
}
