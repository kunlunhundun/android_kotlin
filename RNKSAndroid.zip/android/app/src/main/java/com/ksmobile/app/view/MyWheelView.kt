package com.ksmobile.app.view

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import com.wx.wheelview.widget.WheelView

class MyWheelView<T> (context: Context, attributeSet: AttributeSet):WheelView<T>(context,attributeSet) {

    init {

        skin = WheelView.Skin.Holo
        val wheelViewStyle = WheelViewStyle()
        wheelViewStyle.holoBorderColor = Color.parseColor("#DADADA")
        wheelViewStyle.selectedTextColor = Color.parseColor("#333333")
        wheelViewStyle.textColor = Color.parseColor("#888888")
        wheelViewStyle.textSize =  16
        wheelViewStyle.selectedTextZoom=1.2f
        setLoop(false)
        setWheelClickable(false)
        style = wheelViewStyle

    }





}