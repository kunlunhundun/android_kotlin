package com.ksmobile.app.data

data class PointPayResult (var status:String,
                           var billno:String,
                           var billstatus:String,
                           var message:String
                           )
