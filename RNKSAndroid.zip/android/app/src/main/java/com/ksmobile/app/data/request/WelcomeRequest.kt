package com.ksmobile.app.data.request

import com.ksmobile.app.util.DeviceInfo


class WelcomeRequest:BaseRequestObject( ) {

     val deviceBrand:String?=DeviceInfo.getPhoneBrand()
     val deviceModel:String?=DeviceInfo.getPhoneModel()
     val deviceSystemVersion:String?= DeviceInfo.getFirmwareVersion()
     val deviceType:String ="android"
}