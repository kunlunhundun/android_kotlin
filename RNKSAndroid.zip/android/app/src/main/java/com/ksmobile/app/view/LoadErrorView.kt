package com.ksmobile.app.view

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.ksmobile.app.R
import com.ksmobile.app.util.LoadErrorModel
import com.ksmobile.app.util.LoadErrorType
import kotlinx.android.synthetic.main.view_load_error.view.*


/**
 * Created by ward.y on 2018/4/28.
 */
class LoadErrorView(context: Context?, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {

    init {
        LayoutInflater.from(context).inflate(R.layout.view_load_error, this, true)

    }

    fun showError(type: Int) {
        btn_error_normal.visibility = View.GONE
        btn_error_highlight.visibility = View.GONE
        val loadErrorModel: LoadErrorModel = when (type) {
            LoadErrorType.DATA_EMPTY.code -> {
                LoadErrorType.DATA_EMPTY.getLoadErrorModel(context)
            }
            LoadErrorType.GO_RECHARGE.code -> {
                btn_error_highlight.visibility = View.VISIBLE
                LoadErrorType.GO_RECHARGE.getLoadErrorModel(context)
            }
            LoadErrorType.NOT_FOUND.code -> LoadErrorType.NOT_FOUND.getLoadErrorModel(context)
            LoadErrorType.NET_ERROR.code -> {
                btn_error_normal.visibility = visibility
                LoadErrorType.NET_ERROR.getLoadErrorModel(context)
            }
            LoadErrorType.TIME_OUT.code -> {
                btn_error_normal.visibility = visibility
                LoadErrorType.TIME_OUT.getLoadErrorModel(context)
            }
            LoadErrorType.IS_LOADING.code -> LoadErrorType.IS_LOADING.getLoadErrorModel(context)
            else -> {
                LoadErrorType.DATA_EMPTY.getLoadErrorModel(context)
            }
        }

        iv_error_logo.setImageResource(loadErrorModel.icon)
        error_tips.text = loadErrorModel.message


    }

    fun setIcon(id: Int) {
        iv_error_logo.setImageResource(id)
    }

    fun setTips(id: Int) {
        error_tips.setText(id)
    }

    fun setTips(string: String) {
        error_tips.text = string
    }


    fun showHighLight() {
        btn_error_highlight.visibility = View.VISIBLE
    }

    fun showNormal() {
        btn_error_normal.visibility = visibility
    }

    fun setHighLightText(text: String) {
        btn_error_highlight.text = text
        showHighLight()
    }

    fun setHighLightText(id: Int) {
        btn_error_highlight.setText(id)
        showHighLight()
    }

    fun setNormalText(text: String) {
        btn_error_normal.text = text
        showNormal()
    }

    fun setNormalText(id: Int) {
        btn_error_normal.setText(id)
        showNormal()
    }

    fun setHighLightClickListener(listener: OnClickListener) {
        btn_error_highlight.setOnClickListener(listener)
    }

    fun setNormalClickListener(listener: OnClickListener) {
        btn_error_normal.setOnClickListener(listener)
    }

    fun reset(){
        iv_error_logo.setImageResource(R.drawable.popup_window_transparent)
        error_tips.text = ""
        btn_error_highlight.visibility =View.GONE
        btn_error_normal.visibility =View.GONE
    }

}