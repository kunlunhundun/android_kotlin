package com.ksmobile.app.view

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.Toast
import com.flyco.tablayout.listener.CustomTabEntity
import com.flyco.tablayout.listener.OnTabSelectListener
import com.ksmobile.app.R
import com.ksmobile.app.activity.BaseActivity
import com.ksmobile.app.activity.MainActivity
import com.ksmobile.app.activity.reactnative.MyRnPageActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.data.TabEntity
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.iview.IDialog
import kotlinx.android.synthetic.main.navigation_bar_view.view.*
import java.util.ArrayList

class NavigationBarView(context: Context, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {
    constructor(context: Context) : this(context, null)

    val mTitles = arrayOf("首页", "消息", "客服", "更多")
    var mActivity: BaseActivity? = null
    private var dialog: IDialog? = null

    init {

        LayoutInflater.from(context).inflate(R.layout.navigation_bar_view, this, true)
        val mIconUnselectIds = intArrayOf(R.mipmap.icon_home, R.mipmap.icon_message, R.mipmap.icon_customer_service, R.mipmap.icon_setting)
        var mTabEntities = ArrayList<CustomTabEntity>()
        for (i in mTitles.indices) {
            mTabEntities.add(TabEntity(mTitles[i], mIconUnselectIds[i], mIconUnselectIds[i]))
        }
        cl_tab.setTabData(mTabEntities)


        initListener()
    }


    private fun initListener() {

        cl_tab.setOnTabSelectListener(object : OnTabSelectListener {
            override fun onTabSelect(position: Int) {
                if (Utils.isFastDoubleClick()){
                    return
                }
                showPop(position)

            }

            override fun onTabReselect(position: Int) {
                if (Utils.isFastDoubleClick()){
                    return
                }
                showPop(position)
            }

        })
    }


    /**
     * 显示未读小红点
     */

    fun showDot(position: Int) {
        cl_tab.showDot(position)
    }

    /**
     * 显示未读消息数
     */

    fun showMsg(position: Int, num: Int) {
        if (num==0){
            cl_tab.hideMsg(position)
        }else{
            cl_tab.showMsg(position, num)
            cl_tab.setMsgMargin(1, -5f, 5f)
        }

    }

    fun bindActiviy(activity: BaseActivity) {
        mActivity = activity
    }

    fun getDiaglog(): IDialog? {
        return dialog
    }


    private fun showPop(position: Int) {
        if (mActivity == null) {

            return
        }
        when (position) {
            0 -> {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MAIN, false))
                Handler().postDelayed({
                    AppInitManager.getActivityListManager().killAll()
                }, 300)


            }

            1 -> {
                if (mActivity !is MainActivity) {
                    AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MESSAGE, false))
                    Thread.sleep(100)
                    val intent = Intent(mActivity, MyRnPageActivity::class.java)
                    mActivity!!.startActivity(intent)
                } else {

                    if (TextUtils.isEmpty(ConfigUtils.loginName)) {
                        AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.LOGIN, true))

                    } else {
                        AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MESSAGE, true))

                    }

                }


            }

            2 -> {

                dialog = CustomerServiceDialog()
                (dialog as CustomerServiceDialog).show(mActivity?.supportFragmentManager, "sc")
            }

            3 -> {

                dialog = SettingsDialog()
                (dialog as SettingsDialog).show(mActivity?.supportFragmentManager, "sd")
            }
        }
    }

    fun onLayoutChange(show: Boolean) {

        dialog?.onLayoutChange(show)

    }

}