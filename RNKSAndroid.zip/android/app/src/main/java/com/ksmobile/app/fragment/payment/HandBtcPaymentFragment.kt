package com.ksmobile.app.fragment.payment

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.activity.CreateHandBtcDetailActivity
import com.ksmobile.app.data.response.QueryBtcRateAndAddressResponse
import com.ksmobile.app.fragment.BaseFragment
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import kotlinx.android.synthetic.main.fragment_order_pay_hand_btc.*

/**
 * 手工比特币存款订单页面
 */
class HandBtcPaymentFragment : BaseFragment() {

    var datas: QueryBtcRateAndAddressResponse? = null
    override fun getContentViewId(): Int {
        return R.layout.fragment_order_pay_hand_btc
    }

    override fun initView() {
//        timer.start()
    }

    override fun initListener() {
        copy_btc_url.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = tv_btc_url.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }



        btn_goto_detail.setOnClickListener {
            val intent = Intent(activity, CreateHandBtcDetailActivity::class.java)
            intent.putExtra("btcInfo", Gson().toJson(datas))
            intent.putExtra("money", tv_money.text)
            startActivity(intent)

        }


    }

    override fun initData() {
        val bundle = arguments
        if (bundle != null) {
            datas = Gson().fromJson(bundle.getString("datas"), QueryBtcRateAndAddressResponse::class.java)
        }

        tv_money.text = datas?.body?.btcAmount
        tv_recharge_tips.text = "人民币 ${datas?.body?.amount}元"
        tv_btc_url.text = datas?.body?.btcAddress


    }


//    private val timer = object : CountDownTimer(10 * 60 * 1000, 1000) {
//        override fun onTick(millisUntilFinished: Long) {
//            tv_count_down_time.text = (Utils.secToTime(millisUntilFinished / 1000))
//
//        }
//
//        override fun onFinish() {
//
//        }
//    }


    override fun onDestroy() {
        super.onDestroy()
//        timer.cancel()
    }
}