package com.ksmobile.app.net

import android.text.TextUtils
import android.util.Log
import com.ksmobile.app.BuildConfig
import com.ksmobile.app.MyApplication
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.database.DataBaseHelper
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit
import okhttp3.CacheControl


class ApiClient private constructor() {

    private val TAG = "ApiClient"
    //短缓存有效期为10分钟
    private val CACHE_STALE_SHORT = 60 * 3
    //长缓存有效期为7天
    private val CACHE_STALE_LONG = 60 * 60 * 24 * 7

    var baseUrl = ConfigUtils.runGateUrl
    private var frontUrl = ConfigUtils.frontUrl
    private var addUrl = ConfigUtils.addUrl
    lateinit var service: ApiService
    lateinit var frontService: ApiService
    lateinit var addurlService: ApiService

    private object Holder {
        val INSTANCE = ApiClient()
    }

    companion object {
        val instance by lazy { Holder.INSTANCE }
    }

    fun init() {
        val urlData = DataBaseHelper.getUrl()
        if (!TextUtils.isEmpty(urlData?.url)) {
            baseUrl = "${urlData?.url!!}/"
        }
        if (!TextUtils.isEmpty(urlData?.frontUrl)) {
            frontUrl = "${urlData?.frontUrl!!}/"
        }

        if (!TextUtils.isEmpty(urlData?.addUrl)) {
            addUrl = "${urlData?.addUrl!!}/"
        } else {
            urlData?.addUrl = addUrl
            urlData?.saveOrUpdate("urlId = ?", "1")
            addUrl = "$addUrl/"
        }



        val cache = Cache(File(MyApplication.getinstance().externalCacheDir, "File_AGQJ"), 10 * 1024 * 1024)
        val mOkHttpClient = OkHttpClient.Builder()
                .cache(cache)
                .retryOnConnectionFailure(false)
                .connectTimeout(45, TimeUnit.SECONDS)
                .readTimeout(45, TimeUnit.SECONDS)
                .writeTimeout(45, TimeUnit.SECONDS)
                .addNetworkInterceptor(HttpLoggingInterceptor().setLevel(
                        if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
                        else HttpLoggingInterceptor.Level.NONE
                ))
                .addNetworkInterceptor(rewriteCacheControlInterceptor)
                .addInterceptor(baseInterceptor)
                .addInterceptor(SignInterceptor())
                .build()


        val retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()

        service = retrofit.create(ApiService::class.java)

        //新特性网关
        val frontRetrofit = Retrofit.Builder()
                .baseUrl(frontUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()
        frontService = frontRetrofit.create(ApiService::class.java)
        //轮询网关
        val addRetrofit = Retrofit.Builder()
                .baseUrl(addUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(mOkHttpClient)
                .build()
        addurlService = addRetrofit.create(ApiService::class.java)


    }


    /**
     * 获取缓存
     */
    private var baseInterceptor: Interceptor = Interceptor { chain ->
        var request = chain.request()
        if (!NetWorkUtil.isNetWorkConnected()) {
            /**
             * 离线缓存控制  总的缓存时间=在线缓存时间+设置离线缓存时间
             */

            val tempCacheControl = CacheControl.Builder()
                    .onlyIfCached()
                    .maxStale(CACHE_STALE_LONG, TimeUnit.SECONDS)
                    .build()
            request = request.newBuilder()
                    .cacheControl(tempCacheControl)
                    .build()
            Log.i(TAG, "intercept:no network ")
        }
        chain.proceed(request)
    }

    private var rewriteCacheControlInterceptor: Interceptor = Interceptor { chain ->
        val request = chain.request()
        val originalResponse = chain.proceed(request)

        originalResponse.newBuilder()
                .removeHeader("Pragma")// 清除头信息，因为服务器如果不支持，会返回一些干扰信息，不清除下面无法生效
                .removeHeader("Cache-Control")
                .header("Cache-Control", "public, max-age=$CACHE_STALE_SHORT")
                .build()
    }




}
