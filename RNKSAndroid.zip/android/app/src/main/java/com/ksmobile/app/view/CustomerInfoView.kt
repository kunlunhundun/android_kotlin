package com.ksmobile.app.view

import android.content.Context
import android.graphics.Color
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import com.ksmobile.app.R
import kotlinx.android.synthetic.main.customer_info_view.view.*

class CustomerInfoView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {


    companion object {
        const val STATUS_NORMAL = 0
        const val STATUS_BLUE = 1
        const val STATUS_RED = 2
    }

    init {
        LayoutInflater.from(context).inflate(R.layout.customer_info_view, this, true)
        val a = context.obtainStyledAttributes(attrs, R.styleable.CustomerInfoView)
        val title = a.getString(R.styleable.CustomerInfoView_label_name)
        val status = a.getString(R.styleable.CustomerInfoView_status)
        val titleColor = a.getColor(R.styleable.CustomerInfoView_titleColor,resources.getColor(R.color.colorWhite))
        if (title != null) {
            tv_title.text = title
        }

        if (!TextUtils.isEmpty(status)){
            tv_status.text = status
        }

        tv_title.setTextColor(titleColor)

        tv_content.visibility = View.GONE
        a.recycle()
    }

    fun setTtile(title: String) {
        tv_title.text = title
    }

    fun setContent(content: String) {
        tv_content.text = content
        tv_content.visibility = View.VISIBLE
    }



    fun setStatus(string: String, status: Int) {

        tv_status.text = string

        when (status) {
            0 -> tv_status.setTextColor(Color.parseColor("#ffffff")) //normal
            1 -> tv_status.setTextColor(Color.parseColor("#44D9B5")) //blue
            2 -> tv_status.setTextColor(Color.parseColor("#FA2663")) //red

        }

    }

}