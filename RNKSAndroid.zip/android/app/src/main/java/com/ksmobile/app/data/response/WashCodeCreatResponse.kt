package com.ksmobile.app.data.response

import com.ksmobile.app.data.IRebateInfo
import com.ksmobile.app.data.RebateInfo
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class WashCodeCreatResponse : BaseResponseObject() {

    var body: Body? = null


    data class Body(
            var minXmAmount: BigDecimal,
            var minBetAmount: BigDecimal,
            var totalBetAmount: BigDecimal,
            var totalRemBetAmount: BigDecimal,
            var totalXmAmount: BigDecimal,
            var xmBeginDate: String,
            var xmEndDate: String,
            var xmList: MutableList<Bean>

    )

    data class Bean(
            var betAmount: BigDecimal,
            var totalBetAmont: BigDecimal,
            var xmAmount: BigDecimal,
            var xmRate: BigDecimal,
            var xmName: String,
            var xmTypes: MutableList<Bean2>
    ): RebateInfo(){
        override fun getGameName(): String {
            return xmName
        }

        override fun getRebateAmount(): String {
           return xmAmount.toString()
        }

        override fun getRebateProportion(): String {
            return "$xmRate%"
        }

        override fun getBetAmount(): String {
            return betAmount.toString()
        }


    }

    data class Bean2(
            var betAmount: BigDecimal,
            var totalBetAmount: BigDecimal,
            var xmAmount: BigDecimal,
            var xmRate: BigDecimal,
            var xmType: String
    )
}
