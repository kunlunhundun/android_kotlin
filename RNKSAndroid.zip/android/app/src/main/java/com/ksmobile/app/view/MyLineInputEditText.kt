package com.ksmobile.app.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.support.constraint.ConstraintLayout
import android.text.*
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import com.ksmobile.app.R
import com.ksmobile.app.util.GlideUtils
import kotlinx.android.synthetic.main.my_line_input_edittext.view.*

class MyLineInputEditText(context: Context, attrs: AttributeSet?) : ConstraintLayout(context, attrs) {
    constructor(context: Context) : this(context,null)

    private val TYPE_NUMBER = "number"
    private val TYPE_TEXT = "text"
    private val TYPE_PASSWORD = "password"
    private val TYPE_PHONE = "phone"
    private val TYPE_AMOUNT = "amount"
    private var toggleListener: ItoggleListener? = null
    private  var focusChangeListener:OnFocusChangeListener?=null


    init {
        LayoutInflater.from(context).inflate(R.layout.my_line_input_edittext, this, true)
        if (attrs!=null){
            val a = context.obtainStyledAttributes(attrs, R.styleable.customInput)
            val inputType = a.getString(R.styleable.customInput_inputType)
            val et_hint = a.getString(R.styleable.customInput_et_hint)
            val text = a.getString(R.styleable.customInput_text)
            val des = a.getString(R.styleable.customInput_des)
            val input_text = a.getString(R.styleable.customInput_input_text)
            val show_toggle = a.getBoolean(R.styleable.customInput_show_toggle, false)
            val input_enable = a.getBoolean(R.styleable.customInput_input_enable, true)
            val max_lenth = a.getInt(R.styleable.customInput_max_length, 0)
            val drawable_left = a.getDrawable(R.styleable.customInput_drawable_left)
            val drawable_right = a.getDrawable(R.styleable.customInput_drawable_right)
            val drawable_mid = a.getDrawable(R.styleable.customInput_drawable_mid)


            if (null != et_hint) {
                et_input.hint = et_hint
            }
            if (null != input_text) {
                et_input.setText(input_text)
            }
            if (null != des) {
                tv_describe.text = des
            }

            if (!input_enable){
                et_input.isCursorVisible = false
                et_input.isFocusable = false
                et_input.isFocusableInTouchMode = false
            }
            if (null!=text){
                tv_label.text = text
            }else{
                tv_label.visibility = View.GONE
            }

            if (null != drawable_left) {
                setDrawableLeft(drawable_left)
            }
            if (null != drawable_right) {
                img_right.setImageDrawable(drawable_right)
                img_right.visibility = View.VISIBLE
            }
            if (null != drawable_mid) {
                img_mid.setImageDrawable(drawable_mid)
                img_mid.visibility = View.VISIBLE
            }

            if (max_lenth != 0) {
                et_input.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(max_lenth))
            }

            if (show_toggle) {
                cb_pwd.visibility = View.VISIBLE

            }

            when {
                TYPE_NUMBER == inputType -> et_input.inputType = InputType.TYPE_CLASS_NUMBER
                TYPE_PASSWORD == inputType -> et_input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                TYPE_TEXT == inputType -> et_input.inputType = InputType.TYPE_CLASS_TEXT
                TYPE_PHONE == inputType -> et_input.inputType = InputType.TYPE_CLASS_PHONE
                TYPE_AMOUNT == inputType -> et_input.inputType = InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_CLASS_NUMBER
                null==inputType ->{
                    et_input.inputType = InputType.TYPE_CLASS_TEXT
                }
            }

           
            a.recycle()
        }

        cb_pwd.setOnCheckedChangeListener { _, b ->
            val passwordLength = et_input.text.length
            et_input.inputType = if (b)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            et_input.setSelection(passwordLength)

            if (null != toggleListener) {
                toggleListener?.callBack(b)
            }

        }


        et_input.setOnFocusChangeListener { view, hasFocus ->

            if (hasFocus) {
                hideError()
                line_bottom.setBackgroundResource(R.drawable.et_line_active)

            } else {
                line_bottom.setBackgroundResource(R.drawable.et_line_normal)

            }

            if (focusChangeListener!=null){
                focusChangeListener?.onFocusChange(view,hasFocus)
            }
        }


        et_input.addTextChangedListener(object :TextWatcher{
            override fun afterTextChanged(s: Editable?) {
                if (!TextUtils.isEmpty(s.toString())){
                    hideError()
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

        })


    }

    override fun setOnClickListener(l: OnClickListener?) {
        super.setOnClickListener(l)

            et_input.setOnClickListener(l)

    }

    override fun setOnFocusChangeListener(l: OnFocusChangeListener?) {
       focusChangeListener = l
    }

    fun setEditText(text: String?) {
        et_input.setText(text)
    }

    fun setText(text: String) {
        tv_label.text = text
        tv_label.visibility = View.VISIBLE
    }
    fun getEditTextContent(): String {

        return et_input.text.toString()
    }

    fun getEditText(): EditText {

        return et_input
    }

    fun getToggle(): CheckBox {

        return cb_pwd
    }


    fun setToggleListener(listener: ItoggleListener) {
        toggleListener = listener
    }

    fun showError(errorId: Int) {
        tv_error.setText(errorId)
        tv_error.visibility = View.VISIBLE
        line_bottom.setBackgroundResource(R.drawable.et_line_error)
    }

    fun showError(error: String?) {
        tv_error.text = error
        tv_error.visibility = View.VISIBLE
        line_bottom.setBackgroundResource(R.drawable.et_line_error)
    }

    fun hideError() {
        tv_error.text = ""
        tv_error.visibility = View.GONE
        if (et_input.hasFocus()){
            line_bottom.setBackgroundResource(R.drawable.et_line_active)
        }else{
            line_bottom.setBackgroundResource(R.drawable.et_line_normal)
        }


    }


    fun setDrawableLeft(drawable: Drawable) {
        img_left.setImageDrawable(drawable)
        img_left.visibility = View.VISIBLE
    }

    fun setDrawableLeft(id: Int) {
        img_left.setImageResource(id)
        img_left.visibility = View.VISIBLE
    }

    fun setDrawableLeft(url: String) {
        GlideUtils.load(context,url).into(img_left)
        img_left.visibility = View.VISIBLE
    }

    fun setDrawableRight(id: Int) {
        img_right.setImageResource(id)
        img_right.visibility = View.VISIBLE
    }

    fun setDrawableRight(drawable: Drawable?) {
        if (null==drawable){

            img_right.setImageDrawable(null)
            img_right.visibility = View.GONE
        }else{
            img_right.setImageDrawable(drawable)
            img_right.visibility = View.VISIBLE
        }

    }

    fun setLength(length: Int?) {
        if (length != 0) {
            et_input.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(length!!))
        }
    }

    fun setDrawableMid(drawable: Drawable) {
        img_mid.setImageDrawable(drawable)
        img_mid.visibility = View.VISIBLE
    }

    fun hiddenDrawableMid(){
        img_mid.setImageDrawable(null)
        img_mid.visibility = View.GONE
    }

    fun setDrawableMid(id: Int) {
        img_mid.setImageResource(id)
        img_mid.visibility = View.VISIBLE
    }

    fun setDrawableMid(url: String) {
        GlideUtils.load(context,url).placeholder(R.mipmap.insted_imag_smarll).error(R.mipmap.insted_imag_smarll).into(img_mid)
        img_mid.visibility = View.VISIBLE
    }



    fun hiddenDrawablePromo(){
        img_promo.setImageDrawable(null)
        img_promo.visibility = View.GONE
    }

    fun setDrawablePromo(id: Int) {
        img_promo.setImageResource(id)
        img_promo.visibility = View.VISIBLE
    }

    fun setEnable(enable:Boolean){
        hideError()
        if (enable){
            et_input.isCursorVisible = true
            et_input.isFocusable = true
            et_input.isFocusableInTouchMode = true
        }else{
            et_input.isCursorVisible = false
            et_input.isFocusable = false
            et_input.isFocusableInTouchMode = false
        }
    }

    interface ItoggleListener {
        fun callBack(isShow: Boolean)
    }

    fun setDarkMode(){
        tv_label.setTextColor(resources.getColor(R.color.colorTextGrey))
        et_input.setTextColor(resources.getColor(R.color.colorTextGrey))
    }
}