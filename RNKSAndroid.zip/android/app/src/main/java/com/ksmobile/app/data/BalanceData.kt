package com.ksmobile.app.data

data class BalanceData (val balance:String,val localBalance:String,val minWithdrawAmount:String)