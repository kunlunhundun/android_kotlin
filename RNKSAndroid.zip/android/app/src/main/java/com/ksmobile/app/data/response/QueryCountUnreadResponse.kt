package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryCountUnreadResponse : BaseResponseObject() {

    var body:Body=Body()


    data class Body(val totalRow:Int=0)

}

