package com.ksmobile.app.data.request



class VerifySmsCodeRequest : BaseRequestObject() {
    var messageId : String?=null
    var smsCode : String?=null
    var use : Int?=null

}