package com.ksmobile.app.data.request


class QueryBanksRequest : BaseRequestObject()
