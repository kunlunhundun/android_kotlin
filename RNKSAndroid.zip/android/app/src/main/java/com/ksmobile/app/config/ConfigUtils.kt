package com.ksmobile.app.config

import com.ksmobile.app.BuildConfig
import com.ksmobile.app.MyApplication
import com.ksmobile.app.data.BalanceData
import com.ksmobile.app.database.DataBaseHelper


/**
 * Created by ward.y on 2018/2/23.
 */
object ConfigUtils {
    const val testUrl = "http://www.pt-gateway.com"        //测试环境
   // const val testUrl = "http://m.a06n.com"        //测试环境
    const val runUrl = "https://m.ks0990.com"              //线上环境
    const val testGateUrl = "http://m3.ksbet168.net"      // 运测环境
    const val MODEL_RUNTIME = 3
    const val MODEL_RUNTIME_TEST = 2
    const val MODEL_NATIVAL_TEST = 1
    const val MODEL = BuildConfig.MODEL

    var baseUrl = ""
        set(value) {
            field = value
            runGateUrl = "$field/_glaxy_a06_"
            frontUrl = "$field/_glaxy_a06_/_extra_"
        }

    var runGateUrl = ""
    //新特性网关
    var frontUrl = ""
    var cdnUrl = "http://m3.ksbet168.net"
    const val addUrl = "http://addr.neptuneapi.com:8888"
    var onlineCustomerUrl: String? = ""
    var onlinePaymentUrl = arrayListOf<String>()


    var bankCardCounts = 0
    var mobileNo: String? = null
    var parentId = ""
    var isBindMobile = false
    var NOticeTag = false
    var starLevel: String? = "0"
    var balance = BalanceData("0", "0", "0")
    var realName: String? = ""
    var loginName: String? = ""
        set(value) {
            field = value

            MyApplication.getinstance().mAcach.put("loginName", field)

        }
        get() {
            if (field == null) {
                field = MyApplication.getinstance().mAcach.getAsString("loginName")
            }
            return field
        }


    var token: String? = ""
        set(value) {
            field = value
            if (null != field) {
                MyApplication.getinstance().mAcach.put("token", field)
            }


        }

    var customerId: String? = ""
        set(value) {
            field = value
            MyApplication.getinstance().mAcach.put("customerId", field)
        }

    var currentUserType: Int? = null
    const val USER_TYPE_TRY = 0


    var DOMAIN_NAME = ""
        get() {
            if (field == "") {
                val urlData = DataBaseHelper.getUrl()
                field = urlData?.domain!!

            }
            return field
        }


}
