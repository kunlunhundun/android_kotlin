package com.ksmobile.app.data.response



class WelcomeResponseObject : BaseResponseObject() {


    val body = WelcomeBody()


    class WelcomeBody  {
        var publicKey: String? = null
        var image: String? = null
        var info: String? = null
        var link: String? = null
        var addrServiceUrl: String? = null
        var h5DownUrl: String? = null
        var h5VersionId: Int = 0
        var h5Md5: String = ""
        var mWebUrl: String = ""
    }




}