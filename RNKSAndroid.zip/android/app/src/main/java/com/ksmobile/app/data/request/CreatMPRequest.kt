package com.ksmobile.app.data.request

import java.math.BigDecimal


class CreatMPRequest : BaseRequestObject() {

    var accountId: String? = null
    var password: String? = null
    var amount: BigDecimal? = BigDecimal(0)
    var btcAmount: String?=null
}