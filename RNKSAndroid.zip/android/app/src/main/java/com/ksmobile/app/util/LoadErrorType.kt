
package com.ksmobile.app.util

import android.content.Context
import android.support.annotation.StringRes
import com.ksmobile.app.R

enum class LoadErrorType(val code: Int, @param: StringRes private val messageId: Int,var icon:Int) {
    DATA_EMPTY(0, R.string.load_error_empty,R.mipmap.icon_load_error),
    GO_RECHARGE(1, R.string.load_error_go_recharge,R.mipmap.icon_load_error),
    NOT_FOUND(2, R.string.not_found,R.mipmap.icon_load_error),
    NET_ERROR(3, R.string.load_error_net_error,R.mipmap.icon_load_error),
    IS_LOADING(4, R.string.load_error_is_loading,R.mipmap.icon_load_error),
    TIME_OUT(5, R.string.load_error_is_time_out,R.mipmap.icon_load_error);




    fun getLoadErrorModel(context: Context): LoadErrorModel {
        return LoadErrorModel(code, context.getString(messageId),icon)
    }
}
