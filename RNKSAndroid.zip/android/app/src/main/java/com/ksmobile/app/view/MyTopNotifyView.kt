package com.ksmobile.app.view

import android.content.Context
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.ksmobile.app.R
import kotlinx.android.synthetic.main.top_notify_view.view.*

class MyTopNotifyView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {
    var hiddenCallback:IHinddenCallback?=null

    init {

        LayoutInflater.from(context).inflate(R.layout.top_notify_view, this, true)
        visibility = View.GONE

    }

    fun show() {

       Handler().postDelayed({
            val animation = AnimationUtils.loadAnimation(context, R.anim.popupwindow_show_anim)
            this.startAnimation(animation)
            visibility = View.VISIBLE

        }, 800)


        Handler().postDelayed({
            hidden()
        }, 2800)

    }

    fun hidden() {
        val animation = AnimationUtils.loadAnimation(context, R.anim.popupwindow_hidden_anim)
        this.startAnimation(animation)
        visibility = View.GONE

        animation.setAnimationListener(object :Animation.AnimationListener{
            override fun onAnimationRepeat(animation: Animation?) {
            }

            override fun onAnimationStart(animation: Animation?) {
            }

            override fun onAnimationEnd(animation: Animation?) {
                if (hiddenCallback!=null){
                    hiddenCallback?.onHidden()
                }
            }

        })

    }

    fun setTip(tip: String) {
        tv_notify.text = tip
    }

    fun setIcon(icon: Int) {
        iv_notify.setImageResource(icon)
    }

    interface IHinddenCallback{
        fun onHidden()
    }


    fun setOnHiddenCallBack(callback: IHinddenCallback){
        hiddenCallback = callback
    }
}