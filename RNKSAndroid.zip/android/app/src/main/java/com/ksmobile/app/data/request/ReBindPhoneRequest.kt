package com.ksmobile.app.data.request



class ReBindPhoneRequest : BaseRequestObject() {
    var messageId : String?=null
    var smsCode : String?=null
    var unbindLoginNames: MutableList<String>?=null

}