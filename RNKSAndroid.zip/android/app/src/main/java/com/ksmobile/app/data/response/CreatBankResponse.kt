package com.ksmobile.app.data.response

class CreatBankResponse : BaseResponseObject() {

    var body:Body?=null


    data class Body(
           var realName:String = ""
    )


}
