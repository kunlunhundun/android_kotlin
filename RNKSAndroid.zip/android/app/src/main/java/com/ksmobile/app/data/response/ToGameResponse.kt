package com.ksmobile.app.data.response

class ToGameResponse : BaseResponseObject() {
    var body: String? = null
}