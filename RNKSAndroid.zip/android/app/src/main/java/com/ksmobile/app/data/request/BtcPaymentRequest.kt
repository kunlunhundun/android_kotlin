package com.ksmobile.app.data.request

class BtcPaymentRequest : BaseRequestObject(){
    var accountId:String?= ""
    var amount:String? = ""
    var btcAddress:String? = ""
    var btcAmount:String? = ""
    var btcRate:String?= ""
    var btcUuid :String?= ""
    var depositDate :String?= ""

}


