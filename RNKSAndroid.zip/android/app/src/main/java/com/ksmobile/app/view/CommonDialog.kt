package com.ksmobile.app.view

import android.app.AlarmManager
import android.app.Dialog
import android.app.PendingIntent
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import com.ksmobile.app.R
import com.ksmobile.app.activity.SplashActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.StatusBarUtil
import com.ksmobile.app.util.Utils
import com.trello.rxlifecycle2.components.support.RxDialogFragment


/**
 * Created by ward.y on 2018/9/13.
 */

class CommonDialog : RxDialogFragment(), DialogInterface.OnKeyListener {
    var type = 0
    private var canBackCancle = true
    private var showCv = true
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        // 使用不带Theme的构造器, 获得的dialog边框距离屏幕仍有几毫米的缝隙。
        val bundle = arguments
        //根据STYLE标签选择style样式

        val dialog = initStyle()
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 设置Content前设定
        if (bundle != null) {
            type = bundle.getInt(TYPE, 1)
            canBackCancle = bundle.getBoolean(CANBACKCANCEL, true)
            showCv = bundle.getBoolean(SHOWCV, true)
            when (type) {


                TYPE_DEBUG -> {

                    dialog.setContentView(R.layout.dialog_debug_view)
                    initDebugLogin(dialog)

                }
                TYPE_WECHAT -> {

                    dialog.setContentView(R.layout.wepay_guid_dialog)
                    initWechatDialog(dialog)

                }

                TYPE_ALIPAY -> {

                    dialog.setContentView(R.layout.alipay_guid_dialog)
                    initWechatDialog(dialog)

                }
                TYPE_IP_LIMIT -> {

                    dialog.setContentView(R.layout.ip_limit_dialog)
                    initIpLimitDialog(dialog)

                }

                TYPE_BLACK_LIST -> {

                    dialog.setContentView(R.layout.popup_window_services)
                    initBlackListDialog(dialog)

                }

            }
        }

        dialog.setCanceledOnTouchOutside(false) // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        val window = dialog.window
        setTranslucentStatus(window)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = window.attributes
        lp.width = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.gravity = Gravity.CENTER
        window.attributes = lp


        return dialog
    }


    /**
     * ethan
     * 初始化style样式
     */
    private fun initStyle(): Dialog {

        return Dialog(activity, R.style.MyDialog)
    }


    private fun initWechatDialog(dialog: Dialog) {
        val tv_i_know = dialog.findViewById<TextView>(R.id.tv_i_know)
        val img_close = dialog.findViewById<ImageView>(R.id.img_close)
        tv_i_know.setOnClickListener {
            dismiss()
        }
        img_close.setOnClickListener {
            dismiss()
        }
    }

    private fun initBlackListDialog(dialog: Dialog) {
        val tv_cancel = dialog.findViewById<TextView>(R.id.tv_cancel)
        val tv_sure = dialog.findViewById<TextView>(R.id.tv_sure)
        val toolbar_icon = dialog.findViewById<ImageView>(R.id.toolbar_icon)
        tv_cancel.setOnClickListener {
            AppInitManager.getActivityListManager().killAll()

        }
        toolbar_icon.setOnClickListener {
            AppInitManager.getActivityListManager().killAll()
        }

        tv_sure.setOnClickListener {
            Utils.goOnlineCustomerService()

        }
        dialog.setCancelable(false)
        dialog.setOnKeyListener(this)

    }


    private fun initIpLimitDialog(dialog: Dialog) {
        val tv_i_know = dialog.findViewById<TextView>(R.id.tv_i_know)
        val tv_cv = dialog.findViewById<TextView>(R.id.tv_cv)
        val tv_cv_en = dialog.findViewById<TextView>(R.id.tv_cv_en)
        if (!showCv) {
            tv_i_know.visibility = View.GONE
            tv_cv.visibility = View.GONE
            tv_cv_en.visibility = View.GONE
        }
        tv_i_know.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        dialog.setCancelable(false)

        dialog.setOnKeyListener { dialog, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                AppInitManager.getActivityListManager().exitApp()
                true
            }
            false
        }
    }


    private fun initDebugLogin(dialog: Dialog) {
        val urls: MutableList<String> = mutableListOf()
        val urlData = DataBaseHelper.getUrl()
        when {
            ConfigUtils.testUrl.contains(urlData?.domain!!) -> {
                urls.add("当前：${ConfigUtils.testUrl}")
                urls.add(ConfigUtils.runUrl)
                urls.add(ConfigUtils.testGateUrl)


            }
            ConfigUtils.runUrl.contains(urlData?.domain!!) -> {
                urls.add("当前：${ConfigUtils.runUrl}")
                urls.add(ConfigUtils.testUrl)
                urls.add(ConfigUtils.testGateUrl)

            }

            ConfigUtils.testGateUrl.contains(urlData?.domain!!) -> {
                urls.add("当前：${ConfigUtils.testGateUrl}")
                urls.add(ConfigUtils.testUrl)
                urls.add(ConfigUtils.runUrl)

            }

            else -> {
                urls.add(ConfigUtils.runUrl)
                urls.add(ConfigUtils.testUrl)
                urls.add(ConfigUtils.testGateUrl)
            }
        }
        val lv_debug: ListView = dialog.findViewById(R.id.lv_debug)
        lv_debug.adapter = ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, urls)
        lv_debug.setOnItemClickListener { parent, view, position, id ->
            AppInitManager.getReactPackage().openNativeModule?.logOutLocal()
            DataBaseHelper.updateUrl(urls[position].replace("当前：", ""))
            val mgr = activity?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(activity, SplashActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            val restartIntent = PendingIntent.getActivity(activity, 0, intent, PendingIntent.FLAG_ONE_SHOT)
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 10, restartIntent) // 1秒钟后重启应用
            AppInitManager.getActivityListManager().exitApp()


        }

    }

    companion object {

        const val TYPE = "type"
        const val CANBACKCANCEL = "canBackCancel"
        const val SHOWCV = "showCv"
        const val TYPE_DEBUG = 1
        const val TYPE_WECHAT = 2
        const val TYPE_ALIPAY = 3
        const val TYPE_IP_LIMIT = 4
        const val TYPE_BLACK_LIST = 5

    }


    interface IFinshiCallBacK {
        fun onCallBack() {}
    }


    private fun setTranslucentStatus(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }
        StatusBarUtil.StatusBarLightMode(window)

    }

    override fun onKey(dialog: DialogInterface?, keyCode: Int, event: KeyEvent?): Boolean {
        return if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!canBackCancle) {
                activity?.finish()

            } else {
                dismiss()
            }

            true
        } else {
            false
        }
    }
}

