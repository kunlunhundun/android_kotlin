package com.ksmobile.app.data.response



/**
 * Created by ward.y on 2018/3/19.
 */
class QueryAmountListResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var maxAmount: Double,
            var minAmount: Double,
            var amounts:MutableList<String>,
            var depositorList:MutableList<Depositor>,
            var fix:Int
    )


    data class Depositor(val depositor:String,val id :String)


}
