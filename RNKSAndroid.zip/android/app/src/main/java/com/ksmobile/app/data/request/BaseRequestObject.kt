package com.ksmobile.app.data.request
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.ProjectUtils

/**
 * Created by ward.y on 2018/3/26.
 */
abstract class BaseRequestObject {
    var productId = ProjectUtils.PID
    val loginName = ConfigUtils.loginName

}