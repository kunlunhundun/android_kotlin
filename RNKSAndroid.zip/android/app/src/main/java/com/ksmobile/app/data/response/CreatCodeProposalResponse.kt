package com.ksmobile.app.data.response

import com.ksmobile.app.data.RebateInfo
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class CreatCodeProposalResponse : BaseResponseObject() {
    val body = Body()

    class Body {
        var loginName: String? = null
        var referenceId: String? = null
        var xmAmount: BigDecimal? = null
        var xmResult = mutableListOf<ResultObject>()

    }

    data class ResultObject(var xmType:String,var flag:String, var errCode:String,var errMsg:String,var xmTypeName:String,var xmAmount: BigDecimal,var xmRate:String,var betAmount:BigDecimal): RebateInfo() {
        override fun getGameName(): String {
            return xmTypeName
        }

        override fun getRebateAmount(): String {
            return  errMsg
        }

        override fun getRebateProportion(): String {
            return xmAmount.toString()
        }

        override fun getBetAmount(): String {
            return xmRate+"%"
        }

        override fun getXmFlag(): String {
            return flag
        }

    }
}
