package com.ksmobile.app.data.request



class WashCodeCreatRequest : BaseRequestObject() {
}