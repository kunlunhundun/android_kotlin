package com.ksmobile.app.data.response



/**
 * Created by ward.y on 2018/3/19.
 */
class QueryPayLimitByTypeResponse : BaseResponseObject() {
    val body:Body?=null


    data class Body(var maxAmount:Double,var minAmount:Double,var payType:Int, var optDepositAmounts:MutableList<String>)
}

