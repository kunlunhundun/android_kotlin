package com.ksmobile.app.data.request



class CreatPayOrderRequest : BaseRequestObject() {

    var bankCode: String? = null
    var amount: Int? = 0
    var payType: Int? = 0
    var depositorType: Int = 0
    var depositor: String? = null
}