package com.ksmobile.app.adapter

import android.content.Context
import android.content.Intent
import android.support.v4.view.PagerAdapter
import android.support.v7.widget.CardView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import java.util.ArrayList

import com.ksmobile.app.R
import com.ksmobile.app.activity.BindBankCardActivity
import com.ksmobile.app.activity.BindBitCardActivity
import com.ksmobile.app.activity.RealNameVerifyActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.BankCardObj
import com.ksmobile.app.util.GlideUtils
import kotlinx.android.synthetic.main.adapter_bank_card.view.*

class BankCardPagerAdapter(context: Context) : PagerAdapter(), CardAdapter {

    private val mViews: MutableList<CardView?>
    private val mData: MutableList<BankCardObj?>
    private val mContext: Context = context
    private var mBaseElevation: Float = 0f
    lateinit var view: View

    private var mListener: IDeleteCallBack? = null

    init {
        mData = ArrayList()
        mViews = ArrayList()
    }

    fun addCardItem(item: BankCardObj?) {
        mViews.add(null)
        mData.add(item)
    }

    override fun getBaseElevation(): Float {
        return mBaseElevation
    }

    override fun getCardViewAt(position: Int): CardView? {
        return mViews[position]
    }

    override fun getCount(): Int {
        return mData.size
    }


    override fun isViewFromObject(view: View, ob: Any): Boolean {
        return view === ob
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        view = LayoutInflater.from(container.context)
                .inflate(R.layout.adapter_bank_card, container, false)
        container.addView(view)
        bind(position, view)


        if (mBaseElevation == 0f) {
            mBaseElevation = view.cardView.cardElevation
        }
        view.cardView.maxCardElevation = mBaseElevation * CardAdapter.MAX_ELEVATION_FACTOR
        mViews[position] = view.cardView
        return view
    }

    override fun destroyItem(container: ViewGroup, position: Int, view: Any) {
        container.removeView(view as View)
        mViews[position] = null
    }

    private fun bind(position: Int, view: View) {
        if (null == mData[position]) {
            view.ll_bind_card.visibility = View.VISIBLE
            view.cl_bank_card.visibility = View.GONE
            view.ll_bind_card.setOnClickListener {
               val intent = Intent(mContext, BindBankCardActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                mContext.startActivity(intent)


            }
        } else {
            view.cl_bank_card.visibility = View.VISIBLE

            if (mData[position]?.accountType == "BTC") {
                view.cl_bank_card.setBackgroundResource(R.drawable.bit_card_bg)
            } else {
                when (position % 3) {
                    0 -> {
                        view.cl_bank_card.setBackgroundResource(R.drawable.bank_card_blue_bg)
                    }
                    1 -> {
                        view.cl_bank_card.setBackgroundResource(R.drawable.bank_card_red_bg)
                    }
                    2 -> {
                        view.cl_bank_card.setBackgroundResource(R.drawable.bank_card_purple_bg)
                    }
                }
            }

            view.tv_bank_card_name.text = mData[position]?.bankName
            view.tv_bank_card_address.text = mData[position]?.accountName
            view.tv_bank_card_number.text = mData[position]?.accountNo
            GlideUtils.load(mContext, mData[position]?.bankIcon).error(R.mipmap.icon_mbc).into(view.icon_bank)

            view.iv_delete.setOnClickListener {
                if (mListener != null) {
                    mListener?.onDelete(mData[position]?.accountId, mData[position]?.accountNo)
                }
            }

//            view.cardView.animate().alpha(0.3f)

        }


    }


    fun setIdeleteListener(listener: IDeleteCallBack) {
        mListener = listener
    }

    interface IDeleteCallBack {
        fun onDelete(accountId: String?, accountNo: String?)
    }


}
