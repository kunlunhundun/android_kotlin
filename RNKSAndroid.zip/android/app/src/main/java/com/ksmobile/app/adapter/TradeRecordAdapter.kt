package com.ksmobile.app.adapter


import android.content.Context
import android.graphics.Color
import android.support.constraint.ConstraintLayout
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.daimajia.swipe.SwipeLayout
import com.daimajia.swipe.adapters.RecyclerSwipeAdapter
import com.ksmobile.app.R
import com.ksmobile.app.data.OrderObject
import com.ksmobile.app.util.GlideUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.MyDeleteButton


/**
 * Created by ward on 15/11/26.
 */
class TradeRecordAdapter(context: Context, data: MutableList<OrderObject>) : RecyclerSwipeAdapter<TradeRecordAdapter.ViewHolder>() {
    override fun getSwipeLayoutResourceId(position: Int): Int {
        return position
    }

    var datas = data
    var mContext = context
    val MODE_EDIT: Int = 1
    val MODE_NORMAL: Int = 0
    var currentMode: Int = 0
    var selectAll = false
    val selcetItems = mutableSetOf<Int>()
    val ids = mutableListOf<OrderObject>()
    private var clickCallBack: ItemClickCallBack? = null

    fun setClickCallBack(clickCallBack: ItemClickCallBack) {
        this.clickCallBack = clickCallBack
    }

    interface ItemClickCallBack {
        fun onItemClick(pos: Int)
        fun onItemDelete(pos: Int)
    }


    //创建新View，被LayoutManager所调用
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_order_list_view, viewGroup, false)
        return ViewHolder(view)
    }

    //将数据与界面进行绑定的操作
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        GlideUtils.load(mContext,datas[position].itemIcon).placeholder(R.mipmap.insted_imag_smarll).error(R.mipmap.insted_imag_smarll).into(viewHolder.iv_icon)

        viewHolder.tv_amount.text = Utils.formatMoney(datas[position].amount)
        var day =  datas[position].createDate.split(" ")[0]
        var hour =  datas[position].createDate.split(" ")[1]
        val date = day.substring(day.indexOf("-")+1)+" "+hour
        viewHolder.tv_time.text = date
        if (!TextUtils.isEmpty(datas[position].platformName)) {
            viewHolder.tv_pay_type.text = datas[position].platformName
        } else if (!TextUtils.isEmpty(datas[position].accountNo)) {
            viewHolder.tv_pay_type.text = "尾号${datas[position].accountNo}"
        }else{
            viewHolder.tv_pay_type.text = datas[position].title
        }

        viewHolder.tv_status.text = datas[position].flagDesc
        when (datas[position].flag) {
            0,9,1,97 -> {
                viewHolder.tv_status.setTextColor(Color.parseColor("#E9664B"))
                setEditDisable(viewHolder)
                selcetItems.remove(position)
            }

            2 -> {
                viewHolder.tv_status.setTextColor(Color.parseColor("#50E3C2"))
                setEditEnable(viewHolder)
            }
            else -> {
                viewHolder.tv_status.setTextColor(Color.parseColor("#999999"))
                setEditEnable(viewHolder)
            }

        }

        if (currentMode == MODE_EDIT) {
            viewHolder.sl_report.isSwipeEnabled = false
            viewHolder.iv_delete_mark.visibility = View.VISIBLE
            viewHolder.cl_record.setOnClickListener { viewHolder.iv_delete_mark.performClick() }
            if (datas[position].flag==0||datas[position].flag==1||datas[position].flag==9) {
                viewHolder.fl_delete_disable.visibility = View.VISIBLE
            }else{
                viewHolder.fl_delete_disable.visibility = View.GONE
            }

            viewHolder.iv_delete_mark.setOnCheckedChangeListener { _, checked ->
                if (checked) {
                    ids.add(datas[position])
                    selcetItems.add(position)
                } else {
                    selcetItems.remove(position)
                    ids.remove(datas[position])
                }

            }


            viewHolder.iv_delete_mark.isChecked = selcetItems.contains(position)

        } else if (currentMode == MODE_NORMAL) {
            viewHolder.sl_report.isSwipeEnabled = true
            viewHolder.iv_delete_mark.visibility = View.GONE
            viewHolder.fl_delete_disable.visibility = View.GONE
            viewHolder.iv_delete_mark.setOnCheckedChangeListener(null)
            ids.clear()
            viewHolder.cl_record.setOnClickListener {
                if (clickCallBack != null) {
                    clickCallBack!!.onItemClick(position)
                }
            }
        }


        viewHolder.tv_delete.setOnClickListener {
            if (clickCallBack != null) {
                clickCallBack!!.onItemDelete(position)
            }
        }


    }

    //获取数据的数量
    override fun getItemCount(): Int {
        return datas.size
    }

    fun setMode(mode: Int) {
        currentMode = mode
        if (currentMode == MODE_NORMAL) {
            selectAll = false
        }
        notifyDataSetChanged()
    }

    fun setAllselect(select: Boolean) {
        selectAll = select
        if (!select) {
            ids.clear()
            selcetItems.clear()
        } else {

            for (i in 0 until itemCount) {
                selcetItems.add(i)
            }
        }

        notifyDataSetChanged()
    }

    fun removeItem(pos: Int) {
        datas.removeAt(pos)
        notifyItemRemoved(pos + 1)
        notifyItemRangeChanged(pos + 1, datas.size - pos)

    }

    fun removeAll() {

        ids.forEach {
            datas.remove(it)
        }
        selcetItems.clear()
        notifyDataSetChanged()
    }

    //自定义的ViewHolder，持有每个Item的的所有界面元素
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var iv_icon: ImageView = view.findViewById(R.id.iv_icon)
        var tv_pay_type: TextView = view.findViewById(R.id.tv_pay_type)
        var tv_amount: TextView = view.findViewById(R.id.tv_amount)
        var tv_time: TextView = view.findViewById(R.id.tv_time)
        var tv_status: TextView = view.findViewById(R.id.tv_status)
        var tv_delete: MyDeleteButton = view.findViewById(R.id.tv_delete)
        var cl_record: ConstraintLayout = view.findViewById(R.id.cl_record)
        var iv_delete_mark: CheckBox = view.findViewById(R.id.iv_delete_mark)
        var sl_report: SwipeLayout = view.findViewById(R.id.sl_report)
        var fl_delete_disable: FrameLayout = view.findViewById(R.id.fl_delete_disable)

    }

    private fun setEditEnable(viewHolder: ViewHolder) {
        viewHolder.iv_delete_mark.isEnabled = true
        viewHolder.tv_delete.isEnabled = true
        viewHolder.tv_delete.text ="删除"
        viewHolder.iv_delete_mark.setButtonDrawable(R.drawable.report_edit_selector)
    }

    private fun setEditDisable(viewHolder: ViewHolder) {
        viewHolder.tv_delete.isEnabled = false
        viewHolder.iv_delete_mark.isEnabled = false
        viewHolder.tv_delete.text ="不可删除"
        viewHolder.iv_delete_mark.setButtonDrawable(R.mipmap.icon_disable_checked)


    }
}





















