package com.ksmobile.app.data.request


import com.ksmobile.app.data.response.WashCodeCreatResponse


class CreatWashCodeProposalRequest : BaseRequestObject() {

    var xmBeginDate: String? = null
    var xmEndDate: String? = null
    var xmRequests: MutableList<WashCodeCreatResponse.Bean2> = mutableListOf()


}