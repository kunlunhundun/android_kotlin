package com.ksmobile.app.util


import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.PackageManager.NameNotFoundException
import android.os.Build
import android.os.Environment
import com.ksmobile.app.activity.SplashActivity
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.lang.Thread.UncaughtExceptionHandler
import java.text.SimpleDateFormat
import java.util.*


/**
 * 异常处理类(app出现异常会保留文件到本地)
 *
 * @author ljy
 * @modify ward.y
 * @ClassName: CrashDiary
 * @date 2018年9月18日
 */
class CrashDiary : UncaughtExceptionHandler {

    private var mContext: Context? = null
    private var mDiaryFolder: File? = null
    private var mDefaultHandler: UncaughtExceptionHandler? = null
    // 用于格式化日期,作为日志文件名的一部分
    private val mFormatter = SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", Locale.getDefault())
    //用来存储设备信息和异常信息
    private val mInformation = HashMap<Any,Any>()

    /**
     * 初始化方法
     */
    fun init(context: Context) {
        mContext = context
        mDiaryFolder = File("${Environment.getExternalStorageDirectory().path}/huanya")
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler(this)
    }

    override fun uncaughtException(thread: Thread, ex: Throwable) {
        if (mDefaultHandler != null && !handleException(ex)) {
            mDefaultHandler!!.uncaughtException(thread, ex)
        } else {
            val mgr = mContext?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(mContext, SplashActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            val restartIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_ONE_SHOT)
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, restartIntent) // 1秒钟后重启应用
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(0)
            System.gc()



        }
    }

    private fun handleException(ex: Throwable?): Boolean {
        if (ex == null) {
            return false
        }
        //		DialogHelper helper = new DialogHelper(Context);
        //--
        //收集设备参数信息
        collectDeviceInfo(mContext!!)
        //保存日志文件
        saveCrashInfo2File(ex)
        // 退出程序
        return true
    }

    /**
     * 收集设备参数信息
     *
     * @param ctx
     */
    private fun collectDeviceInfo(ctx: Context) {
        try {
            val pm = ctx.packageManager
            val pi = pm.getPackageInfo(ctx.packageName, PackageManager.GET_ACTIVITIES)
            if (pi != null) {
                val versionName = if (pi.versionName == null) "null" else pi.versionName
                val versionCode = pi.versionCode.toString() + ""
                mInformation.put("versionName", versionName)
                mInformation.put("versionCode", versionCode)
            }
        } catch (e: NameNotFoundException) {
            LogUtils.e(TAG, "an error occured when collect package info", e)
        }

        val fields = Build::class.java.declaredFields
        for (field in fields) {
            try {
                field.isAccessible = true
                mInformation.put(field.name, field.get(null).toString())
                LogUtils.e(TAG, field.name + " : " + field.get(null))
            } catch (e: Exception) {
                LogUtils.e(TAG, "an error occured when collect crash info", e)
            }

        }
    }

    /**
     * 保存错误信息到文件中
     *
     * @param ex
     * @return 返回文件名称, 便于将文件传送到服务器
     */
    private fun saveCrashInfo2File(ex: Throwable): String? {

        val sb = StringBuffer()
        for (entry in mInformation.entries) {
            val key = entry.key
            val value = entry.value
            sb.append("$key =$value\n")
        }

        val writer = StringWriter()
        val printWriter = PrintWriter(writer)
        ex.printStackTrace(printWriter)
        var cause: Throwable? = ex.cause
        while (cause != null) {
            cause.printStackTrace(printWriter)
            cause = cause.cause
        }
        printWriter.close()
        val result = writer.toString()
        sb.append(result)
        LogUtils.e(TAG, sb.toString())
        try {
            val time = mFormatter.format(Date())
            val fileName = "$time.txt"
            if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
                //                File dir = FileUtil.generateCacheTemporaryFile(mContext, fileName);

                val fileOutput: File?

                fileOutput = if (mDiaryFolder != null && mDiaryFolder!!.isDirectory) {
                    FileUtil.getFile(mDiaryFolder, fileName)
                } else {
                    val dirTemp = FileUtil.getDirectory(FileUtil.getExternalCacheDir(mContext!!), "crash_log")
                    FileUtil.getFile(dirTemp, fileName)
                }

                if (fileOutput == null) {
                    LogUtils.e(TAG, "文件创建失败!")
                    return null
                }
                val fos = FileOutputStream(fileOutput)
                fos.write(sb.toString().toByteArray())
                fos.close()
            }
            return fileName
        } catch (e: Exception) {
            LogUtils.e(TAG, "an error occured while writing file...", e)
        }



        return null
    }


    companion object {
        val TAG = CrashDiary::class.java.simpleName
        private var mInstance:CrashDiary?=null

        /**
         * 获取crashDiary实例
         */

        val instance:CrashDiary
        @Synchronized get(){
            if (mInstance==null){
                mInstance = CrashDiary()
            }
            return mInstance!!
        }

    }

}
