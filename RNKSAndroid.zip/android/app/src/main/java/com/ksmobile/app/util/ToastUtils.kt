package com.ksmobile.app.util

import android.widget.Toast

import com.ksmobile.app.MyApplication


/**
 *
 * modify  ward.y
 * date:    2018/8/18
 * description: 吐司工具类
 */
object ToastUtils {
    private var mToast: Toast? = null

    private var lastShowTime:Long = 0
    /**
     * 显示Toast,页面中重复Toast不会重复实例化Toast对象
     * 2000ms
     * @param charSequence 字符串
     */
    fun show(string: String?) {
        val time = System.currentTimeMillis()
        val timeD = time - lastShowTime
        if (timeD<2000){
            return
        }
        if (mToast == null) {
            mToast = Toast.makeText(MyApplication.instance?.baseContext, string, Toast.LENGTH_SHORT)
        } else  {
            mToast?.setText(string)
            mToast?.duration = Toast.LENGTH_SHORT
        }


        mToast?.show()
    }

    /**
     * 显示Toast,页面中重复Toast不会重复实例化Toast对象
     * 3500ms
     * @param charSequence 字符串
     */
    fun show(charSequence: CharSequence?) {
        val time = System.currentTimeMillis()
        val timeD = time - lastShowTime
        if (timeD<2000){
            return
        }
        if (mToast == null) {
            mToast = Toast.makeText(MyApplication.instance?.baseContext, charSequence, Toast.LENGTH_LONG)
        } else {
            mToast!!.setText(charSequence)
            mToast!!.duration = Toast.LENGTH_LONG
        }

        mToast?.show()
    }

    /**
     * 显示Toast,页面中重复Toast不会重复实例化Toast对象
     * 3500ms
     * @param charSequence 字符串
     */
    fun showLong(charSequence: CharSequence) {
        val time = System.currentTimeMillis()
        val timeD = time - lastShowTime
        if (timeD<2000){
            return
        }
        if (mToast == null) {
            mToast = Toast.makeText(MyApplication.instance?.baseContext, charSequence, Toast.LENGTH_LONG)
        } else {
            mToast!!.setText(charSequence)
            mToast!!.duration = Toast.LENGTH_LONG
        }

        mToast?.show()
    }

    /**
     * 显示Toast,页面中重复Toast不会重复实例化Toast对象
     * 2000ms
     * @param resId String资源ID
     */
    fun show(resId: Int) {
        val time = System.currentTimeMillis()
        val timeD = time - lastShowTime
        if (timeD<2000){
            return
        }
        if (mToast == null) {
            mToast = Toast.makeText(MyApplication.instance?.baseContext, resId, Toast.LENGTH_SHORT)
        } else {
            mToast!!.setText(resId)
            mToast!!.duration = Toast.LENGTH_SHORT
        }

        mToast?.show()
    }

    /**
     * 显示Toast,页面中重复Toast不会重复实例化Toast对象
     * 3500ms
     * @param resId String资源ID
     */
    fun showLong(resId: Int) {
        val time = System.currentTimeMillis()
        val timeD = time - lastShowTime
        if (timeD<2000){
            return
        }
        if (mToast == null) {
            mToast = Toast.makeText(MyApplication.instance?.baseContext, resId, Toast.LENGTH_LONG)
        } else {
            mToast!!.setText(resId)
            mToast!!.duration = Toast.LENGTH_LONG
        }

        mToast?.show()
    }

    /**
     * 取消Toast显示
     */
    fun cancelToast() {
        mToast?.cancel()

    }

}
