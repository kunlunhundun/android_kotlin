package com.ksmobile.app.view

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.TextView
import com.ksmobile.app.R

class MySelecteTextView(context: Context, attributeSet: AttributeSet) : TextView(context, attributeSet) {
    init {
        gravity = Gravity.CENTER


    }
    override fun setSelected(selected: Boolean) {
        if (selected) {
            setTextColor(resources.getColor(R.color.colorWhite))
        } else {
            setTextColor(resources.getColor(R.color.colorTextGrey))
        }

    }

}