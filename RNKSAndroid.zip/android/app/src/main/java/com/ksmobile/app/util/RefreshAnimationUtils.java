package com.ksmobile.app.util;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * 创建时间：2018/8/24
 * 方法编写人：Rea.X
 * 功能描述：
 */
public class RefreshAnimationUtils {
    private static ObjectAnimator circle_anim;

    /**
     * 开始刷新的旋转动画
     *
     * @param v 需要执行动画的view
     */
    public static void startRefreshAnim(View v) {
        stopRefreshAnim();
        circle_anim = ObjectAnimator.ofFloat(v, "rotation", 0f, 360f);
        circle_anim.setDuration(1000);
        circle_anim.setInterpolator(new LinearInterpolator());
        circle_anim.setRepeatCount(ValueAnimator.INFINITE);

        circle_anim.start();
    }


    /**
     * 暂停动画
     */
    public static void stopRefreshAnim() {
        if (circle_anim != null) {
            circle_anim.end();
            circle_anim = null;
        }
    }
}
