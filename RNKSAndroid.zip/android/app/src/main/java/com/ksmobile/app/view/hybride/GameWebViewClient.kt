package com.ksmobile.app.view.hybride

import android.annotation.TargetApi
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Handler
import android.text.TextUtils
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import com.ksmobile.app.activity.RechargeActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.Utils

open class GameWebViewClient(activity: Activity) : BaseWebViewClient(activity) {


    @TargetApi(21)
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        return shouldInterceptRequest(view, request.url.toString())
    }

    override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
        return null
    }

    override fun shouldOverrideUrlLoading(webview: WebView?, url: String?): Boolean {
        if (!TextUtils.isEmpty(url)) {
            if (TextUtils.isEmpty(url)) {
                return false
            }
            val uri = Uri.parse(url)
            if (uri == null) {
                return false
            }
            when {

                //竖屏
                url == "https://localhost/portrait.html" -> {
                    mActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    return true
                }
                //横屏
                url == "https://localhost/landscape.html" -> {
                    mActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    return true
                }
                //传感器切换横竖屏
                url == "https://localhost/sensor.html" -> {
                    mActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    return true
                }
                //网络掉线
                url == "https://localhost/disconnect.html" -> {
                    return true
                }

                url!!.contains("method=dp") -> {
                    if (TextUtils.isEmpty(ConfigUtils.token)) {
                        AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.LOGIN, true))
                        Handler().postDelayed({mActivity.finish()},600)
                    } else {
                        val intent = Intent(mActivity, RechargeActivity::class.java)
                        mActivity.startActivity(intent)
                    }

                    return true
                }

                url.contains("method=pcs") -> {
                    Utils.goOnlineCustomerService()
                    return true
                }
                url.contains("method=wd") -> {
                    return true
                }

            }


        }
        return super.shouldOverrideUrlLoading(webview, url)
    }

}