package com.ksmobile.app.data.request


class DeleteRecordRequest : BaseRequestObject() {

    var requestIds = mutableListOf<String>()


}