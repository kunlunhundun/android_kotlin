package com.ksmobile.app.data

data class PointCardObject (val cardCode:String,
                            val desc:String,
                            val fee:Int=0,
                            val id:Int,
                            val name:String,
                            val amountList:MutableList<String>

)
