package com.ksmobile.app.data.response

import com.ksmobile.app.data.IRebateInfo
import com.ksmobile.app.data.RebateInfo
import com.ksmobile.app.data.XmCode
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class WashCodePlatResponse : BaseResponseObject(){

    var body = mutableListOf<Platform>()


    data class Platform(
            var xmPlatformList: MutableList<MutableMap<String, XmCode>>,
            var xmConfigId: BigDecimal,
            var xmConfigName: String
    ): RebateInfo() {
        override fun getGameName(): String {
            return xmConfigName
        }

        override fun getRebateAmount(): String {
            return "10000"
        }


        override fun getRebateProportion(): String {
            return "1%"
        }

        override fun getBetAmount(): String {
            return "1000000"
        }

    }


}
