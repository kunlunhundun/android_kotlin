package com.ksmobile.app.data.request



/**
 * Created by ward.y on 2018/3/19.
 */
class BindMobileRequest : BaseRequestObject() {

    var messageId:String?=null
    var smsCode:String?=null
    var use = 5

}
