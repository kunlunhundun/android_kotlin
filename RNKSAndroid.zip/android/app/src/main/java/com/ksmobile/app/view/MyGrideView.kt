package com.ksmobile.app.view

import android.content.Context
import android.util.AttributeSet
import android.widget.GridView


/**
 * Created by ward.y on 2018/2/19.
 */
class MyGrideView : GridView {
    constructor(context: Context?) : super(context)
    constructor(context: Context?, attributeSet: AttributeSet? = null) : super(context, attributeSet)
    constructor(context: Context?, attributeSet: AttributeSet? = null, defstyleAttr: Int = 0) : super(context, attributeSet, defstyleAttr)
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE shr 2, MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, expandSpec)
    }
}