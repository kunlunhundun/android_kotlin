package com.ksmobile.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckedTextView
import com.ksmobile.app.R
import java.math.BigDecimal


/**
 * Created by ward.y on 18/7/24.
 */
class RechargeFastSelectionListAdapter(context: Context, data: MutableList<String>) : BaseAdapter() {
    var mContext: Context? = context
    var datas = data
    val views = mutableListOf<MyViewHolder>()
    private var clickCallBack: ItemClickCallBack? = null
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var holder: MyViewHolder
        var v: View
        if (convertView == null) {
            holder = MyViewHolder()
            v = LayoutInflater.from(mContext).inflate(R.layout.item_recharge_fast_selection_view, parent, false)
            holder.ctv_check = v.findViewById(R.id.ctv_check)
            v.tag = holder

        } else {
            v = convertView
            holder = v.tag as MyViewHolder
        }

        if (position==views.size){
            views.add(holder)
        }

        holder.ctv_check.text = formatNumber(datas[position])
        holder.ctv_check.isChecked = false
        holder.ctv_check.setOnClickListener {
            if (clickCallBack != null) {
                clickCallBack?.onItemClick(position, holder.ctv_check)
            }

        }


        return v
    }

    override fun getItem(p0: Int): Any {
        return datas[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return datas.size
    }

    class MyViewHolder {
        lateinit var ctv_check: CheckedTextView
    }

    fun setClickCallBack(clickCallBack: ItemClickCallBack) {
        this.clickCallBack = clickCallBack
    }


    fun selectBigger99() {

        kotlin.run outside@{
            datas.forEachIndexed inside@{ index, s ->

                if (s.contains("万") || BigDecimal(s) > BigDecimal(99)) {
                    if (!views.isEmpty()){
                        views[index].ctv_check.performClick()
                    }

                    return@outside

                }

            }

        }




    }

    interface ItemClickCallBack {
        fun onItemClick(pos: Int, textView: CheckedTextView)
    }

    private fun formatNumber(num: String): String {
        var stringBuilder = StringBuilder()
        if (num.endsWith("0000")) {
            stringBuilder.append(num.replace("0000", ""))
            stringBuilder.append("万")

        } else {
            stringBuilder.append(num)
        }
        return stringBuilder.toString()
    }
}





















