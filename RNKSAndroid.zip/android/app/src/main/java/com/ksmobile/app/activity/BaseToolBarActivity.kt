package com.ksmobile.app.activity

import android.graphics.Color
import android.os.Bundle
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.ksmobile.app.BuildConfig
import com.ksmobile.app.R
import com.ksmobile.app.view.CommonDialog


/**
 * Created by ward.y on 2018/2/21.
 */
abstract class BaseToolBarActivity : BaseActivity(), View.OnLayoutChangeListener {
    private var mToolbarTitle: TextView? = null
    private var mToolbarAction: TextView? = null
    private var mToolbarAction2: TextView? = null
    private var mToolbarIcon: ImageView? = null
    private var mToolbarImageAction: ImageView? = null
    private var mToolbar: Toolbar? = null
    private var isShowBack: Boolean = true
    private var isShowAction: Boolean = false
    private var isShowAction2: Boolean = false
    private var mClickListener: View.OnClickListener? = null
    val MODE_WHITE: Int = 1
    val MODE_BLACK: Int = 2
    val MODE_GREY: Int = 3


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mToolbar = findViewById(R.id.tool_bar)
        mToolbarIcon = findViewById(R.id.toolbar_icon)
        mToolbarImageAction = findViewById(R.id.action_image)
        mToolbarTitle = findViewById(R.id.toolbar_title)
        mToolbarAction = findViewById(R.id.action_area)
        mToolbarAction2 = findViewById(R.id.action_area_2)
        if (mToolbar != null) {
            //将Toolbar显示到界面
            setSupportActionBar(mToolbar)
        }
        if (mToolbarTitle != null) {
            //getBankName()的值是activity的android:lable属性值
            mToolbarTitle?.text = title
            //设置默认的标题不显示
            supportActionBar?.setDisplayShowTitleEnabled(false)
        }
        mToolbarIcon?.setOnClickListener {
            if (mClickListener == null) {
                finish()
            } else {
                mClickListener?.onClick(it)
            }

        }

        mToolbar?.setOnLongClickListener {
            if (BuildConfig.DEBUG) {
                val bundle = Bundle()
                bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_DEBUG)
                val dialog = CommonDialog()
                dialog.arguments = bundle
                dialog.show(supportFragmentManager, "debug")
                true
            }

            false
        }


    }


    protected fun setTile(title: String) {
        if (mToolbar != null) {
            //将Toolbar显示到界面
            mToolbarTitle?.text = title
        }
    }

    protected fun getActionContent(): String? {
        return mToolbarAction?.text.toString()
    }

    protected fun setBackListener(listener: View.OnClickListener) {
        mClickListener = listener
    }

    protected fun setLogo(id: Int) {
        if (mToolbar != null) {
            //将Toolbar显示到界面
            mToolbarIcon?.setImageResource(id)
        }
    }

    protected fun setMode(mode: Int) {
        when (mode) {
            MODE_BLACK -> {
                mToolbarTitle?.setTextColor(Color.BLACK)
                mToolbarAction?.setTextColor(Color.BLACK)
            }
            MODE_WHITE -> {
                mToolbarTitle?.setTextColor(Color.WHITE)
                mToolbarAction?.setTextColor(Color.WHITE)
            }

            MODE_GREY -> {
                mToolbarAction?.setTextColor(Color.parseColor("#666666"))
            }
        }
    }

    protected fun setBackground(id: Int) {
        mToolbar?.setBackgroundResource(id)
    }

    fun setActionText(string: String) {
        mToolbarAction?.text = string
        isShowAction(true)
    }

    fun setActionIcon(id: Int) {
        val drawable = resources.getDrawable(id)
        drawable.setBounds(0, 0, drawable.minimumWidth, drawable.minimumHeight)
        mToolbarAction?.setCompoundDrawables(drawable, null, null, null)
        isShowAction(true)
    }

    protected fun getActionView(): TextView? {
        return mToolbarAction
    }

    fun setAction2Text(string: String) {
        mToolbarAction2?.text = string
        isShowAction2(true)
    }

    fun setAction2Icon(id: Int) {
        val drawable = resources.getDrawable(id)
        drawable.setBounds(0, 0, drawable.minimumWidth, drawable.minimumHeight)
        mToolbarAction2?.setCompoundDrawables(drawable, null, null, null)
        isShowAction2(true)
    }

    protected fun getAction2View(): TextView? {
        return mToolbarAction2
    }

    fun setImageActionIcon(id: Int){
        mToolbarImageAction?.setImageResource(id)
        mToolbarImageAction?.visibility =View.VISIBLE

    }
    protected fun getActionImage(): ImageView? {
        return mToolbarImageAction
    }

    protected fun getToobar(): Toolbar? {
        return mToolbar
    }

    protected fun isShowBack(isShowBack: Boolean): Boolean {
        this.isShowBack = isShowBack
        if (isShowBack) {
            mToolbarIcon?.visibility = View.VISIBLE
        } else {
            mToolbarIcon?.visibility = View.GONE
        }
        return this.isShowBack
    }

    private fun isShowAction(isShowAction: Boolean): Boolean {
        this.isShowAction = isShowAction
        if (isShowAction) {
            mToolbarAction?.visibility = View.VISIBLE
        } else {
            mToolbarAction?.visibility = View.GONE
        }
        return this.isShowAction
    }

    private fun isShowAction2(isShowAction: Boolean): Boolean {
        this.isShowAction2 = isShowAction
        if (isShowAction2) {
            mToolbarAction2?.visibility = View.VISIBLE
        } else {
            mToolbarAction2?.visibility = View.GONE
        }
        return this.isShowAction
    }

  


    override fun onLayoutChange(p0: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {

    }
}