package com.ksmobile.app.data

data class BankCardTypeData(var bankType: String) : SelectorItem {
    override fun getImageLeft(): String? {
        return null
    }

    override fun getTitle(): String {
        return bankType
    }

    override fun hasChild(): Boolean {
        return false
    }

    override fun getChildItems(): List<SelectorItem>? {
        return null
    }
}