package com.ksmobile.app.data.request


/**
 * Created by ward.y on 2018/3/19.
 */
class SendSmsRequest : BaseRequestObject() {
    var mobileNo: String? = null
    var use: String? = null  //1 注册 2登陆 3绑定手机 5.解绑手机号
    var ipAddress:String?=null

}
