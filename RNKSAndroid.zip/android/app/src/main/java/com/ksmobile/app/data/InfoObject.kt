package com.ksmobile.app.data

data class InfoObject (val u2token:String, val token:String )