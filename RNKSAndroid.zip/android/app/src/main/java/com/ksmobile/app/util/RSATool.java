package com.ksmobile.app.util;

import android.os.Build;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;



public class RSATool {

    public static final int KEY_SIZE = 1024;

    private static String algorithm = "RSA";

    public static String encrypt(String data, String publicKey) {
        try {
            X509EncodedKeySpec pubX509 = new X509EncodedKeySpec(Base64.decode(publicKey.getBytes
                    (), Base64.DEFAULT));

            KeyFactory keyf;
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.O_MR1) {
                keyf = KeyFactory.getInstance("RSA", "BC");
            } else {
                keyf = KeyFactory.getInstance("RSA");     //适配Android P及以后版本，否则报错NoSuchAlgorithmException
            }
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, keyf.generatePublic(pubX509));
            byte[] resultBytes = null;
            byte[] srcBytes = data.getBytes();
            int segmentSize = KEY_SIZE / 8 - 11;
            if (segmentSize > 0) {
                resultBytes = cipherDoFinal(cipher, srcBytes, segmentSize); // 分段加密
            } else {
                resultBytes = cipher.doFinal(srcBytes);
            }
            return Base64.encodeToString(resultBytes, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String data, String privateKey) {
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decode(privateKey
                    .getBytes(), Base64.DEFAULT));
            KeyFactory keyf = KeyFactory.getInstance(algorithm, "BC");
            PrivateKey privKey = keyf.generatePrivate(priPKCS8);
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, privKey);
            int segmentSize = KEY_SIZE / 8;
            byte[] srcBytes = Base64.decode(data, Base64.DEFAULT);
            byte[] decBytes = null;
            if (segmentSize > 0) {
                decBytes = cipherDoFinal(cipher, srcBytes, segmentSize);
            } else {
                decBytes = cipher.doFinal(srcBytes);
            }
            return new String(decBytes, "utf-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static byte[] cipherDoFinal(Cipher cipher, byte[] srcBytes, int segmentSize) throws
            Exception {
        ByteArrayOutputStream out = null;
        try {
            out = new ByteArrayOutputStream();
            int len = srcBytes.length;
            int offSet = 0;
            byte[] x;
            int i = 0;
            while (len - offSet > 0) {
                if (len - offSet > segmentSize) {
                    x = cipher.doFinal(srcBytes, offSet, segmentSize);
                } else {
                    x = cipher.doFinal(srcBytes, offSet, len - offSet);
                }
                out.write(x, 0, x.length);
                i++;
                offSet = i * segmentSize;
            }
            return out.toByteArray();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (null != out) {
                out.close();
            }
        }
        return null;
    }


    public static String encode(String x) {
        String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSu2AZPdT2Fqpqxctx3EbnRuuYdBxFZDYG7MASIgw/DFl3P9FAp7S9WaQjdM1NmgBDgvfUWx1xj72LNz4EP4Euh9EESKceNCeoE4M8ZP4ENUQX0nDMbpmIG3/JCI8B5Iv2FKj2q0gGbE0WsLdrYDzFXTYbZKRJSbMMjHT3HtKD/wIDAQAB";

        return encrypt(x, publicKey);

    }
}