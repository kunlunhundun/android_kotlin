package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ksmobile.app.R
import com.ksmobile.app.data.request.ChangeUrlRequest
import com.ksmobile.app.data.request.WelcomeRequest
import com.ksmobile.app.data.response.ChangeUrlResponse
import com.ksmobile.app.data.response.WelcomeResponseObject
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.*
import com.ksmobile.app.util.*
import com.ksmobile.app.view.hybride.BrowserActivity
import kotlinx.android.synthetic.main.activity_splashpage.*

class SplashActivity : BaseActivity() {
    lateinit var timer: CountDownTimer
    private var alternate_address: MutableList<String>? = null
    private var jump = false
    var count = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = intent
        if (!isTaskRoot
                && intent != null
                && intent.hasCategory(Intent.CATEGORY_LAUNCHER)
                && intent.action != null
                && intent.action == Intent.ACTION_MAIN) {
            finish()
            return
        }
    }

    override fun initView() {
        AppInitManager.getMainReactRootView().unmountReactApplication()
        AppInitManager.getMainReactRootView().startReactApplication(AppInitManager.getReactInstanceManager(), "A06HybridRNApp")
        initTimer(2).start()
//        showAd()
        getAdContent()
        AppInitManager.createUUID(application)


    }

    override fun initListener() {
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_splashpage
    }

    private fun initTimer(time: Long): CountDownTimer {
        timer = object : CountDownTimer(time * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tv_jump.text = String.format(getString(R.string.splash_activity_wait_tip), (millisUntilFinished / 1000))
                tv_jump.setOnClickListener {
                    timer.cancel()
                    goNextPage()
                }
            }

            override fun onFinish() {
                goNextPage()
            }

        }

        return timer
    }


    private fun getAdContent() {
        ApiClient.instance.service.welcome(WelcomeRequest())
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<WelcomeResponseObject>(this,false) {
                    override fun businessFail(data: WelcomeResponseObject) {

                    }

                    override fun businessSuccess(data: WelcomeResponseObject) {

                        DataBaseHelper.updateAddUrl(data.body.addrServiceUrl)
                        if (!TextUtils.isEmpty(data.body.link)){
                            mAcach.put("adLink", data.body.link)
                        }


                        if (!TextUtils.isEmpty(data.body.image)) {
//                            GlideUtils.load(this@SplashActivity,data.body.image).into(iv_ad)

                            mAcach.put("newAdUrl", data.body.image, 10 * ACache.TIME_DAY)
                            if (mAcach.getAsBitmap(data.body.image) == null) {
                                downloadBitmap(data.body.image)
                            }

                        } else {
                            mAcach.put("newAdUrl", "")
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        when (apiErrorModel.status) {

                            ApiErrorType.NETWORK_NOT_CONNECT.code -> {
                                ToastUtils.show(apiErrorModel.message)
                            }
                            else -> {
//                                Log.d("更换url", "" + count)
                                if (count < 3) {
                                    count++
                                    getAdContent()
                                } else {
                                    if (null == alternate_address) {
                                        getNewUrl()
                                    } else {
                                        if (!alternate_address!!.isEmpty()) {
                                            DataBaseHelper.updateUrl(alternate_address!![0])
                                            alternate_address!!.removeAt(0)
                                            ApiClient.instance.init()
                                            getAdContent()
                                        }

                                    }

                                }
                            }
                        }
                    }
                })
    }

    private fun getNewUrl() {
        val urlData = DataBaseHelper.getUrl()
        val request = ChangeUrlRequest()
        request.url = urlData?.url!!
        ApiClient.instance.addurlService.changeUrl(request)
                .compose(NetworkScheduler.compose())
//                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<ChangeUrlResponse>(this, false) {
                    override fun businessFail(data: ChangeUrlResponse) {

                    }

                    override fun businessSuccess(data: ChangeUrlResponse) {


                        if (null != data.body && !data.body.isEmpty()) {
                            alternate_address = data.body
                            DataBaseHelper.updateUrl(data.body!![0])
                            alternate_address!!.removeAt(0)
                            ApiClient.instance.init()
                            getAdContent()

                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {


                    }
                })
    }



    private fun showAd() {
        if (!TextUtils.isEmpty(mAcach.getAsString("newAdUrl"))) {
            iv_ad.setImageBitmap(mAcach.getAsBitmap(mAcach.getAsString("newAdUrl")))
            tv_jump.visibility = View.VISIBLE
            iv_ad.setOnClickListener {
                if (!TextUtils.isEmpty(mAcach.getAsString("adLink"))) {
                    val intent = Intent(this@SplashActivity, BrowserActivity::class.java)
                    goToPage(intent)
                    timer.cancel()
                    jump = true
                }
            }
        }
    }

    private fun goNextPage() {
        if (TextUtils.isEmpty(AppInitManager.getAcache().getAsString("showGuid"))){
            goToPage(Intent(this, IntroActivity::class.java))
            AppInitManager.getAcache().put("showGuid","1")
        }else{
            goToPage(Intent(this, MainActivity::class.java))
        }

        finish()

    }

    fun downloadBitmap(url: String?) {

        Thread(Runnable {
            try {
                if (!TextUtils.isEmpty(url)) {
                    val myBitmap = GlideUtils
                            .load(this@SplashActivity,url!!)
                            .asBitmap()
                            .centerCrop()
                            .into(750, 1334)
                            .get()
                    mAcach.put(url, myBitmap, 10 * ACache.TIME_DAY)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }).start()

    }

    override fun onResume() {
        super.onResume()
        AppInitManager.getThreeStatisticsObject().time2 = System.currentTimeMillis()
        ThreeStatisticsManager.onInitEvent(AppInitManager.getThreeStatisticsObject().time3)
        AppInitManager.getThreeStatisticsObject().reset()
        if (jump) {
            goNextPage()
        }
    }


}
