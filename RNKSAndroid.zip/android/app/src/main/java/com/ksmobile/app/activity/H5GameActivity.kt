package com.ksmobile.app.activity

import android.annotation.TargetApi
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.*
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.data.request.InGameRequest
import com.ksmobile.app.data.response.InGameResponse
import com.ksmobile.app.data.response.OutGameResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.LogUtils
import com.ksmobile.app.util.RefreshAnimationUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog
import com.ksmobile.app.view.hybride.GameWebViewClient
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import kotlinx.android.synthetic.main.activity_egame_h5.*
import java.io.UnsupportedEncodingException
import java.net.URLDecoder
import java.net.URLEncoder

open class H5GameActivity : BaseToolBarActivity() {


    var mRequest: InGameRequest? = null

    companion object {
        const val PARAM_GAME_REQUEST = "param_game_request"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val str = intent.getStringExtra(H5GameActivity.PARAM_GAME_REQUEST)
        if (!TextUtils.isEmpty(str)) {
            mRequest = Gson().fromJson(str, InGameRequest::class.java)
        }

        webview.webViewClient = object : GameWebViewClient(this) {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                hiddenLoading()
                RefreshAnimationUtils.stopRefreshAnim()
            }
        }


        gameWebView.webViewClient = object : GameWebViewClient(this) {

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                hiddenLoading()

                RefreshAnimationUtils.stopRefreshAnim()

            }

            @TargetApi(21)
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return shouldInterceptRequest(view, request.url.toString())
            }
        }
        gameWebView.webChromeClient = object : WebChromeClient() {

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                NotifyDialog.show(this@H5GameActivity, message!!)
                result?.cancel()
                return true
            }

            override fun onReceivedTitle(view: WebView?, title: String) {
                super.onReceivedTitle(view, title)
                when (title) {
                    "LIVV88" -> {
                        setTile("沙巴体育")
                    }
                    "体育" -> {
                        setTile("BTI体育")
                    }
                    "AS电玩城-Asia Star" -> {
                        setTile("AS电玩城")
                    }
                    "AGIN Games" -> {
                        setTile("AG国际厅")
                    }
                    else -> {
                        setTile(title)
                    }
                }


            }
        }


    }


    override fun getLayoutId(): Int {
        return R.layout.activity_egame_h5
    }

    override fun initView() {
        loading_view.show("正在为您跳转游戏界面，请稍后…")
        setActionIcon(R.mipmap.icon_customer_service)
        setImageActionIcon(R.mipmap.reload)
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        getActionImage()?.setOnClickListener {
            RefreshAnimationUtils.startRefreshAnim(getActionImage())
            loading_view.show("正在为您跳转游戏界面，请稍后…")
            inGame()
        }

        inGame()
    }


    override fun initListener() {
        setBackListener(View.OnClickListener {
            showConfirm()
        })
    }


    override fun onDestroy() {
        super.onDestroy()
        if (null == mRequest) {
            return
        }

        ApiClient.instance.service.outGame(mRequest!!)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<OutGameResponse>(this, false) {

                    override fun businessFail(data: OutGameResponse) {

                    }

                    override fun businessSuccess(data: OutGameResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }
                })

    }


    open fun inGame() {

        ApiClient.instance.service.inGame(mRequest!!)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<InGameResponse>(this, false) {
                    override fun businessFail(data: InGameResponse) {

                        when (data.head.errCode) {
                            "GW_800605","GW_800601" -> {
                                ConfirmDialog.show(this@H5GameActivity,false)
                                ConfirmDialog.setContent("网络不稳定，请刷新或者选择其他游戏")
                                ConfirmDialog.setTitile("")
                                ConfirmDialog.setCancelText("其他游戏")
                                ConfirmDialog.setSureText("刷新")
                                ConfirmDialog.setSureListener(View.OnClickListener {
                                    getActionImage()?.performClick()
                                    ConfirmDialog.dismiss()
                                })

                                ConfirmDialog.setCancelListener(View.OnClickListener {
                                    finish()
                                    ConfirmDialog.dismiss()

                                })
                            }

                            else -> {
                                NotifyDialog.show(this@H5GameActivity, data.head.errMsg)
                                NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                                    override fun onHidden() {
                                        finish()
                                    }

                                })
                            }
                        }



                    }

                    override fun businessSuccess(data: InGameResponse) {
                        //加 webApp=true可返回重定向网址

                        if (data.body?.postMap?.gameType == "PT") {
                            webview.settings.defaultTextEncodingName = "UTF-8"
                            val builder1 = StringBuilder()
                            try {//拼接post提交参数
                                builder1.append("?gameID=").append(URLEncoder.encode(data.body?.postMap?.gameID, "UTF-8")).append("&")
                                        .append("gameType=").append(URLEncoder.encode(data.body?.postMap?.gameType, "UTF-8")).append("&")
                                        .append("password=").append(URLEncoder.encode(data.body?.postMap?.password, "UTF-8")).append("&")
                                        .append("username=").append(URLEncoder.encode(data.body?.postMap?.username, "UTF-8"))

                            } catch (e: UnsupportedEncodingException) {
                                e.printStackTrace()
                            }

                            val postData = builder1.toString()
                            webview.visibility = View.VISIBLE
                            webview.loadUrl("${data.body?.url}$postData")

                        } else {

                            if (mRequest?.gameCode == "A06067") {
                                Handler().postDelayed({
                                    gameWebView.visibility = View.VISIBLE
                                    gameWebView.loadUrl(URLDecoder.decode("${data.body?.url}"))
                                }, 3000)
                            } else {
                                gameWebView.visibility = View.VISIBLE
                                gameWebView.loadUrl(URLDecoder.decode("${data.body?.url}"))
                            }


                        }


                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@H5GameActivity, apiErrorModel.message)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }
                })
    }


    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        if (this.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            tool_bar.visibility = View.GONE

        } else if (this.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            tool_bar.visibility = View.VISIBLE
        }
    }

    fun hiddenLoading() {
        Handler().postDelayed({ loading_view.hidden() }, 5000)

    }

    private fun showConfirm() {
        ConfirmDialog.show(this)
        ConfirmDialog.setTitile("确定要退出游戏么？")
        ConfirmDialog.setCancelText("取消")
        ConfirmDialog.setSureText("退出游戏")
        ConfirmDialog.setSureListener(View.OnClickListener {
            ConfirmDialog.dismiss()
            finish()

        })

    }

    override fun onBackPressed() {
        showConfirm()
    }

}
