package com.ksmobile.app.data.response

import com.ksmobile.app.data.AmountType
import com.ksmobile.app.data.BankInfo


/**
 * Created by ward.y on 2018/3/19.
 */
class QureyPayResponse : BaseResponseObject() {

    var body: Body? = null


    data class Body(
            var maxAmount: Double,
            var minAmount: Double,
            var amountType:AmountType,
            var bankList: MutableList<BankInfo>
    )



}
