package com.ksmobile.app.data

import android.text.TextUtils
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/2/2.
 */

class OrderObject {

    var amount: Float = 0f
    var betAmount: String = ""
    var flag: Int = 0 //0:等待处理; 1:处理中; 2:成功; 9:审核; -1:前台取消; -2:后台取消 -3:拒绝; 97:等待支付; 98:取消; 99:超时
    var createDate: String = ""
    var title: String = ""
        get() {
            if (!TextUtils.isEmpty(mapTitle(transCode))) {
                field = mapTitle(transCode)
            }
            return field
        }
    var flagDesc: String = ""
        get() {
            if (!TextUtils.isEmpty(mapFlagDes(flag))) {
                field = mapFlagDes(flag)
            }

            return field
        }
    var requestId: String = ""
    var loginName: String = ""
    var itemIcon: String = ""
    var accountNo: String = ""
    var bankName: String = ""
    var type: Int = 1
    var remindFlag: Int = 0
    var beginDate: String = ""
    var endDate: String = ""
    var typeIntegral: String = ""
    var platformName: String = ""
    var platformId: String = ""
    var integral: String = ""
    var bettingAmount: String = ""
    var integralCash: String = ""
    var transCode: Int = 0
    var rate: BigDecimal = BigDecimal(0)


    private fun mapTitle(src: Int): String {

        return when (src) {
            1 -> "人工存款"
            3 -> "点卡支付"
            2 -> "网银在线存款"
            4 -> "微信扫码"
            5 -> "支付宝扫码"
            6 -> "银行卡转账"
            7 -> "QQ扫码"
            8 -> "微信支付"
            9 -> "支付宝支付"
            11 -> "QQ钱包支付"
            15 -> "银联扫码"
            16 -> "京东扫码"
            17 -> "京东支付"
            18 -> "银联在线存款"
            19 -> "银联在线存款"
            20 -> "比特币支付"
            22 -> "微信转账"
            26 -> "支付宝转账"
            else -> ""
        }


    }


    private fun mapFlagDes(flag: Int): String {

        return when (flag) {
            1 -> {
                if (TextUtils.isEmpty(bankName)) {
                    "审核中"
                } else {
                    "支付中"
                }
            }
            0, 9, 97 -> "审核中"
            2 -> {
                if (!TextUtils.isEmpty(bankName) || transCode != 0) {
                    "成功"
                } else {
                    "已派发"
                }
            }

            else -> "未通过"
        }


    }
}
