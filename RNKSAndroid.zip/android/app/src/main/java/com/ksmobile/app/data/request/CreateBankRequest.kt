package com.ksmobile.app.data.request


class CreateBankRequest : BaseRequestObject() {

    var accountName:String?=null
    var accountNo:String?=null
    var accountType:String?=null
    var bankBranchName:String?=null
    var bankName:String?=null
    var city:String?=null
    var province:String?=null

}
