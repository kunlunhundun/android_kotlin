package com.ksmobile.app.data

data class AmountType(var fix:Int,var amounts: MutableList<String>)