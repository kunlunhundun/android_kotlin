package com.ksmobile.app.activity

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.LoadingDialog
import com.ksmobile.app.util.ACache
import com.ksmobile.app.util.AndroidBug5497Workaround
import com.ksmobile.app.view.NotifyDialog


/**
 * Created by ward.y on 2018/2/5.
 */

abstract class BaseActivity : RxAppCompatActivity() {
    private val isAddActivityList = "isAddActivityList"
    private var mActivity: Activity? = null
    open lateinit var mAcach: ACache
    private var onstop = false
    //屏幕高度
    var screenHeight = 0
    //软件盘弹起后所占高度阀值
    var keyHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 21) {
            val decorView = window.decorView
            val option = (View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            decorView.systemUiVisibility = option
            window.statusBarColor = Color.TRANSPARENT
        }
        if (getLayoutId() != 0) {
            setContentView(getLayoutId())
        }
        if (this !is H5GameActivity){
            AndroidBug5497Workaround.assistActivity(this)
        }


        mActivity = this
        mAcach = AppInitManager.getAcache()
        if (intent.getBooleanExtra(isAddActivityList, false)) {
            AppInitManager.getActivityListManager().addActivity(mActivity)

        }
        //获取屏幕高度
        screenHeight = windowManager.defaultDisplay.height
        //阀值设置为屏幕高度的1/3
        keyHeight = screenHeight / 3
    }

    override fun onStart() {
        super.onStart()
        if (!onstop) {
            initView()
            initListener()
        } else {
            onstop = false
        }

    }


    override fun onResume() {
        super.onResume()
        AppInitManager.getActivityListManager().currentActivity = mActivity
    }

    override fun onStop() {
        super.onStop()
        onstop = true
        if (AppInitManager.getActivityListManager().currentActivity == mActivity) {
            AppInitManager.getActivityListManager().currentActivity = null

        }

    }

    override fun onDestroy() {
        super.onDestroy()
        AppInitManager.getActivityListManager().removeActivity(mActivity)
        mActivity = null
        LoadingDialog.cancel()
        NotifyDialog.cancel()
//        ConfirmDialog.cancel()
    }


    fun goToPage(intent: Intent, isAdd: Boolean) {

        intent.putExtra(isAddActivityList, isAdd)
        startActivity(intent)
    }

    fun goToPageForResult(intent: Intent, isAdd: Boolean, requstCode: Int) {
        intent.putExtra(isAddActivityList, isAdd)
        startActivityForResult(intent, requstCode)
    }


    fun goToPage(intent: Intent) {

        goToPage(intent, true)

    }

    abstract fun initView()
    abstract fun initListener()

    /**
     * this activity layout res
     * 设置layout布局,在子类重写该方法.
     * @return res layout xml referenceId
     */
    protected abstract fun getLayoutId(): Int

}