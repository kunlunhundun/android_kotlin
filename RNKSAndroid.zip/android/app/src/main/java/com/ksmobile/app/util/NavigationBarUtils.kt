package com.ksmobile.app.util

import android.app.Activity
import android.content.Context
import android.graphics.Point
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.ViewConfiguration
import android.os.Build





object NavigationBarUtils {

    /**
     * 获取是否有虚拟按键
     * 通过判断是否有物理返回键反向判断是否有虚拟按键
     * @param context
     * @return
     */
    private fun checkDeviceHasNavigationBar(context: Context): Boolean {

        val hasMenuKey = ViewConfiguration.get(context)
                .hasPermanentMenuKey()
        val hasBackKey = KeyCharacterMap
                .deviceHasKey(KeyEvent.KEYCODE_BACK)
        return !hasMenuKey and !hasBackKey
    }

    /**
     *  获取虚拟按键的高度
     */

    fun getNavigationBarHeight(context: Context): Int {
        var result = 0
            val res = context.resources
            val resourceId = res.getIdentifier("navigation_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = res.getDimensionPixelSize(resourceId)
            }
        return result
    }

    fun isNavigationBarShow(context: Activity): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            val display = context.windowManager.defaultDisplay
            val size = Point()
            val realSize = Point()
            display.getSize(size)
            display.getRealSize(realSize)
            realSize.y != size.y
        } else {
            checkDeviceHasNavigationBar(context)
        }
    }
}