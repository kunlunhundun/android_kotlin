package com.ksmobile.app.data.request



class OrderRecordRequest : BaseRequestObject() {

    var lastDays:Int?  = null
    var pageNo:Int?  = null
    var pageSize:Int?  = null



}