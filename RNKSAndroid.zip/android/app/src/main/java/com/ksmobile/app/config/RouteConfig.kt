package com.ksmobile.app.config

object RouteConfig {
    const val PROFILE = "Profile"
    const val WITHDRAW = "Withdraw"
    const val REBATE = "Rebate"
    const val RECHARGE = "Recharge"
    const val RECHARGEACTIVITY = "RechargeActivity"
    const val MAIN = "Main"
    const val DOWNLOAD = "Download"
    const val PARTNER = "partner"
    const val SUBSCRIBE = "Subscribe"
    const val CHANGEPASSWORD = "ChangePassword"
    const val LOGIN = "Login"
    const val MESSAGE = "Message"
    const val PROMO = "Promo"
    const val BINDCARD = "BindCard"
    const val BINDPHONE = "BindPhone"
    const val REALNAMEVERIFY = "RealNameVerify"
    const val ONLINECUSTOMER = "OnlineCustomer"
    const val PLAYGAME = "playGame"
}