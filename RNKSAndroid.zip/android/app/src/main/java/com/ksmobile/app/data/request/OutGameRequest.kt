package com.ksmobile.app.data.request



class OutGameRequest : BaseRequestObject() {

    var gameCode: String? = null
    var gameType: String? = null
    var gameId: String? = null
    var gameName: String? = null

}