
package com.ksmobile.app.util

data class LoadErrorModel(var status: Int, var message: String,var icon:Int)
