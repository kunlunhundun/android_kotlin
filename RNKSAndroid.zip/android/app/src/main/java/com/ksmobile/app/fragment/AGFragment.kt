package com.ksmobile.app.fragment

import android.annotation.TargetApi
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.net.http.SslError
import android.os.Handler
import android.text.TextUtils
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ivi.library.statistics.models.T3sAppAgqjBean
import com.ksmobile.app.R
import com.ksmobile.app.activity.MainActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.ProjectUtils
import com.ksmobile.app.data.request.InGameRequest
import com.ksmobile.app.data.request.ToGameRequest
import com.ksmobile.app.data.response.InGameResponse
import com.ksmobile.app.data.response.ToGameResponse
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.AudioMngHelper
import com.ksmobile.app.util.RefreshAnimationUtils
import com.ksmobile.app.view.ConfirmDialog
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import kotlinx.android.synthetic.main.fragment_ag.*
import java.net.URLDecoder

class AGFragment : BaseFragment() {


    var mCurrentVolume: Int? = 0
    var mAudioHelper: AudioMngHelper? = null
    var mShow = false
    var mGameOk = false
    var loginName: String? = null

    override fun getContentViewId(): Int {
        return R.layout.fragment_ag
    }


    override fun initListener() {
        btn_refresh.setOnClickListener {
            ll_refresh.visibility = View.GONE
            inGame()
        }

        (activity as MainActivity).setActionBarShowListner(object : MainActivity.IActionBarIsShowCallBack {
            override fun onReload(view: View?) {
                if (loginName != ConfigUtils.loginName || mShow) {
                    inGame()
                }

            }

            override fun onShow(show: Boolean) {
                mShow = show
                if (show) {
                    if (!mGameOk){
                        initAg()
                    }else{
                        intoAg()
                    }

                    ag_web.visibility = View.VISIBLE
                    ag_web.onResume()
                    if (!TextUtils.isEmpty(ConfigUtils.loginName)) {
                        transferToGame()
                    }
                    if (ll_refresh.visibility==View.VISIBLE){
                        ag_web.reload()
                        ll_refresh.visibility = View.GONE
                    }

                } else {
                    ag_web.onPause()

                }
            }
        })
    }

    override fun initData() {
        inGame()
    }

    override fun initView() {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)
        ag_web.webViewClient = object : WebViewClient() {

            override fun onPageStarted(p0: WebView?, p1: String?, p2: Bitmap?) {
                super.onPageStarted(p0, p1, p2)
            }

            override fun onPageFinished(p0: WebView?, p1: String?) {
                super.onPageFinished(p0, p1)
                if (null != ll_refresh) {
                    ll_refresh.visibility = View.GONE
                }

                RefreshAnimationUtils.stopRefreshAnim()

            }

            override fun onReceivedSslError(p0: WebView?, handler: SslErrorHandler?, p2: SslError?) {
                handler?.proceed()
            }

            @TargetApi(21)
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {

                return shouldInterceptRequest(view, request.url.toString())
            }

            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, url: String?): Boolean {
                if (onShouldOverrideUrlLoading(view, url)) {
                    return true
                }
                return super.shouldOverrideUrlLoading(view, url)
            }


        }


    }

    private fun inGame() {
        initAg()
        mAudioHelper = AudioMngHelper(context)
        mCurrentVolume = mAudioHelper?.get100CurrentVolume()
        mAudioHelper?.setVoice100(0)
        mGameOk = false
        loginName = ConfigUtils.loginName
        val request = InGameRequest()
        request.gameType = "BAC"
        request.gameCode = ProjectUtils.ABC_GAME_CODE
        ApiClient.instance.service.inGame(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<InGameResponse>(activity!!, false) {
                    override fun businessFail(data: InGameResponse) {
                        when(data.head.errCode){
                            "GW_800605","GW_800601" ->{

                                if (mShow){
                                    ConfirmDialog.show(activity,false)
                                    ConfirmDialog.setContent("网络不稳定，请刷新或者选择其他游戏")
                                    ConfirmDialog.setTitile("")
                                    ConfirmDialog.setCancelText("其他游戏")
                                    ConfirmDialog.setSureText("刷新")
                                    ConfirmDialog.setSureListener(View.OnClickListener {
                                        btn_refresh.performClick()
                                        ConfirmDialog.dismiss()
                                    })

                                    ConfirmDialog.setCancelListener(View.OnClickListener {
                                        (activity as MainActivity).quiteAg()
                                        ConfirmDialog.dismiss()

                                    })
                                }else{
                                    if (!ConfigUtils.DOMAIN_NAME.contains("pt-gateway")){
                                        Handler().postDelayed({
                                            inGame()
                                        },5000)
                                    }
                                }



                            }
                            else ->{
                                ll_refresh?.visibility = View.VISIBLE
                                ag_web.reload()
                            }
                        }


                    }

                    override fun businessSuccess(data: InGameResponse) {
//                        ag_web.visibility = View.VISIBLE
                        //加webApp=true可返回重定向网址
                        ag_web.loadUrl(URLDecoder.decode("${data.body?.url}&webApp=true"))
                        setViewStatus()

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ll_refresh?.visibility = View.VISIBLE
                        ag_web.reload()
                    }
                })
    }


    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)



        if (this.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (!mShow) {
                rl_con.visibility = View.GONE
                return
            }
//            activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
            // 加入横屏要处理的代码
            val layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            ag_web.layoutParams = layoutParams
            if (isAttachedContext()) {
                (activity as MainActivity).showActionBar(false)

            }


        } else if (this.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (!mShow) {
                rl_con.visibility = View.VISIBLE
                return
            }
            // 加入竖屏要处理的代码
            if (isAttachedContext()) {
                (activity as MainActivity).showActionBar(true)
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            }
            setViewStatus()
        }
    }


    fun onShouldOverrideUrlLoading(view: WebView, url: String?): Boolean {
        if (TextUtils.isEmpty(url)) {
            return false
        }
        val uri = Uri.parse(url)

        if (!TextUtils.isEmpty(url)) {
            when (url) {
                //说明进入AGQJ大厅了
                "https://localhost/portrait.html" -> {
                    mGameOk = true
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    if (null != rl_con) {
                        rl_con.setBackgroundColor(Color.parseColor("#55392c"))
                    }

                    if (!mShow) {
                        if (null != ag_web) {
                            ag_web.onPause()
                        }

                    }

                    return true
                }
                //说明进桌了
                "https://localhost/landscape.html" -> {
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    return true
                }
                //说明进桌了
                "https://localhost/sensor.html" -> {
                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    return true
                }
                //网络掉线
                "https://localhost/disconnect.html" -> {
                    if (mGameOk &&null!=activity) {
                        mShow = false
                        (activity as MainActivity).quiteAg()
                        ag_web.reload()
                    } else {
                        ll_refresh?.visibility = View.VISIBLE
                        ag_web.reload()
                    }

                    mGameOk = false
                    return true
                }


            }
            //点击回退键
            if (DataBaseHelper.getUrl()?.domain?.equals(uri.host) == true) {
                ag_web.reload()
                activity?.finish()
                return true
            }
        }
        return false
    }


    private fun setViewStatus() {
        val layoutParams = ag_web.layoutParams
        layoutParams.width = resources.displayMetrics.widthPixels
        layoutParams.height = (resources.displayMetrics.widthPixels * 1.516).toInt()
        ag_web.layoutParams = layoutParams
    }


    private fun transferToGame() {
        val request = ToGameRequest()
        request.gameCode = ProjectUtils.ABC_GAME_CODE
        ApiClient.instance.service.transferToGame(request)
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<ToGameResponse>(activity!!, false) {
                    override fun businessFail(data: ToGameResponse) {

                    }

                    override fun businessSuccess(data: ToGameResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }
                })
    }

    override fun onResume() {
        super.onResume()
        if (ag_web != null) {
            if (mShow || !mGameOk) {
                ag_web.onResume()
            }
        }

    }

    override fun onStop() {
        super.onStop()

        if (ag_web != null) {
            ag_web.onPause()
        }

    }

    override fun onPause() {
        super.onPause()
        if (ag_web != null) {
            ag_web.onPause()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        if (ag_web != null) {
            ag_web.destroy()
        }


    }


    private fun initAg(){
        val bean = T3sAppAgqjBean()
        bean.time = "${System.currentTimeMillis()}"
        bean.uuid = AppInitManager.getWebUUID()
        ThreeStatisticsManager.onAgqjEvent(bean)
        AppInitManager.getThreeStatisticsObject().reset()
    }

    private fun intoAg(){
        AppInitManager.getThreeStatisticsObject().time2 = System.currentTimeMillis()
        val bean = T3sAppAgqjBean()
        bean.time = "${AppInitManager.getThreeStatisticsObject().time1}"
        bean.rsptime = AppInitManager.getThreeStatisticsObject().time3
        bean.isPreload = true
        bean.uuid = AppInitManager.getWebUUID()
        ThreeStatisticsManager.onAgqjEvent(bean)
        AppInitManager.getThreeStatisticsObject().reset()
    }


}