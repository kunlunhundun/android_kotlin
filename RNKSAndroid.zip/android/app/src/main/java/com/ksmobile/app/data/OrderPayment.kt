package com.ksmobile.app.data

import com.ksmobile.app.data.response.QueryBanksResponse

data class OrderPayment (val money:String,
                          val title:String,
                          val depositor:String,
                          val depositorId:String,
                          val PayType:Int,
                          val PayWay:Int,
                          val bankInfo: BankInfo?,
                          val handBankInfo: QueryBanksResponse.Bean?
                          )