package com.ksmobile.app.adapter

import android.content.Context
import android.support.constraint.ConstraintLayout
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.ksmobile.app.R

import com.ksmobile.app.data.SelectorItem
import com.ksmobile.app.util.GlideUtils

/**
 * Created by jianghejie on 15/11/26.
 */
class SelectorViewAdapter(context: Context, private var datas: List<SelectorItem>) : RecyclerView.Adapter<SelectorViewAdapter.ViewHolder>() {

    private var clickCallBack: ItemClickCallBack? = null
    private var mContext = context


    fun setClickCallBack(clickCallBack: ItemClickCallBack) {
        this.clickCallBack = clickCallBack
    }

    interface ItemClickCallBack {
        fun onItemClick(pos: Int)
    }


    //创建新View，被LayoutManager所调用
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_custom_selector, viewGroup, false)
        return ViewHolder(view)
    }

    //将数据与界面进行绑定的操作
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        viewHolder.tvLabel.text = datas[position].getTitle()
        if (datas[position].hasChild()) {
            viewHolder.image_right.setImageResource(R.mipmap.arrow_right)
        }

        viewHolder.clContent.setOnClickListener {
            if (null != clickCallBack) {
                clickCallBack?.onItemClick(position)
            }
        }

        if (!TextUtils.isEmpty(datas[position].getImageLeft())){
            GlideUtils.load(mContext,datas[position].getImageLeft()).into(viewHolder.image_left)
            viewHolder.image_left.visibility = View.VISIBLE

        }

    }

    //获取数据的数量
    override fun getItemCount(): Int {
        return datas.size
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvLabel: TextView = view.findViewById(R.id.tv_label)
        var image_right: ImageView = view.findViewById(R.id.img_right)
        var image_left: ImageView = view.findViewById(R.id.img_left)
        var clContent: ConstraintLayout = view.findViewById(R.id.cl_content)

    }
}





















