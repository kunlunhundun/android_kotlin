package com.ksmobile.app.fragment.payment

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderDetailActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.OrderPayment
import com.ksmobile.app.data.request.CreatPayOrderRequest
import com.ksmobile.app.data.response.CreatPayOrderResponse
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.fragment.BaseFragment
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.GlideUtils
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.CommonDialog
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.fragment_order_pay_wepay.*

class WePaymentFragment : BaseFragment() {

    var datas: OrderPayment? = null
    override fun getContentViewId(): Int {
        return R.layout.fragment_order_pay_wepay
    }

    override fun initView() {
//        timer.start()
//        showNewUser()
    }

    override fun initListener() {
        GlideUtils.load(context,datas?.bankInfo?.bankIcon!!)
                .placeholder(R.mipmap.insted_imag_smarll)
                .error(R.mipmap.insted_imag_smarll)
                .into(icon_bank)
        tv_bank_name.text = datas?.bankInfo?.bankName
        tv_show_tutorial.paint.flags= Paint.UNDERLINE_TEXT_FLAG
        copy_name.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = user_card.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }
        copy_bank_number.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = number_card.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }

        copy_bank_address.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = tv_bank_address.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }


        pay_intent.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("weixin://"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
                NotifyDialog.show(activity,"您还未安装微信")
            }
        }

        tv_go_online_customer.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        tv_show_tutorial.setOnClickListener {
            showDialog()
        }
    }

    override fun initData() {
        val bundle = arguments
        if (bundle != null) {
            datas = Gson().fromJson(bundle.getString("datas"), OrderPayment::class.java)
        }

        tv_pay_person.text = datas?.depositor
        var request = CreatPayOrderRequest()
        request.amount = Integer.parseInt(datas?.money)
        request.bankCode = datas?.bankInfo?.bankCode
        if (TextUtils.isEmpty(datas?.depositorId)){
            request.depositor = tv_pay_person.text.toString()
        }else{
            request.depositor = datas?.depositorId
            request.depositorType = 1
        }
        request(request, datas?.PayType!!)

    }


//    private val timer = object : CountDownTimer(10 * 60 * 1000, 1000) {
//
//        override fun onTick(millisUntilFinished: Long) {
//            tv_count_down_time.text = (Utils.secToTime(millisUntilFinished / 1000))
//
//        }
//
//        override fun onFinish() {
//
//        }
//    }

//    private fun showNewUser() {
//        if (DataBaseHelper.getWashCode(ConfigUtils.loginName!!) == null ||
//                DataBaseHelper.getWashCode(ConfigUtils.loginName!!)?.loginName != ConfigUtils.loginName!!) {
//            DataBaseHelper.updataWepayOneTime()
//            showDialog()
//        } else if (DataBaseHelper.getWashCode(ConfigUtils.loginName!!)?.wepayFirstTime == 0) {
//            DataBaseHelper.updataWepayOneTime()
//            showDialog()
//        }else if (DataBaseHelper.getWashCode(ConfigUtils.loginName!!)?.wepayFirstTime == 1) {
//            DataBaseHelper.updateWepayTwoTime()
//            showDialog()
//        }
//    }


    private fun showDialog() {
        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_WECHAT)
        val dialog = CommonDialog()
        dialog.arguments = bundle
        dialog.show(activity?.supportFragmentManager, "dialog")
    }

    private fun request(request: CreatPayOrderRequest, payType: Int) {
        request.payType = payType
        ApiClient.instance.service.creatPayOrder(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatPayOrderResponse>(activity!!, true) {
                    override fun businessFail(data: CreatPayOrderResponse) {
                        NotifyDialog.show(activity!!,data.head.errMsg)
                        NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                            override fun onHidden() {
                                activity?.finish()
                            }

                        })
                    }

                    override fun businessSuccess(data: CreatPayOrderResponse) {
                        number_card.text = Utils.formatBankNumber(data.body.accountNo.toString())
                        user_card.text = data.body.accountName
                        tv_bank_address.text = "${data.body.bankCity} ${data.body.bankBranchName}"
                        tv_money.text = Utils.formatMoney(data.body.amount)
                        tv_bank_name.text = data.body.bankName
                        val ssbuilder = SpannableStringBuilder(tv_money.text)
                        val blueSpan = ForegroundColorSpan(Color.parseColor("#EB5D4D"))
                        ssbuilder.setSpan(blueSpan, (tv_money.text.toString()).indexOf("."),tv_money.text.toString().length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                        tv_money.text = ssbuilder
                        tv_spik_detail.setOnClickListener {
                            var intent = Intent()
                            intent.setClass(context, OrderDetailActivity::class.java)
                            intent.putExtra("referenceId",data.body.billNo)
                            intent.putExtra("type",1)
                            intent.putExtra("showButton",true)
                            goToPage(intent)
                            activity?.finish()

                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(activity!!,apiErrorModel.message)
                        NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                            override fun onHidden() {
                                activity?.finish()
                            }

                        })
                    }
                })
    }

    override fun onDestroy() {
        super.onDestroy()
//        timer.cancel()
    }
}