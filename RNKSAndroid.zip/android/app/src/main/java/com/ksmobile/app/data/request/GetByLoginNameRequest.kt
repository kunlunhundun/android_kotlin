package com.ksmobile.app.data.request



/**
 * Created by ward.y on 2018/3/19.
 */
class GetByLoginNameRequest : BaseRequestObject(){
    var inclRealName:Int?=null
    var inclEmail:Int?=null
    var inclEmailBind:Int?=null
    var inclMobileNo:Int?=null
    var inclMobileNoBind:Int?=null
    var inclAddress:Int?=null
    var inclCredit:Int?=null
    var inclVerifyCode:Int?=null
    var inclBankAccount:Int?=null
    var inclBtcAccount:Int?=null
    var inclXmFlag:Int?=null


}
