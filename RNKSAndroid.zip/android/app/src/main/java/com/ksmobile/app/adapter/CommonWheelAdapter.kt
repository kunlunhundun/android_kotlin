/*
 * Copyright (C) 2016 venshine.cn@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ksmobile.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import com.wx.wheelview.adapter.BaseWheelAdapter

import com.ksmobile.app.R
import com.ksmobile.app.data.WheelTextObjet

/**
 * Demo
 *
 * @author venshine
 */
class CommonWheelAdapter(private val mContext: Context) : BaseWheelAdapter<WheelTextObjet>() {

    override fun bindView(position: Int, convertView: View?, parent: ViewGroup): View {

        val viewHolder: ViewHolder
        var v: View
        if (convertView == null) {
            viewHolder = ViewHolder()
            v = LayoutInflater.from(mContext).inflate(R.layout.bank_item_list, null)
            viewHolder.textView = v.findViewById(R.id.item_name)
            viewHolder.imageView = v.findViewById(R.id.iv_icon)
            v.tag = viewHolder
        } else {
            v = convertView
            viewHolder = convertView.tag as ViewHolder
        }
        viewHolder.textView?.text = mList[position].text
        viewHolder.imageView?.visibility = View.GONE
        return v
    }

    internal class ViewHolder {
        var textView: TextView? = null
        var imageView: ImageView? = null
    }

}
