package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.text.TextUtils
import android.view.View
import com.google.gson.Gson
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ivi.library.statistics.models.T3sAppPageBean
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.BaseMsgRequest
import com.ksmobile.app.data.request.QueryDomainListRequest
import com.ksmobile.app.data.response.QueryDomainListResponse
import com.ksmobile.app.data.response.QueryPayWaysV3Response
import com.ksmobile.app.fragment.recharge.*
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_recharge.*
import okhttp3.*
import java.io.IOException
import java.util.concurrent.TimeUnit


class RechargeActivity : BaseToolBarActivity() {
    var showList = false
    companion object {
        const val  SHOWLIST = "ShowList"
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_recharge
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.recharge_activity_title))
        setActionText("在线客服")
        showList = intent.getBooleanExtra(SHOWLIST,false)
    }

    override fun initView() {
        requestPayWayList()


    }

    override fun initListener() {
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }


    }

    var amount: String? = null
    var name: String? = null
    var datas: QueryPayWaysV3Response? = null
    private var wechatFragment: WechatRechargeFragment? = null
    private var alipayFragment: AlipayRechargeFragment? = null
    private var bankFragment: BankRechargeFragment? = null
    private var otherFragment: OtherRechargeFragment? = null


    val payWay = arrayOf(
            "支付宝",
            "微信",
            "银行卡",
            "其他"
    )


    private fun requestPayWayList() {
        val request = BaseMsgRequest()
        ApiClient.instance.service.queryPayWaysV3(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryPayWaysV3Response>(this, true) {
                    override fun businessFail(data: QueryPayWaysV3Response) {
                        if (AppInitManager.getThreeStatisticsObject().time1>0){
                            AppInitManager.getThreeStatisticsObject().time2 = System.currentTimeMillis()
                            val bean = T3sAppPageBean(AppInitManager.getThreeStatisticsObject().time3!!,"PaymentPageLoad",data.head.errMsg)
                            ThreeStatisticsManager.onPageEvent(bean)
                            AppInitManager.getThreeStatisticsObject().reset()
                        }

                        NotifyDialog.show(this@RechargeActivity, data.head.errMsg)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }

                    override fun businessSuccess(data: QueryPayWaysV3Response) {
                        if (AppInitManager.getThreeStatisticsObject().time1>0){
                            AppInitManager.getThreeStatisticsObject().time2 = System.currentTimeMillis()
                            val bean = T3sAppPageBean(AppInitManager.getThreeStatisticsObject().time3,"PaymentPageLoad",data.head.errMsg)
                            ThreeStatisticsManager.onPageEvent(bean)
                            AppInitManager.getThreeStatisticsObject().reset()
                        }

                        if (data.body.payList.isEmpty()) {
                            NotifyDialog.show(this@RechargeActivity, "您没有存款方式可用")
                            NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                                override fun onHidden() {
                                    finish()
                                }

                            })
                            return
                        }
                        datas = data
                        initPayWay()
                        if (ConfigUtils.onlinePaymentUrl.isEmpty()){
                            queryDomainList()
                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        if (AppInitManager.getThreeStatisticsObject().time1>0){
                            AppInitManager.getThreeStatisticsObject().time2 = System.currentTimeMillis()
                            val bean = T3sAppPageBean(AppInitManager.getThreeStatisticsObject().time3,"PaymentPageLoad",apiErrorModel.message)
                            ThreeStatisticsManager.onPageEvent(bean)
                            AppInitManager.getThreeStatisticsObject().reset()
                        }

                        NotifyDialog.show(this@RechargeActivity, "网络不稳定，请稍后再试")
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }

                })
    }

    fun initPayWay() {
        loading_default_show_view.visibility = View.GONE
        if (datas?.body?.blackFlag == 1) {
            AppInitManager.showServiceDialog(this)
            return
        }
        datas?.body?.initPromoTag()
        showPayWay(datas?.body!!.payList[0])
        preJudgment()

    }


    override fun onResume() {
        super.onResume()
        preJudgment()
    }


    open fun showPayWay(pay: QueryPayWaysV3Response.PayWayObject) {
        hideChildFragment(supportFragmentManager.beginTransaction())
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        val bundle = Bundle()
        val type = pay.payKindName
        bundle.putString("pay", Gson().toJson(pay))
        bundle.putString("datas", Gson().toJson(datas))
        when (type) {
            payWay[0] -> {
                if (alipayFragment == null) {
                    alipayFragment = AlipayRechargeFragment()
                    fragmentTransaction.add(R.id.fl_container, alipayFragment)
                } else {
                    fragmentTransaction.show(alipayFragment)
                }
                alipayFragment?.arguments = bundle
                fragmentTransaction.commitAllowingStateLoss()
            }

            payWay[1] -> {
                if (wechatFragment == null) {
                    wechatFragment = WechatRechargeFragment()
                    fragmentTransaction.add(R.id.fl_container, wechatFragment)
                } else {
                    fragmentTransaction.show(wechatFragment)
                }
                wechatFragment?.arguments = bundle
                fragmentTransaction.commitAllowingStateLoss()
            }

            payWay[2] -> {
                if (bankFragment == null) {
                    bankFragment = BankRechargeFragment()
                    fragmentTransaction.add(R.id.fl_container, bankFragment)
                } else {
                    fragmentTransaction.show(bankFragment)
                }
                bankFragment?.arguments = bundle
                fragmentTransaction.commitAllowingStateLoss()
            }

            payWay[3] -> {
                if (otherFragment == null) {
                    otherFragment = OtherRechargeFragment()
                    fragmentTransaction.add(R.id.fl_container, otherFragment)
                } else {
                    fragmentTransaction.show(otherFragment)
                }
                otherFragment?.arguments = bundle
                fragmentTransaction.commitAllowingStateLoss()
            }


        }


    }


    private fun hideChildFragment(fragmentTransaction: FragmentTransaction) {
        if (alipayFragment != null) {
            fragmentTransaction.hide(alipayFragment)
        }
        if (wechatFragment != null) {
            fragmentTransaction.hide(wechatFragment)
        }
        if (bankFragment != null) {
            fragmentTransaction.hide(bankFragment)
        }

        if (otherFragment != null) {
            fragmentTransaction.hide(otherFragment)
        }

        fragmentTransaction.commitAllowingStateLoss()
    }

    fun toggleViewBg(show: Boolean) {
        if (show) {
            view_bg.visibility = View.VISIBLE
        } else {
            view_bg.visibility = View.GONE
        }

    }


    private fun queryDomainList() {

        val request = QueryDomainListRequest()
        ApiClient.instance.service.queryDomainList(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryDomainListResponse>(this, true) {
                    override fun businessFail(data: QueryDomainListResponse) {

                    }

                    override fun businessSuccess(data: QueryDomainListResponse) {
                        testDomain(data)

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }


    private fun testDomain(data: QueryDomainListResponse) {
        val okHttpClient = OkHttpClient.Builder().readTimeout(3, TimeUnit.SECONDS).build()
        var calls = arrayListOf<Call>()
        data.body?.domainList?.forEach {
            val request = Request.Builder()
                    .url(it)
                    .get()//默认就是GET请求，可以不写
                    .build()
            val call = okHttpClient.newCall(request)
            calls.add(call)
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                }

                override fun onResponse(call: Call, response: Response) {

                    ConfigUtils.onlinePaymentUrl.add(it.replace("//", "*", false).split("/")[0].replace("*", "//"))

                }

            })

        }


    }

    private fun preJudgment() {
        if (datas?.body?.bindMobile == 1 && !ConfigUtils.isBindMobile) {
            ConfirmDialog.show(this,false)
            ConfirmDialog.setContent("您还没有绑定手机号，请绑定后再操作")
            ConfirmDialog.setTitile("")
            ConfirmDialog.setCancelText("返回")
            ConfirmDialog.setSureText("去绑定")
            ConfirmDialog.setSureListener(View.OnClickListener {
                if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {

                    val intent = Intent(this, BindMobilePhoneActivity::class.java)
                    intent.putExtra(BindMobilePhoneActivity.JumpTo, BindMobilePhoneActivity.JumpToDepositor)
                    goToPage(intent)

                } else {
                    val intent = Intent(this, ChangeMobilePhoneActivity::class.java)
                    intent.putExtra("type", 1)
                    intent.putExtra(ChangeMobilePhoneActivity.JumpTo, ChangeMobilePhoneActivity.JumpToDepositor)
                    goToPage(intent)
                }
                ConfirmDialog.dismiss()
            })
            ConfirmDialog.setCancelListener(View.OnClickListener {
                finish()
                ConfirmDialog.dismiss()

            })

        } else if (datas?.body?.bindBankCard == 1 && ConfigUtils.bankCardCounts == 0) {
            ConfirmDialog.show(this,false)
            ConfirmDialog.setContent("您还没有绑定银行卡，请绑定后再操作")
            ConfirmDialog.setTitile("")
            ConfirmDialog.setCancelText("返回")
            ConfirmDialog.setSureText("去绑定")
            ConfirmDialog.setSureListener(View.OnClickListener {
                val intent = Intent(this, BindBankCardActivity::class.java)
                goToPage(intent)
                ConfirmDialog.dismiss()
            })

            ConfirmDialog.setCancelListener(View.OnClickListener {
                finish()
                ConfirmDialog.dismiss()

            })
        }
    }

}
