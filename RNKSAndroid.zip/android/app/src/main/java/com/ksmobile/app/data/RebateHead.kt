package com.ksmobile.app.data

data class RebateHead(val name:String,val rebate:String,val proportion:String,val bet:String): RebateInfo() {
    override fun getGameName(): String {
        return name
    }

    override fun getRebateAmount(): String {
        return rebate
    }

    override fun getRebateProportion(): String {
        return proportion
    }

    override fun getBetAmount(): String {
       return bet
    }
}