package com.ksmobile.app.data

interface IBankInfo {
  fun getbankName():String
  fun getbankCode():String
  fun getbankIcon():String
}
