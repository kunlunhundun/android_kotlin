package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryBackDomainResponse : BaseResponseObject() {

    var body = mutableListOf<Domain>()

    data class Domain(val backDomain:String,val  sortNo:Int)

}

