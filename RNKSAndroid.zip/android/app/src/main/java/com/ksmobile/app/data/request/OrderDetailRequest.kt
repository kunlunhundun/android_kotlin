package com.ksmobile.app.data.request


class OrderDetailRequest : BaseRequestObject() {

    var requestId: String? = null
    var type: Int? = null


}