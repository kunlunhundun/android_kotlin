package com.ksmobile.app.data.response

/**
 * Created by ward.y on 2018/3/19.
 */
class QueryBtcRateAndAddressResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var accountId: String,
            var amount: String,
            var btcAddress: String,
            var btcAmount: String,
            var btcCurrency: String,
            var btcRate: String,
            var btcUuid: String,
            var currency: String


    )


}
