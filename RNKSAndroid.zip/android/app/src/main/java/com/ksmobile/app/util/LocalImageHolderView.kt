package com.ksmobile.app.util

import android.content.Context
import android.view.View
import android.widget.ImageView
import com.bigkoo.convenientbanner.holder.Holder

class LocalImageHolderView: Holder<Int>{
    var imageView: ImageView? = null
    override fun UpdateUI(context: Context?, position: Int, data: Int?) {
        imageView?.setImageResource(data!!)
    }

    override fun createView(context: Context?): View {
        imageView = ImageView(context)
        imageView?.scaleType = ImageView.ScaleType.CENTER_CROP
        return  imageView!!
    }

}
