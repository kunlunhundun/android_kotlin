package com.ksmobile.app.data.response

import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class GetBalanceResponse : BaseResponseObject(){
    val body:Body?=null
    class Body{
        var balance:BigDecimal?=null
        var withdrawBal:BigDecimal?=null
        var localBalance:BigDecimal?=null
        var minWithdrawAmount:BigDecimal?=null
    }
}
