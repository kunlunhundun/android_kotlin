package com.ksmobile.app.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.aigestudio.wheelpicker.widgets.WheelDatePicker
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.data.WheelTextObjet
import com.ksmobile.app.data.request.BtcPaymentRequest
import com.ksmobile.app.data.response.CreateBtcPaymentResponse
import com.ksmobile.app.data.response.QueryBtcRateAndAddressResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.DecimalDigitsInputFilter
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.MyWheelView
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_create_hand_btc.*
import java.math.BigDecimal
import java.math.RoundingMode

class CreateHandBtcDetailActivity : BaseToolBarActivity() {
    var btcInfo: QueryBtcRateAndAddressResponse? = null
    private var endNumber: String? = ""
    override fun getLayoutId(): Int {
        return R.layout.activity_create_hand_btc
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.create_hand_deposit_title))
        setActionText("联系客服")

    }

    override fun initView() {
        if (!TextUtils.isEmpty(intent.getStringExtra("btcInfo"))) {
            btcInfo = Gson().fromJson(intent.getStringExtra("btcInfo"), QueryBtcRateAndAddressResponse::class.java)
            tv_show_money_change_detail.text = btcInfo?.body?.amount
            tv_show_money_change_detail.visibility =View.VISIBLE
        }

        if (!TextUtils.isEmpty(intent.getStringExtra("money"))) {
            et_deposit_amount.setEditText(intent.getStringExtra("money"))
        }

    }

    override fun initListener() {

        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }

        et_deposit_time.setOnClickListener {
            showPopupWindow(it, 1)
        }
        et_deposit_amount.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    TextUtils.isEmpty(et_deposit_amount.getEditTextContent()) -> {
                        et_deposit_amount.showError("存款金额不能为空")
                    }
                }

            }
        }

        et_deposit_amount.getEditText().filters = arrayOf(DecimalDigitsInputFilter(2))
        et_deposit_amount.getEditText().addTextChangedListener(object : TextWatcher {
            @SuppressLint("SetTextI18n")
            override fun afterTextChanged(s: Editable?) {
                if (endNumber=="0"&&s.toString()!="0."&&s.toString()!=""){
                    et_deposit_amount.setEditText("0")
                    et_deposit_amount.getEditText().setSelection(1)
                    return
                }

                if (endNumber==""&&s.toString()=="."){
                    et_deposit_amount.setEditText("")
                    return
                }


                if (!TextUtils.isEmpty(s.toString())&& BigDecimal(s.toString()) > BigDecimal(0)) {

                    var number = BigDecimal(s.toString())
                    if (number <= BigDecimal(30)) {

                    } else {
                        if (endNumber == "") {
                            et_deposit_amount.setEditText("")
                            ToastUtils.show("单笔限额${0.01}BTC~${30}BTC")
                        } else {
                            et_deposit_amount.setEditText(endNumber)
                            et_deposit_amount.getEditText().setSelection(endNumber!!.length - 1)
                            ToastUtils.show("单笔限额${0.01}BTC~${30}BTC")
                        }
                    }
                    if (null != btcInfo?.body?.btcRate) {

                        tv_show_money_change_detail.text = "${BigDecimal(BigDecimal(et_deposit_amount.getEditTextContent()).toDouble().times(btcInfo?.body?.btcRate!!.toDouble())).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()}"
                        tv_show_money_change_detail.visibility = View.VISIBLE
                    }
                }else{
                    tv_show_money_change_detail.text = "        "
                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                endNumber = s.toString()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })


        et_deposit_address.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                checkBtcAddress()
            }


        }



        btn_commit.setOnClickListener {
            var cancel = false
            et_deposit_amount.hideError()
            et_deposit_time.hideError()
            et_deposit_address.hideError()
            when {
                TextUtils.isEmpty(et_deposit_amount.getEditTextContent()) -> {
                    et_deposit_amount.showError("存款金额不能为空")
                    cancel = true
                }

                TextUtils.isEmpty(et_deposit_time.getEditTextContent()) -> {
                    et_deposit_time.showError("提交时间不能为空")
                    cancel = true
                }

                checkBtcAddress() ->{
                    cancel = checkBtcAddress()
                }


            }



            if (cancel) {

            } else {
                request()
            }
        }


    }


    private fun checkBtcAddress(): Boolean {
        var cancle = false
        var error: String? = null

        when {
            !Utils.checkBitWallet(et_deposit_address.getEditTextContent()) -> {
                error = getString(R.string.real_name_formate_tip)
                et_deposit_address.showError(error)
                cancle = true
            }

            et_deposit_address.getEditTextContent().length < 26 -> {
                error = getString(R.string.real_name_formate_tip)
                et_deposit_address.showError(error)
                cancle = true
            }
        }

        return cancle
    }

    private fun request() {
        if (btcInfo?.body == null) {
            ToastUtils.show("支付失败，无法完成订单")
            return
        }
        val request = BtcPaymentRequest()
        request.amount = tv_show_money_change_detail.text.toString()
        request.btcAmount = et_deposit_amount.getEditTextContent()
        request.accountId = btcInfo?.body!!.accountId
        request.btcAddress = et_deposit_address.getEditTextContent()
        request.btcRate = btcInfo?.body!!.btcRate
        request.btcUuid = btcInfo?.body!!.btcUuid
        request.depositDate = et_deposit_time.getEditTextContent()

        ApiClient.instance.service.btcPayment(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreateBtcPaymentResponse>(this, true) {
                    override fun businessFail(data: CreateBtcPaymentResponse) {
                        NotifyDialog.show(this@CreateHandBtcDetailActivity, data.head.errMsg)
                    }

                    override fun businessSuccess(data: CreateBtcPaymentResponse) {
                        var intent = Intent()
                        intent.setClass(this@CreateHandBtcDetailActivity, OrderDetailActivity::class.java)
                        intent.putExtra("referenceId", data.body?.billNo)
                        intent.putExtra("type", 1)
                        intent.putExtra("showButton", true)
                        startActivity(intent)
                        finish()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }


    /**
     * 选择时间弹窗
     */
    private fun showPopupWindow(v: View, type: Int) {
        val layoutInflater = LayoutInflater.from(this@CreateHandBtcDetailActivity)
        val view = layoutInflater.inflate(R.layout.view_popup_window_bank_picker, null)
        val cancel: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val ll_bottom_date_picker: RelativeLayout = view.findViewById(R.id.ll_bottom_date_picker)
        val bank_list: MyWheelView<WheelTextObjet> = view.findViewById(R.id.bank_list)
        val datePicker: WheelDatePicker = view.findViewById(R.id.datePicker)
        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        popupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        popupWindow.isOutsideTouchable = true
        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        popupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        when (type) {
//
            1 -> {


                bank_list.visibility = View.GONE
                datePicker.visibility = View.VISIBLE
                sure.setOnClickListener {
                    et_deposit_time.setEditText(datePicker.selectDate)
                    popupWindow.dismiss()
                }
            }
        }


        // PopupWindow弹出位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)

        cancel.setOnClickListener { popupWindow.dismiss() }
        ll_bottom_date_picker.setOnClickListener { popupWindow.dismiss() }
    }

}