package com.ksmobile.app.data.response

/**
 * Created by ward.y on 2018/3/19.
 */
class DeleteRecordResponse : BaseResponseObject() {
    val body: String? = null
}
