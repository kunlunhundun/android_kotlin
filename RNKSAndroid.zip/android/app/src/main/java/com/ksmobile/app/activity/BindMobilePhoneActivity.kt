package com.ksmobile.app.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.BindMobileRequest
import com.ksmobile.app.data.request.ReBindPhoneRequest
import com.ksmobile.app.data.request.SendSmsRequest
import com.ksmobile.app.data.response.BindMobileResponse
import com.ksmobile.app.data.response.ReBindPhoneResponse
import com.ksmobile.app.data.response.SendSmsResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.RSATool
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_bind_mobile_phone.*

class BindMobilePhoneActivity : BaseToolBarActivity() {
    private var timer: CountDownTimer? = null
    private var messageId: String? = null

    companion object {
        const val JumpToWithDraw = 1  // 取款
        const val JumpToDepositor = 2  // 存款
        const val JumpTo = "JumpTo"
    }

    val TYPE_CHANGE = 0
    val TYPE_BIND = 1
    private var type = TYPE_CHANGE
    private var mJumpTo = 0
    override fun getLayoutId(): Int {
        return R.layout.activity_bind_mobile_phone
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setTile(getString(R.string.bind_mobile_phone_title))

    }

    override fun initView() {
        type = intent.getIntExtra("type", TYPE_BIND)
        mJumpTo = intent.getIntExtra(JumpTo, 0)
    }

    override fun initListener() {
        et_phone_number.getEditText().addTextChangedListener(object : TextWatcher {
            var mCount = 0
            override fun beforeTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                mCount = count


            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {

            }

            override fun afterTextChanged(s: Editable) {

                var length = s.toString().length
                //删除数字
                if (mCount == 0) {
                    if (length == 4) {
                        et_phone_number.getEditText().setText(s.subSequence(0, 3))
                    }
                    if (length == 9) {
                        et_phone_number.getEditText().setText(s.subSequence(0, 8))
                    }
                }
                //添加数字
                if (mCount == 1) {
                    if (length == 4) {
                        var part1 = s.subSequence(0, 3).toString()
                        var part2 = s.subSequence(3, length).toString()
                        et_phone_number.getEditText().setText("$part1 $part2")
                    }
                    if (length == 9) {
                        var part1 = s.subSequence(0, 8).toString()
                        var part2 = s.subSequence(8, length).toString()
                        et_phone_number.getEditText().setText("$part1 $part2")
                    }
                }
                if (mCount >= 4 && !s.contains(" ")) {
                    et_phone_number.getEditText().setText(Utils.getPhoneNumber(s.toString()))
                }
                et_phone_number.getEditText().setSelection(et_phone_number.getEditTextContent().length)
            }
        })

        tv_verify_code.setOnClickListener {
            if (Utils.isFastDoubleClick()){
                return@setOnClickListener
            }
            if (!attemptSignUp()) {
                sendVerifyCode()
            }

        }



        btn_commit.setOnClickListener {
           if (Utils.isFastDoubleClick()){
               return@setOnClickListener
           }

            when {
                attemptSignUp() -> {

                }

                TextUtils.isEmpty(et_verify_code.getEditTextContent()) -> {
                    et_verify_code.showError("验证码不能为空")
                }
                else -> {
                    if (type == TYPE_BIND) {
                        bindMobileNo()
                    } else {
                        reBindPhone()
                    }

                }

            }

        }

        et_phone_number.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                attemptSignUp()
            }

        }

        et_verify_code.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (TextUtils.isEmpty(et_verify_code.getEditTextContent())) {
                    et_verify_code.showError("验证码不能为空")
                }
            }

        }


    }


    private fun attemptSignUp(): Boolean {

        val phoneStr = et_phone_number.getEditTextContent()
        var cancel = false
        // Check for a valid phone number.
        if (TextUtils.isEmpty(phoneStr)) {
            et_phone_number.showError(getString(R.string.error_phone_number_empty))
            cancel = true
        } else if (!isPhoneNumberValid(et_phone_number.getEditText().text.toString().replace(" ", ""))) {
            et_phone_number.showError(getString(R.string.error_phone_number_required))
            cancel = true
        }


        return cancel
    }

    private fun sendVerifyCode() {
        val request = SendSmsRequest()
        request.mobileNo = RSATool.encode(et_phone_number.getEditTextContent().replace(" ", ""))
        if (type == TYPE_BIND) {
            request.use = "3"
        } else {
            request.use = "5"
        }

        ApiClient.instance.service.sendCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this,true) {
                    override fun businessFail(data: SendSmsResponse) {

                        when (data.head.errCode) {
                            "WS_300027", "GW_800205", "WS_300021", "GW_800211", "WS_300020" -> {
                                data.head.errMsg = "短信验证码不正确"
                            }
                            "GW_800210" -> {
                                data.head.errMsg = "手机号不能为空"
                            }
                            "GW_800203" -> {
                                data.head.errMsg = "短信验证码过期"
                            }
                            "WS_300002", "WS_300022" -> {
                                data.head.errMsg = "操作太频繁，请5分钟后再试"
                            }
                            "WS_201723" -> {
                                data.head.errMsg = "您的操作太频繁，请明天再试"
                            }


                        }

                        NotifyDialog.show(this@BindMobilePhoneActivity, data.head.errMsg)
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        NotifyDialog.show(this@BindMobilePhoneActivity, "验证码发送成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        initTimer(60)?.start()
                        messageId = data.body.messageId

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@BindMobilePhoneActivity, apiErrorModel.message)
                    }

                })

    }

    private fun isPhoneNumberValid(phoneNumber: String): Boolean {
        return phoneNumber.length == 11 && Utils.formatPhoneNumber(phoneNumber) == 0
    }

    private fun initTimer(time: Long): CountDownTimer? {
        timer = object : CountDownTimer(time * 1000, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                tv_verify_code.setOnClickListener(null)
                tv_verify_code.text = String.format(getString(R.string.bind_mobile_phone_activity_wait_tip), millisUntilFinished / 1000)
            }

            override fun onFinish() {
                tv_verify_code.text = "重新发送"
                tv_verify_code.setOnClickListener {
                    if (!attemptSignUp()) {
                        sendVerifyCode()
                    }
                }

            }
        }

        return timer
    }

    private fun bindMobileNo() {
        val request = BindMobileRequest()
        request.messageId = messageId
        request.smsCode = et_verify_code.getEditTextContent().trim()
        ApiClient.instance.service.bindMobileNo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<BindMobileResponse>(this, true) {
                    override fun businessFail(data: BindMobileResponse) {
                        when (data.head.errCode) {
                            "WS_300027", "GW_800205", "WS_300021", "GW_800211", "WS_300020" -> {
                                data.head.errMsg = "短信验证码不正确"
                            }
                            "GW_800210" -> {
                                data.head.errMsg = "手机号不能为空"
                            }
                            "GW_800203" -> {
                                data.head.errMsg = "短信验证码过期"
                            }
                            "WS_300002", "WS_300022" -> {
                                data.head.errMsg = "操作太频繁，请5分钟后再试"
                            }

                            "WS_201723" -> {
                                data.head.errMsg = "该手机号操作太频繁，请明天再试"
                            }


                        }

                        NotifyDialog.show(this@BindMobilePhoneActivity, data.head.errMsg)
                    }

                    override fun businessSuccess(data: BindMobileResponse) {
                        ConfigUtils.isBindMobile = true
                        NotifyDialog.show(this@BindMobilePhoneActivity, "绑定成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()

                            }

                        })
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@BindMobilePhoneActivity, apiErrorModel.message)
                    }

                })

    }


    private fun reBindPhone() {
        val request = ReBindPhoneRequest()
        request.smsCode = et_verify_code.getEditTextContent().trim()
        request.messageId = messageId
        ApiClient.instance.service.reBindMobileNo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<ReBindPhoneResponse>(this, true) {
                    override fun businessFail(data: ReBindPhoneResponse) {
                        when (data.head.errCode) {
                            "WS_300027", "GW_800205", "WS_300021", "GW_800211", "WS_300020" -> {
                                data.head.errMsg = "短信验证码不正确"
                            }
                            "GW_800210" -> {
                                data.head.errMsg = "手机号不能为空"
                            }
                            "GW_800203" -> {
                                data.head.errMsg = "短信验证码过期"
                            }
                            "WS_300002", "WS_300022" -> {
                                data.head.errMsg = "操作太频繁，请5分钟后再试"
                            }

                            "WS_201723" -> {
                                data.head.errMsg = "该手机号操作太频繁，请明天再试"
                            }


                        }
                        NotifyDialog.show(this@BindMobilePhoneActivity, data.head.errMsg)
                    }

                    override fun businessSuccess(data: ReBindPhoneResponse) {
                        ConfigUtils.isBindMobile = true
                        NotifyDialog.show(this@BindMobilePhoneActivity, "绑定成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()

                            }

                        })
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@BindMobilePhoneActivity, apiErrorModel.message)
                    }

                })

    }


}