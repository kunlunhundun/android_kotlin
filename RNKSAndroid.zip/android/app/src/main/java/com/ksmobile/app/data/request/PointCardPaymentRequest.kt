package com.ksmobile.app.data.request



class PointCardPaymentRequest : BaseRequestObject(){
    var amount = ""
    var cardCode:String?= ""
    var cardNo = ""
    var cardPwd = ""
    var payid:String?= ""
}