package com.ksmobile.app.data.response

import com.ksmobile.app.data.PromoObject


/**
 * Created by ward.y on 2018/3/19.
 */
class A06PromoResponse : BaseResponseObject() {
    val body: Body? = null

    class Body {
        val promoCount:Int?=0
        val tA06MyPromoList = mutableListOf<PromoObject>()
    }


}
