package com.ksmobile.app.data.request



class CreateOnlineRequest : BaseRequestObject() {

    var amount: Int = -1
    var payid: String? = null
    var bankNo: String? = ""
    var payType: String? = ""

}