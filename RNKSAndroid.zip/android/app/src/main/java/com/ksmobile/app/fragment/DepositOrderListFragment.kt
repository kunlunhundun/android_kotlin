package com.ksmobile.app.fragment

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jcodecraeer.xrecyclerview.ProgressStyle
import com.jcodecraeer.xrecyclerview.XRecyclerView
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderDetailActivity
import com.ksmobile.app.activity.OrderReportActivity
import com.ksmobile.app.adapter.TradeRecordAdapter
import com.ksmobile.app.data.OrderObject
import com.ksmobile.app.data.request.DeleteRecordRequest
import com.ksmobile.app.data.request.OrderRecordRequest
import com.ksmobile.app.data.response.DeleteRecordResponse
import com.ksmobile.app.data.response.OrderRecordResponse
import com.ksmobile.app.net.*
import com.ksmobile.app.util.LoadErrorType
import com.ksmobile.app.util.ToastUtils
import kotlinx.android.synthetic.main.fragment_oder_list.*
import android.support.v7.widget.RecyclerView
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog


class DepositOrderListFragment : LazyLoadFragment() {
    lateinit var mAdapter: TradeRecordAdapter
    private lateinit var oders: MutableList<OrderObject>
    lateinit var response: OrderRecordResponse
    val REFRESH: Int = 1
    val LOAD_MORE: Int = 0
    var refreshTag: Int = LOAD_MORE
    var mLastDays: Int = 7
    var isEditable = false
    var mActivity: OrderReportActivity? = null
    var deleteRecordRequest = DeleteRecordRequest()
    var layoutManager: LinearLayoutManager? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_oder_list, null)
    }


    override fun requestData() {
        LoadingDialog.show(activity!!)
        initData()
        initListener()
    }

    override fun repeat() {
        mActivity = activity as OrderReportActivity
        if (isEditable) {
            mActivity?.setActionText("取消")
        } else {
            mActivity?.setActionText("编辑")
        }

        mActivity?.setEditListener(object : OrderReportActivity.IEditCallBack {
            override fun onEditAble() {
                isEditable = !isEditable
                if (isEditable) {
                    showEditMode()

                } else {
                    hiddenEditMode()
                }

            }

        })

    }

    private fun showEditMode() {
        cl_edit.visibility = View.VISIBLE
        mAdapter.setMode(mAdapter.MODE_EDIT)
        mAdapter.setAllselect(false)
        mActivity?.setActionText("取消")
    }

    private fun hiddenEditMode() {
        cl_edit.visibility = View.GONE
        mAdapter.setMode(mAdapter.MODE_NORMAL)
        mActivity?.setActionText("编辑")
    }

    private fun showEmpty() {
        load_error.visibility = View.VISIBLE
        load_error.showError(LoadErrorType.DATA_EMPTY.code)
        load_error.setTips("暂无存款记录")
    }


    private fun initListener() {

        tv_15.setOnClickListener {
            tv_7.isSelected = false
            tv_15.isSelected = true
            mLastDays = 15
            scollToPosition(0)
            lv_order.refresh()
            load_error.visibility =View.GONE
        }

        tv_7.setOnClickListener {
            tv_7.isSelected = true
            tv_15.isSelected = false
            mLastDays = 7
            scollToPosition(0)
            lv_order.refresh()
            load_error.visibility =View.GONE
        }

        tv_select_all.setOnClickListener {
            if (tv_select_all.text == "全选") {
                mAdapter.setAllselect(true)
                tv_select_all.text = "取消全选"
            } else {
                mAdapter.setAllselect(false)
                tv_select_all.text = "全选"
            }

        }

        iv_delete.setOnClickListener {

            if (mAdapter.selcetItems.isEmpty()) {
                NotifyDialog.show(mActivity,"请选择要删除的内容")

            } else {

                ConfirmDialog.show(mActivity)
                ConfirmDialog.setTitile("确定删除您选中的信息吗？")
                ConfirmDialog.setCancelText("取消")
                ConfirmDialog.setSureText("确定")
                ConfirmDialog.setSureListener(View.OnClickListener {
                    deleteRecordRequest.requestIds.clear()
                    mAdapter.ids.forEach {
                        deleteRecordRequest.requestIds.add(it.requestId)
                    }
                    deleteRecord(deleteRecordRequest)
                    mAdapter.removeAll()
                    hiddenEditMode()
                    if (mAdapter.datas.isEmpty()) {
                        showEmpty()
                    }
                    ConfirmDialog.dismiss()
                    mActivity?.showDeleteNotify()


                })

            }


        }

    }

    private fun initData() {
        oders = mutableListOf()
        initListView(oders)
        tv_15.isSelected = false
        getData(1)

    }

    private fun getData(pageNo: Int) {
        getData(pageNo, mLastDays)
    }


    private fun getData(pageNo: Int, lastDays: Int) {
        val request = OrderRecordRequest()
        request.lastDays = lastDays
        request.pageSize = 10
        request.pageNo = pageNo
        ApiClient.instance.service.queryTrans(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<OrderRecordResponse>(activity!!, false) {
                    override fun businessFail(data: OrderRecordResponse) {
                        load_error.visibility = View.VISIBLE
                        load_error.showError(LoadErrorType.NOT_FOUND.code)
                        load_error.setTips(data.head.errMsg!!)
                        load_error.setNormalClickListener(View.OnClickListener {
                            lv_order.visibility = View.VISIBLE
                            getData(1)
                        })
                        updateError()
                    }

                    override fun businessSuccess(data: OrderRecordResponse) {

                        if (data.body?.data == null || data.body.data.isEmpty()) {
                            updateError()
                            load_error.visibility = View.VISIBLE
                            load_error.showError(LoadErrorType.DATA_EMPTY.code)
                            load_error.setTips("暂无存款记录")


                        } else {
                            load_error.visibility = View.GONE
                            response = data
                            if (pageNo == 1) {
                                //当请求为页数1时，全部重置为refresh
                                refreshTag = REFRESH
                            }
                            updateData()
                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        if (refreshTag == LOAD_MORE && pageNo == 1) {
                            when (apiErrorModel.status) {
                                504 -> {
                                    load_error.visibility = View.VISIBLE
                                    load_error.showError(LoadErrorType.NET_ERROR.code)
                                    load_error.setNormalClickListener(View.OnClickListener {
                                        load_error.visibility = View.GONE
                                        getData(1)
                                    })

                                }
                                ApiErrorType.CONNECTION_TIMEOUT.code -> {
                                    load_error.visibility = View.VISIBLE
                                    load_error.showError(LoadErrorType.TIME_OUT.code)
                                    load_error.setNormalClickListener(View.OnClickListener {
                                        load_error.visibility = View.GONE
                                        getData(1)
                                    })
                                }
                                else -> ToastUtils.show(apiErrorModel.message)
                            }
                        } else {
                            ToastUtils.show(apiErrorModel.message)
                        }
                        updateError()
                    }

                })

    }


    private fun updateError() {
        LoadingDialog.cancel()
        when (refreshTag) {
            REFRESH -> {


                if (lv_order != null) {
                    oders.clear()
                    mAdapter.notifyDataSetChanged()
                    lv_order.refreshComplete()


                }
            }

            LOAD_MORE -> {

                if (lv_order != null) {
                    lv_order.loadMoreComplete()
                }
            }
        }
    }

    private fun updateData() {
        LoadingDialog.cancel()
        lv_order.visibility =View.VISIBLE
        when (refreshTag) {
            REFRESH -> {
                oders.clear()
                oders.addAll(response.body?.data!!)
                mAdapter.notifyDataSetChanged()
                if (lv_order != null) {
                    lv_order.refreshComplete()
                }
            }

            LOAD_MORE -> {
                oders.addAll(response.body?.data!!)
                mAdapter.notifyDataSetChanged()
                if (lv_order != null) {
                    lv_order.loadMoreComplete()
                }
            }
        }


        if (response.body?.pageNo!! >= response.body?.totalPage!!) {
            lv_order.setNoMore(true)
        }

    }

    private fun initListView(data: MutableList<OrderObject>) {
        layoutManager = LinearLayoutManager(activity)
        layoutManager?.orientation = LinearLayoutManager.VERTICAL
        lv_order.layoutManager = layoutManager
        lv_order.setRefreshProgressStyle(ProgressStyle.BallSpinFadeLoader)
        lv_order.setLoadingMoreProgressStyle(ProgressStyle.LineScalePulseOutRapid)
        lv_order.setArrowImageView(R.mipmap.iconfont_downgrey)
//        lv_order.defaultFootView.setLoadingHint("年轻人不要着急...")
        lv_order.defaultFootView.setNoMoreHint("")
        lv_order.setLoadingMoreEnabled(true)
//        lv_order.defaultFootView.setPadding(0, 0, 0, Dip2PixleUtil.dp2px(activity, 45f))
        lv_order.setLimitNumberToCallLoadMore(10)
        lv_order.setLoadingListener(object : XRecyclerView.LoadingListener {
            override fun onRefresh() {
                refreshTag = REFRESH
                getData(1)
            }

            override fun onLoadMore() {
                refreshTag = LOAD_MORE
                getData(response.body?.pageNo!!.plus(1))
            }
        })


        mAdapter = TradeRecordAdapter(context!!, data)
        mAdapter.setClickCallBack(
                object : TradeRecordAdapter.ItemClickCallBack {
                    override fun onItemClick(pos: Int) {
                        val intent = Intent(activity?.baseContext, OrderDetailActivity::class.java)
                        intent.putExtra("referenceId", data[pos].requestId)
                        intent.putExtra("type", 1)
                        goToPage(intent)

                    }

                    override fun onItemDelete(pos: Int) {
                        ConfirmDialog.show(mActivity)
                        ConfirmDialog.setTitile("确定删除您选中的信息吗？")
                        ConfirmDialog.setCancelText("取消")
                        ConfirmDialog.setSureText("确定")
                        ConfirmDialog.setSureListener(View.OnClickListener {
                            deleteRecordRequest.requestIds.clear()
                            deleteRecordRequest.requestIds.add(data[pos].requestId)
                            deleteRecord(deleteRecordRequest)
                            mAdapter.removeItem(pos)
                            ConfirmDialog.dismiss()
                            mActivity?.showDeleteNotify()
                        })


                    }
                }
        )
        lv_order.adapter = mAdapter
        lv_order.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView?, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                //在这里进行第二次滚动
                if (move) {
                    move = false
                    //获取要置顶的项在当前屏幕的位置，mIndex是记录的要置顶项在RecyclerView中的位置
                    val n = index - layoutManager!!.findFirstVisibleItemPosition()
                    if (0 <= n && n < recyclerView!!.childCount) {
                        //获取要置顶的项顶部离RecyclerView顶部的距离
                        val top = recyclerView.getChildAt(n).top
                        //最后的移动
                        recyclerView.smoothScrollBy(0, top)
                    }
                }
            }
        })

    }


    private fun deleteRecord(request: DeleteRecordRequest) {
        ApiClient.instance.service.deleteDepositRecord(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<DeleteRecordResponse>(activity!!, false) {
                    override fun businessFail(data: DeleteRecordResponse) {

                    }

                    override fun businessSuccess(data: DeleteRecordResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }
                })
    }

    var index = 0
    var move = false

    private fun scollToPosition(n: Int) {
        //滑动到指定的item
        this.index = n//记录一下 在第三种情况下会用到
        //拿到当前屏幕可见的第一个position跟最后一个postion
        val firstItem = layoutManager!!.findFirstVisibleItemPosition()
        val lastItem = layoutManager!!.findLastVisibleItemPosition()
        //区分情况
        when {
            n <= firstItem -> //当要置顶的项在当前显示的第一个项的前面时
                lv_order.smoothScrollToPosition(n)
            n <= lastItem -> {
                //当要置顶的项已经在屏幕上显示时
                val top = lv_order.getChildAt(n - firstItem).top
                lv_order.smoothScrollBy(0, top)
            }
            else -> {
                //当要置顶的项在当前显示的最后一项的后面时
                lv_order.smoothScrollToPosition(n)
                //这里这个变量是用在RecyclerView滚动监听里面的
                move = true
            }
        }
    }


}