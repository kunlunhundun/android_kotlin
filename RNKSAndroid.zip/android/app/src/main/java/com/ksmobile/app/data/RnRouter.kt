package com.ksmobile.app.data

data class RnRouter(val pageName:String,val needBack:Boolean)
