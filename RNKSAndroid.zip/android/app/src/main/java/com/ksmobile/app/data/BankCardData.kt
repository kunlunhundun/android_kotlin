package com.ksmobile.app.data

data class BankCardData(var bankName: String, var bankIcon: String,var bankCode:String) : SelectorItem {
    override fun getImageLeft(): String? {
        return bankIcon
    }

    override fun getTitle(): String {
        return bankName
    }

    override fun hasChild(): Boolean {
        return false
    }

    override fun getChildItems(): List<SelectorItem>? {
        return null
    }
}