package com.ksmobile.app.data

data class CityData(var cityName: String, var cityId: String) : SelectorItem {
    override fun getImageLeft(): String? {
        return null
    }

    override fun getTitle(): String {
        return cityName
    }

    override fun hasChild(): Boolean {
        return false
    }

    override fun getChildItems(): List<SelectorItem>? {
        return null
    }
}