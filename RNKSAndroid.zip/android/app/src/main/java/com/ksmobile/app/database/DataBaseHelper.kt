package com.ksmobile.app.database

import com.ksmobile.app.config.ConfigUtils
import org.litepal.LitePal
import org.litepal.crud.DataSupport


/**
 * Created by ward.y on 2018/4/2.
 */
object DataBaseHelper {

    @JvmStatic
    fun creatDataBase() {
        LitePal.getDatabase()
    }
    @JvmStatic
    fun getUrl(): UrlData? {
        var urlData = DataSupport.findFirst(UrlData::class.java)
        return if (urlData != null) {
            urlData
        } else {
            ConfigUtils.baseUrl =  when(ConfigUtils.MODEL){
                ConfigUtils.MODEL_NATIVAL_TEST -> ConfigUtils.testUrl
                ConfigUtils.MODEL_RUNTIME_TEST ->ConfigUtils.testGateUrl
                else ->ConfigUtils.runUrl

            }
            val urlData = UrlData()
            urlData.url =  ConfigUtils.runGateUrl
            urlData.frontUrl = ConfigUtils.frontUrl
            urlData.domain = ConfigUtils.baseUrl.split("//")[1].split("/")[0]
            ConfigUtils.DOMAIN_NAME = urlData.domain!!
            urlData.saveOrUpdate("urlId = ?", "1")
            urlData
        }

    }

    @JvmStatic
    fun updateUrl(url: String) {
        ConfigUtils.baseUrl = url
        val urlData = UrlData()
        urlData.url = ConfigUtils.runGateUrl
        urlData.frontUrl = ConfigUtils.frontUrl
        if (url.contains("//")) {
            urlData.domain = ConfigUtils.baseUrl.split("//")[1]
            ConfigUtils.DOMAIN_NAME = urlData.domain!!
        }

        urlData.saveOrUpdate("urlId = ?", "1")
    }


    @JvmStatic
    fun updateAddUrl(url: String?) {
        val urlData = UrlData()
        urlData.addUrl = url
        urlData.saveOrUpdate("urlId = ?", "1")
    }










}