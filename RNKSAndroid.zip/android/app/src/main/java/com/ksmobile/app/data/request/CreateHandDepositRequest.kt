package com.ksmobile.app.data.request



class CreateHandDepositRequest : BaseRequestObject() {

    var amount: String? = null
    var bankCardId: String? = null
    var depositDate: String? = null
    var depositor: String? = null
    var depositType: String? = null
    var depositorType: Int = 0
    var depositLocation: String? = null
}