package com.ksmobile.app.data

data class GateWayObject (val gateWay:String,
                          val versionName :String
                          )