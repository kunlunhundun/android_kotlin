package com.ksmobile.app.data.response

import com.ksmobile.app.data.PointCardObject


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryPointCardListResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var cardNum: Int,
            var channelCode: String,
            var payid: String,
            var pointCardList: MutableList<PointCardObject>
    )

}
