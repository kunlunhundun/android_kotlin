package com.ksmobile.app.util


import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.Base64
import com.github.dfqin.grantor.PermissionsUtil
import com.ksmobile.app.BuildConfig
import com.ksmobile.app.MyApplication
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.ProjectUtils
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.view.hybride.BrowserActivity
import common.util.sign.SignUtils
import java.io.File
import java.io.FileInputStream
import java.math.BigDecimal
import java.net.NetworkInterface
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.text.DecimalFormat
import java.util.*


/**
 * Created by ward.y on 2018/2/23.
 */
object Utils {

    var iswelcome = false
    /**
     * 获取版本号
     * @return 当前应用的版本号
     */
    @JvmStatic
    fun getVersion(): String {
        return try {
            val manager = MyApplication.instance!!.packageManager
            val info = manager.getPackageInfo(MyApplication.instance!!.packageName, 0)
            val version = info.versionName
            version
        } catch (e: Exception) {
            e.printStackTrace()
            "1.0.0"
        }
    }

    /**
     * 获取当前时区ID
     * @return 当前时区ID
     */
    @JvmStatic
    fun getTimeZoneID(): String {
        var tz = TimeZone.getDefault()
        return tz.id.toString()
    }

    /**
     * @return 获取当前的格式化日期比如 2018-03-01 12:23:35
     */
    @JvmStatic
    fun getCurentTime(): String {
        return try {
            System.currentTimeMillis().toString()
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    /**
     * @return 手机运营商
     */

    @SuppressLint("MissingPermission", "HardwareIds")
    @JvmStatic
    fun getNetFirm(): String {
        var providersName: String? = null

        var IMSI: String? = null
        if (getTelephonyManager()?.subscriberId == null) {
            return "无运行商"
        } else {
            IMSI = getTelephonyManager()!!.subscriberId
        }
        if (TextUtils.isEmpty(IMSI)) {
            return "无运行商"
        }
        if (IMSI.startsWith("46000") || IMSI.startsWith("46002")) {
            providersName = "中国移动"
        } else if (IMSI.startsWith("46001")) {
            providersName = "中国联通"
        } else if (IMSI.startsWith("46003")) {
            providersName = "中国电信"
        }
        return providersName.toString()
    }

    @JvmStatic
    fun getSimCode(): String? {
        return getTelephonyManager()?.simSerialNumber
    }


    @JvmStatic
    fun getSimUserCode(): String? {
        return getTelephonyManager()?.subscriberId
    }

    @JvmStatic
    fun getCountry(): String? {
        return MyApplication.getinstance().baseContext.resources.configuration.locale.country
    }

    private var sTelephonyManager: TelephonyManager? = null

    @JvmStatic
    private fun getTelephonyManager(): TelephonyManager? {

        if (PermissionsUtil.hasPermission(MyApplication.getinstance().applicationContext, Manifest.permission.READ_PHONE_STATE)) {
            if (sTelephonyManager == null) {
                sTelephonyManager = MyApplication.instance!!.getSystemService(
                        Context.TELEPHONY_SERVICE) as TelephonyManager?
            }
        }

        return sTelephonyManager
    }


    @JvmStatic
    fun getUqid(): String {
        var temp = StringBuffer()
        if (null != getTelephonyManager()) {
            val imei = getTelephonyManager()?.deviceId
            if (imei != null) {
                temp.append(imei)
            }
        }
        if (!TextUtils.isEmpty(getMacAddr())) {
            temp.append(getMacAddr())
        }

        return md5Encode(temp.toString())
    }

    /**
     * 获取设备IMEI码
     */
    @JvmStatic
    fun getIMEI(): String {
        val tm = getTelephonyManager()?.deviceId
        if (tm == null) {
            return " "
        } else {
            return tm
        }
    }

    private fun getMacAddr(): String {
        try {
            val all = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (nif in all) {
                if (!nif.name.equals("wlan0", ignoreCase = true)) continue

                val macBytes = nif.hardwareAddress ?: return ""

                val res1 = StringBuilder()
                for (b in macBytes) {
                    res1.append(String.format("%02X:", b))
                }

                if (res1.length > 0) {
                    res1.deleteCharAt(res1.length - 1)
                }
                return res1.toString()
            }
        } catch (ex: Exception) {
        }

        return "02:00:00:00:00:00"
    }


    @JvmStatic
    // a integer to xx:xx:xx
    fun secToTime(time: Long): String {
        var timeStr: String? = null
        var hour: Long
        var minute: Long
        var second: Long
        if (time <= 0)
            return "00:00"
        else {
            minute = time / 60
            if (minute < 60) {
                second = time % 60
                timeStr = unitFormat(minute) + ":" + unitFormat(second)
            } else {
                hour = minute / 60
                if (hour > 99)
                    return "99:59:59"
                minute %= 60
                second = time - hour * 3600 - minute * 60
                timeStr = unitFormat(hour) + ":" + unitFormat(minute) + ":" + unitFormat(second)
            }
        }
        return timeStr
    }

    private fun unitFormat(i: Long): String {

        return if (i in 0..9)
            "0$i"
        else
            "" + i
    }

    @JvmStatic
    fun checkBitWallet(string: String): Boolean {
        val r1 = Regex("^[0-9a-zA-Z]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkStringChinese(string: String): Boolean {
        val r1 = Regex("^(\\*|[\\u4e00-\\u9fa5])[\\u4e00-\\u9fa5]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkStringFullChinese(string: String): Boolean {
        val r1 = Regex("^[\\u4e00-\\u9fa5·a-zA-Z]([\\u4e00-\\u9fa5·a-zA-Z]*$)")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkRealName(string: String): Boolean {
        if (string.contains("··"))
            return false
        val r1 = Regex("^[\\u4e00-\\u9fa5]([\\u4e00-\\u9fa5·]{1,20}$)+(?<!·)")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkBankBranch(string: String): Boolean {
        val r1 = Regex("^[-/0-9a-zA-Z\\u4e00-\\u9fa5]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkPoint(string: String): Boolean {
        val r1 = Regex("^[，,.。*、]*$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkPointCardNumber(string: String): Boolean {
        val r1 = Regex("^[0-9a-zA-Z]{6,45}$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkPointCardPassword(string: String): Boolean {
        val r1 = Regex("^[0-9a-zA-Z]{6,25}$")
        return r1.matches(string)
    }

    @JvmStatic
    fun checkPassword(string: String): Boolean {
        val r1 = Regex("^[0-9a-zA-Z]{6,16}$")
        return r1.matches(string)
    }

    fun formatPhoneNumber(phoneNumber: String): Int {
        var result = 0
        result = if (!TextUtils.isEmpty(phoneNumber)) {
            if (phoneNumber.trim().length == 11) {
                val r1 = Regex("^((13[0-9])|(15[^4])|(18[0-9])|(17[0-8])|(19[8,9])|(166)|(14[5,7]))\\d{8}\$")
                if (r1.matches(phoneNumber)) {
                    0
                } else {
                    1
                }

            } else {
                1
            }

        } else {
            1
        }
        return result

    }

    @JvmStatic
    fun getPhoneNumber(number: String): String {
        val sb = StringBuilder()
        val charArray = number.toCharArray()

        charArray.forEachIndexed { index, c ->
            if (index in 1..12) {
                if (index < 4 && index % 3 == 0) {
                    sb.append(" $c")
                } else if ((index - 3) % 4 == 0) {
                    sb.append(" $c")
                } else {
                    sb.append(c)
                }


            } else {
                sb.append(c)
            }

        }
        return sb.toString()
    }

    @JvmStatic
    fun md5Encode(password: String): String {
        try {
            val instance: MessageDigest = MessageDigest.getInstance("MD5")//获取md5加密对象
            val digest: ByteArray = instance.digest(password.toByteArray())//对字符串加密，返回字节数组
            var sb = StringBuffer()
            for (b in digest) {
                var i: Int = b.toInt() and 0xff//获取低八位有效值
                var hexString = Integer.toHexString(i)//将整数转化为16进制
                if (hexString.length < 2) {
                    hexString = "0" + hexString//如果是一位的话，补0
                }
                sb.append(hexString)
            }
            return sb.toString()

        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }

        return ""
    }


    @JvmStatic
    fun getSign(uuid: String, qid: String): String {

        return getNormalSign(uuid, qid)


    }

    private fun getNormalSign(sort: String, qid: String): String {
        val sign = "$sort$qid${ProjectUtils.APPID}${BuildConfig.VERSION_NAME}${ConfigUtils.DOMAIN_NAME}${Utils.getToken()}${DeviceInfo.getDeviceId()}${ConfigUtils.parentId}"

        LogUtils.d(sign)
        return SignUtils.getSign(sign, qid, if (ApiClient.instance.baseUrl.contains(ConfigUtils.testUrl)){"1"} else{"0"})

    }


    @JvmStatic
    fun stringToBitmap(string: String?): Bitmap? {
        var bitmap: Bitmap? = null
        try {
            val input = Base64.decode(string, Base64.DEFAULT)
            bitmap = BitmapFactory.decodeByteArray(input, 0, input.size)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return bitmap
    }

    @JvmStatic
    fun getToken(): String {
        var token = ""
        if (!TextUtils.isEmpty(ConfigUtils.token)) {
            token = ConfigUtils.token!!
        } else if (!TextUtils.isEmpty(AppInitManager.getAcache().getAsString("token"))) {
            ConfigUtils.token = AppInitManager.getAcache().getAsString("token")
            token = ConfigUtils.token!!
        }
        return token
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */

    @JvmStatic
    fun formatMoney(amount: String?): String {
        var temp = StringBuffer()
        if (!TextUtils.isEmpty(amount)) {
            return formatMoney(amount!!.toFloat(), false)
        }
        return temp.append("0.00").toString()
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: Float): String {
        var temp = StringBuffer()
        val decimalFormat = DecimalFormat(".00")
        var p = decimalFormat.format(amount)
        when {
            amount == 0f -> {
                temp.append("0")
                temp.append(p)
            }
            (amount < 1.0f && amount > 0f) -> {
                temp.append("0")
                temp.append(p)
            }
            (amount > 0f && amount < 1000.0f) -> temp.append(p)
            amount < 0f -> {
                when {
                    amount > -1000 -> {
                        temp.append(p)
                    }
                    else -> {
                        p = p.replaceFirst("-", "")
                        val txt = p.split(".")
                        var charArray = txt[0].toCharArray()
                        charArray.reverse()
                        charArray.forEachIndexed { index, c ->
                            if (index % 3 == 0 && index != 0) {
                                temp.insert(0, "$c,")
                            } else {
                                temp.insert(0, c)
                            }
                        }

                        temp.insert(0, "-")
                        temp.append(".${txt[1]}")
                    }
                }
            }
            else -> {
                val txt = p.split(".")
                var charArray = txt[0].toCharArray()
                charArray.reverse()
                charArray.forEachIndexed { index, c ->
                    if (index % 3 == 0 && index != 0) {
                        temp.insert(0, "$c,")
                    } else {
                        temp.insert(0, c)
                    }
                }

                temp.append(".${txt[1]}")
            }
        }



        return "¥ $temp"
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: BigDecimal): String {
        var temp = StringBuffer()
        val decimalFormat = DecimalFormat(".00")
        var p = decimalFormat.format(amount)
        when {
            amount.toFloat() == 0.00f -> {
                temp.append("0")
                temp.append(p)
            }
            (amount < BigDecimal(1.00) && amount > BigDecimal(0.00)) -> {
                temp.append("0")
                temp.append(p)
            }
            (amount > BigDecimal(0.00) && amount < BigDecimal(1000.00)) -> temp.append(p)
            amount < BigDecimal(0.00) -> {
                when {
                    amount > BigDecimal(-1000.00) -> {
                        temp.append(p)
                    }
                    else -> {
                        p = p.replaceFirst("-", "")
                        val txt = p.split(".")
                        var charArray = txt[0].toCharArray()
                        charArray.reverse()
                        charArray.forEachIndexed { index, c ->
                            if (index % 3 == 0 && index != 0) {
                                temp.insert(0, "$c,")
                            } else {
                                temp.insert(0, c)
                            }
                        }

                        temp.insert(0, "-")
                        temp.append(".${txt[1]}")
                    }
                }
            }
            else -> {
                val txt = p.split(".")
                var charArray = txt[0].toCharArray()
                charArray.reverse()
                charArray.forEachIndexed { index, c ->
                    if (index % 3 == 0 && index != 0) {
                        temp.insert(0, "$c,")
                    } else {
                        temp.insert(0, c)
                    }
                }

                temp.append(".${txt[1]}")
            }
        }



        return "¥ $temp"
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: Float, hasLabel: Boolean): String {
        return if (!hasLabel) formatMoney(amount).replaceFirst("¥ ", "") else formatMoney(amount)
    }


    /**
     * 格式化账户金额显示
     * @amount 金额
     */
    @JvmStatic
    fun formatMoney(amount: BigDecimal, hasLabel: Boolean): String {
        return if (!hasLabel) formatMoney(amount).replaceFirst("¥ ", "") else formatMoney(amount)
    }

    /**
     * 获取当前的网络状态 ：没有网络-0：WIFI网络1：4G网络-4：3G网络-3：2G网络-2
     * 自定义
     *
     * @param context
     * @return
     */
    fun getAPNType(context: Context): Int {
        //结果返回值
        var netType = 0
        //获取手机所有连接管理对象
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        //获取NetworkInfo对象
        val networkInfo = manager.activeNetworkInfo ?: return netType
        //NetworkInfo对象为空 则代表没有网络
        //否则 NetworkInfo对象不为空 则获取该networkInfo的类型
        val nType = networkInfo.type
        if (nType == ConnectivityManager.TYPE_WIFI) {
            //WIFI
            netType = 1
        } else if (nType == ConnectivityManager.TYPE_MOBILE) {
            val nSubType = networkInfo.subtype
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            //3G   联通的3G为UMTS或HSDPA 电信的3G为EVDO
            if (nSubType == TelephonyManager.NETWORK_TYPE_LTE && !telephonyManager.isNetworkRoaming) {
                netType = 4
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_UMTS
                    || nSubType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || nSubType == TelephonyManager.NETWORK_TYPE_EVDO_0 && !telephonyManager.isNetworkRoaming) {
                netType = 3
                //2G 移动和联通的2G为GPRS或EGDE，电信的2G为CDMA
            } else if (nSubType == TelephonyManager.NETWORK_TYPE_GPRS
                    || nSubType == TelephonyManager.NETWORK_TYPE_EDGE
                    || nSubType == TelephonyManager.NETWORK_TYPE_CDMA && !telephonyManager.isNetworkRoaming) {
                netType = 2
            } else {
                netType = 2
            }
        }
        return netType
    }

    //使用的网络类型
    @JvmStatic
    fun getAPNTypeString(): String {
        val context = MyApplication.instance
        val type = getAPNType(context!!)
        return when (type) {
            0 -> context.getString(R.string.hybrid_net_no)
            1 -> context.getString(R.string.hybrid_net_wifi)
            2 -> context.getString(R.string.hybrid_net_2g)
            3 -> context.getString(R.string.hybrid_net_3g)
            4 -> context.getString(R.string.hybrid_net_4g)
            else -> context.getString(R.string.hybrid_net_unkonw)
        }
    }

    @JvmStatic
    fun formatBankNumber(number: String): String {
        val sb = StringBuilder()
        val charArray = number.toCharArray()

        charArray.forEachIndexed { index, c ->
            if (index > 0 && index % 4 == 0) {
                sb.append(" $c")
            } else {
                sb.append(c)
            }

        }
        return sb.toString()
    }


    @JvmStatic
    fun goOnlineCustomerService() {
        val intent = Intent(MyApplication.getinstance(), BrowserActivity::class.java)
        intent.putExtra(BrowserActivity.PARAM_URL, ConfigUtils.onlineCustomerUrl)
        intent.putExtra(BrowserActivity.PARAM_IS_ONLINE_CUSTOMER_SERVICE, true)
        intent.putExtra(BrowserActivity.PARAM_FULL_SCREEN, true)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        MyApplication.instance?.startActivity(intent)

    }

    private var lastClickTime: Long = 0
    @JvmStatic
    fun isFastDoubleClick(): Boolean {
        val time = System.currentTimeMillis()
        val timeD = time - lastClickTime
        if (timeD in 1..2000) {
            return true
        }
        lastClickTime = time
        return false
    }


    @JvmStatic
    fun getImei(): String {
        var temp = StringBuffer()
        if (null != getTelephonyManager()) {
            val imei = sTelephonyManager?.deviceId
            if (imei != null) {
                temp.append(imei)
            }
        }
        return temp.toString()
    }

    fun getFileMD5(file: File): String? {
        if (!file.isFile) {
            return null
        }
        var digest: MessageDigest? = null
        var inp: FileInputStream? = null
        val buffer = ByteArray(1024)
        var len: Int
        try {
            digest = MessageDigest.getInstance("MD5")
            inp = FileInputStream(file)
            len = inp.read(buffer, 0, 1024)
            while (len != -1) {
                digest!!.update(buffer, 0, len)
                len = inp.read(buffer, 0, 1024)
            }
            inp!!.close()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return bytesToHexString(digest!!.digest())
    }


    private fun bytesToHexString(src: ByteArray?): String? {
        val stringBuilder = StringBuilder("")
        if (src == null || src.isEmpty()) {
            return null
        }
        for (i in src.indices) {
            val v = src[i].toInt() and 0xFF
            val hv = Integer.toHexString(v)
            if (hv.length < 2) {
                stringBuilder.append(0)
            }
            stringBuilder.append(hv)
        }
        return stringBuilder.toString()
    }


}



