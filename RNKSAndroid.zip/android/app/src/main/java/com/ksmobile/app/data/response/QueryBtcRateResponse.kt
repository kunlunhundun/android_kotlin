package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryBtcRateResponse : BaseResponseObject() {
    val body = Body()

    class Body {
        var amount: String? = null
        var btcAmount: String? = null
        var btcCurrency: String? = null
        var btcRate: String? = null
        var btcUuid: String? = null
        var currency: String? = null
        var payid: String? = null

    }

}
