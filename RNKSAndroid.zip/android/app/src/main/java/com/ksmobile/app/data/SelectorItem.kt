package com.ksmobile.app.data

 interface SelectorItem {
     fun getTitle():String
     fun hasChild():Boolean
     fun getImageLeft():String?
     fun getChildItems():List<SelectorItem>?
}