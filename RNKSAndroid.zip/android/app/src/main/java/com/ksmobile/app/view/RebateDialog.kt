package com.ksmobile.app.view

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.v7.widget.LinearLayoutManager
import android.text.TextUtils
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.gson.Gson
import com.jcodecraeer.xrecyclerview.XRecyclerView
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.components.support.RxDialogFragment
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.adapter.RebateDetailAdapter
import com.ksmobile.app.adapter.RebateResultDetailAdapter
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.IRebateInfo
import com.ksmobile.app.data.RebateHead
import com.ksmobile.app.data.request.CreatWashCodeProposalRequest
import com.ksmobile.app.data.request.WashCodeCreatRequest
import com.ksmobile.app.data.response.CreatCodeProposalResponse
import com.ksmobile.app.data.response.WashCodeCreatResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.NavigationBarUtils
import com.ksmobile.app.util.StatusBarUtil
import com.ksmobile.app.util.Utils
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/11/09.
 */

class RebateDialog : RxDialogFragment() {

    var creatRquest = CreatWashCodeProposalRequest()
    var washCodeCreatResponse: WashCodeCreatResponse? = null
    lateinit var rebate_view: LinearLayout
    lateinit var image_close: ImageView
    lateinit var rebate_result: ConstraintLayout
    lateinit var rebate_view_real_result: ConstraintLayout
    lateinit var cl_rebate_detail_show: ConstraintLayout
    lateinit var tv_sure: TextView
    lateinit var tv_cancle: TextView
    lateinit var tv_ok: TextView
    lateinit var tv_tip: TextView
    lateinit var tv_user_name: TextView
    lateinit var tv_user_level: TextView
    lateinit var tv_amount_number: ScrollingDigitalAnimation
    lateinit var tv_amount_number_add: TextView
    lateinit var tv_detail: TextView
    lateinit var rebate_tv_amount: TextView
    lateinit var tv_amount: TextView
    lateinit var lv_detail: XRecyclerView
    lateinit var lv_result: XRecyclerView
    lateinit var cl_list:ConstraintLayout
    lateinit var line_div: View
    lateinit var my_top_confirm: MyTopComfirmDialog
    lateinit var circle_progress_first: ProgressBar
    lateinit var view_padding: TextView
    lateinit var view_bg: RealtimeBlurView

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(activity, R.style.MyDialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 设置Content前设定
        dialog.setContentView(R.layout.view_rebeat_dialog)
        val bundle = arguments
        if (!TextUtils.isEmpty(bundle?.getString("data"))) {
            washCodeCreatResponse = Gson().fromJson(bundle?.getString("data"), WashCodeCreatResponse::class.java)
        }

        initCommonView(dialog)
        dialog.setCanceledOnTouchOutside(false) // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        val window = dialog.window
        setTranslucentStatus(window)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = window.attributes
        lp.width = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.gravity = Gravity.CENTER
        window.attributes = lp
        return dialog
    }


    private fun initCommonView(dialog: Dialog) {
        rebate_view = dialog.findViewById(R.id.rebate_view)
        rebate_result = dialog.findViewById(R.id.rebate_result)
        rebate_view_real_result = dialog.findViewById(R.id.rebate_view_real_result)
        tv_sure = dialog.findViewById(R.id.tv_sure)
        tv_user_level = dialog.findViewById(R.id.tv_user_level)
        tv_user_name = dialog.findViewById(R.id.tv_user_name)
        tv_cancle = dialog.findViewById(R.id.tv_cancle)
        tv_ok = dialog.findViewById(R.id.tv_ok)
        tv_tip = dialog.findViewById(R.id.tv_tip)
        tv_amount_number = dialog.findViewById(R.id.tv_amount_number)
        tv_amount_number_add = dialog.findViewById(R.id.tv_amount_number_add)
        lv_detail = dialog.findViewById(R.id.lv_detail)
        cl_list = dialog.findViewById(R.id.cl_list)
        tv_detail = dialog.findViewById(R.id.tv_detail)
        line_div = dialog.findViewById(R.id.line_div)
        rebate_tv_amount = dialog.findViewById(R.id.rebate_tv_amount)
        my_top_confirm = dialog.findViewById(R.id.my_top_confirm)
        tv_amount = dialog.findViewById(R.id.tv_amount)
        lv_result = dialog.findViewById(R.id.lv_result)
        image_close = dialog.findViewById(R.id.image_close)
        circle_progress_first = dialog.findViewById(R.id.circle_progress_first)
        cl_rebate_detail_show = dialog.findViewById(R.id.cl_rebate_detail_show)
        view_bg = dialog.findViewById(R.id.view_bg)
        view_padding = dialog.findViewById(R.id.view_padding)
        if (NavigationBarUtils.isNavigationBarShow(activity!!)) {
            view_padding.height = Dip2PixleUtil.dp2px(context, 50f)
        }


        showRebatePreview()


    }

    /**
     * 展示确认弹窗
     */
    private fun showRebatePreview() {
        val animation = AnimationUtils.loadAnimation(context, R.anim.common_fragment_show_anim)
        rebate_view.startAnimation(animation)
        rebate_view.visibility = View.VISIBLE
        if (null == washCodeCreatResponse) {
            request()
        } else {
            initRebateView(washCodeCreatResponse!!)
        }


        tv_sure.setOnClickListener {

            NotifyDialog.show(activity!!, "单一游戏类型投注额不足300，请投注满额后再试")
            NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                override fun onHidden() {
                    dismiss()
                }

            })

        }
        tv_cancle.setOnClickListener {
            dismiss()
        }

        image_close.setOnClickListener {
            dismiss()
        }
    }

    /**
     * 展示洗码动画
     */

    private fun showRebateInfo() {
        rebate_result.visibility = View.VISIBLE
        rebate_view.visibility = View.GONE
        tv_user_name.text = ConfigUtils.loginName
        tv_user_level.text = ConfigUtils.starLevel
        tv_amount_number.text = ConfigUtils.balance.balance
        tv_amount_number_add.text = "+${rebate_tv_amount.text}"



        Handler().postDelayed({
            tv_amount_number_add.visibility = View.GONE
            tv_amount_number.setNumberString(ConfigUtils.balance.balance, (BigDecimal(ConfigUtils.balance.balance) + BigDecimal(rebate_tv_amount.text.toString())).toString())
            tv_amount_number.setDuration(3000)
        }, 1000)

    }

    /**
     * 展示结果
     */

    private fun showRebateResult() {
        Handler().postDelayed({
            rebate_view_real_result.visibility = View.VISIBLE
        }, 4000)

        tv_ok.setOnClickListener {
            dismiss()
        }


    }

    /**
     * 查询洗码金额
     */

    private fun request() {
        val request = WashCodeCreatRequest()
        ApiClient.instance.service.creatWashCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<WashCodeCreatResponse>(activity!!, false) {
                    override fun businessFail(data: WashCodeCreatResponse) {
                        NotifyDialog.show(activity!!, "系统繁忙，请稍后再试")
                        NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                            override fun onHidden() {
                                dismiss()
                            }
                        })


                    }

                    override fun businessSuccess(data: WashCodeCreatResponse) {
                        if (data.body?.xmList?.isEmpty()!!) {
                            return
                        } else {
                            initRebateView(data)

                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(activity!!, getString(R.string.unexpected_error))
                        NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                            override fun onHidden() {
                                dismiss()
                            }
                        })
                    }


                })
    }


    private fun requestEnd() {
        ApiClient.instance.service.creatWashCodeProposal(creatRquest)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatCodeProposalResponse>(activity!!, false) {
                    override fun businessFail(data: CreatCodeProposalResponse) {

                        if (data.head.errCode.equals("GW_801702")) {
                            showConfirmNotify()

                        } else {

                            NotifyDialog.show(activity!!, data.head.errMsg)
                            NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                                override fun onHidden() {
                                    dismiss()
                                }

                            })

                        }
                    }

                    override fun businessSuccess(data: CreatCodeProposalResponse) {
                        showRebateInfo()
                        showRebateResult()
                        tv_amount.text = data.body.xmAmount.toString()
                        val list = mutableListOf<IRebateInfo>()
                        list.add(RebateHead("游戏", "状态", "洗码金额", "洗码比例"))
                        list.addAll(data.body.xmResult)
                        val layoutManager = LinearLayoutManager(activity)
                        layoutManager.orientation = LinearLayoutManager.VERTICAL
                        lv_result.layoutManager = layoutManager
                        lv_result.setPullRefreshEnabled(false)
                        lv_result.setLoadingMoreEnabled(false)
                        var adapter = RebateResultDetailAdapter(context!!, list)
                        lv_result.adapter = adapter


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        dismiss()
                        NotifyDialog.show(activity!!, apiErrorModel.message)

                    }

                })
    }


    private fun showConfirmNotify() {
        cl_rebate_detail_show.visibility = View.VISIBLE
        circle_progress_first.visibility = View.GONE
        my_top_confirm.setTipTitle("您的自助洗码功能尚未激活，请联系客服!")
        my_top_confirm.setSureText("联系客服")
        my_top_confirm.setCancelText("")
        my_top_confirm.setSureListener(View.OnClickListener {
            my_top_confirm.hidden()
            Utils.goOnlineCustomerService()
        })
        my_top_confirm.show()


    }

    private fun setTranslucentStatus(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }

        StatusBarUtil.StatusBarLightMode(window)
    }

    private fun initRebateView(data: WashCodeCreatResponse) {
        tv_tip.text = "单一游戏类型可洗码投注额需≥${data.body?.minBetAmount}"
        circle_progress_first.visibility = View.GONE
        cl_rebate_detail_show.visibility = View.VISIBLE
        rebate_tv_amount.text = data.body?.totalXmAmount.toString()
        val list = mutableListOf<IRebateInfo>()
        list.add(RebateHead("游戏", "洗码金额", "洗码比例", "投注额"))
        list.addAll(data.body?.xmList!!)
        val layoutManager = LinearLayoutManager(activity)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        lv_detail.layoutManager = layoutManager
        lv_detail.setPullRefreshEnabled(false)
        lv_detail.setLoadingMoreEnabled(false)
        var adapter = RebateDetailAdapter(context!!, list, data.body!!.minBetAmount)
        lv_detail.adapter = adapter
        tv_detail.setOnClickListener {
            if (lv_detail.visibility == View.VISIBLE) {
                tv_detail.text = "详细展开"
                cl_list.visibility = View.GONE

                lv_detail.visibility = View.GONE
                line_div.visibility = View.GONE
            } else {
                tv_detail.text = "点击收起"
                cl_list.visibility = View.VISIBLE
                lv_detail.visibility = View.VISIBLE
                line_div.visibility = View.VISIBLE
            }
            val rightDrawable = if (lv_detail.visibility == View.GONE) {
                resources.getDrawable(R.mipmap.arrow_down)
            } else {
                resources.getDrawable(R.mipmap.arrow_up)
            }
            rightDrawable.setBounds(0, 0, rightDrawable.minimumWidth, rightDrawable.minimumHeight)
            tv_detail.setCompoundDrawables(null, null, rightDrawable, null)

        }

        creatRquest.xmBeginDate = data.body?.xmBeginDate
        creatRquest.xmEndDate = data.body?.xmEndDate

        data.body?.xmList!!.forEach { it ->

            it.xmTypes.forEach {

                if (it.xmAmount > BigDecimal(0.99)) {
                    creatRquest.xmRequests.add(it)
                }

            }

        }

        if (!creatRquest.xmRequests.isEmpty()) {

            tv_tip.text = "洗码金额会在提交后10分钟内到账"
            tv_sure.setOnClickListener {
                circle_progress_first.visibility = View.VISIBLE
                cl_rebate_detail_show.visibility = View.GONE
                requestEnd()
            }
        }

    }
}

