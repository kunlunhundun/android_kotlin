package com.ksmobile.app.view

import android.Manifest
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.view.*
import com.trello.rxlifecycle2.components.support.RxDialogFragment
import com.ksmobile.app.R
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import android.content.Intent
import android.net.Uri
import android.support.annotation.NonNull
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.widget.*
import com.github.dfqin.grantor.PermissionListener
import com.github.dfqin.grantor.PermissionsUtil
import com.jxccp.lib.sip.CallApi
import com.jxccp.lib.sip.util.SettingUtils
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.activity.CallActivity
import com.ksmobile.app.activity.ConfigActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.CallBackRequest
import com.ksmobile.app.data.response.CallBackResponse
import com.ksmobile.app.util.*
import com.ksmobile.app.view.iview.IDialog


/**
 * Created by ward.y on 2018/11/09.
 */

class CustomerServiceDialog : RxDialogFragment(), IDialog {

    lateinit var tv_cancel: TextView
    lateinit var hot_line_close: ImageView
    lateinit var image_close: ImageView
    lateinit var tv_dismiss: TextView
    lateinit var line_bottom: TextView
    lateinit var tv_call: MyButton
    lateinit var tv_confirm_recall: MyButton
    lateinit var cl_recall: ConstraintLayout
    lateinit var cl_online_customer_service: ConstraintLayout
    lateinit var cl_customer_service_phone: ConstraintLayout
    lateinit var cl_voice: ConstraintLayout
    lateinit var main_customer: LinearLayout
    lateinit var hot_line: LinearLayout
    lateinit var recall_customer: LinearLayout
    lateinit var et_phone_number: EditText
    lateinit var my_notify_view: MyTopNotifyView
    lateinit var view_bg: RealtimeBlurView
    lateinit var view_padding: TextView
    lateinit var content: RelativeLayout
    val KEY_UID = "key_uid"
    val KEY_CALL_NUMBER = "key_call_number"
    //屏幕高度
    var screenHeight = 0
    //软件盘弹起后所占高度阀值
    var keyHeight = 0

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(activity, R.style.MyDialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 设置Content前设定
        dialog.setContentView(R.layout.view_customer_service_dialog)
        initCommonView(dialog)
        dialog.setCanceledOnTouchOutside(true) // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        val window = dialog.window
        setTranslucentStatus(window)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = window.attributes
        lp.width = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.gravity = Gravity.CENTER
        window.attributes = lp
        return dialog
    }


    private fun initCommonView(dialog: Dialog) {
        //获取屏幕高度
        screenHeight = activity!!.windowManager.defaultDisplay.height
        //阀值设置为屏幕高度的1/3
        keyHeight = screenHeight / 3
        tv_cancel = dialog.findViewById(R.id.tv_cancel)
        cl_recall = dialog.findViewById(R.id.cl_recall)
        cl_online_customer_service = dialog.findViewById(R.id.cl_online_customer_service)
        cl_customer_service_phone = dialog.findViewById(R.id.cl_customer_service_phone)
        main_customer = dialog.findViewById(R.id.main_customer)
        hot_line = dialog.findViewById(R.id.hot_line)
        recall_customer = dialog.findViewById(R.id.recall_customer)
        my_notify_view = dialog.findViewById(R.id.my_notify_view)
        view_bg = dialog.findViewById(R.id.view_bg)
        cl_voice = dialog.findViewById(R.id.cl_voice)
        view_padding = dialog.findViewById(R.id.view_padding)
        content = dialog.findViewById(R.id.content)

        if (NavigationBarUtils.isNavigationBarShow(activity!!)) {
            view_padding.height = Dip2PixleUtil.dp2px(context, 50f)
        }

        tv_cancel.setOnClickListener {
            dismiss()
        }

        view_bg.setOnClickListener {
            dismiss()
        }

        cl_recall.setOnClickListener {
            showCallback()
        }
        cl_online_customer_service.setOnClickListener {
            Utils.goOnlineCustomerService()
            dismiss()

        }
        cl_customer_service_phone.setOnClickListener {
            showHotLine()
        }

        cl_voice.setOnClickListener {
            requestPhoneState()
        }

    }


    private fun showHotLine() {
        hot_line.visibility = View.VISIBLE
        main_customer.visibility = View.GONE
        hot_line_close = dialog.findViewById(R.id.hot_line_close)
        tv_dismiss = dialog.findViewById(R.id.tv_dismiss)
        tv_call = dialog.findViewById(R.id.tv_call)
        hot_line_close.setOnClickListener { dismiss() }
        tv_dismiss.setOnClickListener { dismiss() }
        tv_call.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:400-1200-667"))
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)

        }

    }

    private fun showCallback() {
        main_customer.visibility = View.GONE
        recall_customer.visibility = View.VISIBLE
        image_close = dialog.findViewById(R.id.image_close)
        et_phone_number = dialog.findViewById(R.id.et_phone_number)
        line_bottom = dialog.findViewById(R.id.line_bottom)
        tv_confirm_recall = dialog.findViewById(R.id.tv_confirm_recall)
        tv_confirm_recall.isEnabled = false
        image_close.setOnClickListener { dismiss() }
        if (ConfigUtils.isBindMobile) {
            et_phone_number.setText(ConfigUtils.mobileNo)
            tv_confirm_recall.isEnabled = true
        }

        et_phone_number.addTextChangedListener(object : TextWatcher {
            var mCount = 0
            override fun afterTextChanged(s: Editable) {
                if (s.contains("*")) {
                    s.clear()
                }

                tv_confirm_recall.isEnabled = s.length == 13 && isPhoneNumberValid(s.toString().replace(" ", ""))
                var length = s.toString().length
                //删除数字
                if (mCount == 0) {
                    if (length == 4) {
                        et_phone_number.setText(s.subSequence(0, 3))
                    }
                    if (length == 9) {
                        et_phone_number.setText(s.subSequence(0, 8))
                    }
                }
                //添加数字
                if (mCount == 1) {
                    if (length == 4) {
                        var part1 = s.subSequence(0, 3).toString()
                        var part2 = s.subSequence(3, length).toString()
                        et_phone_number.setText("$part1 $part2")
                    }
                    if (length == 9) {
                        var part1 = s.subSequence(0, 8).toString()
                        var part2 = s.subSequence(8, length).toString()
                        et_phone_number.setText("$part1 $part2")
                    }
                }

                et_phone_number.setSelection(et_phone_number.text.toString().length)
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, count: Int) {
                mCount = count

            }

            override fun onTextChanged(s: CharSequence, p1: Int, p2: Int, p3: Int) {


            }
        })

        tv_confirm_recall.setOnClickListener {

            if (et_phone_number.text.contains("**")) {
                callBack("")
            } else {
                callBack(et_phone_number.text.toString())
            }


        }

    }


    private fun showNotify() {
        view_bg.visibility = View.INVISIBLE
        my_notify_view.setTip("客服将在1分钟内致电，请保持电话畅通")
        my_notify_view.show()
        my_notify_view.setOnHiddenCallBack(object : MyTopNotifyView.IHinddenCallback {
            override fun onHidden() {
                dismiss()
            }

        })
    }

    private fun isPhoneNumberValid(phoneNumber: String): Boolean {
        return phoneNumber.length == 11 && Utils.formatPhoneNumber(phoneNumber) == 0
    }

    /**
     * 电话回拨
     */
    private fun callBack(mobielNum: String) {
        val request = CallBackRequest()
        if (TextUtils.isEmpty(mobielNum)) {
            request.type = 1
        } else {
            request.mobileNo = mobielNum.replace(" ", "")
        }

        ApiClient.instance.service.callBack(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<CallBackResponse>(activity!!, true) {
                    override fun businessFail(data: CallBackResponse) {
                        ToastUtils.show(data.head.errMsg)

                    }

                    override fun businessSuccess(data: CallBackResponse) {

                        recall_customer.visibility = View.GONE
                        showNotify()


                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ToastUtils.show(apiErrorModel.message)
                    }

                })

    }


    private fun requestPhoneState() {
        PermissionsUtil.requestPermission(activity, object : PermissionListener {
            override fun permissionGranted(@NonNull permissions: Array<String>) {
                CallApi.setAudioCodec(SettingUtils.get(activity, ConfigActivity.AUDIOCODEC_CONFIG, null))
                CallApi.setAecEnable(SettingUtils.get(activity, ConfigActivity.AUDIO_AEC_CONFIG, false))
                CallApi.setNsEnable(SettingUtils.get(activity, ConfigActivity.AUDIO_NS_ONFIG, false))
                CallApi.setAgcEnable(SettingUtils.get(activity, ConfigActivity.AUDIO_AGC_CONFIG, false))
                SettingUtils.set(activity, KEY_UID, ConfigUtils.customerId)
                SettingUtils.set(activity, KEY_CALL_NUMBER, "7770755566610601")
                CallActivity.startCall(activity!!, "7770755566610601", ConfigUtils.customerId!!)

            }

            override fun permissionDenied(@NonNull permissions: Array<String>) {
                ToastUtils.show("请先允许所需权限")
            }
        }, Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO)
    }

    private fun setTranslucentStatus(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }

        StatusBarUtil.StatusBarLightMode(window)
    }


    override fun onLayoutChange(show: Boolean) {
        if (null == activity) {
            return
        }
        if (show) {
            view_padding.height = Dip2PixleUtil.dp2px(activity, 350f)
        } else {
            if (NavigationBarUtils.isNavigationBarShow(activity!!)) {
                view_padding.height = Dip2PixleUtil.dp2px(activity, 50f)
            } else {
                view_padding.height = Dip2PixleUtil.dp2px(activity, 0f)
            }
        }

    }
}

