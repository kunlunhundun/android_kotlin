package com.ksmobile.app.fragment

import android.content.Intent
import android.os.Bundle
import com.trello.rxlifecycle2.components.support.RxFragment

abstract class LazyLoadFragment : RxFragment() {
    private var isViewInitiated: Boolean = false
    private var isDataLoaded: Boolean = false
    private val isAddActivityList = "isAddActivityList"
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        isViewInitiated = true
        prepareRequestData()
        repeatLoad()
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        prepareRequestData()
        repeatLoad()
    }

    abstract fun requestData()
    abstract fun repeat()
    open fun prepareRequestData(forceUpdate: Boolean = false): Boolean {
        if (userVisibleHint && isViewInitiated && (!isDataLoaded || forceUpdate)) {
            requestData()
            isDataLoaded = true
            return true
        }
        return false
    }

    open fun repeatLoad() {
        if (userVisibleHint && isViewInitiated ) {
            repeat()
        }
    }

    /**
     * 跳转页面方法，方便加入Activity管理
     * @param isAdd false 为不加入管理
     */

    fun goToPage(intent: Intent, isAdd: Boolean) {
        checkActivityAttached()
        intent.putExtra(isAddActivityList, isAdd)
        startActivity(intent)

    }

    fun goToPageForResult(intent: Intent, isAdd: Boolean, requstCode: Int) {
        intent.putExtra(isAddActivityList, isAdd)
        startActivityForResult(intent, requstCode)
    }

    /**
     * 跳转页面方法，方便加入Activity管理
     */

    fun goToPage(intent: Intent) {

        goToPage(intent, true)

    }


    protected fun isAttachedContext(): Boolean {
        return activity != null
    }

    /**
     * 检查activity连接情况
     */
    fun checkActivityAttached() {
        if (activity == null) {
            throw ActivityNotAttachedException()
        }
    }

    class ActivityNotAttachedException : RuntimeException("Fragment has disconnected from Activity ! - -.")
}