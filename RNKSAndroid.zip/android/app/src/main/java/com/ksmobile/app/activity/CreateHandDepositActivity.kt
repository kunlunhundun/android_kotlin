package com.ksmobile.app.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.aigestudio.wheelpicker.widgets.WheelDatePicker
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.adapter.CommonWheelAdapter
import com.ksmobile.app.data.WheelTextObjet
import com.ksmobile.app.data.request.CreateHandDepositRequest
import com.ksmobile.app.data.response.CreateHandDepositResponse
import com.ksmobile.app.data.response.QueryBanksResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.MyWheelView
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_create_hand_deposit.*

class CreateHandDepositActivity : BaseToolBarActivity() {
    val reqCode = 100
    var bankInfo: QueryBanksResponse.Bean? = null
    val payWays = mutableListOf("柜台转账", "ATM转账", "网银转账", "电话转账", "跨行转账", "跨行转账", "自动终端机", "手机转账", "支付宝转账", "其他方式")
    override fun getLayoutId(): Int {
        return R.layout.activity_create_hand_deposit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.create_hand_deposit_title))
        setActionText("联系客服")
        setActionIcon(R.mipmap.icon_customer_service)


    }

    override fun initView() {
        if (!TextUtils.isEmpty(intent.getStringExtra("bankInfo"))) {
            bankInfo = Gson().fromJson(intent.getStringExtra("bankInfo"), QueryBanksResponse.Bean::class.java)
        }

        if (!TextUtils.isEmpty(intent.getStringExtra("money"))) {
            et_deposit_amount.setEditText(intent.getStringExtra("money"))
        }

    }

    override fun initListener() {
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        et_deposit_type.setOnClickListener {
            showPopupWindow(it, 0)
        }

        et_deposit_time.setOnClickListener {
            showPopupWindow(it, 1)
        }

        et_deposit_address.setOnClickListener {
            val intent = Intent(this, CustomSelectorActivity::class.java)
            intent.putExtra(CustomSelectorActivity.SELECTOR_TYPE, CustomSelectorActivity.CITY)
            startActivityForResult(intent, reqCode)
        }

        et_deposit_amount.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (TextUtils.isEmpty(et_deposit_amount.getEditTextContent())) {
                    et_deposit_amount.showError("存款金额不能为空")
                }
            }

        }

        et_depositor.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                if (!Utils.checkRealName(et_depositor.getEditTextContent())) {
                    et_depositor.showError("请输入正确的存款人")
                }
            }
        }

        et_depositor.getEditText().addTextChangedListener(textWatcher)

        btn_commit.setOnClickListener {
            var cancel = false
            et_deposit_amount.hideError()
            et_deposit_type.hideError()
            et_depositor.hideError()
            et_deposit_time.hideError()
            et_deposit_address.hideError()

            when {
                TextUtils.isEmpty(et_deposit_amount.getEditTextContent()) -> {
                    et_deposit_amount.showError("存款金额不能为空")
                    cancel = true
                }

                TextUtils.isEmpty(et_deposit_type.getEditTextContent()) -> {
                    et_deposit_type.showError("存款方式不能为空")
                    cancel = true
                }

                !Utils.checkRealName(et_depositor.getEditTextContent()) -> {
                    et_depositor.showError("请输入正确的存款人")
                    cancel = true
                }

                TextUtils.isEmpty(et_deposit_time.getEditTextContent()) -> {
                    et_deposit_time.showError("提交时间不能为空")
                    cancel = true
                }

                TextUtils.isEmpty(et_deposit_address.getEditTextContent()) -> {
                    et_deposit_address.showError("地址不能为空")
                    cancel = true
                }
            }

            if (cancel) {

            } else {
                request()
            }
        }
    }

    private fun request() {
        val request = CreateHandDepositRequest()
        request.amount = et_deposit_amount.getEditTextContent()
        request.depositor = et_depositor.getEditTextContent()
        request.bankCardId = bankInfo?.bankCardId
        request.depositDate = et_deposit_time.getEditTextContent()
        request.depositType = et_deposit_type.getEditTextContent()
        request.depositLocation = et_deposit_address.getEditTextContent()
        ApiClient.instance.service.createHandDeposit(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreateHandDepositResponse>(this, true) {
                    override fun businessFail(data: CreateHandDepositResponse) {
                        NotifyDialog.show(this@CreateHandDepositActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: CreateHandDepositResponse) {
                        var intent = Intent()
                        intent.setClass(this@CreateHandDepositActivity, OrderDetailActivity::class.java)
                        intent.putExtra("referenceId", data.body?.referenceId)
                        intent.putExtra("type", 1)
                        intent.putExtra("showButton", true)
                        startActivity(intent)
                        finish()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }


    private fun showPopupWindow(v: View, type: Int) {
        val layoutInflater = LayoutInflater.from(this@CreateHandDepositActivity)
        val view = layoutInflater.inflate(R.layout.view_popup_window_bank_picker, null)
        val cancel: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val ll_bottom_date_picker: RelativeLayout = view.findViewById(R.id.ll_bottom_date_picker)
        val bank_list: MyWheelView<WheelTextObjet> = view.findViewById(R.id.bank_list)
        val datePicker: WheelDatePicker = view.findViewById(R.id.datePicker)
        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        popupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        popupWindow.isOutsideTouchable = true
        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        popupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        when (type) {
            0 -> {

                val list = mutableListOf<WheelTextObjet>()
                payWays.forEach {
                    val bank = WheelTextObjet(it)
                    list.add(bank)
                }


                bank_list.setWheelAdapter(CommonWheelAdapter(this))
                bank_list.setWheelData(list)
                bank_list.setWheelSize(5)
                sure.setOnClickListener {
                    val bank = bank_list.selectionItem
                    et_deposit_type.setEditText(bank.text)
                    popupWindow.dismiss()
                }
            }

            1 -> {
                bank_list.visibility = View.GONE
                datePicker.visibility = View.VISIBLE
                sure.setOnClickListener {
                    et_deposit_time.setEditText(datePicker.selectDate)
                    popupWindow.dismiss()
                }
            }
        }


        // PopupWindow弹出位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)

        cancel.setOnClickListener { popupWindow.dismiss() }
        ll_bottom_date_picker.setOnClickListener { popupWindow.dismiss() }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode) {

            if (resultCode == Activity.RESULT_OK) {
                et_deposit_address.setEditText(data?.getStringExtra("value"))

            }
        }


    }


    private val textWatcher = object : TextWatcher {
        var beforeText = ""

        override fun afterTextChanged(s: Editable?) {
            val  temp = s.toString()
            if (!TextUtils.isEmpty(temp)) {

                if (!Utils.checkStringFullChinese(temp)) {
                    if (!TextUtils.isEmpty(beforeText) && Utils.checkPoint(temp[temp.lastIndex].toString())) {
                        if (!beforeText.endsWith("·")){
                            beforeText = "$beforeText·"
                        }

                    }
                    et_depositor.setEditText(beforeText)
                    et_depositor.getEditText().setSelection(et_depositor.getEditTextContent().length)
                } else {

                    if (beforeText.endsWith("·") && s.toString().endsWith("·") && (beforeText.length + 1 == s.toString().length)) {
                        et_depositor.setEditText(beforeText)
                        et_depositor.getEditText().setSelection(et_depositor.getEditTextContent().length)
                    }


                }
            }

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            beforeText = s.toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {


        }


    }

}