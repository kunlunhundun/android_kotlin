package com.ksmobile.app.data


import java.util.ArrayList

/**
 * Created by ward.y on 2018/4/11.
 */

class ProviceDatas {


    var provinces: List<ProvinceData> = ArrayList()
}
