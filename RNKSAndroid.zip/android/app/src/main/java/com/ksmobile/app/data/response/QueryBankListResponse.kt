package com.ksmobile.app.data.response

import com.ksmobile.app.data.BankCardData

class QueryBankListResponse : BaseResponseObject() {

    var body= mutableListOf<BankCardData>()




}
