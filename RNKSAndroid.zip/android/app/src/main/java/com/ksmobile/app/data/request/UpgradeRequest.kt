package com.ksmobile.app.data.request


class UpgradeRequest : BaseRequestObject() {
    var h5V: Int? = null
}