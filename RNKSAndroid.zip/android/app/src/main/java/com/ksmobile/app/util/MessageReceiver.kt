package com.ksmobile.app.util

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Vibrator
import com.ksmobile.app.MyApplication
import com.rea.push.utils.Cons
import com.ksmobile.app.activity.SplashActivity
import com.ksmobile.app.manager.AppInitManager

class MessageReceiver : BroadcastReceiver() {
    var mContext: Context? = null
    private lateinit var vibrator: Vibrator
    private lateinit var notificationManager: NotificationManager
    override fun onReceive(context: Context?, intent: Intent?) {
        vibrator = context?.getSystemService(Service.VIBRATOR_SERVICE) as Vibrator
        notificationManager = context?.getSystemService(Service.NOTIFICATION_SERVICE) as NotificationManager
        val action = intent?.action
        mContext = context
        when (action) {

            Cons.ACTION_MESSAGE -> {
                LogUtils.e("接收到了message")
                dealMessage(intent, action)
            }
            Cons.ACTION_CLICK -> {
                dealMessage(intent, action)
            }

        }

    }


    private fun dealMessage(intent: Intent?, type: String) {
        val id = intent?.getStringExtra("id")
        val title = intent?.getStringExtra("title")
        val content = intent?.getStringExtra("content")
        val url = intent?.getStringExtra("url")
        val jumptype = intent?.getStringExtra("type")
        when (type) {
            Cons.ACTION_CLICK -> {
                if (null!=MyApplication.instance&&MyApplication.getinstance().mActivityCount==0){
                    val mgr = mContext?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    val intent = Intent(mContext, SplashActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                    val restartIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_ONE_SHOT)
                    mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1, restartIntent) // 1秒钟后重启应用
                    AppInitManager.getActivityListManager().exitApp()

                }else{
                    val intent = Intent(mContext, SplashActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    mContext?.startActivity(intent)
                }


            }

            Cons.ACTION_MESSAGE -> {

            }
        }

    }


}