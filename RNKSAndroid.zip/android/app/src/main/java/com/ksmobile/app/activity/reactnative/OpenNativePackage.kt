package com.ksmobile.app.activity.reactnative

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.uimanager.ViewManager
import java.util.*


/**
 * Created by Ward.y on 2018/5/2.
 */

class OpenNativePackage : ReactPackage {

    var openNativeModule: OpenNative? = null
    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> {
        if (openNativeModule == null) {
            openNativeModule = OpenNative(reactContext)
        }
        val modules = ArrayList<NativeModule>()
        modules.add(openNativeModule!!)
        return modules
    }

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> {
        return Arrays.asList(

        )
    }
}
