package com.ksmobile.app.activity.reactnative

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.text.TextUtils
import android.view.WindowManager
import com.facebook.react.bridge.*
import com.google.gson.Gson
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.view.RebateDialog
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ksmobile.app.BuildConfig
import com.ksmobile.app.MyApplication
import com.ksmobile.app.activity.*
import com.ksmobile.app.data.*
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.NetWorkUtil
import com.ksmobile.app.util.DeviceInfo
import com.ksmobile.app.util.RSATool
import com.ksmobile.app.util.Utils
import common.util.sign.SignUtils
import com.ksmobile.app.data.request.InGameRequest
import com.ksmobile.app.view.hybride.BrowserActivity
import com.rea.push.helper.PushHelper


/**
 * Created by ward on 2018/5/2.
 */

class OpenNative(context: ReactApplicationContext) : ReactContextBaseJavaModule(context) {

    private val isAddActivityList = "isAddActivityList"


    companion object {
        private var mReactContext: ReactContext? = null
        private var rnPage: RNPageActivity? = null
        fun registerRNpage(page: RNPageActivity) {
            rnPage = page
            mReactContext = rnPage?.reactInstanceManager?.currentReactContext
        }

        fun unRegisterRNpage() {
            rnPage = null
        }
    }

    override fun getName(): String {
        return "NativeInteraction"
    }

    /**
     * 跳转native路由
     */
    @ReactMethod
    fun openNative(route: String) {
        val intent = Intent()
        intent.putExtra(isAddActivityList, true)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

        when (route) {

            RouteConfig.PROFILE -> {
                intent.setClass(mReactContext, ProfileCenterActivity::class.java)

            }

            RouteConfig.WITHDRAW -> {
                intent.setClass(mReactContext, WithdrawActivity::class.java)


            }

            RouteConfig.RECHARGE -> {
                AppInitManager.getThreeStatisticsObject().time1 = System.currentTimeMillis()
                intent.setClass(mReactContext, RechargeActivity::class.java)
            }

            RouteConfig.RECHARGEACTIVITY -> {
                AppInitManager.getThreeStatisticsObject().time1 = System.currentTimeMillis()
                intent.setClass(mReactContext, RechargeActivity::class.java)
                intent.putExtra(RechargeActivity.SHOWLIST,true)
            }

            RouteConfig.BINDCARD -> {
                intent.setClass(mReactContext, BindBankCardActivity::class.java)
            }
            RouteConfig.BINDPHONE -> {
                if (ConfigUtils.isBindMobile) {
                    intent.setClass(mReactContext, ChangeMobilePhoneActivity::class.java)

                } else {
                    if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {

                        intent.setClass(mReactContext, BindMobilePhoneActivity::class.java)


                    } else {
                        intent.setClass(mReactContext, ChangeMobilePhoneActivity::class.java)
                        intent.putExtra("type", 1)


                    }
                }
            }
            RouteConfig.REALNAMEVERIFY -> {
                intent.setClass(mReactContext, RealNameVerifyActivity::class.java)
            }
            RouteConfig.REBATE -> {
                val rebeatDialog = RebateDialog()
                rebeatDialog.show(rnPage?.supportFragmentManager, "rebeat")
                return
            }

            RouteConfig.ONLINECUSTOMER -> {
                Utils.goOnlineCustomerService()
                return
            }
        }
        mReactContext?.startActivity(intent)
    }


    @ReactMethod
    fun setUserInfo(string: String) {
        val userinfo = Gson().fromJson(string, CommonLoginBody::class.java)
        ConfigUtils.token = userinfo.token
        ConfigUtils.loginName = userinfo.loginName
        ConfigUtils.customerId = userinfo.customerId
        ConfigUtils.starLevel = userinfo.starLevelName
        ConfigUtils.currentUserType = userinfo.customerType
        ConfigUtils.customerId = userinfo.customerId
        ConfigUtils.mobileNo = userinfo.mobileNo
        ConfigUtils.isBindMobile = (userinfo.mobileNoBind == 1)
        ConfigUtils.bankCardCounts = userinfo.bankCardNum.plus(userinfo.btcNum)
        rnPage?.queryOnlineCustomerService()
        rnPage?.queryCountUnread()
        rnPage?.getUserInfo()
        rnPage?.runOnUiThread {
            rnPage?.reloadGame()
            PushHelper.restartService(MyApplication.getinstance())

        }

        ThreeStatisticsManager.setLoginName(ConfigUtils.loginName)

    }


    @ReactMethod
    fun setBanlanceInfo(string: String) {
        val balance = Gson().fromJson(string, BalanceData::class.java)
        ConfigUtils.balance = balance
    }

    @ReactMethod
    fun showNavigationBar(show: Boolean) {
        rnPage?.showNavigation(show)
    }


    @ReactMethod
    fun exitApp() {
        AppInitManager.getActivityListManager().exitApp()
    }

    @ReactMethod
    fun finishPage() {

        rnPage?.finish()
    }

    @ReactMethod
    fun updateMessageCount() {
        rnPage?.queryCountUnread()

    }


    @ReactMethod
    fun getGateway(callback: Callback) {
        val gateway = GateWayObject(ApiClient.instance.baseUrl, BuildConfig.VERSION_NAME)
        callback.invoke(Gson().toJson(gateway))
    }

    @ReactMethod
    fun setAllowRotation(boolean: Boolean) {

        if (boolean) {
            rnPage?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            rnPage?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }


    }


    @ReactMethod
    fun setFullScreen(boolean: Boolean) {

        if (boolean) {

            rnPage?.runOnUiThread {
                val attrs = rnPage?.window?.attributes
                attrs?.flags = attrs?.flags?.or(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                rnPage?.window?.attributes = attrs
            }

        } else {
            rnPage?.runOnUiThread {
                val attrs = rnPage?.window?.attributes
                attrs?.flags = attrs?.flags?.and(WindowManager.LayoutParams.FLAG_FULLSCREEN.inv())
                rnPage?.window?.attributes = attrs
            }

        }


    }

    //getRsaEncode

    @ReactMethod
    fun getRsaEncode(src: String, callback: Callback) {
        callback.invoke(RSATool.encode(src))
    }


    @ReactMethod
    fun getSign(src: String, qid: String, keyEnum: String, callback: Callback) {
        val result = Gson().toJson(SignObject(SignUtils.getSign("$src${DeviceInfo.getDeviceId()}${ConfigUtils.DOMAIN_NAME}${ConfigUtils.parentId}", qid, keyEnum), DeviceInfo.getDeviceId(), ConfigUtils.DOMAIN_NAME, NetWorkUtil.isNetWorkConnected(),ConfigUtils.parentId))
        callback.invoke(result)

    }


    @ReactMethod
    fun setCDNDomainName(url: String) {

        ConfigUtils.cdnUrl = url
    }


    @ReactMethod
    fun playGame(param: String) {
        val gameRequest = Gson().fromJson(param, InGameRequest::class.java)
        when (gameRequest.gameCode) {

            "KLC" -> {
                val intent = Intent()
                intent.putExtra(isAddActivityList, true)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                intent.setClass(mReactContext, BrowserActivity::class.java)
                intent.putExtra(BrowserActivity.PARAM_URL, gameRequest.gameUrl)
                intent.putExtra(BrowserActivity.PARAM_IS_ONLINE_CUSTOMER_SERVICE, true)
                intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
                mReactContext?.startActivity(intent)
            }

            "A06003" -> {
                AppInitManager.getThreeStatisticsObject().time1 = System.currentTimeMillis()
                rnPage?.runOnUiThread {
                    rnPage?.handleGame()

                }
            }

            else -> {
                val intent = Intent()
                intent.putExtra(isAddActivityList, true)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                intent.setClass(mReactContext, H5GameActivity::class.java)
                intent.putExtra(H5GameActivity.PARAM_GAME_REQUEST, param)
                mReactContext?.startActivity(intent)
            }


        }


    }


    @ReactMethod
    fun clearLoginStatus() {
        ConfigUtils.loginName = ""
        ConfigUtils.customerId = ""
        ConfigUtils.token = ""
        ConfigUtils.mobileNo = ""
        rnPage?.queryCountUnread()
        rnPage?.runOnUiThread {
            rnPage?.reloadGame()
            PushHelper.restartService(MyApplication.getinstance())

        }
        AppInitManager.getActivityListManager().killAll()
        ThreeStatisticsManager.setLoginName(ConfigUtils.loginName)


    }


    @ReactMethod
    fun dial(phoneNum: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNum"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        mReactContext?.startActivity(intent)
    }


    /**
     * Native调用RN
     * @param msg
     */
    fun jumpToPage(msg: RnRouter) {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("jumpToPage", Gson().toJson(msg))
    }


    /**
     * Native调用RN
     * @param msg
     */
    fun resetWebView() {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("resetWebView", "")
    }



    /**
     * 登出
     *
     */
    fun logOut() {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("logOut", "")

    }

    /**
     * 跳转福利链接
     *
     */
    fun goToPromo(linkUrl: String?) {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("goToPromo", linkUrl)

    }

    /**
     * 跳转福利链接
     *
     */
    fun refreshData() {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("refreshData", "")

    }

    /**
     *单点退出
     *
     */
    fun logOutLocal() {
        mReactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("logoutLocal", "")

    }


}
