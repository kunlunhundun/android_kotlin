package com.ksmobile.app.data

data class ProvinceData(var provinceName: String, var provinceId: String, var citys: List<CityData>) : SelectorItem {
    override fun getImageLeft(): String? {
        return null
    }

    override fun getTitle(): String {
        return provinceName
    }

    override fun hasChild(): Boolean {
        return true
    }

    override fun getChildItems(): List<SelectorItem> {
        return citys
    }
}