package com.ksmobile.app.data

interface IRebateInfo {
  fun  getGameName():String
  fun  getRebateAmount():String
  fun  getRebateProportion():String
  fun  getBetAmount():String
  fun  getMinBetAmount():String
  fun  getXmFlag():String
}