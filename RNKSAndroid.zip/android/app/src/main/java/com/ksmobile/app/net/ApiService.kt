/*******************************************************************************
 *
 *所有的api接口维护在这里
 *
 *******************************************************************************/
package com.ksmobile.app.net

import com.ksmobile.app.data.RemainOrderResponse
import com.ksmobile.app.data.request.*
import com.ksmobile.app.data.response.*
import io.reactivex.Observable
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    /***
     * 闪屏页面接口
     */
    @POST("welcome")
    fun welcome(@Body request: WelcomeRequest): Observable<WelcomeResponseObject>

    /**
     *新获取支付方式列表
     */
    @POST("deposit/queryPayWaysV3")
    fun queryPayWaysV3(@Body baseMsgRequest: BaseMsgRequest): Observable<QueryPayWaysV3Response>

    /**
     * 获取个人信息接口
     */

    @POST("customer/getByLoginName")
    fun getByLoginName(@Body getByLoginNameRequest: GetByLoginNameRequest): Observable<GetByLoginNameResponse>


    /**
     *查询在线支付银行列表
     */
    @POST("deposit/queryOnlineBanks")
    fun queryOnlineBanks(@Body queryOnlineBanksRequest: QueryOnlineBanksRequest): Observable<OnlineBanksResponse>


    /**
     *创建在线支付订单
     */
    @POST("deposit/createOnlineOrder")
    fun createOnlineOrder(@Body createOnlineRequest: CreateOnlineRequest): Observable<CreateOnlineResponse>

    /**
     *查询BQ存款银行
     */
    @POST("deposit/queryBQBanks")
    fun quireBank(@Body queryPayRequest: QueryPayRequest): Observable<QureyPayResponse>

    /**
     *查询手工存款银行列表
     */
    @POST("deposit/queryRequestBanks")
    fun queryRequestBanks(@Body baseMsgRequest: BaseMsgRequest): Observable<QueryBanksResponse>

    /**
     *创建支付订单
     */
    @POST("deposit/BQPayment")
    fun creatPayOrder(@Body creatPayOrderRequest: CreatPayOrderRequest): Observable<CreatPayOrderResponse>


    /**
     *创建手工存款提案
     */
    @POST("deposit/createRequest")
    fun createHandDeposit(@Body createHandDepositRequest: CreateHandDepositRequest): Observable<CreateHandDepositResponse>

    /**
     *查询快捷金额及限额
     */
    @POST("deposit/queryAmountList")
    fun queryAmountList(@Body queryAmountListRequest: QueryAmountListRequest): Observable<QueryAmountListResponse>

    /**
     *点卡支付获取支付ID及点卡列表接口
     */
    @POST("deposit/queryPointCardList")
    fun queryPointCardList(@Body queryPointCardListRequest: QueryPointCardListRequest): Observable<QueryPointCardListResponse>

    /**
     *点卡支付接口
     */
    @POST("deposit/pointCardPayment")
    fun pointCardPayment(@Body pointCardPaymentRequest: PointCardPaymentRequest): Observable<PointCardPaymentResponse>

    /**
     *点卡支付结果接口
     */
    @POST("deposit/queryPointCardPayResult")
    fun queryPointCardPayResult(@Body queryPointCardPayResultRequest: QueryPointCardPayResultRequest): Observable<QueryPointCardPayResultResponse>

    /**
     *查询比特币汇率及存款地址
     */
    @POST("deposit/queryBtcRateAndAddress")
    fun queryBtcRateAndAddress(@Body queryBtcRateAndAddressRequest: QueryBtcRateAndAddressRequest): Observable<QueryBtcRateAndAddressResponse>

    /**
     *创建手工比特币订单
     */
    @POST("deposit/btcPayment")
    fun btcPayment(@Body btcPaymentRequest: BtcPaymentRequest): Observable<CreateBtcPaymentResponse>

    /**
     *存款交易记录
     */
    @POST("deposit/queryTrans")
    fun queryTrans(@Body orderRecordRequest: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     *提现交易记录
     */
    @POST("withdraw/queryRequest")
    fun queryWithdrawRecord(@Body orderRecordRequest: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     *洗码交易记录
     */
    @POST("xm/queryRequest")
    fun queryXmRecord(@Body orderRecordRequest: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     *交易记录
     */
    @POST("promo/queryRequest")
    fun queryPromoRecord(@Body orderRecordRequest: OrderRecordRequest): Observable<OrderRecordResponse>

    /**
     *删除存款交易记录
     */
    @POST("deposit/deleteTrans")
    fun deleteDepositRecord(@Body deleteRecordRequest: DeleteRecordRequest): Observable<DeleteRecordResponse>

    /**
     *删除提现交易记录
     */
    @POST("withdraw/deleteRequest")
    fun deleteWithdrawRecord(@Body deleteRecordRequest: DeleteRecordRequest): Observable<DeleteRecordResponse>

    /**
     *删除洗码交易记录
     */
    @POST("xm/deleteRequest")
    fun deleteXmRecord(@Body deleteRecordRequest: DeleteRecordRequest): Observable<DeleteRecordResponse>

    /**
     *删除优惠交易记录
     */
    @POST("promo/deleteRequest")
    fun deletePromoRecord(@Body deleteRecordRequest: DeleteRecordRequest): Observable<DeleteRecordResponse>

    /**
     *存款交易详情
     */
    @POST("deposit/findTranById")
    fun queryDepositOrderDetail(@Body orderDetailRequest: OrderDetailRequest): Observable<OrderDetailResponse>

    /**
     *存款交易详情
     */
    @POST("deposit/queryDomainList")
    fun queryDomainList(@Body queryDomainListRequest: QueryDomainListRequest): Observable<QueryDomainListResponse>


    /**
     *提现交易详情
     */
    @POST("withdraw/findRequestById")
    fun queryWithdrawOrderDetail(@Body orderDetailRequest: OrderDetailRequest): Observable<OrderDetailResponse>

    /**
     *存款交易详情
     */
    @POST("xm/findRequestById")
    fun queryXmOrderDetail(@Body orderDetailRequest: OrderDetailRequest): Observable<OrderDetailResponse>

    /**
     *存款交易详情
     */
    @POST("promo/findRequestById")
    fun queryPromoOrderDetail(@Body orderDetailRequest: OrderDetailRequest): Observable<OrderDetailResponse>

    /**
     * 管理银行卡接口
     */
    @POST("account/query")
    fun cardManager(@Body cardManagerRequest: CardManagerRequest): Observable<CardManagerResponse>


    /**
     * 识别银行卡接口
     */
    @POST("getByCardBin")
    fun getByCardBin(@Body getByCardBinRequest: GetByCardBinRequest): Observable<GetByCardBinResponse>


    /**
     * 添加银行卡接口
     */
    @POST("account/createBank")
    fun createBank(@Body createBankRequest: CreateBankRequest): Observable<CreatBankResponse>

    /**
     * 删除银行卡接口
     */
    @POST("account/delete")
    fun deleteBankCard(@Body deleteBankCardRequest: DeleteBankCardRequest): Observable<DeleteBankCardResponse>

    /**
     * 实名验证接口
     */
    @POST("customer/modify")
    fun modifyRealName(@Body modifyRealNameRequest: ModifyRealNameRequest): Observable<ModifyRealNameResponse>

    /**
     * 手机 登录/注册/找回密码/绑定手机/解绑手机号 获取验证码接口
     */
    @POST("sms/sendCode")
    fun sendCode(@Body sendSmsRequest: SendSmsRequest): Observable<SendSmsResponse>

    /**
     * 绑定手机号接口
     */
    @POST("customer/bindMobileNoV2")
    fun bindMobileNo(@Body bindMobileRequest: BindMobileRequest): Observable<BindMobileResponse>

    /**
     * 根据用户名发送验证码
     */
    @POST("sms/sendCodeByLoginName")
    fun sendCodeByLoginName(@Body sendSmsRequest: SendSmsRequest): Observable<SendSmsResponse>

    /**
     *解绑手机号
     */
    @POST("customer/reBindMobileNoV2")
    fun reBindMobileNo(@Body reBindPhoneRequest: ReBindPhoneRequest): Observable<ReBindPhoneResponse>

    /**
     *验证短信验证码
     */
    @POST("sms/verifySmsCode")
    fun verifySmsCode(@Body verifySmsCodeRequest: VerifySmsCodeRequest): Observable<VerifySmsCodeResponse>


    /**
     * 添加比特币钱包接口
     */
    @POST("account/createBtc")
    fun createBtc(@Body createBtcPaymentRequest: CreateBtcPaymentRequest): Observable<CreatBtcResponse>

    /**
     * 查询银行列表
     */
    @POST("account/queryBanks")
    fun queryBanks(@Body queryBanksRequest: QueryBanksRequest): Observable<QueryBankListResponse>


    /**
     * 查询洗码额度
     */
    @POST("xm/calcAmountV2")
    fun creatWashCode(@Body washCodeRequest: WashCodeCreatRequest): Observable<WashCodeCreatResponse>

    /**
     *创建洗码提案
     */
    @POST("xm/createRequest")
    fun creatWashCodeProposal(@Body washCodeRequest: CreatWashCodeProposalRequest): Observable<CreatCodeProposalResponse>

    /**
     * 获取账户金额
     */
    @POST("customer/getBalance")
    fun getBalance(@Body getBalanceRequest: GetBalanceRequest): Observable<GetBalanceResponse>


    /**
     *创建取款提案
     */
    @POST("withdraw/createRequest")
    fun creatWithdrawalsProposal(@Body creatWPRequest: CreatMPRequest): Observable<CreatWPResponse>


    /**
     *查询取款比特币
     */
    @POST("withdraw/queryBtcRate")
    fun queryBtcRate(@Body queryBtcRateRequest: QueryBtcRateRequest): Observable<QueryBtcRateResponse>


    /**
     *A06优惠
     */
    @POST("a06/promo/a06MyPromo")
    fun a06MyPromo(@Body a06PromoRequest: A06PromoRequest): Observable<A06PromoResponse>

    /**
     *更换域名
     */
    @POST("getDsGwAddress")
    fun changeUrl(@Body changeUrlRequest: ChangeUrlRequest): Observable<ChangeUrlResponse>

    /**
     * 电话回拨接口
     */
    @POST("callback")
    fun callBack(@Body callBackRequest: CallBackRequest): Observable<CallBackResponse>

    /**
     * 催单接口
     */
    @POST("message/remain")
    fun remainOrder(@Body remainOrderRequest: RemainOrderRequest): Observable<RemainOrderResponse>

    /**
     *检查更新
     */
    @POST("upgrade")
    fun upgrade(@Body upgradeRequest: UpgradeRequest): Observable<UpgradeResponse>

    /**
     * 查询IP限制
     */
    @POST("areaLimitV2")
    fun areaLimit(@Body queryAreaLimitRequest: QueryAreaLimitRequest): Observable<QueryAreaLimitResponse>

    /**
     * 查询省市列表
     */
    @POST("queryCities")
    fun queryCities(@Body queryAreaLimitRequest: QueryAreaLimitRequest): Observable<QueryCitiesResponse>

    /**
     * 获取在线客服跳转地址
     */
    @POST("liveChatAddress")
    fun liveChatAddress(@Body queryLiveChatAddressRequest: QueryLiveChatAddressRequest): Observable<QueryLiveChatAddressResponse>

    /**
     * 查询未读站内信个数
     */
    @POST("letter/query")
    fun countUnread(@Body queryCountUnreadRequest: QueryCountUnreadRequest): Observable<QueryCountUnreadResponse>

    /**
     *获取游戏进桌链接
     */
    @POST("game/inGame")
    fun inGame(@Body inGameRequest: InGameRequest): Observable<InGameResponse>
    /**
     * PT转账
     */
    @POST("game/transferToGame")
    fun transferToGame(@Body toGameRequest: ToGameRequest): Observable<ToGameResponse>

    /**
     *退出游戏
     */
    @POST("game/outGame")
    fun outGame(@Body inGameRequest: InGameRequest): Observable<OutGameResponse>

    /**
     *支付活动接口
     */
    @POST("promo/queryRequest")
    fun queryPayPromo(@Body payPromoRequest: PayPromoRequest): Observable<PayPromoResponse>

}
