/*
 * Tencent is pleased to support the open source community by making VasSonic available.
 *
 * Copyright (C) 2017 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 *
 * https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 *
 *
 */

package com.ksmobile.app.view.hybride


import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.webkit.JavascriptInterface
import android.widget.Toast
import com.ksmobile.app.activity.*
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.ProjectUtils
import com.ksmobile.app.net.LoadingDialog
import com.ksmobile.app.util.CommonCallback
import com.ksmobile.app.util.LogUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.CommonDialog

/**
 * Sonic javaScript Interface (Android API Level >= 17)
 */

class JavaScriptInterface(private val
                          activity: Activity?, private val callback: CommonCallback) {


    //Webview传递参数标签
    val RECHARGE = 1
    val PLAYGAME = 2
    val MESSAGE = 3
    val REBATE = 4
    val REGISTER = 5
    val KEFU = 6
    val CLOSE = 7
    val CARDBIND = 8 //绑卡
    val FUNDPWD = 9
    val PHONEBIND = 10  //绑定手机号
    val WITHDRAW = 11 //提现
    val TRANSCATION = 12 //交易记录
    val WEBVIEW_CLOSE = 21
    val SHOWLOADING = 15
    val HIDELOADING = 16
    val PROFILEDETAIL = 18
    val WEBVIEWCLOSE = 21 //关闭webview
    val WEBVIEW = 20  //打开新的页面
    val POINTEXCHANGE = 25  //积分兑换
    val PHONECALL = 26  //拨打电话


    private fun toJsString(value: String?): String {
        if (value == null) {
            return "null"
        }
        val out = StringBuilder(1024)
        var i = 0
        val length = value.length
        while (i < length) {
            val c = value[i]


            when (c) {
                '"', '\\', '/' -> out.append('\\').append(c)

                '\t' -> out.append("\\t")

                '\b' -> out.append("\\b")

                '\n' -> out.append("\\n")

                '\r' -> out.append("\\r")

                '\u000C' -> out.append("\\f")

                else -> if (c.toInt() <= 0x1F) {
                    out.append(String.format("\\u%04x", c.toInt()))
                } else {
                    out.append(c)
                }
            }
            i++
        }
        return out.toString()
    }


    /**
     * js调用方法
     */
    @JavascriptInterface
    fun jumpPage(tag: Int, url: String) {

        if (TextUtils.isEmpty(ConfigUtils.token)) {
            when (tag) {
                REGISTER -> {
                }
                CLOSE -> {
                }
                WEBVIEW -> {
                }
                WEBVIEW_CLOSE -> {
                }
                KEFU -> {
                }
                MESSAGE -> {
                }
                SHOWLOADING -> {
                }
                HIDELOADING -> {
                }

            }

        }

        when (tag) {

            WEBVIEWCLOSE ->
                //关闭webview
                callback.onCalled()
            WEBVIEW -> {
                //跳转webview

            }
            PHONECALL -> {
                //打电话弹窗
                var intent = Intent(Intent.ACTION_DIAL)
                var data = Uri.parse("tel:$url")
                intent.data = data
                activity?.startActivity(intent)
            }
        }

        val intent = Intent()
        when (tag) {
            RECHARGE -> {
                intent.setClass(activity, RechargeActivity::class.java)
            }
            MESSAGE -> {
                //todo
            }
            REBATE -> {
                //todo
            }
            REGISTER -> {
                //todo
            }
            CLOSE -> {
                callback.onCalled()
                return
            }
            WEBVIEW -> {
                intent.setClass(activity, BrowserActivity::class.java)
                intent.putExtra("url", url)
            }
            WEBVIEW_CLOSE -> {
                callback.onCalled()
                return
            }
            KEFU -> {

                Utils.goOnlineCustomerService()
                return
            }

            CARDBIND -> {
                when {
                    !ConfigUtils.isBindMobile -> {
                        intent.setClass(activity, BindMobilePhoneActivity::class.java)
                    }
                    (TextUtils.isEmpty(ConfigUtils.realName)) -> intent.setClass(activity, RealNameVerifyActivity::class.java)
                    else -> intent.setClass(activity, BindBankCardActivity::class.java)
                }
                intent.putExtra("addCard", true)
            }

            PHONEBIND -> {
                intent.setClass(activity, BindMobilePhoneActivity::class.java)
            }

            WITHDRAW -> {
                when {
                    !ConfigUtils.isBindMobile -> {
                        intent.setClass(activity, BindMobilePhoneActivity::class.java)
                    }
                    (TextUtils.isEmpty(ConfigUtils.realName)) -> intent.setClass(activity, RealNameVerifyActivity::class.java)
                    else -> intent.setClass(activity, WithdrawActivity::class.java)
                }
                intent.putExtra("addCard", true)
            }


            TRANSCATION -> {
                intent.setClass(activity, OrderReportActivity::class.java)
                if (!TextUtils.isEmpty(url)) {
                    intent.putExtra("index", url.toInt() + 1)
                }
            }

            SHOWLOADING -> {
                LoadingDialog.show(activity as BrowserActivity)
            }
            HIDELOADING -> {
                LoadingDialog.cancel()
            }

            PROFILEDETAIL -> {
                intent.setClass(activity, UserInfoCenterActivity::class.java)
            }
        }
        activity?.startActivity(intent)
    }



}
