package com.ksmobile.app.data

import com.ksmobile.app.data.response.BaseResponseObject


/**
 * Created by ward.y on 2018/3/19.
 */
class RemainOrderResponse : BaseResponseObject() {
    val body :Int?=null



}
