package com.ksmobile.app.data.response

import com.ksmobile.app.data.PostMapObject


/**
 * Created by ward.y on 2018/3/19.
 */
class InGameResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var formMethod: String? = null,
            var url: String? = null,
            var lineIp: String? = null,
            var postMap: PostMapObject? = null
    )
}
