
package com.ksmobile.app.net

import android.app.Activity
import android.app.Dialog
import android.support.v4.app.FragmentActivity
import com.ksmobile.app.R
import java.lang.ref.WeakReference

object LoadingDialog {
    private var dialog: Dialog? = null
    var mActivity : WeakReference<Activity>? = null
    fun show(activity: FragmentActivity) {
        cancel()
        mActivity = WeakReference (activity)
        if (mActivity==null){
            return
        }
        dialog = Dialog(mActivity?.get(), R.style.LoadingDialog)
        dialog?.setContentView(R.layout.dialog_loading)
        dialog?.setCancelable(true)
        dialog?.setCanceledOnTouchOutside(true)
        if (mActivity!=null){
            dialog?.show()
        }



    }

    fun cancel() {
        if (dialog!=null&&dialog?.isShowing!!) {
            dialog?.dismiss()
        }
        dialog = null

    }

}
