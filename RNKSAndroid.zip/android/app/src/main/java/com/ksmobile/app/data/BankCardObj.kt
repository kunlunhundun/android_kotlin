package com.ksmobile.app.data


/**
 * Created by ward.y on 2018/2/2.
 */

data class BankCardObj(
        var accountName: String = "",
        var accountNo: String = "",
        var accountType: String = "",
        var bankName: String = "",
        var branch: String = "",
        var catalog: String = "",
        var city: String = "",
        var flag: String = "",
        var accountId: String = "",
        var loginName: String = "",
        var provence: String = "",
        var bankIcon: String = "",
        var backgroundColor: String = "",
        var isSlelected: Boolean = false

)

