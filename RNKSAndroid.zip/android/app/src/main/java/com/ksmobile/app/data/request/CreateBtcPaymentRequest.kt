package com.ksmobile.app.data.request


class CreateBtcPaymentRequest : BaseRequestObject() {

    var btcName:String?=null
    var btcUrl:String?=null

}
