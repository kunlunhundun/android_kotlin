package com.ksmobile.app.data.request

import com.ksmobile.app.config.ConfigUtils


class ChangeUrlRequest : BaseRequestObject() {

    var url: String = ConfigUtils.testGateUrl


}