package com.ksmobile.app.data

data class BankInfo(var bankName:String, var bankCode:String, var bankIcon:String)