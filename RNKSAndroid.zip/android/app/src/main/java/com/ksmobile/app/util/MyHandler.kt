package com.ksmobile.app.util

import android.os.Handler
import android.os.Message
import com.ksmobile.app.activity.BaseActivity
import java.lang.ref.WeakReference

/**
 * Created by ward.y on 2018/3/31.
 */
open class MyHandler(activity: BaseActivity) : Handler() {
    private val mActivity: WeakReference<BaseActivity> = WeakReference(activity)
    lateinit var activity: BaseActivity
    override fun handleMessage(msg: Message) {
        if (mActivity.get() == null) {
            return
        }
        activity = mActivity.get() as BaseActivity

    }
}