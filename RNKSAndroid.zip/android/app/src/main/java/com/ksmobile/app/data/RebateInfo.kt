package com.ksmobile.app.data

abstract class RebateInfo: IRebateInfo{

    override fun getMinBetAmount(): String {
        return ""
    }

    override fun getXmFlag(): String {
       return ""
    }

}