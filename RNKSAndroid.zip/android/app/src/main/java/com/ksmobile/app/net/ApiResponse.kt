
package com.ksmobile.app.net

import android.support.v4.app.FragmentActivity
import com.ksmobile.app.data.response.BaseResponseObject
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.view.NotifyDialog
import io.reactivex.Observer
import io.reactivex.disposables.Disposable
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

abstract class ApiResponse<T: BaseResponseObject>(private val context: FragmentActivity, private val showProgress:Boolean) : Observer<T> {

    constructor( context: FragmentActivity):this(context,true)
    abstract fun businessFail(data: T)
    abstract fun businessSuccess(data: T)
    abstract fun failure(statusCode: Int, apiErrorModel: ApiErrorModel)

    override fun onSubscribe(d: Disposable) {
        if (showProgress){
            LoadingDialog.show(context)
        }

    }

    override fun onNext(t: T) {

        when(t.head.errCode){
            "0000" ->{
                businessSuccess(t)}
            "GW_890206" ->{
                NotifyDialog.show(context,"您的账号正在其他地方登陆,您被迫登出,如非本人操作请立即联系客服")
                NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                    override fun onHidden() {
                        AppInitManager.loginOutLocal()
                    }

                })

            }

            "GW_890405" ->{
                NotifyDialog.show(context,"您的账号已登出，如有疑问请联系客服")
                NotifyDialog.setOnHiddenCallback(object :NotifyDialog.HiddenCallback{
                    override fun onHidden() {
                        context.finish()
                        AppInitManager.loginOutLocal()
                    }

                })
            }
            "GW_890407" -> {
                AppInitManager.showServiceDialog(context)

            }
            else ->{
                businessFail(t)
            }
        }

    }

    override fun onComplete() {
        if (showProgress){
            LoadingDialog.cancel()
        }

    }

    override fun onError(e: Throwable) {
        if (showProgress){
            LoadingDialog.cancel()
        }

        if (e is HttpException) {
            val apiErrorModel: ApiErrorModel = when (e.code()) {
                ApiErrorType.INTERNAL_SERVER_ERROR.code ->
                    ApiErrorType.INTERNAL_SERVER_ERROR.getApiErrorModel(context)
                ApiErrorType.BAD_GATEWAY.code ->
                    ApiErrorType.BAD_GATEWAY.getApiErrorModel(context)
                ApiErrorType.NOT_FOUND.code ->
                    ApiErrorType.NOT_FOUND.getApiErrorModel(context)
                ApiErrorType.NETWORK_NOT_CONNECT.code ->
                    ApiErrorType.NETWORK_NOT_CONNECT.getApiErrorModel(context)
                else -> otherError(e)

            }
            failure(e.code(), apiErrorModel)
            return
        }

        val apiErrorType: ApiErrorType = when (e) {
            is UnknownHostException -> ApiErrorType.UNKNOWN_HOST_EXCEPTION
            is ConnectException -> ApiErrorType.NETWORK_NOT_CONNECT
            is SocketTimeoutException -> ApiErrorType.CONNECTION_TIMEOUT
            else -> ApiErrorType.UNEXPECTED_ERROR
        }
        failure(apiErrorType.code, apiErrorType.getApiErrorModel(context))
    }

    private fun otherError(e: HttpException) = ApiErrorModel(e.code(),e.message())

}
