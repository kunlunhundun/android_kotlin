package com.ksmobile.app.data.request



class QueryOnlineBanksRequest : BaseRequestObject() {
    var payType: String = "1"
}