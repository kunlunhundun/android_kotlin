package com.ksmobile.app.data.request



class QueryBtcRateAndAddressRequest : BaseRequestObject(){
    var btcAmount = ""

}