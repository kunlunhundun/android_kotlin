package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import com.ksmobile.app.MyApplication
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.reactnative.MyRnPageActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.BalanceData
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.data.request.*
import com.ksmobile.app.data.response.*
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.NotifyDialog
import com.ksmobile.app.view.RebateDialog
import kotlinx.android.synthetic.main.activity_profile_center.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class ProfileCenterActivity : BaseToolBarActivity() {

    var xmFlag: Int? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_profile_center
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.profile_center_title))

    }

    override fun initView() {
        OverScrollDecoratorHelper.setUpOverScroll(sv_profile)
        navigation_bar.bindActiviy(this)
        tv_user_name.text = ConfigUtils.loginName
        tv_vip.text = ConfigUtils.starLevel
        total_assets.text = ConfigUtils.balance.balance
        tv_version.text = "版本号：v${Utils.getVersion()}"
        getPromoInfo()
        getDepositData()
        getWithdrawData()
    }

    override fun initListener() {
        cl_profile_info.setOnClickListener {
            goToPage(Intent(this, UserInfoCenterActivity::class.java))
        }

        ll_recharge.setOnClickListener {
            AppInitManager.getThreeStatisticsObject().time1 = System.currentTimeMillis()

            goToPage(Intent(this, RechargeActivity::class.java))
        }
        ll_withdraw.setOnClickListener {
            goToPage(Intent(this, WithdrawActivity::class.java))
        }

        ll_rebate.setOnClickListener {
            if (xmFlag == 0) {
                NotifyDialog.show(this@ProfileCenterActivity, "您的自助洗码功能未开通，请联系客服")

                return@setOnClickListener
            }

            val rebeatDialog = RebateDialog()
            rebeatDialog.show(supportFragmentManager, "rebeat")


        }
        report_all.setOnClickListener {
            goToPage(Intent(this, OrderReportActivity::class.java))
        }
        promo_all.setOnClickListener {
            AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.PROMO, false))
            val intent = Intent(this@ProfileCenterActivity, MyRnPageActivity::class.java)
            Handler().postDelayed({
                goToPage(intent)
            }, 100)
        }
        content.addOnLayoutChangeListener(this)

        setBackListener(View.OnClickListener {
            AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MAIN, false))
            Handler().postDelayed({
                finish()
            }, 300)
        })

    }

    override fun onResume() {
        super.onResume()
        getUserInfo()
        queryCountUnread()
        getBalance()

    }

    private fun getUserInfo() {
        val request = GetByLoginNameRequest()
        request.inclMobileNo = 1
        request.inclMobileNoBind = 1
        request.inclRealName = 1
        request.inclBankAccount = 1
        request.inclBtcAccount = 1
        request.inclXmFlag = 1
        ApiClient.instance.service.getByLoginName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetByLoginNameResponse>(this, true) {
                    override fun businessFail(data: GetByLoginNameResponse) {
                    }

                    override fun businessSuccess(data: GetByLoginNameResponse) {
                        xmFlag = data.body?.xmFlag
                        ConfigUtils.mobileNo = data.body?.mobileNo
                        ConfigUtils.realName = data.body?.realName
                        ConfigUtils.isBindMobile = (data.body?.mobileNoBind == 1)
                        ConfigUtils.starLevel = data.body?.starLevelName
                        ConfigUtils.bankCardCounts = data.body?.bankCardNum!!.plus(data.body.btcNum)
                        tv_vip.text = ConfigUtils.starLevel
                        if (ConfigUtils.isBindMobile) {
                            iv_mobile_phone.setImageResource(R.mipmap.icon_mobile_phone_verify)
                            tv_mobile_phone.setTextColor(resources.getColor(R.color.colorWhite))
                        }

                        if (!TextUtils.isEmpty(data.body.birthday)) {
                            iv_real_name.setImageResource(R.mipmap.icon_real_name_verify)
                            tv_real_name.setTextColor(resources.getColor(R.color.colorWhite))
                        }

                        if (ConfigUtils.bankCardCounts > 0) {
                            iv_email.setImageResource(R.mipmap.icon_email_verify)
                            tv_email.setTextColor(resources.getColor(R.color.colorWhite))
                        }


                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }


    private fun getPromoInfo() {
        val request = A06PromoRequest()
        ApiClient.instance.frontService.a06MyPromo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<A06PromoResponse>(this, false) {
                    override fun businessFail(data: A06PromoResponse) {
                    }

                    override fun businessSuccess(data: A06PromoResponse) {
                        if (data.body?.tA06MyPromoList != null && !data.body.tA06MyPromoList.isEmpty()) {
                            data.body.tA06MyPromoList.forEachIndexed { index, promoObject ->
                                if (index == 0) {
                                    promo_item_1.setData(promoObject)
                                    promo_item_1.visibility = View.VISIBLE
                                } else if (index == 1) {
                                    promo_item_2.setData(promoObject)
                                    promo_item_2.visibility = View.VISIBLE
                                }


                            }
                        } else {
                            promo_title.visibility = View.GONE
                            promo_all.visibility = View.GONE
                        }

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }

    /**
     * 获取用户账户金额
     */
    private fun getBalance() {
        val request = GetBalanceRequest()
        request.flag = 1
        ApiClient.instance.service.getBalance(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetBalanceResponse>(this, false) {
                    override fun businessFail(data: GetBalanceResponse) {

                    }

                    override fun businessSuccess(data: GetBalanceResponse) {
                        ConfigUtils.balance = BalanceData(data.body?.balance.toString(), data.body?.localBalance.toString(), data.body?.minWithdrawAmount.toString())
                        total_assets.text = ConfigUtils.balance.balance
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }

    private fun getDepositData() {
        val request = OrderRecordRequest()
        request.pageSize = 1
        request.pageNo = 1
        request.lastDays = 15
        ApiClient.instance.service.queryTrans(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<OrderRecordResponse>(this, false) {
                    override fun businessFail(data: OrderRecordResponse) {

                    }

                    override fun businessSuccess(data: OrderRecordResponse) {

                        if (!data.body!!.data.isEmpty()) {
                            data.body.data[0].type = 1
                            report_view_1.setData(data.body.data[0])
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }


    private fun getWithdrawData() {
        val request = OrderRecordRequest()
        request.pageSize = 1
        request.pageNo = 1
        request.lastDays = 15
        ApiClient.instance.service.queryWithdrawRecord(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<OrderRecordResponse>(this, false) {
                    override fun businessFail(data: OrderRecordResponse) {


                    }

                    override fun businessSuccess(data: OrderRecordResponse) {

                        if (!data.body!!.data.isEmpty()) {
                            data.body.data[0].type = 2
                            report_view_2.setData(data.body.data[0])
                        }


                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }


    /**
     * 获取未读消息个数
     */


    private fun queryCountUnread() {
        val request = QueryCountUnreadRequest()
        ApiClient.instance.service.countUnread(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryCountUnreadResponse>(this, false) {
                    override fun businessFail(data: QueryCountUnreadResponse) {
                    }

                    override fun businessSuccess(data: QueryCountUnreadResponse) {
                        navigation_bar.showMsg(1, data.body.totalRow)


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }


    override fun onLayoutChange(v: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {

        if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight)) {
            navigation_bar.onLayoutChange(true)
        } else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight)) {
            navigation_bar.onLayoutChange(false)
        }
    }


    override fun onBackPressed() {
        AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MAIN, false))
        Handler().postDelayed({
            finish()
        }, 300)
    }




}