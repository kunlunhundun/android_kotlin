package com.ksmobile.app.data.request



class InGameRequest : BaseRequestObject() {
    var gameCode: String? =  null
    var gameType: String? = null
    var gameId: String? = null
    var gameName: String? = null
    var gameUrl: String? = null

}