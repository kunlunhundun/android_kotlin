package com.ksmobile.app.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.ksmobile.app.R
import com.ksmobile.app.data.IRebateInfo

import java.math.BigDecimal

/**
 * Created by ward on 15/11/26.
 */
class RebateDetailAdapter(context: Context, private var datas: List<IRebateInfo>, private var minBetAmount: BigDecimal) : RecyclerView.Adapter<RebateDetailAdapter.ViewHolder>() {

    private var clickCallBack: ItemClickCallBack? = null

    private var mContext = context

    fun setClickCallBack(clickCallBack: ItemClickCallBack) {
        this.clickCallBack = clickCallBack
    }

    interface ItemClickCallBack {
        fun onItemClick(pos: Int)
    }


    //创建新View，被LayoutManager所调用
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_rebate_view, viewGroup, false)
        return ViewHolder(view)
    }

    //将数据与界面进行绑定的操作
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        viewHolder.tv_game.text = datas[position].getGameName()
        viewHolder.tv_betAmount.text = datas[position].getBetAmount()
        viewHolder.tv_proportion.text = datas[position].getRebateProportion()
        viewHolder.tv_rebate_amount.text = datas[position].getRebateAmount()

        if (isNumeric(datas[position].getBetAmount())&&BigDecimal(datas[position].getBetAmount())<minBetAmount){
            viewHolder.tv_game.setTextColor(mContext.resources.getColor(R.color.colorTextGrey))
            viewHolder.tv_betAmount.setTextColor(mContext.resources.getColor(R.color.colorTextGrey))
            viewHolder.tv_proportion.setTextColor(mContext.resources.getColor(R.color.colorTextGrey))
            viewHolder.tv_rebate_amount.setTextColor(mContext.resources.getColor(R.color.colorTextGrey))
        }


    }

    //获取数据的数量
    override fun getItemCount(): Int {
        return datas.size
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tv_game: TextView = view.findViewById(R.id.tv_game)
        var tv_betAmount: TextView = view.findViewById(R.id.tv_betAmount)
        var tv_proportion: TextView = view.findViewById(R.id.tv_proportion)
        var tv_rebate_amount: TextView = view.findViewById(R.id.tv_rebate_amount)


    }

    private fun isNumeric(str: String): Boolean {

        try {
             BigDecimal(str).toString()
        } catch (e: Exception) {
            return false//异常 说明包含非数字。
        }

        return true
    }

}





















