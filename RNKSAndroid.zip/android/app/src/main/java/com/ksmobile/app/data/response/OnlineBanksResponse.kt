package com.ksmobile.app.data.response

import com.ksmobile.app.data.AmountType


/**
 * Created by ward.y on 2018/3/19.
 */
class OnlineBanksResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var bankList: MutableList<Bean>,
            var payid: String,
            var maxAmount: Double,
            var minAmount: Double,
            var paymentCode: String,
            var amountType:AmountType,
            var optDepositAmounts:MutableList<String>
    )

    data class Bean(
            var bankCode: String,
            var bankNo: String,
            var bankName: String,
            var bankIcon: String
    )


}
