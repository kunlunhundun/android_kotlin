package com.ksmobile.app.data.response

import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class CreateOnlineResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var amount: BigDecimal,
            var billDate: String,
            var billNo: String,
            var currency: String,
            var keycode: String,
            var paycode: String,
            var productId: String,
            var loginName: String,
            var customerType: Int,
            var url: String,
            var payUrl: String,
            var domainList:MutableList<String> = arrayListOf()
    )
}
