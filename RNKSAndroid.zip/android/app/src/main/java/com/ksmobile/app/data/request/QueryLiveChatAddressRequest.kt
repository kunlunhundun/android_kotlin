package com.ksmobile.app.data.request

class QueryLiveChatAddressRequest : BaseRequestObject()