package com.ksmobile.app.activity

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import com.github.vipulasri.timelineview.LineType
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.reactnative.RNPageActivity
import com.ksmobile.app.data.RemainOrderResponse
import com.ksmobile.app.data.request.OrderDetailRequest
import com.ksmobile.app.data.request.RemainOrderRequest
import com.ksmobile.app.data.response.OrderDetailResponse
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.*
import com.ksmobile.app.util.LoadErrorType
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_order_detail.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class OrderDetailActivity : BaseToolBarActivity() {
    var type: Int = -1
    var showButton = false
    private val orderDetailRequest = OrderDetailRequest()
    override fun getLayoutId(): Int {
        return R.layout.activity_order_detail
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OverScrollDecoratorHelper.setUpOverScroll(sv_order_detail)
    }

    override fun initView() {
        LoadingDialog.show(this)
        sv_order_detail.visibility = View.INVISIBLE
        val referenceId = intent.getStringExtra("referenceId")
        type = intent.getIntExtra("type", -1)

        when (type) {
            1 -> {
                setTile("存款详情")
                setWaitPayText("等待支付")
            }
            2 -> {
                setTile("取款详情")
                setWaitPayText("提现请求")
            }
            3 -> {
                setTile("洗码详情")
                setWaitPayText("洗码请求")
            }
            4 -> {
                setTile("优惠详情")
                setWaitPayText("优惠请求")
            }

        }
        showButton = intent.getBooleanExtra("showButton", false)
        if (showButton) {
            tv_cancle.visibility = View.VISIBLE
            tv_sure.visibility = View.VISIBLE
        }

        orderDetailRequest.requestId = referenceId


        Handler().postDelayed({
            request(orderDetailRequest)
        }, 1500)

    }

    override fun initListener() {
        tv_cancle.setOnClickListener {
            AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java)
            finish()
        }

        tv_sure.setOnClickListener {
            AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java, ProfileCenterActivity::class.java)
            goToPage(Intent(this, RechargeActivity::class.java))
            finish()
        }

        setBackListener(View.OnClickListener {
            AppInitManager.getActivityListManager().killAllExclude(MainActivity::class.java, ProfileCenterActivity::class.java, OrderReportActivity::class.java)
            finish()
        })
    }


    private fun request(request: OrderDetailRequest) {

        when (type) {
            1 -> {
                ApiClient.instance.service.queryDepositOrderDetail(request)
                        .compose(NetworkScheduler.compose())
                        .bindUntilEvent(this, ActivityEvent.DESTROY)
                        .subscribe(object : ApiResponse<OrderDetailResponse>(this, false) {
                            override fun businessFail(data: OrderDetailResponse) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                LoadingDialog.cancel()

                            }

                            override fun businessSuccess(data: OrderDetailResponse) {
                                if (data.body != null) {
                                    showDetail(data)
                                } else {
                                    load_error.visibility = View.VISIBLE
                                    sv_order_detail.visibility = View.GONE
                                    load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                    LoadingDialog.cancel()
                                }

                            }

                            override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.NET_ERROR.code)
                                load_error.setNormalClickListener(View.OnClickListener {
                                    load_error.visibility = View.GONE
                                    LoadingDialog.show(this@OrderDetailActivity)
                                    request(orderDetailRequest)
                                })
                                LoadingDialog.cancel()
                            }
                        })
            }

            2 -> {
                ApiClient.instance.service.queryWithdrawOrderDetail(request)
                        .compose(NetworkScheduler.compose())
                        .bindUntilEvent(this, ActivityEvent.DESTROY)
                        .subscribe(object : ApiResponse<OrderDetailResponse>(this, true) {
                            override fun businessFail(data: OrderDetailResponse) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                LoadingDialog.cancel()
                            }

                            override fun businessSuccess(data: OrderDetailResponse) {
                                if (data.body != null) {
                                    showDetail(data)
                                } else {
                                    load_error.visibility = View.VISIBLE
                                    sv_order_detail.visibility = View.GONE
                                    load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                    LoadingDialog.cancel()
                                }

                            }

                            override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.NET_ERROR.code)
                                load_error.setNormalClickListener(View.OnClickListener {
                                    load_error.visibility = View.GONE
                                    LoadingDialog.show(this@OrderDetailActivity)
                                    request(orderDetailRequest)
                                })
                                LoadingDialog.cancel()
                            }
                        })
            }

            3 -> {
                ApiClient.instance.service.queryXmOrderDetail(request)
                        .compose(NetworkScheduler.compose())
                        .bindUntilEvent(this, ActivityEvent.DESTROY)
                        .subscribe(object : ApiResponse<OrderDetailResponse>(this, true) {
                            override fun businessFail(data: OrderDetailResponse) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                LoadingDialog.cancel()
                            }

                            override fun businessSuccess(data: OrderDetailResponse) {
                                if (data.body != null) {
                                    showDetail(data)
                                } else {
                                    load_error.visibility = View.VISIBLE
                                    sv_order_detail.visibility = View.GONE
                                    load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                    LoadingDialog.cancel()
                                }

                            }

                            override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.NET_ERROR.code)
                                load_error.setNormalClickListener(View.OnClickListener {
                                    load_error.visibility = View.GONE
                                    LoadingDialog.show(this@OrderDetailActivity)
                                    request(orderDetailRequest)
                                })
                                LoadingDialog.cancel()
                            }
                        })
            }

            4 -> {
                ApiClient.instance.service.queryPromoOrderDetail(request)
                        .compose(NetworkScheduler.compose())
                        .bindUntilEvent(this, ActivityEvent.DESTROY)
                        .subscribe(object : ApiResponse<OrderDetailResponse>(this, true) {
                            override fun businessFail(data: OrderDetailResponse) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                LoadingDialog.cancel()
                            }

                            override fun businessSuccess(data: OrderDetailResponse) {
                                if (data.body != null) {
                                    showDetail(data)
                                } else {
                                    load_error.visibility = View.VISIBLE
                                    sv_order_detail.visibility = View.GONE
                                    load_error.showError(LoadErrorType.DATA_EMPTY.code)
                                }


                            }

                            override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                                load_error.visibility = View.VISIBLE
                                sv_order_detail.visibility = View.GONE
                                load_error.showError(LoadErrorType.NET_ERROR.code)
                                load_error.setNormalClickListener(View.OnClickListener {
                                    load_error.visibility = View.GONE
                                    LoadingDialog.show(this@OrderDetailActivity)
                                    request(orderDetailRequest)
                                })
                                LoadingDialog.cancel()
                            }
                        })
            }
        }


    }


    private fun showDetail(data: OrderDetailResponse) {
        LoadingDialog.cancel()
        sv_order_detail.visibility = View.VISIBLE
        tv_order_amount.text = Utils.formatMoney(data.body?.amount!!)
        tv_order_tips.text = data.body.flagDesc
        cv_style.setContent(data.body.title)
        cv_proportion_number.setContent(data.body.requestId)
        cv_time.setContent(data.body.createDate)
        if (!TextUtils.isEmpty(data.body.bankName)) {
            cv_withdraw_to.setContent("${data.body.bankName}(${data.body.accountNo})")
            cv_withdraw_to.visibility = View.VISIBLE
            cv_withdraw_to.setDrawable(data.body.itemIcon)
        }

        if (data.body.rate != null) {
            cv_rate.setContent("1BTC≈${Utils.formatMoney(data.body.rate, false)}元")
        }

        //优惠详情才显示流水要求
        if(type == 4){
            cv_rebate_standard.visibility =View.VISIBLE
            if (!TextUtils.isEmpty(data.body.betAmount)){
                cv_rebate_standard.setContent(data.body.betAmount)

            }else{
                cv_rebate_standard.setContent("0")
            }
        }


        when (data.body.flag) {
            0, 9, 1, 97 -> {
                tv_order_tips.setTextColor(Color.parseColor("#E9664B"))
            }
            2 -> {
                tv_order_tips.setTextColor(Color.parseColor("#50E3C2"))
            }
            else -> {
                tv_order_tips.setTextColor(Color.parseColor("#999999"))
            }

        }

        showStatus(data)


    }

    private fun showStatus(data: OrderDetailResponse) {
        when {
            (data.body?.flag) == 0 || (data.body?.flag) == 9 -> {
                cv_progress.setOnClickListener {
                    Utils.goOnlineCustomerService()
                }
                if (showButton) {
                    tv_tips.visibility = View.VISIBLE
                } else {
                    tv_tips.visibility = View.GONE
                }
                order_status_progress_first.setEndLine(Color.parseColor("#7ED321"), LineType.BEGIN)
                order_status_progress_first.setMarker(resources.getDrawable(R.mipmap.icon_progress_normal))
                order_status_progress_second.setMarker(resources.getDrawable(R.mipmap.icon_default))
                order_status_progress_second.setStartLine(Color.parseColor("#666666"), LineType.NORMAL)
                order_status_progress_second.setEndLine(Color.parseColor("#666666"), LineType.NORMAL)
                order_status_progress_third.setStartLine(Color.parseColor("#666666"), LineType.END)
                order_status_progress_third.setMarker(resources.getDrawable(R.mipmap.icon_default))
                tv_wait_pay.setTextColor(resources.getColor(R.color.colorWhite))
            }

            data.body?.flag == 1 -> {
                cv_progress.setOnClickListener { Utils.goOnlineCustomerService() }
                order_status_progress_first.setEndLine(Color.parseColor("#8095FF"), LineType.BEGIN)
                order_status_progress_first.setMarker(resources.getDrawable(R.mipmap.icon_check))
                order_status_progress_second.setMarker(resources.getDrawable(R.mipmap.icon_check))
                order_status_progress_second.setStartLine(Color.parseColor("#8095FF"), LineType.NORMAL)
                order_status_progress_second.setEndLine(Color.parseColor("#8095FF"), LineType.NORMAL)
                order_status_progress_third.setStartLine(Color.parseColor("#dddddd"), LineType.END)
                order_status_progress_third.setMarker(resources.getDrawable(R.mipmap.icon_default))
                tv_detail_deal.setTextColor(resources.getColor(R.color.colorWhite))
            }

            data.body?.flag == 2 -> {
                cv_progress.setContent(resources.getString(R.string.order_detail_page_customer))
                cv_progress.setOnClickListener { Utils.goOnlineCustomerService() }
                tv_tips.visibility = View.GONE

                order_status_progress_first.setEndLine(Color.parseColor("#8095FF"), LineType.BEGIN)
                order_status_progress_first.setMarker(resources.getDrawable(R.mipmap.icon_check))
                order_status_progress_second.setMarker(resources.getDrawable(R.mipmap.icon_check))
                order_status_progress_second.setStartLine(Color.parseColor("#8095FF"), LineType.NORMAL)
                order_status_progress_second.setEndLine(Color.parseColor("#8095FF"), LineType.NORMAL)
                order_status_progress_third.setStartLine(Color.parseColor("#8095FF"), LineType.END)
                order_status_progress_third.setMarker(resources.getDrawable(R.mipmap.icon_check))
                tv_pay_success.setTextColor(resources.getColor(R.color.colorWhite))
            }

            data.body?.flag == -3 -> {
                tv_tips.visibility = View.GONE
                cv_progress.setContent(resources.getString(R.string.order_detail_page_customer))
                cv_progress.setOnClickListener { Utils.goOnlineCustomerService() }
                order_status_progress_first.setEndLine(Color.parseColor("#F56262"), LineType.BEGIN)
                order_status_progress_first.setMarker(resources.getDrawable(R.mipmap.icon_progress_error))
                order_status_progress_second.setMarker(resources.getDrawable(R.mipmap.icon_default))
                order_status_progress_second.setStartLine(Color.parseColor("#666666"), LineType.NORMAL)
                order_status_progress_second.setEndLine(Color.parseColor("#666666"), LineType.NORMAL)
                order_status_progress_third.setStartLine(Color.parseColor("#666666"), LineType.END)
                order_status_progress_third.setMarker(resources.getDrawable(R.mipmap.icon_default))
                tv_wait_pay.setTextColor(resources.getColor(R.color.colorWhite))
            }

            else -> {
                tv_tips.visibility = View.GONE
                cv_progress.setContent(resources.getString(R.string.order_detail_page_customer))
                cv_progress.setOnClickListener { Utils.goOnlineCustomerService() }
                order_status_progress_first.setEndLine(Color.parseColor("#dddddd"), LineType.BEGIN)
                order_status_progress_first.setMarker(resources.getDrawable(R.mipmap.icon_progress_error))
                order_status_progress_second.setMarker(resources.getDrawable(R.mipmap.icon_default))
                order_status_progress_second.setStartLine(Color.parseColor("#dddddd"), LineType.NORMAL)
                order_status_progress_second.setEndLine(Color.parseColor("#dddddd"), LineType.NORMAL)
                order_status_progress_third.setStartLine(Color.parseColor("#dddddd"), LineType.END)
                order_status_progress_third.setMarker(resources.getDrawable(R.mipmap.icon_default))
                tv_wait_pay.setTextColor(resources.getColor(R.color.colorWhite))
            }
        }
        order_status_progress_first.invalidate()
        order_status_progress_second.invalidate()
        order_status_progress_third.invalidate()

    }

    private fun setWaitPayText(str: String){
        tv_wait_pay.text = str
    }

//    private fun remainOrder(data: OrderDetailResponse) {
//        val request = RemainOrderRequest()
//        request.referenceId = data.body?.requestId
//        request.type = data.body?.type
//        ApiClient.instance.service.remainOrder(request)
//                .compose(NetworkScheduler.compose())
//                .bindUntilEvent(this, ActivityEvent.DESTROY)
//                .subscribe(object : ApiResponse<RemainOrderResponse>(this, true) {
//                    override fun businessFail(data: RemainOrderResponse) {
//                        NotifyDialog.show(this@OrderDetailActivity, "客服已收到您的订单请求，请您稍等")
//                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
//
//                    }
//
//                    override fun businessSuccess(data: RemainOrderResponse) {
//                        NotifyDialog.show(this@OrderDetailActivity, "客服已收到您的订单请求，请您稍等")
//                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
//                    }
//
//                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
//                        NotifyDialog.show(this@OrderDetailActivity, "客服已收到您的订单请求，请您稍等")
//                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
//                    }
//                })

//    }
}