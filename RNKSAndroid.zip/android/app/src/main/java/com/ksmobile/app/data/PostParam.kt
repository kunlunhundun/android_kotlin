package com.ksmobile.app.data

data class PostParam (val newaccount:String,
                      val keycode:String,
                      val product:String,
                      val customerType:String,
                      val loginname:String,
                      val language:String,
                      val billno:String
                      )




