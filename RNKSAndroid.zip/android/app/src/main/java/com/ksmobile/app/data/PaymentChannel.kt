package com.ksmobile.app.data
import com.google.gson.annotations.SerializedName


/**
 * Created by ward.y on 2018/2/2.
 */

data class PaymentChannel(
		@SerializedName("channelName") var channelName: String = "",
		@SerializedName("channelDes") var channelDes: String? = "",
		@SerializedName("channelIcon") var channelIcon: Int = 0
)