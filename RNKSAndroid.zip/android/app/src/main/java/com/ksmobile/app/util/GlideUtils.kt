package com.ksmobile.app.util

import android.content.Context
import com.bumptech.glide.DrawableTypeRequest
import com.bumptech.glide.Glide
import com.ksmobile.app.config.ConfigUtils

object GlideUtils {

    /**
     * @param context
     * @param url 下载地址
     */

    @JvmStatic
    fun load(context: Context?,url:String?): DrawableTypeRequest<String> {

        return Glide.with(context).load("${ConfigUtils.cdnUrl}$url")
    }



}