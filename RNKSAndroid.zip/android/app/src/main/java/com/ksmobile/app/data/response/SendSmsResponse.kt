package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/20.
 */


class SendSmsResponse : BaseResponseObject() {
    val body = Body()

    class Body {
        var expire: Int? = null
        var messageId: String? = null
    }
}
