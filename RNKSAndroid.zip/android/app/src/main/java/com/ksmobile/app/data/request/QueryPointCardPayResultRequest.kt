package com.ksmobile.app.data.request



class QueryPointCardPayResultRequest : BaseRequestObject(){
    var billNo = ""

}