package com.ksmobile.app.view.hybride

import android.content.Context
import android.net.http.SslError
import android.os.Build
import android.util.AttributeSet
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient


import java.lang.reflect.InvocationTargetException


class MyWebView : WebView {


    constructor(context: Context) : super(context) {
        initWebView()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        initWebView()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initWebView()
    }

    private fun initWebView() {
        clearHistory()
        clearCache(true)
        val settings = this.settings
        // init webview settings
        settings.textZoom = 100
        settings.javaScriptEnabled = true
        settings.pluginState = WebSettings.PluginState.ON
        settings.allowContentAccess = true
        settings.databaseEnabled = true
        settings.domStorageEnabled = true
        settings.setAppCacheEnabled(true)
        settings.savePassword = false
        settings.saveFormData = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        this.requestFocus()
        this.settings.setGeolocationEnabled(true)
        this.webViewClient = object : WebViewClient() {

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.proceed()
            }
        }

        this.setOnLongClickListener { true }
        this.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                result.confirm()
                return true
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= 16) {
                val clazz = this.settings.javaClass
                val method = clazz.getMethod(
                        "setAllowUniversalAccessFromFileURLs", Boolean::class.javaPrimitiveType)
                method?.invoke(this.settings, true)
            }
        } catch (e: IllegalArgumentException) {
            e.printStackTrace()
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        } catch (e: InvocationTargetException) {
            e.printStackTrace()
        }

    }


}
