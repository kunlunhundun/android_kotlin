package com.ksmobile.app.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.CreateBankRequest
import com.ksmobile.app.data.request.GetByCardBinRequest
import com.ksmobile.app.data.response.CreatBankResponse
import com.ksmobile.app.data.response.GetByCardBinResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.MyLineInputEditText
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_bind_bank_card.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class BindBankCardActivity : BaseToolBarActivity() {
    val reqCode = 100
    var inputEditText: MyLineInputEditText? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_bind_bank_card
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.bind_card_activity_title))

    }

    override fun initView() {
        OverScrollDecoratorHelper.setUpOverScroll(sv_bind_bank)
        if (!TextUtils.isEmpty(ConfigUtils.realName)) {
            et_card_holder.setEditText(ConfigUtils.realName)
            et_card_holder.getEditText().isFocusable = false
            et_card_holder.getEditText().isFocusableInTouchMode = false
            et_card_holder.getEditText().isClickable = false

        }

        et_bank_card_type.setEditText("借记卡")

    }

    override fun initListener() {

        et_bank_address.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }

            inputEditText = et_bank_address
            val intent = Intent(this, CustomSelectorActivity::class.java)
            intent.putExtra(CustomSelectorActivity.SELECTOR_TYPE, CustomSelectorActivity.CITY)
            startActivityForResult(intent, reqCode)

        }


        et_bank_name.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            inputEditText = et_bank_name
            val intent = Intent(this, CustomSelectorActivity::class.java)
            intent.putExtra(CustomSelectorActivity.SELECTOR_TYPE, CustomSelectorActivity.BANKCARD)
            startActivityForResult(intent, reqCode)

        }

        et_bank_card_type.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            inputEditText = et_bank_card_type
            val intent = Intent(this, CustomSelectorActivity::class.java)
            intent.putExtra(CustomSelectorActivity.SELECTOR_TYPE, CustomSelectorActivity.BANKCARDTYPE)
            startActivityForResult(intent, reqCode)

        }

        btn_commit.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            checkRequest()
        }


        et_bank_card_number.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (TextUtils.isEmpty(et_bank_card_number.getEditTextContent())) {
                    et_bank_card_number.showError("银行卡号不能为空")
                } else if (et_bank_card_number.getEditTextContent().length < 8) {
                    et_bank_card_number.showError("为免取款失败，请输入您真实的银行卡号")
                }

            }

        }

        et_bank_branch.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    et_bank_branch.getEditTextContent().length < 4 -> {

                        et_bank_branch.showError("请输入银行卡的真实开户行")
                    }
                    !Utils.checkBankBranch(et_bank_branch.getEditTextContent()) -> {
                        et_bank_branch.showError("请您输入真实有效的开户网点地址")
                    }
                }
            }


        }
        et_bank_branch.getEditText().addTextChangedListener(bankTextWatcher)

        et_card_holder.getEditText().addTextChangedListener(textWatcher)

        et_bank_card_number.getEditText().addTextChangedListener(object : TextWatcher {
            var mCount = 0

            override fun afterTextChanged(s: Editable) {
                var length = s.toString().length
                //删除数字
                if (mCount == 0) {
                    if (length <= 14) {
                        et_bank_name.setEditText("")
                        et_bank_name.hiddenDrawableMid()
                        et_bank_card_type.setEditText("借记卡")
                        et_bank_card_number.hideError()
                    }
                }
                //添加数字
                if (mCount == 1) {
                    when (s.length) {
                        14 -> {
                            getByCardBin(s.toString().replace(" ", ""))
                        }

                    }
                }


            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, count: Int) {
                mCount = count
            }

            override fun onTextChanged(s: CharSequence, p1: Int, p2: Int, p3: Int) {


            }
        })

    }


    private fun checkRequest() {
        currentFocus.clearFocus()
        var cancle = false
        var error: String? = null
        var inputEditText: MyLineInputEditText? = null
        et_bank_card_number.hideError()
        et_bank_branch.hideError()
        et_card_holder.hideError()
        et_bank_name.hideError()
        et_bank_card_type.hideError()
        et_bank_address.hideError()
        when {
            TextUtils.isEmpty(et_card_holder.getEditTextContent()) -> {
                error = "持卡人不能为空"
                cancle = true
                inputEditText = et_card_holder
            }
            et_card_holder.getEditText().isFocusable && !Utils.checkRealName(et_card_holder.getEditTextContent()) -> {
                error = "请输入与您的银行卡一致的真实姓名"
                cancle = true
                inputEditText = et_card_holder
            }
            TextUtils.isEmpty(et_bank_card_number.getEditTextContent()) -> {
                error = "银行卡号不能为空"
                cancle = true
                inputEditText = et_bank_card_number
            }
            et_bank_card_number.getEditTextContent().length < 8 -> {
                error = "为免取款失败，请输入您真实的银行卡号"
                cancle = true
                inputEditText = et_bank_card_number
            }
            TextUtils.isEmpty(et_bank_name.getEditTextContent()) -> {
                error = "银行名称不能为空"
                cancle = true
                inputEditText = et_bank_name
            }
//            TextUtils.isEmpty(et_bank_card_type.getEditTextContent()) -> {
//                error = "银行卡类型不能为空"
//                cancle = true
//                inputEditText = et_bank_card_type
//            }
            TextUtils.isEmpty(et_bank_address.getEditTextContent()) -> {
                error = "请填写开户地区"
                cancle = true
                inputEditText = et_bank_address
            }

            et_bank_branch.getEditTextContent().length < 4 -> {
                error = "请输入银行卡的真实开户行"
                cancle = true
                inputEditText = et_bank_branch
            }
            !Utils.checkBankBranch(et_bank_branch.getEditTextContent()) -> {
                error = "请您输入真实有效的开户网点地址"
                cancle = true
                inputEditText = et_bank_branch
            }

        }

        if (cancle) {
            inputEditText?.showError(error)

        } else {
            addBankCard()
        }


    }


    private fun getByCardBin(cardNo: String) {
        val request = GetByCardBinRequest()
        request.bankCardNo = cardNo
        ApiClient.instance.service.getByCardBin(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetByCardBinResponse>(this, false) {
                    override fun businessFail(data: GetByCardBinResponse) {
//                        et_bank_card_number.showError(data.head.errMsg)
                    }

                    override fun businessSuccess(data: GetByCardBinResponse) {
                        et_bank_name.setDrawableMid(data.body?.bankIcon!!)
                        et_bank_card_number.hideError()
                        et_bank_name.setEditText(data.body?.bankName!!)
                        et_bank_card_type.setEditText(data.body?.cardTypeDesc)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }

                })

    }


    private fun addBankCard() {
        val request = CreateBankRequest()
        request.accountName = et_card_holder.getEditTextContent()
        request.accountNo = et_bank_card_number.getEditTextContent().replace(" ", "")
        request.accountType = et_bank_card_type.getEditTextContent()
        request.bankName = et_bank_name.getEditTextContent()
        request.bankBranchName = et_bank_branch.getEditTextContent()
        val temp = et_bank_address.getEditTextContent().split("  ")
        if (!temp.isEmpty()) {

            request.province = temp[0]
            request.city = temp[0]
        }
        if (temp.size>1) {
            request.city = temp[1]
        }

        ApiClient.instance.service.createBank(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatBankResponse>(this, true) {
                    override fun businessFail(data: CreatBankResponse) {
                        when (data.head.errCode) {
                            "GW_800824" -> {
                                NotifyDialog.show(this@BindBankCardActivity, "暂不支持取款到信用卡，请更换")
                            }

                            else -> {
                                NotifyDialog.show(this@BindBankCardActivity, data.head.errMsg)
                            }
                        }

                    }

                    override fun businessSuccess(data: CreatBankResponse) {
                        ConfigUtils.realName = data.body?.realName
                        ConfigUtils.bankCardCounts = ConfigUtils.bankCardCounts+1
                        NotifyDialog.show(this@BindBankCardActivity, "添加成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@BindBankCardActivity, apiErrorModel.message)
                    }

                })

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode) {

            if (resultCode == Activity.RESULT_OK) {
                inputEditText?.setEditText(data?.getStringExtra("value"))
                if (!TextUtils.isEmpty(data?.getStringExtra("img"))) {
                    inputEditText?.setDrawableMid(data?.getStringExtra("img")!!)
                }
            }
        }

    }

    private val textWatcher = object : TextWatcher {
        var beforeText = ""

        override fun afterTextChanged(s: Editable?) {
            val temp = s.toString()
            if (!TextUtils.isEmpty(temp)) {

                if (!Utils.checkStringFullChinese(temp)) {
                    if (!TextUtils.isEmpty(beforeText) && Utils.checkPoint(temp[temp.lastIndex].toString())) {
                        if (!beforeText.endsWith("·")) {
                            beforeText = "$beforeText·"
                        }

                    }
                    et_card_holder.setEditText(beforeText)
                    et_card_holder.getEditText().setSelection(et_card_holder.getEditTextContent().length)
                } else {

                    if (beforeText.endsWith("·") && s.toString().endsWith("·") && (beforeText.length + 1 == s.toString().length)) {
                        et_card_holder.setEditText(beforeText)
                        et_card_holder.getEditText().setSelection(et_card_holder.getEditTextContent().length)
                    }


                }
            }

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            beforeText = s.toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {


        }


    }


    private val bankTextWatcher = object : TextWatcher {
        var beforeText = ""

        override fun afterTextChanged(s: Editable?) {
            if (!TextUtils.isEmpty(s.toString())) {
                if (!Utils.checkBankBranch(s.toString())) {
                    et_bank_branch.setEditText(beforeText)
                    et_bank_branch.getEditText().setSelection(et_bank_branch.getEditTextContent().length)
                }
            }

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            beforeText = s.toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {


        }


    }

}