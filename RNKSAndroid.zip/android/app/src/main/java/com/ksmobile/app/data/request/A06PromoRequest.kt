package com.ksmobile.app.data.request



class A06PromoRequest : BaseRequestObject() {
    var promoCode = "SC"
//    var endpointType = "1"

}