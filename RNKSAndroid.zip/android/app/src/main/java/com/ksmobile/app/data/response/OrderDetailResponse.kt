package com.ksmobile.app.data.response

import com.ksmobile.app.data.OrderObject


/**
 * Created by ward.y on 2018/3/19.
 */
class OrderDetailResponse : BaseResponseObject() {
    val body:OrderObject? = null


}
