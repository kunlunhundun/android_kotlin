package com.ksmobile.app.data.response

import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class CreatPayOrderResponse : BaseResponseObject() {
    val body = Body()

    class Body {
        var accountName: String? = null
        var accountNo: String? = null
        var amount: BigDecimal = BigDecimal(0.0)
        var bankBranchName: String? = null
        var bankCity: String? = null
        var bankCode: String? = null
        var bankName: String? = null
        var bankIcon: String? = null
        var billNo: String? = null
        var createDate: String? = null
        var depositor: String? = null
        var flag: Int? = null
        var payLimitTime: String? = null
        var postscript: String? = null

    }
}
