package com.ksmobile.app.fragment.recharge

import android.annotation.SuppressLint
import android.app.ActionBar
import android.content.Intent
import android.graphics.Color
import android.support.constraint.ConstraintLayout
import android.text.*
import android.text.method.DigitsKeyListener
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderHandBtcPaymentActivity
import com.ksmobile.app.adapter.RechargeFastSelectionListAdapter
import com.ksmobile.app.data.request.PointCardPaymentRequest
import com.ksmobile.app.data.request.QueryBtcRateAndAddressRequest
import com.ksmobile.app.data.request.QueryPointCardListRequest
import com.ksmobile.app.data.response.PointCardPaymentResponse
import com.ksmobile.app.data.response.QueryBtcRateAndAddressResponse
import com.ksmobile.app.data.response.QueryPayWaysV3Response
import com.ksmobile.app.data.response.QueryPointCardListResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.DecimalDigitsInputFilter
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.NotifyDialog
import com.ksmobile.app.view.hybride.BrowserActivity
import kotlinx.android.synthetic.main.fragment_recharge_base_view.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat

class OtherRechargeFragment : MobileRechargeFragment() {

    val QQWAP = "11"
    val QQQRCOD = "7"
    val JDWAP = "17"
    val JDQRCODE = "16"
    val POINTCARD = "2"
    val BITE = "20"
    val HANDBITE = "98"
    var fee: Int? = 0
    private var endNumber: String? = ""
    var queryBtcRateAndAddressResponse: QueryBtcRateAndAddressResponse? = null
    override fun showPayWay() {
        super.showPayWay()
        rl_transfer_account.setDrawableLeft(R.mipmap.icon_payment_other)
        rl_transfer_account.setEditText(payWay[3])
        linear_visible.visibility = View.VISIBLE
        recharge_account_payment_name.visibility = View.VISIBLE
        pay_bank_layout.visibility = View.GONE
        qrcode_pay_layout.visibility = View.GONE
        rl_pay_type.visibility = View.VISIBLE
        initPayType(payKind)

        et_point_card_type.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    TextUtils.isEmpty(et_point_card_type.getEditTextContent()) -> {
                        et_point_card_type.showError("请选择充值点卡类型")
                    }
                }
            }
        }

        et_point_card_number.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    !Utils.checkPointCardNumber(et_point_card_number.getEditTextContent()) -> {
                        et_point_card_number.showError("请输入正确的点卡卡号")
                    }
                }
            }
        }

        et_point_card_number.getEditText().keyListener = (DigitsKeyListener.getInstance("1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"))

        et_point_card_password.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    !Utils.checkPointCardPassword(et_point_card_password.getEditTextContent()) -> {
                        et_point_card_password.showError("请输入正确的点卡密码")
                    }
                }
            }
        }
        et_point_card_password.getEditText().keyListener = (DigitsKeyListener.getInstance("1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"))

        et_bit_hand_amount.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    TextUtils.isEmpty(et_bit_hand_amount.getEditTextContent()) -> {
                        et_bit_hand_amount.showError("请输入比特币数量")
                    }
                }
            }
        }

        et_bit_hand_amount.getEditText().filters = arrayOf(DecimalDigitsInputFilter(2))
        et_bit_hand_amount.getEditText().addTextChangedListener(object : TextWatcher {
            @SuppressLint("SetTextI18n")
            override fun afterTextChanged(s: Editable?) {
                if (endNumber == "0" && s.toString() != "0." && s.toString() != "") {
                    et_bit_hand_amount.setEditText("0")
                    et_bit_hand_amount.getEditText().setSelection(1)
                    return
                }

                if (endNumber == "" && s.toString() == ".") {
                    et_bit_hand_amount.setEditText("")
                    return
                }


                if (!TextUtils.isEmpty(s.toString()) && BigDecimal(s.toString()) > BigDecimal(0)) {

                    var number = BigDecimal(s.toString())
                    if (number <= BigDecimal(30)) {

                    } else {
                        if (endNumber == "") {
                            et_bit_hand_amount.setEditText("")
                            ToastUtils.show("单笔限额${0.01}BTC~${30}BTC")
                        } else {
                            et_bit_hand_amount.setEditText(endNumber)
                            et_bit_hand_amount.getEditText().setSelection(endNumber!!.length - 1)
                            ToastUtils.show("单笔限额${0.01}BTC~${30}BTC")
                        }
                    }
                    if (null != queryBtcRateAndAddressResponse?.body?.btcRate) {

                        tv_show_money_change_detail.text = "${BigDecimal(BigDecimal(et_bit_hand_amount.getEditTextContent()).toDouble().times(queryBtcRateAndAddressResponse?.body?.btcRate!!.toDouble())).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()}元"
                        et_recharge_amount.setEditText(tv_show_money_change_detail.text.toString().replace("元", ""))
                        tv_show_money_change_detail.visibility = View.VISIBLE
                    }
                } else {
                    tv_show_money_change_detail.text = "        "
                }

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                endNumber = s.toString()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })

    }

    override fun goPay() {


        if (payType == POINTCARD) {

            when {
                TextUtils.isEmpty(et_point_card_type.getEditTextContent()) -> {
                    et_point_card_type.showError("请选择充值点卡类型")
                }

                !Utils.checkPointCardNumber(et_point_card_number.getEditTextContent()) -> {
                    et_point_card_number.showError("请输入正确的点卡卡号")
                }
                !Utils.checkPointCardPassword(et_point_card_password.getEditTextContent()) -> {
                    et_point_card_password.showError("请输入正确的点卡密码")
                }

                TextUtils.isEmpty(et_recharge_amount.getEditTextContent()) -> {
                    error_no_selected.visibility = View.VISIBLE
                }
                else -> {
                    pointCardPayment()
                }
            }

        } else if (payType == HANDBITE) {
            if (TextUtils.isEmpty(et_bit_hand_amount.getEditTextContent())) {
                et_bit_hand_amount.showError("请输入比特币数量")

            } else {
                queryBtcRateAndAddress(et_bit_hand_amount.getEditTextContent())

            }

        } else {
            if (TextUtils.isEmpty(et_recharge_amount.getEditTextContent())) {
                if (et_recharge_amount.visibility == View.VISIBLE) {
                    et_recharge_amount.showError("请输入金额")
                } else {
                    error_no_selected.visibility = View.VISIBLE
                }

                return
            }

            if (BigDecimal(et_recharge_amount.getEditTextContent()) < minAmount
                    || BigDecimal(et_recharge_amount.getEditTextContent()) > maxAmount) {
                et_recharge_amount.showError("单笔限额${minAmount}元~${maxAmount}元")
                return
            }
            showOnlinePopWindow(rl_transfer_account)
        }

    }

    /**
     * 初始化充值方式
     */
    private fun initPayType(payWayObject: QueryPayWaysV3Response.PayWayObject?) {
        payNames.clear()
        payTypes.clear()
        payWayObject?.payTypeList?.forEach {
            payTypes.add(it.payType)
            payNames.add(it.payTypeName)

        }

        togglePayType(payTypes[0])
        rl_pay_type.setEditText(payNames[0])
    }

    /**
     * 切换充值方式
     */
    override fun togglePayType(onlinePayType: String) {
        super.togglePayType(onlinePayType)
        payType = onlinePayType
        recharge_account_payment_name.visibility = View.GONE
        et_point_card_type.visibility = View.GONE
        ll_point_card.visibility = View.GONE
        point_recharge_number.visibility = View.GONE
        ll_hand_bit.visibility = View.GONE
        et_point_card_type.setEditText("")
        error_no_selected.visibility = View.GONE
        when (payType) {
            POINTCARD -> {
                ll_point_card.visibility = View.VISIBLE
                et_point_card_type.visibility = View.VISIBLE
                et_recharge_amount.visibility = View.GONE
                lv_selections.visibility = View.GONE
                tv_show_point_detail.text = String.format(getString(R.string.recharge_point_card_info), 0, 0, 0)
                queryPointCardList()
                et_point_card_type.setOnClickListener {
                    if (pointcardData == null) {
                        NotifyDialog.show(reChargeActivity!!, "暂无支持点卡，请更换存款方式")

                    } else {
                        pickPointCardPopWindow()
                    }
                }
            }
            HANDBITE -> {
                ll_hand_bit.visibility = View.VISIBLE
                et_bit_hand_amount.setEditText("")
                et_recharge_amount.visibility = View.GONE
                lv_selections.visibility = View.GONE
                queryBtcRateAndAddress("1")

            }
            else -> {
                if (onlinePayType==QQQRCOD){
                    tv_qrcode_tip.visibility = View.VISIBLE
                }
                queryOnlineBanks(onlinePayType)

            }
        }


    }

    /**
     * 展示充值确认弹窗
     */
    override fun showPopWindow() {
        showBQPopWindow(rl_transfer_account, 0)
    }

    /**
     * 确认充值弹窗
     */
    override fun showOnlinePopWindow(v: View) {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_query_online, null)
        val height = if(payType==JDQRCODE&&restPromoAmount>BigDecimal(0)) 360f else 260f
        val mPopupWindow1 = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(context, height), true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val close: ImageView = view.findViewById(R.id.image_close)
        val cancle: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val bankMsg: TextView = view.findViewById(R.id.tv_bank_msg)
        val tvMoney: TextView = view.findViewById(R.id.tv_money)
        val btcLabel: TextView = view.findViewById(R.id.btc_label)
        val linear: LinearLayout = view.findViewById(R.id.linear_bank_msg)
        val ll_promo_detail: LinearLayout = view.findViewById(R.id.ll_promo_detail)
        val pop_promo_money: TextView = view.findViewById(R.id.pop_promo_money)
        val pop_arrival_money: TextView = view.findViewById(R.id.pop_arrival_money)

        linear.visibility = View.GONE
        sure.text = "前往支付"
        when (payType) {

            HANDBITE -> {
                bankMsg.text = "请使用比特币支付"

            }
            else ->{
                bankMsg.text = "请使用${rl_pay_type.getEditTextContent()}"

                if (restPromoAmount> BigDecimal(0) &&payType==JDQRCODE){
                    ll_promo_detail.visibility=View.VISIBLE
                    pop_promo_money.text = tv_promo_money.text
                    pop_arrival_money.text = tv_arrival_money.text
                }
            }
        }

        if (payType == HANDBITE) {
            btcLabel.visibility = View.VISIBLE
            tvMoney.text = et_bit_hand_amount.getEditTextContent()
            sure.setOnClickListener {
                mPopupWindow1.dismiss()
                val intent = Intent(reChargeActivity, OrderHandBtcPaymentActivity::class.java)
                intent.putExtra("data", Gson().toJson(queryBtcRateAndAddressResponse))
                startActivity(intent)
            }

        } else {
            tvMoney.text = "¥${Utils.formatMoney(et_recharge_amount.getEditTextContent())}"
            sure.setOnClickListener {
                createOnlineOrderRequest("", payType)
                mPopupWindow1.dismiss()

            }
        }




        close.setOnClickListener { mPopupWindow1.dismiss() }
        cancle.setOnClickListener { mPopupWindow1.dismiss() }


        mPopupWindow1.showAtLocation(v, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }

    /**
     * 查询点卡支付接口
     */
    private fun queryPointCardList() {
        var request = QueryPointCardListRequest()
        ApiClient.instance.service.queryPointCardList(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryPointCardListResponse>(activity!!, true) {
                    override fun businessFail(data: QueryPointCardListResponse) {

                        NotifyDialog.show(reChargeActivity!!, "暂无支持点卡，请更换存款方式")
                    }

                    override fun businessSuccess(data: QueryPointCardListResponse) {
                        if (data.body?.pointCardList != null) {
                            if (data.body?.pointCardList!!.isEmpty()) {
                                NotifyDialog.show(reChargeActivity!!, "暂无支持点卡，请更换存款方式")
                            } else {
                                pointcardData = data
                                wheelPosition = -1

                            }
                        } else {
                            NotifyDialog.show(reChargeActivity!!, "暂无支持点卡，请更换存款方式")
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }


    /**
     * 查询比特币汇率及存款地址
     */
    private fun queryBtcRateAndAddress(amount: String) {

        var request = QueryBtcRateAndAddressRequest()
        request.btcAmount = amount
        ApiClient.instance.service.queryBtcRateAndAddress(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryBtcRateAndAddressResponse>(activity!!, true) {
                    override fun businessFail(data: QueryBtcRateAndAddressResponse) {
                        NotifyDialog.show(activity!!, data.head.errMsg)

                    }

                    override fun businessSuccess(data: QueryBtcRateAndAddressResponse) {
                        queryBtcRateAndAddressResponse = data
                        if (TextUtils.isEmpty(et_bit_hand_amount.getEditTextContent())) {
                            setLimit(0.00, 100000000.00)
                        } else {

                            if (TextUtils.isEmpty(data.body?.btcAddress)){
                                NotifyDialog.show(activity!!,"暂不支持比特币支付，请更换存款方式")
                            }else{
                                tv_show_money_change_detail.text = " ${data.body?.amount}元 "
                                tv_show_money_change_detail.visibility = View.VISIBLE
                                et_recharge_amount.setEditText(data.body?.amount)
                                showOnlinePopWindow(rl_transfer_account)
                            }

                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(activity!!, apiErrorModel.message)
                    }

                })
    }


    /**
     * 点卡支付接口
     */
    private fun pointCardPayment() {
        var request = PointCardPaymentRequest()
        request.amount = et_recharge_amount.getEditTextContent()
        request.cardCode = pointcardData?.body?.pointCardList?.get(wheelPosition)?.cardCode
        request.payid = pointcardData?.body?.payid
        request.cardNo = et_point_card_number.getEditTextContent()
        request.cardPwd = et_point_card_password.getEditTextContent()

        ApiClient.instance.service.pointCardPayment(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<PointCardPaymentResponse>(activity!!, true) {
                    override fun businessFail(data: PointCardPaymentResponse) {
                        NotifyDialog.show(reChargeActivity!!, "支付失败，请更换存款方式")
                    }

                    override fun businessSuccess(data: PointCardPaymentResponse) {
                        if (data.body != null) {

                            pointCardPaymentResponse = data
                            val intent = Intent(activity, BrowserActivity::class.java)
                            intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
                            intent.putExtra(BrowserActivity.PARAM_IS_CARD_PAY, true)
                            val postString = StringBuilder("")
                            if (data.body?.xparam != null) {
                                postString.append("newaccount=${data.body?.xparam?.newaccount}&")
                                        .append("keycode=${data.body?.xparam?.keycode}&")
                                        .append("product=${data.body?.xparam?.product}&")
                                        .append("customerType=${data.body?.xparam?.customerType}&")
                                        .append("loginname=${data.body?.xparam?.loginname}&")
                                        .append("language=${data.body?.xparam?.language}&")
                                        .append("billno=${data.body?.xparam?.billno}&")
                            }

                            if (data.body?.nextType == "1") {
                                intent.putExtra(BrowserActivity.PARAM_POST_PARAM, postString.toString())
                                intent.putExtra(BrowserActivity.PARAM_URL, data.body?.xurl)
                            } else {
                                intent.putExtra(BrowserActivity.PARAM_URL, "${data.body?.xurl}?$postString")
                            }


                            startActivity(intent)


                        } else {
                            NotifyDialog.show(reChargeActivity!!, "支付失败，请更换存款方式")
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }


    /**
     * 选择点卡
     */

    private fun pickPointCardPopWindow() {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_transfer, null)
        val mPopupWindow1 = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(context, 315f), true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style
        var adapter: PointCardListAdapter
        var iv_back: ImageView = view.findViewById(R.id.iv_back)
        var iv_x: ImageView = view.findViewById(R.id.iv_x)
        var lv_bank_list: ListView = view.findViewById(R.id.lv_bank_list)
        var pop_confirm: LinearLayout = view.findViewById(R.id.pop_confirm)
        var pop_bank_list: ConstraintLayout = view.findViewById(R.id.pop_bank_list)
        var tv_title: TextView = view.findViewById(R.id.pick_title)
        iv_x.visibility =View.VISIBLE
        iv_back.visibility =View.GONE
        pop_confirm.visibility = View.GONE
        tv_title.text = "选择点卡类型"
        pop_bank_list.visibility = View.VISIBLE
        if (pointcardData?.body?.pointCardList?.size != 0) {
            adapter = PointCardListAdapter(pointcardData?.body?.pointCardList)
            lv_bank_list.adapter = adapter
            lv_bank_list.setOnItemClickListener { _, _, position, _ ->
                wheelPosition = position
                adapter.notifyDataSetChanged()
                et_point_card_type.setEditText(pointcardData?.body?.pointCardList?.get(wheelPosition)?.name)
                fee = pointcardData?.body?.pointCardList?.get(wheelPosition)?.fee
                point_recharge_number.visibility = View.VISIBLE
                setPointSelections(pointcardData?.body?.pointCardList?.get(wheelPosition)?.amountList)

                mPopupWindow1.dismiss()
            }
        }


        iv_x.setOnClickListener { mPopupWindow1.dismiss() }
        mPopupWindow1.showAtLocation(rl_pay_type, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }


    private fun setPointSelections(selections: MutableList<String>?) {
        tv_show_point_detail.text = String.format(getString(R.string.recharge_point_card_info), 0, 0, 0)
        if (selections == null || selections.isEmpty()) {
            return
        }
        lv_selections.visibility = View.VISIBLE
        mAdapter = RechargeFastSelectionListAdapter(baseContext!!, selections)
        mAdapter?.setClickCallBack(object : RechargeFastSelectionListAdapter.ItemClickCallBack {
            override fun onItemClick(pos: Int, textView: CheckedTextView) {
                if (fee!=null){
                    val total = BigDecimal(selections[pos]).toFloat()
                    val serviceCharge = total*(BigDecimal(fee!!).toFloat()/100f)
                    val decimalFormat = DecimalFormat("0.00")
                    tv_show_point_detail.text = String.format(getString(R.string.recharge_point_card_info),selections[pos], decimalFormat.format(serviceCharge).replace(".00",""), decimalFormat.format(total-serviceCharge).replace(".00",""))
                }

                et_recharge_amount.setEditText(selections[pos])
                val tempString = tv_show_point_detail.text
                val ssbuilder = SpannableStringBuilder(tempString)
                ssbuilder.setSpan(ForegroundColorSpan(Color.parseColor("#E9664B")), tempString.indexOf(":", 0) + 1, tempString.indexOf("元", 0) + 1, Spannable.SPAN_EXCLUSIVE_INCLUSIVE)
                ssbuilder.setSpan(ForegroundColorSpan(Color.parseColor("#E9664B")), tempString.indexOf(":", 7) + 1, tempString.indexOf("元", tempString.indexOf(":", 7)) + 1, Spannable.SPAN_EXCLUSIVE_INCLUSIVE)
                ssbuilder.setSpan(ForegroundColorSpan(Color.parseColor("#E9664B")), tempString.lastIndexOf(":") + 1, tempString.length, Spannable.SPAN_EXCLUSIVE_INCLUSIVE)
                tv_show_point_detail.text = ssbuilder
                textView.isChecked = true
                if (oldSelectedView != null && oldSelectedView != textView) {
                    oldSelectedView?.isChecked = false
                }
                oldSelectedView = textView
            }

        })

        lv_selections.adapter = mAdapter
    }
}