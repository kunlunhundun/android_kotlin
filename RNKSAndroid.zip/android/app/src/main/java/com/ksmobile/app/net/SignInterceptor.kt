package com.ksmobile.app.net

import com.ksmobile.app.BuildConfig
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.ProjectUtils
import com.ksmobile.app.util.DeviceInfo
import com.ksmobile.app.util.LogUtils
import com.ksmobile.app.util.Utils
import common.util.sign.SignUtils
import java.io.EOFException
import java.io.IOException
import java.nio.charset.Charset

import okhttp3.Interceptor
import okhttp3.Response
import okio.Buffer

/**
 * @Create by ward 2018/10/29
 */
class SignInterceptor : Interceptor {

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {

        var request = chain.request()


        val requestBody = request.body()
        val hasRequestBody = requestBody != null

        if (hasRequestBody) {
            val buffer = Buffer()
            requestBody!!.writeTo(buffer)

            var charset: Charset? = UTF8
            val contentType = requestBody.contentType()
            if (contentType != null) {
                charset = contentType.charset(UTF8)
            }

            if (isPlaintext(buffer)) {
                val qid = SignUtils.getQid()
                val temp = buffer.readString(charset!!)
                request = request.newBuilder()
                        .addHeader("sign", Utils.getSign(temp, qid))
                        .addHeader("qid", qid)
                        .addHeader("pid", ProjectUtils.PID)
                        .addHeader("token", Utils.getToken())
                        .addHeader("appId", ProjectUtils.APPID)
                        .addHeader("v", BuildConfig.VERSION_NAME)
                        .addHeader("domainName", ConfigUtils.DOMAIN_NAME)
                        .addHeader("parentId", ConfigUtils.parentId)
                        .addHeader("deviceId", DeviceInfo.getDeviceId())
                        .build()

            }

        }

        val response: Response
        try {
            response = chain.proceed(request)
        } catch (e: Exception) {
            LogUtils.e("<-- HTTP FAILED: $e")
            throw e
        }

        return response
    }

    companion object {
        private val UTF8 = Charset.forName("UTF-8")
        internal fun isPlaintext(buffer: Buffer): Boolean {
            try {
                val prefix = Buffer()
                val byteCount = if (buffer.size() < 64) buffer.size() else 64
                buffer.copyTo(prefix, 0, byteCount)
                for (i in 0..15) {
                    if (prefix.exhausted()) {
                        break
                    }
                    val codePoint = prefix.readUtf8CodePoint()
                    if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                        return false
                    }
                }
                return true
            } catch (e: EOFException) {
                return false // Truncated UTF-8 sequence.
            }

        }
    }

}
