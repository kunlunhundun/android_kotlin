package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryPayWaysV3Response : BaseResponseObject() {
    val body = Body(0, 0, 0, 0, mutableListOf())

    data class Body(var promoTag: Int, val bindMobile: Int, val blackFlag: Int, val bindBankCard: Int, val payList: MutableList<PayWayObject>) {

        fun initPromoTag() {
            payList.forEach {
                it.initPromoTag()
                if (it.promoTag == 1) {
                    promoTag = 1
                }
            }
        }
    }

    data class PayWayObject(var promoTag: Int, var payKind: String, var payKindName: String, var payKindIcon: String, var payTypeList: MutableList<PayType>) {


        fun initPromoTag() {
            payTypeList.forEach {

                it.initPromoTag()
                if (it.promoTag == 1) {
                    promoTag = 1
                }
            }
        }
    }

    data class PayType(var promoTag: Int, var payType: String, var payTypeIcon: String, var payTypeName: String, var typeTip:TypeTip, var liveUrl:String) {

        fun initPromoTag() {
            if (payType == "15" || payType == "16") {
                promoTag = 1
            }
        }

    }
    data class TypeTip(var recommend:Int,var status:String){

    }



}
