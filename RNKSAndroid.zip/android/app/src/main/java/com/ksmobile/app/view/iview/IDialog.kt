package com.ksmobile.app.view.iview

interface IDialog {
    fun onLayoutChange(show: Boolean)
}