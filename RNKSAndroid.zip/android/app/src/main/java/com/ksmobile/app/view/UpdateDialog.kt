package com.ksmobile.app.view

import android.app.Dialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.support.v4.app.FragmentManager
import android.text.TextUtils
import android.view.*
import android.widget.*
import com.google.gson.Gson
import com.trello.rxlifecycle2.components.support.RxDialogFragment
import com.vector.update_app.UpdateAppBean
import com.vector.update_app.UpdateAppManager
import com.vector.update_app.service.DownloadService
import com.vector.update_app.utils.AppUpdateUtils
import com.ksmobile.app.R
import com.ksmobile.app.data.response.UpgradeResponse
import com.ksmobile.app.download.UpdateAppHttpUtil
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.StatusBarUtil
import com.ksmobile.app.util.ToastUtils
import java.io.File
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/9/13.
 * 升级弹窗
 */

class UpdateDialog : RxDialogFragment(), DialogInterface.OnKeyListener {
    lateinit var timer: CountDownTimer
    lateinit var tv_progress: TextView
    lateinit var tv_size: TextView
    lateinit var tv_go_install: TextView
    lateinit var tv_tip: TextView
    lateinit var title: TextView
    lateinit var progress_bar: ProgressBar
    lateinit var data: UpgradeResponse

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        // 使用不带Theme的构造器, 获得的dialog边框距离屏幕仍有几毫米的缝隙。
        val bundle = arguments
        if (!TextUtils.isEmpty(bundle?.getString("data"))) {
            data = Gson().fromJson(bundle?.getString("data"), UpgradeResponse::class.java)
        }
        val dialog = initStyle()
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 设置Content前设定
        dialog.setContentView(R.layout.update_app_dialog)
        initUpdateDialog(dialog)
        dialog.setCanceledOnTouchOutside(false) // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        val window = dialog.window
        setTranslucentStatus(window)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = window.attributes
        lp.width = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.gravity = Gravity.CENTER
        window.attributes = lp
        dialog.setOnKeyListener(this)

        return dialog
    }


    /**
     * ethan
     * 初始化style样式
     */
    private fun initStyle(): Dialog {

        return Dialog(activity, R.style.MyDialog)
    }


    private fun initUpdateDialog(dialog: Dialog) {
        title = dialog.findViewById(R.id.title)
        val cl_update_confirm = dialog.findViewById<ConstraintLayout>(R.id.cl_update_confirm)
        val ll_update_progress = dialog.findViewById<ConstraintLayout>(R.id.ll_update_progress)
        val tv_update_content = dialog.findViewById<TextView>(R.id.tv_update_content)
        val tv_exit = dialog.findViewById<TextView>(R.id.tv_exit)
        val tv_update = dialog.findViewById<TextView>(R.id.tv_update)
        tv_size = dialog.findViewById(R.id.tv_size)
        tv_progress = dialog.findViewById(R.id.tv_progress)
        progress_bar = dialog.findViewById(R.id.progress_bar)
        tv_go_install = dialog.findViewById(R.id.tv_go_install)
        tv_tip = dialog.findViewById(R.id.tv_tip)

        tv_update.setOnClickListener {
//            data.body?.appDownUrl = "http://file.ws.126.net/3g/client/netease_newsreader_android.apk"
            if (!TextUtils.isEmpty(data.body?.appDownUrl)) {
                ll_update_progress.visibility = View.VISIBLE
                cl_update_confirm.visibility = View.GONE
                title.text = "新版本升级中..."
                updateApp(data.body?.appDownUrl!!)
            } else {
                ToastUtils.show("更新失败，没有检测到下载地址")
                dismiss()
            }

        }
        tv_exit.setOnClickListener {
            AppInitManager.getActivityListManager().exitApp()
        }


    }


    private fun setTranslucentStatus(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }

        StatusBarUtil.StatusBarLightMode(window)
    }

    override fun onKey(dialog: DialogInterface?, keyCode: Int, event: KeyEvent?): Boolean {
        return if (keyCode == KeyEvent.KEYCODE_BACK) {
            activity?.finish()
            true
        } else {
            false
        }
    }

    private fun updateApp(mDyAppDownUrl: String) {
        if (!TextUtils.isEmpty(mDyAppDownUrl)) {
            val updateAppBean = UpdateAppBean()

            //设置 apk 的下载地址
            updateAppBean.apkFileUrl = mDyAppDownUrl
            var path: String? = ""
            if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED || !Environment.isExternalStorageRemovable()) {
                try {
                    path = context!!.externalCacheDir?.absolutePath
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (TextUtils.isEmpty(path)) {
                    path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                }
            } else {
                path = context!!.cacheDir.absolutePath
            }

            //设置apk 的保存路径
            updateAppBean.targetPath = path
            //实现网络接口，只实现下载就可以
            updateAppBean.httpManager = UpdateAppHttpUtil()
            updateAppBean.dismissNotificationProgress(true)
            UpdateAppManager.download(activity, updateAppBean, object : DownloadService.DownloadCallback {

                override fun onStart() {

                }

                override fun onProgress(progress: Float, totalSize: Long) {
                    progress_bar.progress = Math.round(progress * 100)
                    tv_progress.text = "${Math.round(progress * 100)}%"
                    tv_size.text = "${BigDecimal((totalSize * progress).toString()).divide(BigDecimal(1024 * 1024), 2, BigDecimal.ROUND_DOWN)}MB/${BigDecimal(totalSize).divide(BigDecimal(1024 * 1024), 2, BigDecimal.ROUND_DOWN)}MB"

                }

                override fun setMax(totalSize: Long) {
                }

                override fun onFinish(file: File): Boolean {
                    timer = initTimer(10)
                    progress_bar.progressDrawable = resources.getDrawable(R.drawable.progress_bg_complete)
                    tv_go_install.visibility = View.VISIBLE
                    title.text = "升级完成"
                    timer.start()
                    tv_go_install.setOnClickListener {
                        timer.cancel()
                        dismiss()
                        AppUpdateUtils.installApp(this@UpdateDialog, file)
                    }
                    return false
                }

                override fun onError(msg: String) {
                }

                override fun onInstallAppAndAppOnForeground(file: File): Boolean {
                    return false
                }
            })

        }

    }


    private fun initTimer(time: Long): CountDownTimer {
        timer = object : CountDownTimer(time * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tv_go_install.text = String.format(getString(R.string.update_install), (millisUntilFinished / 1000))
            }

            override fun onFinish() {
                tv_go_install.performClick()
            }

        }

        return timer
    }



}

