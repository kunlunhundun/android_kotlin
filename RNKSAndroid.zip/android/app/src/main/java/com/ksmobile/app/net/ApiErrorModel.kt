
package com.ksmobile.app.net

data class ApiErrorModel(var status: Int, var message: String)
