package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class GetByLoginNameResponse : BaseResponseObject() {

    val body:Body?=null


    data class Body(var email:String?,
                    var emailBind:Int?,
                    var loginName:String?,
                    var mobileNo:String?,
                    var mobileNoBind:Int?,
                    var realName:String?,
                    var starLevel:Int?,
                    var token:String?,
                    var type:Int?,
                    var registDate:String?,
                    var gender:String?,
                    var address:String?,
                    var remark:String?,
                    var birthday:String?,
                    var avatar: String?,
                    var cashCredit:Float = 0f,
                    var bankCardNum:Int,
                    var btcNum:Int,
                    var xmFlag:Int,
                    var gameCredit:Float=0f,
                    var verifyCode:String,
                    var starLevelName:String
    )

}
