package com.ksmobile.app.view

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.Button
import com.ksmobile.app.R

class MyButton (context: Context,attributeSet: AttributeSet):Button(context,attributeSet) {

    init {
        setBackgroundResource(R.drawable.my_button_selector)
        gravity = Gravity.CENTER
        if (isEnabled){
            setTextColor(resources.getColor(R.color.colorWhite))
        }else{
            setTextColor(resources.getColor(R.color.colorTextGrey))
        }

    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)

        if (enabled){
            setTextColor(resources.getColor(R.color.colorWhite))
        }else{
            setTextColor(resources.getColor(R.color.colorTextGrey))
        }

    }

}