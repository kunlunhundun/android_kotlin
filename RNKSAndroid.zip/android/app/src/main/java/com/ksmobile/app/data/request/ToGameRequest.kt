package com.ksmobile.app.data.request


class ToGameRequest : BaseRequestObject() {
    var gameCode = ""
}