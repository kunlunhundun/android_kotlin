package com.ksmobile.app.activity

import android.content.Intent
import com.bigkoo.convenientbanner.ConvenientBanner
import com.ksmobile.app.R
import com.ksmobile.app.util.LocalImageHolderView
import kotlinx.android.synthetic.main.activity_intro.*

class IntroActivity : BaseActivity() {

    private var banner: ConvenientBanner<Int>? = null
    private var bannerImages = listOf(R.mipmap.intro1)

    override fun getLayoutId(): Int {
        return R.layout.activity_intro
    }

    override fun initView() {

        tv_jump.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        if (bannerImages != null && bannerImages.isNotEmpty()) {
            banner = findViewById(R.id.iv_banner)
            banner?.setPages({ LocalImageHolderView() }, bannerImages)?.setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.ALIGN_PARENT_RIGHT)
            banner?.scrollDuration = 1000
//            banner?.setPageIndicator(intArrayOf(R.drawable.page_indicator, R.drawable.page_indicator_focus))
            banner?.setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.CENTER_HORIZONTAL)
            banner?.isCanLoop = false
            banner?.setcurrentitem(0)
        }
    }

    override fun initListener() {


    }
}