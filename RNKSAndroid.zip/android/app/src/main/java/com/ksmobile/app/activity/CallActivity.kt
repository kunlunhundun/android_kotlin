package com.ksmobile.app.activity

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.TextUtils
import android.view.View
import com.jxccp.lib.sip.CallApi
import com.jxccp.lib.sip.CallException
import com.jxccp.lib.sip.CallListener
import com.ksmobile.app.R
import com.ksmobile.app.util.ToastUtils
import kotlinx.android.synthetic.main.activity_call.*


class CallActivity : BaseActivity() {

    private var stateStringBuider = StringBuilder()
    override fun initView() {
        val intent = intent
        val number = intent.getStringExtra("number")
        val uid = intent.getStringExtra("uid")
        val isIncoming = intent.getBooleanExtra("isIncoming", false)
        if (!isIncoming) {
            makeCall(number, uid)
        } else {
            hang_up.tag = "Accept"
        }
    }

    override fun initListener() {
        CallApi.addListener(mCallListener)
        button0.setOnClickListener(l)
        button1.setOnClickListener(l)
        button2.setOnClickListener(l)
        button3.setOnClickListener(l)
        button4.setOnClickListener(l)
        button5.setOnClickListener(l)
        button6.setOnClickListener(l)
        button7.setOnClickListener(l)
        button8.setOnClickListener(l)
        button9.setOnClickListener(l)
        buttonSharp.setOnClickListener(l)
        buttonStar.setOnClickListener(l)
        hang_up.setOnClickListener(l)
        hands_free.setOnClickListener(l)
        dial.setOnClickListener(l)
        enableButtons(false)


    }

    override fun getLayoutId(): Int {
        return R.layout.activity_call
    }


    private val mCallListener = object : CallListener() {

        override fun onIncomingCall(from: String) {

        }

        override fun onStateChanged(state: Int, stateCode: Int) {
            runOnUiThread {
                when (state) {
                    CallListener.CALL_STATE_CONNECTED -> {
                        enableButtons(true)
                        showTime()
                    }
                    CallListener.CALL_STATE_TERMINATED -> finish()
                }
            }
        }

        override fun onError(reason: Int) {
            ToastUtils.show("onError: reason=$reason")
            when (reason) {
                CallListener.REASON_TIMEOUT -> {
                }
                else -> {
                }
            }
            finish()
        }
    }

    private var l: View.OnClickListener = View.OnClickListener { v ->
        when (v.id) {
            R.id.hands_free -> {
                hands_free.isSelected = !hands_free.isSelected
                CallApi.enableSpeaker(hands_free.isSelected)
                if (hands_free.isSelected) {
                    hands_free.setImageResource(R.mipmap.hands_free_normal)
                } else {
                    hands_free.setImageResource(R.mipmap.hands_free_hover)
                }
            }
            R.id.dial -> {
                dial.isSelected = !dial.isSelected
                if (dial.isSelected) {
                    dial.setImageResource(R.mipmap.hidden)
                    ll_dial.visibility = View.VISIBLE
                    voice_show.visibility = View.GONE
                } else {
                    ll_dial.visibility = View.GONE
                    voice_show.visibility = View.VISIBLE
                    dispearDial()
                    dial.setImageResource(R.mipmap.dial)
                }
            }
            R.id.button0 -> {
                pressButton("0")

            }
            R.id.button1 ->pressButton("1")
            R.id.button2 -> pressButton("2")
            R.id.button3 -> pressButton("3")
            R.id.button4 -> pressButton("4")
            R.id.button5 -> pressButton("5")
            R.id.button6 -> pressButton("6")
            R.id.button7 -> pressButton("7")
            R.id.button8 -> pressButton("8")
            R.id.button9 -> pressButton("9")
            R.id.buttonStar -> pressButton("*")
            R.id.buttonSharp -> pressButton("#")
            R.id.hang_up -> if (v.tag == "Accept") {
                acceptCall()

            } else {
                terminateCall()
            }
        }
    }


    override fun onDestroy() {
        CallApi.removeListener(mCallListener)
        super.onDestroy()
    }

    override fun onBackPressed() {
        terminateCall()
        super.onBackPressed()
    }

    private fun makeCall(calleeNumber: String, uid: String) {
        object : Thread() {
            override fun run() {
                try {
                    CallApi.makeCall(calleeNumber, uid)
                } catch (e: CallException) {
                    processCallException(e)
                }

            }
        }.start()
    }

    private fun processCallException(e: CallException) {
        when (e.code) {
            CallException.CODE_NOT_INITIALIZED, CallException.CODE_NETWORK_NOT_AVAILABLE, CallException.CODE_CLIENT_BUSY -> ToastUtils.show(e.message!!)
        }
        finish()
    }

    private fun enableButtons(enable: Boolean) {
        button0.isEnabled = enable
        button1.isEnabled = enable
        button2.isEnabled = enable
        button3.isEnabled = enable
        button4.isEnabled = enable
        button5.isEnabled = enable
        button6.isEnabled = enable
        button7.isEnabled = enable
        button8.isEnabled = enable
        button9.isEnabled = enable
        buttonSharp.isEnabled = enable
        buttonStar.isEnabled = enable
        hands_free.isEnabled = enable
        dial.isEnabled = enable
        voice_show.start()
    }

    private fun acceptCall() {
        object : Thread() {
            override fun run() {
                CallApi.acceptCall()
            }
        }.start()
    }

    private fun terminateCall() {
        enableButtons(false)
        object : Thread() {
            override fun run() {
                try {
                    CallApi.terminateCall()
                } catch (e: CallException) {
                    processCallException(e)
                }

            }
        }.start()
    }


    companion object {

        fun startCall(context: Context, calledNumber: String, uid: String) {
            val intent = Intent(context, CallActivity::class.java)
            intent.putExtra("number", calledNumber)
            if (TextUtils.isEmpty(uid)){
                intent.putExtra("uid", "00000000000")
            }else{
                intent.putExtra("uid", uid)
            }

            intent.putExtra("isIncoming", false)
            context.startActivity(intent)
        }

        fun incomingCall(context: Context, calledNumber: String) {
            val intent = Intent(context, CallActivity::class.java)
            intent.putExtra("number", calledNumber)
            intent.putExtra("isIncoming", true)
            context.startActivity(intent)
        }
    }

    private fun showTime() {
        tv_time_show.visibility = View.VISIBLE
        tv_status.visibility = View.GONE
        tv_time_show.base = SystemClock.elapsedRealtime()
        val hour = ((SystemClock.elapsedRealtime() - tv_time_show.base) / 1000 / 60)
        tv_time_show.format = "0$hour:%s"
        tv_time_show.start()
    }

    private fun pressButton(number:String){
        CallApi.sendDtmf(number)
        stateStringBuider.append(number)
        tv_show_text.text = stateStringBuider.toString()
        tv_time_show.visibility = View.INVISIBLE

    }

    private fun dispearDial(){
        stateStringBuider = StringBuilder("")
        tv_show_text.text = "语音通话"
        tv_time_show.visibility = View.VISIBLE

    }
}
