package com.ksmobile.app.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.view.View
import android.view.ViewGroup
import com.ksmobile.app.R
import com.ksmobile.app.fragment.DepositOrderListFragment
import com.ksmobile.app.fragment.PromoOrderListFragment
import com.ksmobile.app.fragment.WithdrawOrderListFragment
import com.ksmobile.app.fragment.XmOrderListFragment
import kotlinx.android.synthetic.main.activity_order_report.*

class OrderReportActivity : BaseToolBarActivity() {

    var fragments: MutableList<Fragment>? = null
    var titles = arrayOf("存款", "取款", "洗码", "优惠")

    private var editaListener: IEditCallBack? = null

    override fun getLayoutId(): Int {
        return R.layout.activity_order_report
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.order_report_title))
        setActionText("编辑")

    }

    override fun initView() {
        fragments = mutableListOf()
        titles.forEach {
            when (it) {
                "存款" -> {
                    val fragment = DepositOrderListFragment()
                    fragments?.add(fragment)
                }
                "取款" -> {
                    val fragment = WithdrawOrderListFragment()
                    fragments?.add(fragment)
                }
                "洗码" -> {
                    val fragment = XmOrderListFragment()
                    fragments?.add(fragment)
                }
                "优惠" -> {
                    val fragment = PromoOrderListFragment()
                    fragments?.add(fragment)
                }
            }


        }
        viewPager.setNoScroll(true)
        viewPager.adapter = ContentAdapter(supportFragmentManager)
        val index1 = intent.getIntExtra("index", 1)
        viewPager.currentItem = (index1 - 1)
        tabs.setViewPager(viewPager, titles)

    }

    override fun initListener() {
        getActionView()?.setOnClickListener {
            if (null != editaListener) {
                editaListener?.onEditAble()
            }

            if (getActionContent()=="取消"){
                tv_cover.visibility =View.VISIBLE
            }else{
                tv_cover.visibility =View.GONE
            }
        }
    }


    fun showDeleteNotify() {
        my_notify_view.show()
        my_notify_view.setTip("您的删除操作已完成")

    }

    /**
     * 内容页的适配器
     */
    private inner class ContentAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

        val fm = fm

        override fun getPageTitle(position: Int): CharSequence {
            return titles[position]
        }

        override fun getItem(position: Int): Fragment {
            return fragments!![position]
        }

        override fun getCount(): Int {
            return fragments!!.size
        }

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val fragment = super.instantiateItem(container, position) as Fragment
            fm.beginTransaction().show(fragment).commit()
            return fragment
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            val fragment = fragments!![position]
            fm.beginTransaction().hide(fragment).commit()

        }

    }


    interface IEditCallBack {
        fun onEditAble()
    }

    fun setEditListener(listener: IEditCallBack) {

        editaListener = listener
    }

}