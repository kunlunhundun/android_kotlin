package com.ksmobile.app.data.response

import com.ksmobile.app.data.AmountType


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryBanksResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var bankCards: MutableList<Bean>,
            var amountType:AmountType,
            var optDepositAmounts:MutableList<String>
    )

    data class Bean(
            var accountName: String,
            var accountNo: String,
            var bankBranchName: String,
            var bankCardId: String,
            var bankIcon: String,
            var bankName: String,
            var city: String,
            var province: String,
            var showFlag: Int =1
    )

}
