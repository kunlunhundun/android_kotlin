package com.ksmobile.app.activity

import android.Manifest
import android.os.Bundle
import android.support.annotation.NonNull
import android.view.View
import com.github.dfqin.grantor.PermissionListener
import com.github.dfqin.grantor.PermissionsUtil
import com.google.gson.Gson
import com.ksmobile.app.MyApplication
import com.ksmobile.app.R
import com.ksmobile.app.activity.reactnative.RNPageActivity
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.data.request.QueryAreaLimitRequest
import com.ksmobile.app.data.request.UpgradeRequest
import com.ksmobile.app.data.response.QueryAreaLimitResponse
import com.ksmobile.app.data.response.UpgradeResponse
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.RefreshAnimationUtils
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.CommonDialog
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.UpdateDialog
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import kotlinx.android.synthetic.main.activity_main_view.*

class MainActivity : RNPageActivity() {
    private var hasStop = false
    override fun getLayoutId(): Int {
        return R.layout.activity_main_view
    }

    override fun initView() {
    }

    override fun initListener() {

        getActionImage()?.setOnClickListener {
            actionbarShowCallBack?.onReload(getActionImage())
            RefreshAnimationUtils.startRefreshAnim(getActionImage())
        }
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        setBackListener(View.OnClickListener {
            showConfirm()
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions()
        queryOnlineCustomerService()
        setTile("AG旗舰")
        setActionIcon(R.mipmap.icon_customer_service)
        setImageActionIcon(R.mipmap.reload)

    //  NotifyHelper.showNotify(this,"-2","测试测试测试","测试测试测试","","2")
    }


    override fun onStop() {
        super.onStop()
        hasStop = true
    }


    override fun onResume() {

        super.onResume()
            detachView(AppInitManager.getMainReactRootView())
            fl_container.addView(AppInitManager.getMainReactRootView())
        if (MyApplication.getinstance().showAg) {
            handleGame()
            MyApplication.getinstance().showAg = false
            AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.MAIN, false))
        }

        AppInitManager.getReactPackage().openNativeModule?.refreshData()
        queryAreaLimit()

    }


    override fun onDestroy() {

        super.onDestroy()
        detachView(AppInitManager.getMainReactRootView())
        AppInitManager.getMainReactRootView().unmountReactApplication()
    }


    override fun onBackPressed() {
        if (tool_bar.visibility == View.VISIBLE) {
            showConfirm()
        } else {
            mReactInstanceManager.onBackPressed()
        }

    }


    /**
     * 检查升级
     */
    private fun upgrade() {
        val request = UpgradeRequest()
        request.h5V = 20
        ApiClient.instance.service.upgrade(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<UpgradeResponse>(this, false) {
                    override fun businessFail(data: UpgradeResponse) {
                    }

                    override fun businessSuccess(data: UpgradeResponse) {
                        if (data.body?.flag != 0) {

                            if (dialog.dialog != null && dialog.dialog.isShowing) {

                            } else {
                                showUpgradeDialog(data)
                            }

                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }

    val dialog = UpdateDialog()
    fun showUpgradeDialog(data: UpgradeResponse) {
        val bundle = Bundle()
        bundle.putString("data", Gson().toJson(data))
        dialog.arguments = bundle
        try {
            dialog.show(supportFragmentManager, "")
        }catch (e:Exception){

        }

    }




    private fun queryAreaLimit() {
        val request = QueryAreaLimitRequest()
        ApiClient.instance.service.areaLimit(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryAreaLimitResponse>(this, false) {
                    override fun businessFail(data: QueryAreaLimitResponse) {
                        upgrade()
                    }

                    override fun businessSuccess(data: QueryAreaLimitResponse) {
                        val isShowIPLimit = data.body?.allowAccess == "0"
                        if (isShowIPLimit) {
                            createDialog(CommonDialog.TYPE_IP_LIMIT, data.body?.goCode != "403t")
                        } else {
                            upgrade()
                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        upgrade()
                    }
                })
    }


    /**
     * 弹窗
     */
    private fun createDialog(type: Int, showCv: Boolean) {

        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, type)
        bundle.putBoolean(CommonDialog.SHOWCV, showCv)
        bundle.putBoolean(CommonDialog.CANBACKCANCEL, false)
        val dialog = CommonDialog()
        dialog.arguments = bundle
        dialog.show(supportFragmentManager, "limit")
    }

    private fun requestPermissions() {
        PermissionsUtil.requestPermission(this, object : PermissionListener {
            override fun permissionGranted(@NonNull permissions: Array<String>) {


            }

            override fun permissionDenied(@NonNull permissions: Array<String>) {

                ToastUtils.show("请先允许所需权限")
            }
        }, Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO

        )
    }

    override fun handleGame() {
        rl_rn.visibility = View.GONE
        tool_bar.visibility = View.VISIBLE
        actionbarShowCallBack?.onShow(true)

    }

    override fun reloadGame() {
        actionbarShowCallBack?.onReload(getActionImage())
    }

    private fun showConfirm() {
        ConfirmDialog.show(this)
        ConfirmDialog.setTitile("确定要退出游戏么？")
        ConfirmDialog.setCancelText("取消")
        ConfirmDialog.setSureText("退出游戏")
        ConfirmDialog.setSureListener(View.OnClickListener {
            quiteAg()
            ConfirmDialog.dismiss()
            actionbarShowCallBack?.onShow(false)

        })

    }

    fun showActionBar(show: Boolean) {

        if (show) {
            tool_bar.visibility = View.VISIBLE

        } else {
            tool_bar.visibility = View.GONE
        }
    }

    fun quiteAg() {

        rl_rn.visibility = View.VISIBLE
        tool_bar.visibility = View.GONE
    }

    fun setActionBarShowListner(callback: IActionBarIsShowCallBack) {

        actionbarShowCallBack = callback

    }

    var actionbarShowCallBack: IActionBarIsShowCallBack? = null

    interface IActionBarIsShowCallBack {
        fun onShow(show: Boolean)
        fun onReload(view: View?)
    }

}
