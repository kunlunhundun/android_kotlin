package com.ksmobile.app.data.response

/**
 * Created by ward.y on 2018/3/19.
 */
class QueryPointCardPayResultResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var cardNo: String,
            var status: String,
            var billNo: String,
            var statusDesc: String


    )






}
