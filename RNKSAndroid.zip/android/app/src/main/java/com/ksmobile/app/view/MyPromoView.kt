package com.ksmobile.app.view

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.activity.reactnative.MyRnPageActivity
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.PromoObject
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.GlideUtils
import kotlinx.android.synthetic.main.item_promo_view.view.*

class MyPromoView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {

    init {
        LayoutInflater.from(context).inflate(R.layout.item_promo_view, this, true)
    }


    fun setData(data: PromoObject?) {

        if (data != null) {
            tv_promo_title.text = data.title
            if (data.promoFlag == 1) {
                tv_date.text = "长期活动"
            } else {
                tv_date.text = "${data.beginDate.split(" ")[0].replace("-", "/")} － ${data.endDate.split(" ")[0].replace("-", "/")}"
            }

            if (!TextUtils.isEmpty(data.linkUrl)) {
                this.setOnClickListener {
                    AppInitManager.getReactPackage().openNativeModule?.goToPromo(Gson().toJson(data))
                    val intent = Intent(context, MyRnPageActivity::class.java)
                    intent.putExtra("promoTag",true)
                    Handler().postDelayed({
                        context.startActivity(intent)
                    }, 200)
                }
            }

        }


    }


}