package com.ksmobile.app.data.request

class QueryAreaLimitRequest : BaseRequestObject() {
}