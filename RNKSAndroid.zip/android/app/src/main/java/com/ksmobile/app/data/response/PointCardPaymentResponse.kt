package com.ksmobile.app.data.response

import com.ksmobile.app.data.PostParam


/**
 * Created by ward.y on 2018/3/19.
 */
class PointCardPaymentResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var amount: String,
            var billDate: String,
            var billNo: String,
            var nextType: String,
            var xurl: String,
            var remark: String,
            var xparam: PostParam

    )






}
