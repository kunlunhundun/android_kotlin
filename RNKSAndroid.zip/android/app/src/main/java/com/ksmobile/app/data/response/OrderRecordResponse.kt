package com.ksmobile.app.data.response

import com.ksmobile.app.data.OrderObject


/**
 * Created by ward.y on 2018/3/19.
 */
class OrderRecordResponse : BaseResponseObject() {
    val body: Body? = null
    data class Body(
            var data: MutableList<OrderObject> = mutableListOf(),
            var pageNo: Int = 0,
            var pageSize: Int = 0,
            var totalPage: Int = 0,
            var totalRow: Int = 0

    )

}
