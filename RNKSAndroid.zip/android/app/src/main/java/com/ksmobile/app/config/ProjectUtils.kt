package com.ksmobile.app.config


object ProjectUtils {

    const val PID = "A06"
    const val APPID = "A06DS01"
    const val PUSH_CODE = "A06_KSZH"
    const val ABC_GAME_CODE = "A06003"



}