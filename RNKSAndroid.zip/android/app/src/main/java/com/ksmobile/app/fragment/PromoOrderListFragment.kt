package com.ksmobile.app.fragment

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.jcodecraeer.xrecyclerview.ProgressStyle
import com.jcodecraeer.xrecyclerview.XRecyclerView
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderDetailActivity
import com.ksmobile.app.activity.OrderReportActivity
import com.ksmobile.app.adapter.TradeRecordAdapter
import com.ksmobile.app.data.OrderObject
import com.ksmobile.app.data.request.DeleteRecordRequest
import com.ksmobile.app.data.request.OrderRecordRequest
import com.ksmobile.app.data.response.DeleteRecordResponse
import com.ksmobile.app.data.response.OrderRecordResponse
import com.ksmobile.app.net.*
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.LoadErrorType
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.fragment_oder_list.*

class PromoOrderListFragment : LazyLoadFragment() {
    lateinit var mAdapter: TradeRecordAdapter
    private lateinit var oders: MutableList<OrderObject>
    lateinit var response: OrderRecordResponse
    val REFRESH: Int = 1
    val LOAD_MORE: Int = 0
    var refreshTag: Int = LOAD_MORE
    var mLastDays: Int = 7
    var isEditable = false
    var mActivity: OrderReportActivity? = null
    var deleteRecordRequest = DeleteRecordRequest()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_oder_list, null)
    }


    override fun requestData() {
        initData()
        initListener()
    }

    override fun repeat() {
        mActivity = activity as OrderReportActivity
        if (isEditable) {
            mActivity?.setActionText("取消")
        } else {
            mActivity?.setActionText("编辑")
        }

        mActivity?.setEditListener(object : OrderReportActivity.IEditCallBack {
            override fun onEditAble() {
                isEditable = !isEditable
                if (isEditable) {
                    showEditMode()

                } else {
                    hiddenEditMode()
                }

            }

        })

    }

    private fun showEditMode() {
        cl_edit.visibility = View.VISIBLE
        mAdapter.setMode(mAdapter.MODE_EDIT)
        mAdapter.setAllselect(false)
        mActivity?.setActionText("取消")
    }

    private fun hiddenEditMode() {
        cl_edit.visibility = View.GONE
        mAdapter.setMode(mAdapter.MODE_NORMAL)
        mActivity?.setActionText("编辑")
    }

    private fun showEmpty() {
        load_error.visibility = View.VISIBLE
        load_error.showError(LoadErrorType.DATA_EMPTY.code)
        load_error.setTips("暂时优惠记录")
    }


    private fun initListener() {

        tv_15.setOnClickListener {
            //            refreshTag = REFRESH
            tv_7.isSelected = false
            tv_15.isSelected = true
            mLastDays = 15
            lv_order.refresh()
            load_error.visibility = View.GONE
        }

        tv_7.setOnClickListener {
            //            refreshTag = REFRESH
            tv_7.isSelected = true
            tv_15.isSelected = false
            mLastDays = 7
            lv_order.refresh()
            load_error.visibility = View.GONE
        }

        tv_select_all.setOnClickListener {
            if (tv_select_all.text == "全选") {
                mAdapter.setAllselect(true)
                tv_select_all.text = "取消全选"
            } else {
                mAdapter.setAllselect(false)
                tv_select_all.text = "全选"
            }

        }

        iv_delete.setOnClickListener {

            if (mAdapter.selcetItems.isEmpty()) {
                NotifyDialog.show(mActivity,"请选择要删除的内容")
            } else {
                ConfirmDialog.show(mActivity)
                ConfirmDialog.setTitile("确定删除您选中的信息吗？")
                ConfirmDialog.setCancelText("取消")
                ConfirmDialog.setSureText("确定")
                ConfirmDialog.setSureListener(View.OnClickListener {
                    deleteRecordRequest.requestIds.clear()
                    mAdapter.ids.forEach {
                        deleteRecordRequest.requestIds.add(it.requestId)
                    }
                    deleteRecord(deleteRecordRequest)
                    mAdapter.removeAll()
                    hiddenEditMode()
                    if (mAdapter.datas.isEmpty()) {
                        showEmpty()
                    }
                    ConfirmDialog.dismiss()
                    mActivity?.showDeleteNotify()


                })


            }


        }

    }

    private fun initData() {
        oders = mutableListOf()
        initListView(oders)
        tv_15.isSelected = false
        getData(1)

    }

    private fun getData(pageNo: Int) {
        getData(pageNo, mLastDays)
    }


    private fun getData(pageNo: Int, lastDays: Int) {
        val request = OrderRecordRequest()
        request.lastDays = lastDays
        request.pageSize = 10
        request.pageNo = pageNo
        ApiClient.instance.service.queryPromoRecord(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<OrderRecordResponse>(activity!!, false) {
                    override fun businessFail(data: OrderRecordResponse) {
                        load_error.visibility = View.VISIBLE
                        load_error.showError(LoadErrorType.NOT_FOUND.code)
                        load_error.setTips(data.head.errMsg!!)
                        load_error.setNormalClickListener(View.OnClickListener {
                            lv_order.visibility = View.VISIBLE
                            getData(1)
                        })
                        lv_order.visibility = View.GONE
                        updateError()
                    }

                    override fun businessSuccess(data: OrderRecordResponse) {

                        if (data.body?.data == null || data.body.data.isEmpty()) {
                            updateError()
                            load_error.visibility = View.VISIBLE
                            load_error.showError(LoadErrorType.DATA_EMPTY.code)
                            load_error.setTips("暂无优惠记录")


                        } else {
                            load_error.visibility = View.GONE
                            response = data
                            if (pageNo == 1) {
                                //当请求为页数1时，全部重置为refresh
                                refreshTag = REFRESH
                            }
                            updateData()
                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        if (refreshTag == LOAD_MORE && pageNo == 1) {
                            when (apiErrorModel.status) {
                                504 -> {
                                    load_error.visibility = View.VISIBLE
                                    load_error.showError(LoadErrorType.NET_ERROR.code)
                                    load_error.setNormalClickListener(View.OnClickListener {
                                        load_error.visibility = View.GONE
                                        getData(1)
                                    })

                                }
                                ApiErrorType.CONNECTION_TIMEOUT.code -> {
                                    load_error.visibility = View.VISIBLE
                                    load_error.showError(LoadErrorType.TIME_OUT.code)
                                    load_error.setNormalClickListener(View.OnClickListener {
                                        load_error.visibility = View.GONE
                                        getData(1)
                                    })
                                }
                                else -> ToastUtils.show(apiErrorModel.message)
                            }
                        } else {
                            ToastUtils.show(apiErrorModel.message)
                        }
                        updateError()
                    }

                })

    }


    private fun updateError() {
        when (refreshTag) {
            REFRESH -> {


                if (lv_order != null) {
                    oders.clear()
                    mAdapter.notifyDataSetChanged()
                    lv_order.refreshComplete()
                }
            }

            LOAD_MORE -> {

                if (lv_order != null) {
                    lv_order.loadMoreComplete()
                }
            }
        }
    }

    private fun updateData() {

        lv_order.visibility = View.VISIBLE
        when (refreshTag) {
            REFRESH -> {
                oders.clear()
                oders.addAll(response.body?.data!!)
                mAdapter.notifyDataSetChanged()
                if (lv_order != null) {
                    lv_order.refreshComplete()
                }
            }

            LOAD_MORE -> {
                oders.addAll(response.body?.data!!)
                mAdapter.notifyDataSetChanged()
                if (lv_order != null) {
                    lv_order.loadMoreComplete()
                }
            }
        }


        if (response.body?.pageNo!! >= response.body?.totalPage!!) {
            lv_order.setNoMore(true)
        }

    }

    private fun initListView(data: MutableList<OrderObject>) {
        val layoutManager = LinearLayoutManager(activity)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        lv_order.layoutManager = layoutManager
        lv_order.setRefreshProgressStyle(ProgressStyle.BallSpinFadeLoader)
        lv_order.setLoadingMoreProgressStyle(ProgressStyle.LineScalePulseOutRapid)
        lv_order.setArrowImageView(R.mipmap.iconfont_downgrey)
//        lv_order.defaultFootView.setLoadingHint("年轻人不要着急...")
        lv_order.defaultFootView.setNoMoreHint("")
        lv_order.setLoadingMoreEnabled(true)
//        lv_order.defaultFootView.setPadding(0, 0, 0, Dip2PixleUtil.dp2px(activity, 45f))
        lv_order.setLimitNumberToCallLoadMore(10)
        lv_order.setLoadingListener(object : XRecyclerView.LoadingListener {
            override fun onRefresh() {
                refreshTag = REFRESH
                getData(1)
            }

            override fun onLoadMore() {
                refreshTag = LOAD_MORE
                getData(response.body?.pageNo!!.plus(1))
            }
        })


        mAdapter = TradeRecordAdapter(context!!, data)
        mAdapter.setClickCallBack(
                object : TradeRecordAdapter.ItemClickCallBack {
                    override fun onItemClick(pos: Int) {
                        val intent = Intent(activity?.baseContext, OrderDetailActivity::class.java)
                        intent.putExtra("referenceId", data[pos].requestId)
                        intent.putExtra("type", 4)
                        goToPage(intent)

                    }

                    override fun onItemDelete(pos: Int) {
                        ConfirmDialog.show(mActivity)
                        ConfirmDialog.setTitile("确定删除您选中的信息吗？")
                        ConfirmDialog.setCancelText("取消")
                        ConfirmDialog.setSureText("确定")
                        ConfirmDialog.setSureListener(View.OnClickListener {
                            deleteRecordRequest.requestIds.clear()
                            deleteRecordRequest.requestIds.add(data[pos].requestId)
                            deleteRecord(deleteRecordRequest)
                            mAdapter.removeItem(pos)
                            ConfirmDialog.dismiss()
                            mActivity?.showDeleteNotify()
                        })


                    }
                }
        )
        lv_order.adapter = mAdapter


    }

    private fun deleteRecord(request: DeleteRecordRequest) {
        ApiClient.instance.service.deletePromoRecord(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<DeleteRecordResponse>(activity!!, false) {
                    override fun businessFail(data: DeleteRecordResponse) {

                    }

                    override fun businessSuccess(data: DeleteRecordResponse) {

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {

                    }
                })
    }
}