package com.ksmobile.app.fragment.recharge

import android.app.ActionBar
import android.content.Intent
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.AmountType
import com.ksmobile.app.data.BankInfo
import com.ksmobile.app.data.request.CreateOnlineRequest
import com.ksmobile.app.data.request.QueryOnlineBanksRequest
import com.ksmobile.app.data.response.CreateOnlineResponse
import com.ksmobile.app.data.response.OnlineBanksResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.LogUtils
import com.ksmobile.app.view.NotifyDialog
import com.ksmobile.app.view.hybride.BrowserActivity
import kotlinx.android.synthetic.main.fragment_recharge_base_view.*


abstract class BaseOnlineRechargeFragment : BaseRechargeFragment() {
    var payNames = mutableListOf<String>()
    var payTypes = mutableListOf<String>()
    /**
     * 在线支付类型弹窗
     */

    abstract fun showOnlinePopWindow(v: View)

    /**
     * 查询在线支付银行卡列表
     */
    fun queryOnlineBanks(i: String) {
        var request = QueryOnlineBanksRequest()
        request.payType = i
        ApiClient.instance.service.queryOnlineBanks(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<OnlineBanksResponse>(activity!!, true) {
                    override fun businessFail(data: OnlineBanksResponse) {
                        if (data.head.errCode == "GW_801102") {
                            NotifyDialog.show(activity!!, "支付渠道暂不可用，请更换支付渠道或者重试")
                        }
                        disableSubmit()
                    }

                    override fun businessSuccess(data: OnlineBanksResponse) {
                        wheelPosition = 0
                        qOBankNameList = null
                        onlinedatas = data
                        setLimit(data.body?.minAmount!!, data.body?.maxAmount!!)
                        showFastSelectAmount(data.body?.amountType)

                        if (data.body?.bankList?.size!! > 0) {
                            if (i == "1") {
                                pay_bank_layout.setEditText(data.body?.bankList!![wheelPosition].bankName)
                                pay_bank_layout.setDrawableMid(data.body?.bankList!![wheelPosition].bankIcon)
                                var list = data.body!!.bankList
                                qOBankNameList = mutableListOf()
                                list.forEach {
                                    val bankInfo = BankInfo(it.bankName, it.bankCode, it.bankIcon)
                                    qOBankNameList!!.add(bankInfo)
                                }
                            }
                        }else{
                             pay_bank_layout.visibility = View.GONE
                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }

    /**
     * 创建在线支付订单
     */
    fun createOnlineOrderRequest(payWay: String,payType:String) {
        var request = CreateOnlineRequest()
        request.payType = payType
        request.amount = Integer.parseInt(et_recharge_amount.getEditTextContent())
        request.payid = onlinedatas?.body?.payid
        if (onlinedatas?.body?.bankList?.size != 0) {
            request.bankNo = onlinedatas?.body?.bankList?.get(wheelPosition)?.bankNo
        }
        ApiClient.instance.service.createOnlineOrder(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<CreateOnlineResponse>(activity!!, true) {
                    override fun businessFail(data: CreateOnlineResponse) {
                        if (payWay == "online_banking") {
                            if (data.head.errCode == "GW_801102") {
                                NotifyDialog.show(reChargeActivity!!, "存款额度超过限额")
                            } else {
                                NotifyDialog.show(reChargeActivity!!, data.head.errMsg)
                            }
                        } else {
                            NotifyDialog.show(reChargeActivity!!, data.head.errMsg)
                        }
                    }

                    override fun businessSuccess(data: CreateOnlineResponse) {
                        onlineChargeResponse = data
                        //跳到第三方页面进行支付
                        if (!TextUtils.isEmpty(data.body?.payUrl)) {
                            var url = data.body?.payUrl
                            if (!ConfigUtils.onlinePaymentUrl.isEmpty()){

                                ConfigUtils.onlinePaymentUrl.forEach {
                                    if (data.body?.domainList!!.contains(it)){
                                        url = url?.replace("//","*")
                                        url =  url!!.substring(url?.indexOf("/",0)!!+1,url!!.lastIndex)
                                        url = "${ConfigUtils.onlinePaymentUrl}/$url"
                                    }
                                }


                            }

                            val intent = Intent(activity, BrowserActivity::class.java)
                            intent.putExtra(BrowserActivity.PARAM_URL,url)
                            intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR,true)
                            startActivity(intent)
                        } else {
                           NotifyDialog.show(reChargeActivity!!, "支付渠道暂不可用，请更换支付渠道或者重试")
                        }


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }

    /**
     * 展示快捷金额选择
     */

    fun showFastSelectAmount(amountType: AmountType?) {
        if (null != amountType) {
            if (amountType.fix == 1) {
                et_recharge_amount.visibility = View.GONE
            } else {
                et_recharge_amount.visibility = View.VISIBLE
            }

            if (!amountType.amounts.isEmpty()) {
                setFastSelections(amountType.amounts)
            }else{
                lv_selections.visibility =View.GONE
            }


        }
    }

    /**
     * 选择银行卡
     */

    fun pickBankPopWindow() {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_transfer, null)
        val mPopupWindow1 = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(context, 315f), true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style
        var adapter: BankListAdapter
        var iv_back: ImageView = view.findViewById(R.id.iv_back)
        var iv_x: ImageView = view.findViewById(R.id.iv_x)
        var lv_bank_list: ListView = view.findViewById(R.id.lv_bank_list)
        var pop_confirm: LinearLayout = view.findViewById(R.id.pop_confirm)
        var pop_bank_list: ConstraintLayout = view.findViewById(R.id.pop_bank_list)
        pop_confirm.visibility = View.GONE
        pop_bank_list.visibility = View.VISIBLE
        iv_x.visibility = View.VISIBLE
        iv_back.visibility = View.GONE
        if (qOBankNameList!=null) {
            adapter = BankListAdapter(qOBankNameList)
            lv_bank_list.adapter = adapter
            lv_bank_list.setOnItemClickListener { _, _, position, _ ->
                wheelPosition = position
                adapter.notifyDataSetChanged()
                pay_bank_layout.setEditText(qOBankNameList?.get(wheelPosition)?.bankName)
                pay_bank_layout.setDrawableMid(qOBankNameList?.get(wheelPosition)?.bankIcon!!)
                mPopupWindow1.dismiss()
            }
        }


        iv_x.setOnClickListener { mPopupWindow1.dismiss() }
        mPopupWindow1.showAtLocation(rl_pay_type, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }


}