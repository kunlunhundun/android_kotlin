package com.ksmobile.app.data.response

/**
 * Created by ward.y on 2018/3/19.
 */
class CreateBtcPaymentResponse : BaseResponseObject() {

    var body: Body? = null

    data class Body(
            var billNo: String,
            var loginName: String


    )


}
