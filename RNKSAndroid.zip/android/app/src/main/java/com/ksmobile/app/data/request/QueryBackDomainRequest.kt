package com.ksmobile.app.data.request

class QueryBackDomainRequest : BaseRequestObject(){
    val type = 1
}