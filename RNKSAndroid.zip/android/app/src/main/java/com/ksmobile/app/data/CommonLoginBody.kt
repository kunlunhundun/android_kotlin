package com.ksmobile.app.data


/**
 * Created by ward.y on 2018/4/3.
 */

class CommonLoginBody {
    var loginName: String? = null
    var mobileNo: String? = null
    var token: String? = null
    var realName: String? = null
    var starLevelName: String? = null
    var customerId: String? = null
    var starLevel: Int? = 0
    var customerType: Int? = null
    var mobileNoBind:Int? =0
    var bankCardNum:Int =0
    var btcNum:Int =0
}