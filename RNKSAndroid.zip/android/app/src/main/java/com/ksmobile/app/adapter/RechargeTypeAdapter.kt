package com.ksmobile.app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.ksmobile.app.R
import com.ksmobile.app.data.response.QueryPayWaysV3Response

class RechargeTypeAdapter(context: Context, datas: MutableList<String>,payType: MutableList<String>, payTypeList:MutableList<QueryPayWaysV3Response.PayType>?) : BaseAdapter() {
    var mContext: Context = context
    var datas: MutableList<String> = datas
    var payType: MutableList<String> = payType
    var payTypeList:MutableList<QueryPayWaysV3Response.PayType>? = payTypeList

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var holder: MyViewHolder
        var v: View
        if (convertView == null) {
            holder = MyViewHolder()
            v = LayoutInflater.from(mContext).inflate(R.layout.item_recharge_type, parent, false)
            holder.tvType = v.findViewById(R.id.tv_type)
            holder.ivPromo = v.findViewById(R.id.iv_promo)

            v.tag = holder

        } else {
            v = convertView
            holder = v.tag as MyViewHolder
        }
        holder.ivPromo.setImageResource(R.mipmap.promo_1888)
        holder.tvType.text = datas[position]
        if (payType[position]=="15"||payType[position]=="16"){
            holder.ivPromo.visibility =View.VISIBLE
        }else{
            holder.ivPromo.visibility =View.GONE
        }
        var payTypeObj = payTypeList?.elementAtOrNull(position)
        if (payTypeObj?.promoTag == 1) {
            holder.ivPromo.visibility =View.VISIBLE
        }else if( payTypeObj?.typeTip?.recommend == 1 ) {
            holder.ivPromo.setImageResource(R.mipmap.icon_recharge_recomend)
            holder.ivPromo.visibility =View.VISIBLE
        }
//        if (payType[position]=="100"||payType[position]=="101"||payType[position]=="102"){
//            var payTypeObj = payTypeList?.elementAtOrNull(position)
//            if( payTypeObj?.typeTip?.recommend == 1 ) {
//                holder.ivPromo.setImageResource(R.mipmap.icon_recharge_recomend)
//                holder.ivPromo.visibility =View.VISIBLE
//            }
//        }

        return v
    }

    override fun getItem(p0: Int): Any {
        return datas[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return datas.size
    }

    class MyViewHolder {

        lateinit var tvType: TextView
        lateinit var ivPromo: ImageView

    }
}