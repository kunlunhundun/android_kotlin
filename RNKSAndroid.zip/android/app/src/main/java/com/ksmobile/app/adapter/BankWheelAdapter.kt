package com.ksmobile.app.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


import com.ksmobile.app.R
import com.ksmobile.app.data.BankCardObj
import com.ksmobile.app.util.GlideUtils


class BankWheelAdapter(private val mContext: Context, bankInfos: MutableList<BankCardObj>) : BaseAdapter() {
    private val mBankInfos = bankInfos
    @SuppressLint("SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var holder: MyViewHolder
        var v: View
        if (convertView == null) {
            holder = MyViewHolder()
            v = LayoutInflater.from(mContext).inflate(R.layout.item_bank_list_view, parent, false)
            holder.iv_icon = v.findViewById(R.id.iv_icon)
            holder.tv_bank_name = v.findViewById(R.id.tv_bank_name)
            holder.tv_enable_tip = v.findViewById(R.id.tv_enable_tip)
            holder.image_selected = v.findViewById(R.id.image_selected)
            v.tag = holder

        } else {
            v = convertView
            holder = v.tag as MyViewHolder
        }
        GlideUtils.load(mContext, mBankInfos[position].bankIcon).placeholder(R.mipmap.insted_imag_smarll).error(R.mipmap.insted_imag_smarll).into(holder.iv_icon)
        holder.tv_bank_name.text = mBankInfos[position].bankName + " (" + mBankInfos[position].accountNo.replace("*", "").replace(" ", "")+")"
        if (mBankInfos[position].isSlelected) {
            holder.image_selected.visibility = View.VISIBLE
        } else {
            holder.image_selected.visibility = View.GONE
        }

        if (mBankInfos[position].flag == "1") {
            holder.tv_bank_name.setTextColor(mContext.resources.getColor(R.color.colorWhite))
            holder.tv_enable_tip.visibility = View.GONE
        } else {
            holder.tv_bank_name.setTextColor(mContext.resources.getColor(R.color.colorTextGrey))
            holder.tv_enable_tip.visibility = View.VISIBLE
        }

        return v
    }

    override fun getItem(p0: Int): Any {
        return mBankInfos[p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return mBankInfos.size
    }

    class MyViewHolder {
        lateinit var iv_icon: ImageView
        lateinit var tv_bank_name: TextView
        lateinit var tv_enable_tip: TextView
        lateinit var image_selected: ImageView
    }

}
