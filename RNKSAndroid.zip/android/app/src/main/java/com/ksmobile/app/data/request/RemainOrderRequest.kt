package com.ksmobile.app.data.request


class RemainOrderRequest : BaseRequestObject() {

    var referenceId: String? = null
    var type: Int? = null


}