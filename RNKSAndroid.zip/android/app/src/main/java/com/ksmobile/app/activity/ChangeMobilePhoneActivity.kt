package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.BindMobileRequest
import com.ksmobile.app.data.request.SendSmsRequest
import com.ksmobile.app.data.request.VerifySmsCodeRequest
import com.ksmobile.app.data.response.BindMobileResponse
import com.ksmobile.app.data.response.SendSmsResponse
import com.ksmobile.app.data.response.VerifySmsCodeResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_bind_mobile_phone.*

/**
 * 解绑手机号
 */
class ChangeMobilePhoneActivity : BaseToolBarActivity() {
    private var timer: CountDownTimer? = null
    private var messageId: String? = null
    val TYPE_CHANGE = 0
    val TYPE_BIND = 1
    private var type = TYPE_CHANGE
    companion object {
        const val JumpToWithDraw = 1  // 取款
        const val JumpToDepositor = 2  // 存款
        const val JumpTo = "JumpTo"
    }
    private var mJumpTo = 0
    override fun getLayoutId(): Int {
        return R.layout.activity_bind_mobile_phone
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setTile(getString(R.string.rebind_mobile_phone_title))
        tv_tip.text = "为了您的账户资金安全，请验证手机"
        et_phone_number.setEnable(false)
        et_phone_number.setEditText(ConfigUtils.mobileNo)
        et_phone_number.setDarkMode()
        type = intent.getIntExtra("type",TYPE_CHANGE)
        mJumpTo = intent.getIntExtra(JumpTo,0)
        if (type==TYPE_CHANGE){
            btn_commit.text = "验证手机号"
        }


    }

    override fun initView() {

    }

    override fun initListener() {

        tv_verify_code.setOnClickListener {
            if (Utils.isFastDoubleClick()){
                return@setOnClickListener
            }
            sendVerifyCodeByLoginName()

        }


        btn_commit.setOnClickListener {
            if (Utils.isFastDoubleClick()){
                return@setOnClickListener
            }
            if (!TextUtils.isEmpty(et_verify_code.getEditTextContent())) {
                if (type==TYPE_CHANGE){
                    verifySmsCode(et_verify_code.getEditTextContent().trim())
                }else{
                    bindMobileNo()
                }
            }else{
                et_verify_code.showError("验证码不能为空")
            }


        }

        et_verify_code.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus){
                if (TextUtils.isEmpty(et_verify_code.getEditTextContent())){
                    et_verify_code.showError("验证码不能为空")
                }
            }

        }
    }


    private fun initTimer(time: Long): CountDownTimer? {
        timer = object : CountDownTimer(time * 1000, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                tv_verify_code.setOnClickListener(null)
                tv_verify_code.text = String.format(getString(R.string.bind_mobile_phone_activity_wait_tip), millisUntilFinished / 1000)
            }

            override fun onFinish() {
                tv_verify_code.text = "重新发送"
                tv_verify_code.setOnClickListener {
                    sendVerifyCodeByLoginName()
                }

            }
        }

        return timer
    }


    private fun sendVerifyCodeByLoginName() {
        val request = SendSmsRequest()
        if (type==TYPE_BIND){
            request.use = "3"
        }else{
            request.use = "6"
        }

        ApiClient.instance.service.sendCodeByLoginName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<SendSmsResponse>(this) {
                    override fun businessFail(data: SendSmsResponse) {
                        when(data.head.errCode){
                            "WS_300027","GW_800205","WS_300021","GW_800211","WS_300020" ->{
                                data.head.errMsg ="短信验证码不正确"
                            }
                            "GW_800210" ->{
                                data.head.errMsg ="手机号不能为空"
                            }
                            "GW_800203" ->{
                                data.head.errMsg ="短信验证码过期"
                            }
                            "WS_300002","WS_300022" ->{
                                data.head.errMsg ="操作太频繁，请5分钟后再试"
                            }
                            "WS_201723" ->{
                                data.head.errMsg ="该手机号操作太频繁，请明天再试"
                            }

                        }
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: SendSmsResponse) {
                        NotifyDialog.show(this@ChangeMobilePhoneActivity, "验证码发送成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        initTimer(60)?.start()
                        messageId = data.body.messageId

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,apiErrorModel.message)
                    }

                })

    }


    private fun verifySmsCode(code: String) {
        val request = VerifySmsCodeRequest()
        request.smsCode = code
        request.messageId = messageId
        request.use = 6
        ApiClient.instance.service.verifySmsCode(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<VerifySmsCodeResponse>(this, true) {
                    override fun businessFail(data: VerifySmsCodeResponse) {
                        when(data.head.errCode){
                            "WS_300027","GW_800205","WS_300021","GW_800211","WS_300020" ->{
                                data.head.errMsg ="短信验证码不正确"
                            }
                            "GW_800210" ->{
                                data.head.errMsg ="手机号不能为空"
                            }
                            "GW_800203" ->{
                                data.head.errMsg ="短信验证码过期"
                            }
                            "WS_300002","WS_300022" ->{
                                data.head.errMsg ="操作太频繁，请5分钟后再试"
                            }
                            "WS_201723" ->{
                                data.head.errMsg ="该手机号操作太频繁，请明天再试"
                            }


                        }
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: VerifySmsCodeResponse) {
                        val intent = Intent(this@ChangeMobilePhoneActivity, BindMobilePhoneActivity::class.java)
                        intent.putExtra("type",type)
                        startActivity(intent)
                        finish()
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,apiErrorModel.message)
                    }

                })

    }


    private fun bindMobileNo() {
        val request = BindMobileRequest()
        request.messageId = messageId
        request.smsCode = et_verify_code.getEditTextContent().trim()
        ApiClient.instance.service.bindMobileNo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<BindMobileResponse>(this, true) {
                    override fun businessFail(data: BindMobileResponse) {
                        when(data.head.errCode){
                            "WS_300027","GW_800205","WS_300021","GW_800211","WS_300020" ->{
                                data.head.errMsg ="短信验证码不正确"
                            }
                            "GW_800210" ->{
                                data.head.errMsg ="手机号不能为空"
                            }
                            "GW_800203" ->{
                                data.head.errMsg ="短信验证码过期"
                            }
                            "WS_300002","WS_300022" ->{
                                data.head.errMsg ="操作太频繁，请5分钟后再试"
                            }
                            "WS_201723" ->{
                                data.head.errMsg ="该手机号操作太频繁，请明天再试"
                            }


                        }
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: BindMobileResponse) {
                        ConfigUtils.isBindMobile = true
                        NotifyDialog.show(this@ChangeMobilePhoneActivity, "绑定成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {

                                finish()
//                                when (mJumpTo) {
//                                    0 -> {
//                                        finish()
//                                    }
//                                    JumpToWithDraw -> {
//                                        goToPage(Intent(this@ChangeMobilePhoneActivity, WithdrawActivity::class.java))
//                                        finish()
//                                    }
//                                    JumpToDepositor -> {
//                                        goToPage(Intent(this@ChangeMobilePhoneActivity, RechargeActivity::class.java))
//                                        finish()
//                                    }
//                                    else -> {
//                                        finish()
//                                    }
//                                }

                            }

                        })
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@ChangeMobilePhoneActivity,apiErrorModel.message)
                    }

                })

    }

}