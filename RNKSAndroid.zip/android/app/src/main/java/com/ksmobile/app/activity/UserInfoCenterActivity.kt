package com.ksmobile.app.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.flyco.tablayout.listener.CustomTabEntity
import com.flyco.tablayout.listener.OnTabSelectListener
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.adapter.BankCardPagerAdapter
import com.ksmobile.app.adapter.BitCardPagerAdapter
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.TabEntity
import com.ksmobile.app.data.request.CardManagerRequest
import com.ksmobile.app.data.request.DeleteBankCardRequest
import com.ksmobile.app.data.request.GetByLoginNameRequest
import com.ksmobile.app.data.response.CardManagerResponse
import com.ksmobile.app.data.response.DeleteBankCardResponse
import com.ksmobile.app.data.response.GetByLoginNameResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.ShadowTransformer
import com.ksmobile.app.view.CustomerInfoView
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_user_info_center.*
import java.util.ArrayList

class UserInfoCenterActivity : BaseToolBarActivity() {

    private val mTabEntities = ArrayList<CustomTabEntity>()
    private var bankNum = 0
    private var BitNum = 0
    override fun getLayoutId(): Int {
        return R.layout.activity_user_info_center
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.user_center_info_title))

    }

    override fun initView() {
        val mTitles = arrayOf("我的银行卡(0/3)", "我的比特币卡(0/1)")
        mTitles.forEach {
            mTabEntities.add(TabEntity(it, 0, 0))
        }

        tabs.setTabData(mTabEntities)

    }

    override fun onResume() {
        super.onResume()
        getUserInfo()

    }

    override fun initListener() {
        ci_real_name.setOnClickListener {
            startActivity(Intent(this, RealNameVerifyActivity::class.java))
        }
        ci_bind_phone.setOnClickListener {

            if (ConfigUtils.isBindMobile) {
                val intent = Intent(this, ChangeMobilePhoneActivity::class.java)
                startActivity(intent)
            } else {
                if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {

                    val intent = Intent(this, BindMobilePhoneActivity::class.java)
                    startActivity(intent)

                } else {
                    val intent = Intent(this, ChangeMobilePhoneActivity::class.java)
                    intent.putExtra("type",1)
                    startActivity(intent)
                }


            }


        }

        tabs.setOnTabSelectListener(object : OnTabSelectListener {
            override fun onTabSelect(position: Int) {
                when (position) {
                    0 -> {
                        vp_bank_card.visibility = View.VISIBLE
                        vp_bank_bit.visibility = View.GONE
                    }
                    1 -> {
                        vp_bank_card.visibility = View.GONE
                        vp_bank_bit.visibility = View.VISIBLE
                    }
                    else -> {
                        vp_bank_card.visibility = View.VISIBLE
                        vp_bank_bit.visibility = View.GONE
                    }
                }
            }

            override fun onTabReselect(position: Int) {
            }

        })
    }

    private fun loadData() {
        val request = CardManagerRequest()
        ApiClient.instance.service.cardManager(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CardManagerResponse>(this, true) {
                    override fun businessFail(data: CardManagerResponse) {
                        NotifyDialog.show(this@UserInfoCenterActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: CardManagerResponse) {

                        updateBankInfoView(data)
                        updateBitInfoView(data)
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@UserInfoCenterActivity,apiErrorModel.message)
                    }

                })

    }

    private fun updateBankInfoView(data: CardManagerResponse) {
        val mBankCardPagerAdapter = BankCardPagerAdapter(baseContext)
        if (!data.body.accounts.isEmpty()) {
            data.body.accounts.forEach {
                if (it.accountType != "BTC") {
                    mBankCardPagerAdapter.addCardItem(it)
                }
            }
            bankNum = mBankCardPagerAdapter.count
        }

        tabs.getTitleView(0).text = String.format(getString(R.string.my_bank), bankNum)
        if (mBankCardPagerAdapter.count < 3) {
            mBankCardPagerAdapter.addCardItem(null)
        }

        val mCardShadowTransformer = ShadowTransformer(vp_bank_card, mBankCardPagerAdapter)
        mBankCardPagerAdapter.setIdeleteListener(object : BankCardPagerAdapter.IDeleteCallBack {
            override fun onDelete(accountId: String?, accountNo: String?) {

                my_top_confirm.setTipTitle("您确定要删除尾号${accountNo?.replace("*", "")?.replace(" ", "")}的银行卡么？")
                my_top_confirm.setSureText("删除")
                my_top_confirm.setSureListener(View.OnClickListener {
                    deleteBankCard(accountId)
                    my_top_confirm.hidden()
                })

                my_top_confirm.show()

            }

        })
        vp_bank_card.adapter = mBankCardPagerAdapter
        vp_bank_card.setPageTransformer(false, mCardShadowTransformer)
        vp_bank_card.offscreenPageLimit = 3
        mCardShadowTransformer.enableScaling(true)
    }

    private fun updateBitInfoView(data: CardManagerResponse) {
        val mBankCardPagerAdapter = BitCardPagerAdapter(baseContext)
        if (!data.body.accounts.isEmpty()) {
            data.body.accounts.forEach {
                if (it.accountType == "BTC") {
                    mBankCardPagerAdapter.addCardItem(it)
                }

            }
            BitNum = mBankCardPagerAdapter.count
        }
        tabs.getTitleView(1).text = String.format(getString(R.string.my_btc), BitNum)
        if (mBankCardPagerAdapter.count < 1) {
            mBankCardPagerAdapter.addCardItem(null)
        }

        val mCardShadowTransformer = ShadowTransformer(vp_bank_card, mBankCardPagerAdapter)
        mBankCardPagerAdapter.setIdeleteListener(object : BitCardPagerAdapter.IDeleteCallBack {
            override fun onDelete(accountId: String?, accountNo: String?) {

                my_top_confirm.setTipTitle("您确定要删除比特币卡？")
                my_top_confirm.setSureText("删除")
                my_top_confirm.setSureListener(View.OnClickListener {
                    deleteBankCard(accountId)
                    my_top_confirm.hidden()
                })

                my_top_confirm.show()

            }

        })
        vp_bank_bit.adapter = mBankCardPagerAdapter
        vp_bank_bit.setPageTransformer(false, mCardShadowTransformer)
        vp_bank_bit.offscreenPageLimit = 3
        mCardShadowTransformer.enableScaling(true)
    }


    private fun deleteBankCard(accountId: String?) {
        val request = DeleteBankCardRequest()
        request.accountId = accountId
        ApiClient.instance.service.deleteBankCard(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<DeleteBankCardResponse>(this, true) {
                    override fun businessFail(data: DeleteBankCardResponse) {
                        if(data.head.errCode=="GW_800813"){
                            data.head.errMsg = "至少保留一张取款卡"
                        }
                        NotifyDialog.show(this@UserInfoCenterActivity,data.head.errMsg)
                    }

                    override fun businessSuccess(data: DeleteBankCardResponse) {
                        NotifyDialog.show(this@UserInfoCenterActivity,"删除成功")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        loadData()
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@UserInfoCenterActivity,apiErrorModel.message)
                    }

                })

    }


    private fun getUserInfo() {
        val request = GetByLoginNameRequest()
        request.inclMobileNo = 1
        request.inclMobileNoBind = 1
        request.inclRealName = 1
        request.inclBankAccount = 1
        request.inclBtcAccount = 1
        ApiClient.instance.service.getByLoginName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetByLoginNameResponse>(this, false) {
                    override fun businessFail(data: GetByLoginNameResponse) {
                    }

                    override fun businessSuccess(data: GetByLoginNameResponse) {
                        ConfigUtils.mobileNo = data.body?.mobileNo
                        ConfigUtils.realName = data.body?.realName
                        ConfigUtils.isBindMobile = (data.body?.mobileNoBind == 1)
                        ConfigUtils.bankCardCounts = data.body?.bankCardNum!!.plus(data.body.btcNum)
//                        bankNum = data.body.bankCardNum
//                        BitNum = data.body.btcNum
                        loadData()
                        if (!TextUtils.isEmpty(data.body.birthday)) {
                            ci_real_name.setContent(ConfigUtils.realName!!)
                            ci_real_name.setStatus("已完善", CustomerInfoView.STATUS_BLUE)
                        }
                        if (ConfigUtils.isBindMobile) {
                            ci_bind_phone.setContent(ConfigUtils.mobileNo!!)
                            ci_bind_phone.setStatus("更换", CustomerInfoView.STATUS_RED)
                        }
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }

}