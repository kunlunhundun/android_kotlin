package com.ksmobile.app.data

data class XmCode(val xmRate: String, val xmType: String)