package com.ksmobile.app.data.response


class UpgradeResponse : BaseResponseObject() {


    var body: Body? = null

    data class Body(var appDownUrl: String?, var flag: Int?, var h5DownUrl: String?, var h5Md5: String?
                    , var h5VersionId: Int, var versionCode: String?, var versionId: Int?)

}