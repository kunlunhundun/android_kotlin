package com.ksmobile.app.activity.reactnative

import android.os.Bundle
import android.view.*
import com.facebook.react.ReactInstanceManager

import com.facebook.react.modules.core.DefaultHardwareBackBtnHandler
import kotlinx.android.synthetic.main.activity_rn_view.*
import com.ksmobile.app.manager.AppInitManager
import com.facebook.react.ReactRootView
import com.ksmobile.app.activity.BaseToolBarActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.GetByLoginNameRequest
import com.ksmobile.app.data.request.QueryCountUnreadRequest
import com.ksmobile.app.data.request.QueryLiveChatAddressRequest
import com.ksmobile.app.data.response.GetByLoginNameResponse
import com.ksmobile.app.data.response.QueryCountUnreadResponse
import com.ksmobile.app.data.response.QueryLiveChatAddressResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.microsoft.codepush.react.CodePush
import com.microsoft.codepush.react.ReactInstanceHolder
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent


abstract class RNPageActivity : BaseToolBarActivity(), DefaultHardwareBackBtnHandler, View.OnLayoutChangeListener, ReactInstanceHolder {

    val mReactInstanceManager = AppInitManager.getReactInstanceManager()
//    var  fromNative = false


    override fun getReactInstanceManager(): ReactInstanceManager {

        return AppInitManager.getReactInstanceManager()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        navigation_bar.bindActiviy(this)
        content.addOnLayoutChangeListener(this)
    }


    private fun initPage() {
        OpenNative.registerRNpage(this)


    }

    fun showNavigation(show: Boolean) {

        runOnUiThread {
            if (show) {
                navigation_bar.visibility = View.VISIBLE
            } else {
                navigation_bar.visibility = View.GONE
            }
        }


    }


    override fun invokeDefaultOnBackPressed() {
        super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        mReactInstanceManager.onHostPause(this)

    }

    override fun onResume() {
        super.onResume()
        mReactInstanceManager.onHostResume(this, this)
        if (mReactInstanceManager.viewManagerNames==null){
            mReactInstanceManager.attachRootView(AppInitManager.getMainReactRootView())
        }

        CodePush.setReactInstanceHolder(this)

        initPage()
        queryCountUnread()


    }

    override fun onDestroy() {
        super.onDestroy()
        OpenNative.unRegisterRNpage()
        mReactInstanceManager.onHostDestroy(this)

    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (mReactInstanceManager.devSupportManager!!.devSupportEnabled) {
            if (keyCode == KeyEvent.KEYCODE_MENU) {//Ctrl + M 打开RN开发者菜单
                mReactInstanceManager.showDevOptionsDialog()
                return true
            }
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onLayoutChange(v: View?, left: Int, top: Int, right: Int, bottom: Int, oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int) {

        if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight)) {
            navigation_bar.onLayoutChange(true)
        } else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight)) {
            navigation_bar.onLayoutChange(false)
        }
    }


    /**
     * 从当前界面移除 ReactRootView
     */
    fun detachView(reactView: ReactRootView) {
        try {


            val parent = reactView.parent
            if (parent != null) {
                (parent as ViewGroup).removeView(reactView)
            }

        } catch (e: Throwable) {
            e.printStackTrace()
        }

    }

    /**
     * 获取客服链接
     */
    fun queryOnlineCustomerService() {
        val request = QueryLiveChatAddressRequest()
        ApiClient.instance.service.liveChatAddress(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryLiveChatAddressResponse>(this, false) {
                    override fun businessFail(data: QueryLiveChatAddressResponse) {
                    }

                    override fun businessSuccess(data: QueryLiveChatAddressResponse) {

                        ConfigUtils.onlineCustomerUrl = data.body

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }

    /**
     * 获取未读消息个数
     */


    fun queryCountUnread() {
        val request = QueryCountUnreadRequest()
        ApiClient.instance.service.countUnread(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryCountUnreadResponse>(this, false) {
                    override fun businessFail(data: QueryCountUnreadResponse) {
                        navigation_bar.showMsg(1, 0)
                    }

                    override fun businessSuccess(data: QueryCountUnreadResponse) {

                        navigation_bar.showMsg(1, data.body.totalRow)


                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        navigation_bar.showMsg(1, 0)
                    }
                })
    }

    fun getUserInfo() {
        val request = GetByLoginNameRequest()
        request.inclMobileNo = 1
        request.inclMobileNoBind = 1
        request.inclRealName = 1
        request.inclBankAccount = 1
        request.inclBtcAccount = 1
        request.inclXmFlag = 1
        ApiClient.instance.service.getByLoginName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetByLoginNameResponse>(this, false) {
                    override fun businessFail(data: GetByLoginNameResponse) {
                    }

                    override fun businessSuccess(data: GetByLoginNameResponse) {
                        ConfigUtils.mobileNo = data.body?.mobileNo
                        ConfigUtils.realName = data.body?.realName
                        ConfigUtils.isBindMobile = (data.body?.mobileNoBind == 1)
                        ConfigUtils.starLevel = data.body?.starLevelName
                        ConfigUtils.bankCardCounts = data.body?.bankCardNum!!.plus(data.body.btcNum)

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }


    abstract fun handleGame()

    abstract fun reloadGame()




}
