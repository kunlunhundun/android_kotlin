package com.ksmobile.app.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import com.ksmobile.app.R
import com.ksmobile.app.util.GlideUtils
import kotlinx.android.synthetic.main.customer_horize_view.view.*

class CustomHorizeView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {




    init {
        LayoutInflater.from(context).inflate(R.layout.customer_horize_view, this, true)
        val a = context.obtainStyledAttributes(attrs, R.styleable.CustomerInfoView)
        val title = a.getString(R.styleable.CustomerInfoView_label_name)
        val content = a.getString(R.styleable.CustomerInfoView_content_name)
        val titleColor = a.getColor(R.styleable.CustomerInfoView_titleColor,resources.getColor(R.color.colorWhite))
        val contentColor = a.getColor(R.styleable.CustomerInfoView_ContentColor,resources.getColor(R.color.colorWhite))
        if (title != null) {
            tv_title.text = title
        }
        if (content != null) {
            tv_content.text = content
        }

        tv_title.setTextColor(titleColor)
        tv_content.setTextColor(contentColor)

        a.recycle()
    }

    fun setTtile(title: String) {
        tv_title.text = title
    }

    fun setContent(content: String) {
        tv_content.text = content
        tv_content.visibility = View.VISIBLE
    }


    fun setContenColor(){

    }


    fun setDrawable(drawable: Drawable) {
        iv_icon.setImageDrawable(drawable)
        iv_icon.visibility = View.VISIBLE
    }

    fun hiddenDrawable(){
        iv_icon.setImageDrawable(null)
        iv_icon.visibility = View.GONE
    }

    fun setDrawable(id: Int) {
        iv_icon.setImageResource(id)
        iv_icon.visibility = View.VISIBLE
    }

    fun setDrawable(url: String) {
        GlideUtils.load(context,url).placeholder(R.mipmap.insted_imag_smarll).error(R.mipmap.insted_imag_smarll).into(iv_icon)
        iv_icon.visibility = View.VISIBLE
    }

}