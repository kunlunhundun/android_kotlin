package com.ksmobile.app.view.hybride


import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.TextUtils
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.ProgressBar
import android.widget.Toast
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.activity.BaseToolBarActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.PointPayResult
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.download.UpdateAppHttpUtil
import com.ksmobile.app.net.LoadingDialog
import com.ksmobile.app.util.CommonCallback
import com.ksmobile.app.util.HProgressDialogUtils
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.view.NotifyDialog
import com.vector.update_app.UpdateAppBean
import com.vector.update_app.UpdateAppManager
import com.vector.update_app.service.DownloadService
import kotlinx.android.synthetic.main.activity_browser.*
import kotlinx.android.synthetic.main.dialog_notify.*
import java.io.File
import java.net.URISyntaxException


/**
 * Sonic WebActivity
 * @author Ward.Y
 */

class BrowserActivity : BaseToolBarActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_browser
    }

    interface BroadListener {
        fun OnFinishLoadBarListener()
    }

    var mUrl: String? = null
    private var param: String? = null
    private var isFullScreen: Boolean = false
    private var isPointCardPay: Boolean = false
    private var isOnlineCustomerService: Boolean = false
    private var isShowActionBar: Boolean = false
    private var mCallback = BrowserCallback()
    private var mHtmlContent: String? = null
    var isPause = false
    var imageUri: Uri? = null
    var mUploadCallbackBelow: ValueCallback<Uri>? = null
    var mUploadCallbackAboveL: ValueCallback<Array<Uri>>? = null
    val REQUEST_CODE = 1
    var isQKChargeBar = false
    var urlDomain:String? = null
    var onFinishLoadBar:BroadListener? = null //监听推荐客服的URL加载完后在接收动画

    companion object {
        const val PARAM_URL = "param_url"
        const val PARAM_HTML_CONTENT = "param_html_content"
        const val PARAM_POST_PARAM = "param"
        const val PARAM_FULL_SCREEN = "full_screen"
        const val PARAM_SHOW_ACTION_BAR = "show_action_bar"
        const val PARAM_QK_CHARGE_BAR = "show_qk_charge_bar"
        const val PARAM_IS_CARD_PAY = "is_card_pay"
        const val PARAM_IS_ONLINE_CUSTOMER_SERVICE = "is_online_customer_service"

    }




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mUrl = intent.getStringExtra(PARAM_URL)
        mHtmlContent = intent.getStringExtra(PARAM_HTML_CONTENT)
        param = intent.getStringExtra(PARAM_POST_PARAM)
        isFullScreen = intent.getBooleanExtra(PARAM_FULL_SCREEN, false)
        isPointCardPay = intent.getBooleanExtra(PARAM_IS_CARD_PAY, false)
        isOnlineCustomerService = intent.getBooleanExtra(PARAM_IS_ONLINE_CUSTOMER_SERVICE, false)
        isShowActionBar = intent.getBooleanExtra(PARAM_SHOW_ACTION_BAR, false)
        isQKChargeBar = intent.getBooleanExtra(PARAM_QK_CHARGE_BAR,false)
        if (TextUtils.isEmpty(mUrl) && TextUtils.isEmpty(mHtmlContent)) {
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED)
      //  https://www.ks015.com/chat/chatClient/chatbox.jsp?companyID=8991&configID=80&skillId=26


        if (isFullScreen) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }

        if (isShowActionBar) {
            tool_bar.visibility = View.VISIBLE
        }
        if (isQKChargeBar) {
            if (mUrl?.contains("//") == true) {
                urlDomain = mUrl!!.split("//")[1].split("/")[0]
            }
            ll_pgb_recharge_customer.visibility = View.VISIBLE
            setAnimation(pgb_recharge_customer,80)

            setBroadListener( object :BroadListener {
                override fun OnFinishLoadBarListener(){
                    ll_pgb_recharge_customer.visibility = View.GONE
                }
            })

            return
        }

        if (!isOnlineCustomerService) {
            loading_view.show("")
        } else {
            LoadingDialog.show(this)
        }

    }

    /**
     * 进度条的动画效果
     */
    private fun setAnimation(mProgressBar: ProgressBar, mProgress: Int) {
        val animator = ValueAnimator.ofInt(0, mProgress).setDuration(3000)

        animator.addUpdateListener {
            valueAnimator -> mProgressBar.setProgress(valueAnimator.animatedValue as Int)
            if (valueAnimator.animatedValue == 80) {

              //  ll_pgb_recharge_customer.visibility = View.GONE
            }
        }
        animator.start()
    }

    fun setBroadListener(broadListener: BroadListener) {
        this.onFinishLoadBar = broadListener
    }


    override fun onSaveInstanceState(outState: Bundle?) {
        super.onSaveInstanceState(outState)
        webview.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
        super.onRestoreInstanceState(savedInstanceState)
        webview.restoreState(savedInstanceState)
    }

    @SuppressLint("AddJavascriptInterface")
    override fun initView() {
        webview.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (intent.getStringExtra("SBSPORT") != null) {

                    setTile("沙巴体育")
                } else {

                    setTile(title!!)
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                Toast.makeText(this@BrowserActivity, message, Toast.LENGTH_SHORT).show()
                result!!.cancel()
                return true
            }

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?): Boolean {
                return super.onJsPrompt(view, url, message, defaultValue, result)

            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                return super.onJsConfirm(view, url, message, result)
            }

            /**
             * 8(Android 2.2) <= API <= 10(Android 2.3)回调此方法
             */
            fun openFileChooser(uploadMsg: ValueCallback<Uri>) {
//                Log.e("WangJ", "运行方法 openFileChooser-1")
                // (2)该方法回调时说明版本API < 21，此时将结果赋值给 mUploadCallbackBelow，使之 != null
                mUploadCallbackBelow = uploadMsg
                takePhoto()
            }

            /**
             * 11(Android 3.0) <= API <= 15(Android 4.0.3)回调此方法
             */
            fun openFileChooser(uploadMsg: ValueCallback<Uri>, acceptType: String) {
//                Log.e("WangJ", "运行方法 openFileChooser-2 (acceptType: $acceptType)")
                openFileChooser(uploadMsg)
            }

            /**
             * 16(Android 4.1.2) <= API <= 20(Android 4.4W.2)回调此方法
             */
            fun openFileChooser(uploadMsg: ValueCallback<Uri>, acceptType: String, capture: String) {
//                Log.e("WangJ", "运行方法 openFileChooser-3 (acceptType: $acceptType; capture: $capture)")
                openFileChooser(uploadMsg)
            }

            /**
             * API >= 21(Android 5.0.1)回调此方法
             */
            override fun onShowFileChooser(webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: FileChooserParams): Boolean {
//                Log.e("WangJ", "运行方法 onShowFileChooser")
                // (1)该方法回调时说明版本API >= 21，此时将结果赋值给 mUploadCallbackAboveL，使之 != null
                mUploadCallbackAboveL = filePathCallback
                takePhoto()
                return true
            }
        }



        webview.webViewClient = object : BaseWebViewClient(this) {

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (isPointCardPay) {
                    /**这个是为了加载网页内容*/
                    view?.loadUrl("javascript:window.discover.showSource(document.getElementsByTagName('pre')[0].innerText);")
                } else if (isOnlineCustomerService) {
                    LoadingDialog.cancel()
                } else {
                    loading_view.hidden()
                    onFinishLoadBar?.OnFinishLoadBarListener()//快捷存款URL加载完后消失动画页面

                }

            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                return super.shouldInterceptRequest(view, request)

            }

            override fun shouldOverrideUrlLoading(webview: WebView?, url: String?): Boolean {
                if (TextUtils.isEmpty(url)) {
                    return false
                }


                try {
                    //处理intent协议
                    if (url!!.startsWith("intent://")) {
                        val intent: Intent
                        try {
                            intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                            intent.addCategory("android.intent.category.BROWSABLE")
                            intent.component = null
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
                                intent.selector = null
                            }
                            val resolves = mActivity.packageManager.queryIntentActivities(intent, 0)
                            if (resolves.size > 0) {
                                mActivity.startActivityIfNeeded(intent, -1)
                            }
                            return true
                        } catch (e: URISyntaxException) {
                            e.printStackTrace()
                        }

                    }
                    // 处理自定义scheme协议
                    if (!url.startsWith("http")) {
                        try {
                            // 以下固定写法
                            val intent = Intent(Intent.ACTION_VIEW,
                                    Uri.parse(url))
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            mActivity.startActivity(intent)
                        } catch (e: Exception) {
                            // 防止没有安装的情况
                            e.printStackTrace()
                            NotifyDialog.show(this@BrowserActivity,"您所打开的第三方App未安装！")
                        }

                        return true
                    }


                    when{
                        url.contains("brand.htm")->{
                            finish()
                        }

                    }


                } catch (e: Exception) {
                    e.printStackTrace()
                }

                val uri = Uri.parse(url) ?: return false
                //点击回退键
                if (DataBaseHelper.getUrl()?.domain?.equals(uri.host) == true) {
                    if (url=="https://m.0799ks.com/#/ground/type/1"){
                        return false
                    }
                    webview?.reload()
                    finish()
                    return true
                }

                if(isQKChargeBar) {
                    if (urlDomain == uri.host) {
                        finish()
                        return  true
                    }
                }
                if (ConfigUtils.parentId == uri.host) {
                    finish()
                    return true
                }
                return super.shouldOverrideUrlLoading(webview, url)
            }

        }

        webview.addJavascriptInterface(this, "discover")


        if (TextUtils.isEmpty(mHtmlContent)) {

            if (TextUtils.isEmpty(param)) {
                webview.loadUrl(mUrl)
            } else {
                webview.postUrl(mUrl, param?.toByteArray())
            }


        } else {
            //加载Html文本
            webview.settings.defaultTextEncodingName = "UTF -8"
//            webView.loadData(mHtmlContent, "text/html", "UTF-8")
            webview.loadData(mHtmlContent, "text/html; charset=UTF-8", null)
        }

    }

    override fun initListener() {
        webview.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            downLoadApp(url)

        }

    }

    fun hiddenActionBar(boolean: Boolean) {
        if (boolean) {
            tool_bar.visibility = View.GONE
        } else {
            tool_bar.visibility = View.VISIBLE
        }
    }

    override fun onPause() {
        super.onPause()
        isPause = true
        if (webview != null) {
            webview.onPause()
        }

    }

    override fun onResume() {
        super.onResume()
        if (webview != null) {
            webview.onResume()
        }

        isPause = false
    }

    override fun onDestroy() {
        super.onDestroy()
        if (webview != null) {
            webview.destroy()
        }

    }

    inner class BrowserCallback : CommonCallback {

        override fun onCalled() {
            finish()
        }
    }

    /**
     * 调用相机
     */
    private fun takePhoto() {
        // 指定拍照存储位置的方式调起相机
//        val filePath = (Environment.getExternalStorageDirectory().toString() + File.separator
//                + Environment.DIRECTORY_PICTURES + File.separator)
//        val fileName = "IMG_" + DateFormat.format("yyyyMMdd_hhmmss", Calendar.getInstance(Locale.CHINA)) + ".jpg"
//        imageUri = Uri.fromFile(File(filePath + fileName))
//
//        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
//        startActivityForResult(intent, REQUEST_CODE)


//         选择图片（不包括相机拍照）,则不用成功后发刷新图库的广播
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(Intent.createChooser(i, "Image Chooser"), REQUEST_CODE)

    }


    private fun updatePhotos() {
        // 该广播即使多发（即选取照片成功时也发送）也没有关系，只是唤醒系统刷新媒体文件
        val intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
        intent.data = imageUri
        sendBroadcast(intent)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE) {

            if (resultCode == Activity.RESULT_OK) {
                // 经过上边(1)、(2)两个赋值操作，此处即可根据其值是否为空来决定采用哪种处理方法
                when {
                    mUploadCallbackBelow != null -> chooseBelow(resultCode, data)
                    mUploadCallbackAboveL != null -> chooseAbove(resultCode, data)
                    else -> Toast.makeText(this, "发生错误", Toast.LENGTH_SHORT).show()
                }
            }

            if (resultCode == Activity.RESULT_CANCELED) {
                if (mUploadCallbackAboveL != null) {
                    mUploadCallbackAboveL?.onReceiveValue(null)
                    mUploadCallbackAboveL = null

                }

                if (mUploadCallbackBelow != null) {
                    mUploadCallbackBelow?.onReceiveValue(null)
                    mUploadCallbackBelow = null

                }
            }
        }


    }


    /**
     * Android API >= 21(Android 5.0) 版本的回调处理
     * @param resultCode 选取文件或拍照的返回码
     * @param data 选取文件或拍照的返回结果
     */
    private fun chooseAbove(resultCode: Int, data: Intent?) {
        if (Activity.RESULT_OK == resultCode) {
            updatePhotos()

            if (data != null) {
                // 这里是针对从文件中选图片的处理
                val results: Array<Uri>
                val uriData = data.data
                if (uriData != null) {
                    results = arrayOf(uriData)
                    for (uri in results) {
//                        Log.e("WangJ", "系统返回URI：" + uri.toString())
                    }
                    mUploadCallbackAboveL?.onReceiveValue(results)
                } else {
                    mUploadCallbackAboveL?.onReceiveValue(null)
                }
            } else {
//                Log.e("WangJ", "自定义结果：" + imageUri.toString())
                mUploadCallbackAboveL?.onReceiveValue(arrayOf(imageUri!!))
            }
        } else {
            mUploadCallbackAboveL?.onReceiveValue(null)
        }
        mUploadCallbackAboveL = null
    }


    /**
     * Android API < 21(Android 5.0)版本的回调处理
     * @param resultCode 选取文件或拍照的返回码
     * @param data 选取文件或拍照的返回结果
     */
    private fun chooseBelow(resultCode: Int, data: Intent?) {
//        Log.e("WangJ", "返回调用方法--chooseBelow")

        if (Activity.RESULT_OK == resultCode) {
            updatePhotos()

            if (data != null) {
                // 这里是针对文件路径处理
                val uri = data.data
                if (uri != null) {
//                    Log.e("WangJ", "系统返回URI：" + uri.toString())
                    mUploadCallbackBelow?.onReceiveValue(uri)
                } else {
                    mUploadCallbackBelow?.onReceiveValue(null)
                }
            } else {
                // 以指定图像存储路径的方式调起相机，成功后返回data为空
//                Log.e("WangJ", "自定义结果：" + imageUri.toString())
                mUploadCallbackBelow?.onReceiveValue(imageUri)
            }
        } else {
            mUploadCallbackBelow?.onReceiveValue(null)
        }
        mUploadCallbackBelow = null
    }

    @JavascriptInterface
    fun showSource(html: String) {
        runOnUiThread {
            loading_view.hidden()
            ll_show_result.visibility = View.VISIBLE
            val pointPayResult = Gson().fromJson(html, PointPayResult::class.java)
            tv_message.text = pointPayResult.message
            if (pointPayResult.message.contains("成功", true)) {
                img_status.setImageResource(R.mipmap.point_card_pay_success)
            }

        }


    }


    private fun downLoadApp(mDyAppDownUrl: String) {
        if (!TextUtils.isEmpty(mDyAppDownUrl)) {
            val updateAppBean = UpdateAppBean()

            //设置 apk 的下载地址
            updateAppBean.apkFileUrl = mDyAppDownUrl
            var path: String? = ""
            if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED || !Environment.isExternalStorageRemovable()) {
                try {
                    path = baseContext.externalCacheDir?.absolutePath
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                if (TextUtils.isEmpty(path)) {
                    path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath
                }
            } else {
                path = baseContext.cacheDir?.absolutePath
            }

            //设置apk 的保存路径
            updateAppBean.targetPath = path
            //实现网络接口，只实现下载就可以
            updateAppBean.httpManager = UpdateAppHttpUtil()
            updateAppBean.dismissNotificationProgress(true)
//
//            UpdateAppManager.download(baseContext, updateAppBean, null)

            UpdateAppManager.download(this, updateAppBean, object : DownloadService.DownloadCallback {

                override fun onStart() {
                    HProgressDialogUtils.showHorizontalProgressDialog(this@BrowserActivity,
                            "${webview.title}下载中", false)
                }

                override fun onProgress(progress: Float, totalSize: Long) {
                    HProgressDialogUtils.setProgress(Math.round(progress * 100))

                }

                override fun setMax(totalSize: Long) {
                }

                override fun onFinish(file: File): Boolean {
                    HProgressDialogUtils.cancel()
                    return true
                }

                override fun onError(msg: String) {
                    HProgressDialogUtils.cancel()
                }

                override fun onInstallAppAndAppOnForeground(file: File): Boolean {
                    return false
                }
            })

        }
    }


}
