package com.ksmobile.app.database

import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class WashCodeRecord : DataSupport() {
    var loginName: String? = ""
    var alipayFirstTime: Int? = 0
    var wepayFirstTime: Int? = 0
    var bankfirstTime: Int? = 0

}