package com.ksmobile.app.activity

import android.app.ActionBar
import android.content.Intent
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.*
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.adapter.BankWheelAdapter
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.BankCardObj
import com.ksmobile.app.data.request.CardManagerRequest
import com.ksmobile.app.data.request.CreatMPRequest
import com.ksmobile.app.data.request.GetBalanceRequest
import com.ksmobile.app.data.request.QueryBtcRateRequest
import com.ksmobile.app.data.response.CardManagerResponse
import com.ksmobile.app.data.response.CreatWPResponse
import com.ksmobile.app.data.response.GetBalanceResponse
import com.ksmobile.app.data.response.QueryBtcRateResponse
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.RSATool
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.ConfirmDialog
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activiy_withdraw.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper
import java.math.BigDecimal

class WithdrawActivity : BaseToolBarActivity(), TextWatcher {
    var datas: GetBalanceResponse? = null
    val list: MutableList<BankCardObj> = mutableListOf()
    var beforeText: String? = null
    var bank: BankCardObj? = null
    var btcRate: BigDecimal = BigDecimal(1)
    var minWithDraw: BigDecimal? = BigDecimal(1)
    override fun getLayoutId(): Int {
        return R.layout.activiy_withdraw
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.withdraw_title))
        setActionText("在线客服")
        OverScrollDecoratorHelper.setUpOverScroll(sv_withdraw)
    }

    override fun initView() {
        getBalance()
    }

    override fun initListener() {
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
        mt_bank.setOnClickListener { pickBankPopWindow(it) }
        btn_commit.setOnClickListener {
            checkRequest()


        }

        tv_money.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(baseContext, R.anim.anim_round_rotate)
            iv_refresh.startAnimation(animation)
            getBalance()
        }

        mt_input_amount.getEditText().addTextChangedListener(this)


        mt_input_amount.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    TextUtils.isEmpty(mt_input_amount.getEditTextContent()) -> {
                        mt_input_amount.showError("请输入您的取款金额")

                    }
                }
            }

        }

        mt_password.setOnFocusChangeListener { v, hasFocus ->

            if (!hasFocus) {
                when {
                    TextUtils.isEmpty(mt_password.getEditTextContent()) -> {
                        mt_password.showError("请输入您的登录密码")

                    }

                    !Utils.checkPassword(mt_password.getEditTextContent()) -> {
                        mt_password.showError("请输入6-16位数字和字母组成的密码")

                    }
                }
            }

        }

    }


    override fun onResume() {
        super.onResume()
        if (ConfigUtils.isBindMobile) {
            requestCardMsg()
        } else {
            ConfirmDialog.show(this, false)
            ConfirmDialog.setContent("您还没有绑定手机号，请绑定后再操作")
            ConfirmDialog.setTitile("")
            ConfirmDialog.setCancelText("返回")
            ConfirmDialog.setSureText("去绑定")
            ConfirmDialog.setSureListener(View.OnClickListener {
                if (TextUtils.isEmpty(ConfigUtils.mobileNo)) {

                    val intent = Intent(this, BindMobilePhoneActivity::class.java)
                    intent.putExtra(BindMobilePhoneActivity.JumpTo, BindMobilePhoneActivity.JumpToWithDraw)
                    goToPage(intent)

                } else {
                    val intent = Intent(this, ChangeMobilePhoneActivity::class.java)
                    intent.putExtra("type", 1)
                    intent.putExtra(ChangeMobilePhoneActivity.JumpTo, ChangeMobilePhoneActivity.JumpToWithDraw)
                    goToPage(intent)
                }
                ConfirmDialog.dismiss()
            })

            ConfirmDialog.setCancelListener(View.OnClickListener {
                ConfirmDialog.dismiss()
                finish()
            })

        }


    }

    /**
     * 获取用户账户金额
     */
    private fun getBalance() {
        val request = GetBalanceRequest()
        request.flag = 9
        ApiClient.instance.service.getBalance(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<GetBalanceResponse>(this, true) {
                    override fun businessFail(data: GetBalanceResponse) {

                        NotifyDialog.show(this@WithdrawActivity, data.head.errMsg)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })

                    }

                    override fun businessSuccess(data: GetBalanceResponse) {
                        datas = data
                        tv_money.text = Utils.formatMoney(data.body?.balance!!, false)
                        tv_can_withdraw.text = "¥ ${data.body.withdrawBal?.toInt()}"
                        minWithDraw = data.body.minWithdrawAmount
                        mt_input_amount.getEditText().hint = String.format(getString(R.string.withdraw_deposit_page_input), data.body.minWithdrawAmount?.toInt(), "1000万")
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@WithdrawActivity, apiErrorModel.message)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }

                })

    }


    private fun requestCardMsg() {
        val request = CardManagerRequest()
        ApiClient.instance.service.cardManager(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CardManagerResponse>(this, false) {
                    override fun businessFail(data: CardManagerResponse) {

                    }

                    override fun businessSuccess(data: CardManagerResponse) {

                        if (data.body.accounts.size < 1) {
                            ConfirmDialog.show(this@WithdrawActivity, false)
                            ConfirmDialog.setContent("您还没有绑定银行卡，请绑定后操作")
                            ConfirmDialog.setTitile("")
                            ConfirmDialog.setCancelText("取消")
                            ConfirmDialog.setSureText("去绑定")
                            ConfirmDialog.setSureListener(View.OnClickListener {
                                val intent = Intent(this@WithdrawActivity, BindBankCardActivity::class.java)
                                goToPage(intent)
                                ConfirmDialog.dismiss()
                            })

                            ConfirmDialog.setCancelListener(View.OnClickListener {
                                ConfirmDialog.dismiss()
                                finish()
                            })


                        } else {
                            list.clear()
                            list.addAll(data.body.accounts)
                            btcRate = data.body.btcRate
                            defaultSelectCard()

                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }
                })
    }


    override fun afterTextChanged(p0: Editable?) {
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        beforeText = p0.toString()
    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        if (datas == null) {
            return
        }
        if (0f == datas?.body?.withdrawBal!!.toFloat()) {
            mt_input_amount.getEditText().text.clear()
            Toast.makeText(this, "您现在没有可提现余额", Toast.LENGTH_SHORT).show()
        } else {
            if (p0!!.isNotEmpty()) {
                if (bank?.accountType == "BTC") {
                    tv_show_btc_rate.visibility = View.VISIBLE
                }
            } else {
                tv_show_btc_rate.visibility = View.GONE

            }



            when {
                TextUtils.isEmpty(mt_input_amount.getEditTextContent()) -> {
                }
                BigDecimal(mt_input_amount.getEditTextContent()) > (datas?.body?.withdrawBal!!) -> {
                    mt_input_amount.setEditText(beforeText)
                    mt_input_amount.getEditText().setSelection(beforeText!!.length - 1)
                    Toast.makeText(this, "取款金额不得大于账号可取款金额", Toast.LENGTH_SHORT).show()
                }
                BigDecimal(mt_input_amount.getEditTextContent()) > (BigDecimal(10000000)) -> {
                    mt_input_amount.setEditText(beforeText)
                    mt_input_amount.getEditText().setSelection(beforeText!!.length - 1)
                    Toast.makeText(this, "取款金额不得大于账号可取款金额", Toast.LENGTH_SHORT).show()
                }
                BigDecimal(mt_input_amount.getEditTextContent()) == BigDecimal(0) -> {
                    mt_input_amount.setEditText("")
                    return

                }
                else -> {
                    tv_show_btc_rate.text = "≈ ${BigDecimal(mt_input_amount.getEditTextContent()).divide(btcRate, 8, BigDecimal.ROUND_DOWN)} BTC"

                }

            }

        }
    }


    private fun request(btcAmount: String?) {
        val request = CreatMPRequest()
        request.amount = BigDecimal(mt_input_amount.getEditTextContent())
        request.btcAmount = btcAmount
        request.accountId = bank?.accountId
        request.password = RSATool.encode(mt_password.getEditTextContent())
        ApiClient.instance.service.creatWithdrawalsProposal(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<CreatWPResponse>(this, true) {
                    override fun businessFail(data: CreatWPResponse) {

                        when (data.head.errCode) {
                            "WS_304817" -> {
                                NotifyDialog.show(this@WithdrawActivity, "您尚有处理中的取款申请")

                            }
                            "WS_304820" -> {
                                NotifyDialog.show(this@WithdrawActivity, "取款银行卡不存在，请重试")
                                requestCardMsg()

                            }
                            "WS_304848", "WS_304847" -> {
                                NotifyDialog.show(this@WithdrawActivity, "当前卡号不可用,请选择其他取款方式")
                                requestCardMsg()

                            }

                            "GW_800411" -> {
                                NotifyDialog.show(this@WithdrawActivity, data.head.errMsg)
                                NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                                    override fun onHidden() {
                                        AppInitManager.loginOut()
                                    }

                                })
                            }
                            else -> {
                                NotifyDialog.show(this@WithdrawActivity, data.head.errMsg)
                            }

                        }


                    }

                    override fun businessSuccess(data: CreatWPResponse) {
                        NotifyDialog.show(this@WithdrawActivity, "已成功提交取款提案")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@WithdrawActivity, apiErrorModel.message)
                    }

                })
    }

    private fun checkRequest() {
        var cancel = false

        when {
            TextUtils.isEmpty(mt_bank.getEditTextContent()) -> {
                mt_bank.showError("请选择您要提现的银行卡")
                cancel = true
            }

            TextUtils.isEmpty(mt_input_amount.getEditTextContent()) -> {
                cancel = true
                mt_input_amount.showError("请输入您的取款金额")
            }

            BigDecimal(mt_input_amount.getEditTextContent()) < minWithDraw -> {
                cancel = true
                mt_input_amount.showError("您的取款金额需≥${minWithDraw}元")
            }

            TextUtils.isEmpty(mt_password.getEditTextContent()) -> {
                mt_password.showError("请输入您的登录密码")
                cancel = true
            }

            !Utils.checkPassword(mt_password.getEditTextContent()) -> {
                mt_password.showError("请输入6-16位数字和字母组成的密码")
                cancel = true
            }

        }

        if (!cancel) {
            if (bank?.accountType == "BTC") {
                queryBtc()

            } else {
                request("")
            }
        }

    }


    /**
     * 选择银行卡
     */

    private fun pickBankPopWindow(v: View) {

        if (list.isEmpty()) {
            Toast.makeText(this, "请先去绑定银行卡", Toast.LENGTH_SHORT).show()
            return
        }

        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_transfer, null)
        val mPopupWindow = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(baseContext, 315f), true)
        mPopupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow.isOutsideTouchable = true
        mPopupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        mPopupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        var adapter = BankWheelAdapter(baseContext, list)
        val iv_back: ImageView = view.findViewById(R.id.iv_back)
        val iv_x: ImageView = view.findViewById(R.id.iv_x)
        val lv_bank_list: ListView = view.findViewById(R.id.lv_bank_list)
        val pop_confirm: LinearLayout = view.findViewById(R.id.pop_confirm)
        val pop_bank_list: ConstraintLayout = view.findViewById(R.id.pop_bank_list)
        pop_confirm.visibility = View.GONE
        pop_bank_list.visibility = View.VISIBLE
        iv_x.visibility = View.VISIBLE
        iv_back.visibility = View.GONE
        lv_bank_list.adapter = adapter
        lv_bank_list.setOnItemClickListener { _, _, position, _ ->
            if (list[position].flag == "0") {
                ToastUtils.show("当前渠道维护中，暂不可用")
                return@setOnItemClickListener
            }

            list.forEach {
                it.isSlelected = false
            }
            list[position].isSlelected = true
            adapter.notifyDataSetChanged()
            bank = list[position]
            mt_bank.setEditText(bank?.bankName + " (" + bank?.accountNo!!.replace("*", "").replace(" ", "") + ")")
            mt_bank.setDrawableMid(bank!!.bankIcon)
            if (bank?.accountType == "BTC") {
                mt_input_amount.getEditText().hint = String.format(getString(R.string.withdraw_btc_rate), btcRate.toString())
                if (!TextUtils.isEmpty(mt_input_amount.getEditTextContent())) {
                    tv_show_btc_rate.visibility = View.VISIBLE
                }
            } else {
                tv_show_btc_rate.visibility = View.GONE
                mt_input_amount.getEditText().hint = String.format(getString(R.string.withdraw_deposit_page_input), minWithDraw?.toInt(), "1000万")
            }

            mPopupWindow.dismiss()
        }
        view_bg.visibility = View.VISIBLE

        iv_x.setOnClickListener { mPopupWindow.dismiss() }
        mPopupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)
        mPopupWindow.setOnDismissListener { view_bg.visibility = View.GONE }
    }


    private fun defaultSelectCard() {
        list.forEach {
            if (it.flag != "0") {
                it.isSlelected = true
                bank = it
                mt_bank.setEditText(bank?.bankName + " (" + bank?.accountNo!!.replace("*", "").replace(" ", "") + ")")
                mt_bank.setDrawableMid(bank!!.bankIcon)
                if (bank?.accountType == "BTC") {
                    mt_input_amount.getEditText().hint = String.format(getString(R.string.withdraw_btc_rate), btcRate.toString())
                    if (!TextUtils.isEmpty(mt_input_amount.getEditTextContent())) {
                        tv_show_btc_rate.visibility = View.VISIBLE
                    }
                } else {
                    tv_show_btc_rate.visibility = View.GONE
                    mt_input_amount.getEditText().hint = String.format(getString(R.string.withdraw_deposit_page_input), minWithDraw?.toInt(), "1000万")
                }

                return
            }
        }

        if (bank == null) {
            ConfirmDialog.show(this@WithdrawActivity)
            ConfirmDialog.setContent("请添加有效取款卡")
            ConfirmDialog.setTitile("")
            ConfirmDialog.setCancelText("取消")
            ConfirmDialog.setSureText("去绑定")
            ConfirmDialog.setSureListener(View.OnClickListener {
                val intent = Intent(this@WithdrawActivity, BindBankCardActivity::class.java)
                goToPage(intent)
                ConfirmDialog.dismiss()
            })

            ConfirmDialog.setCancelListener(View.OnClickListener {
                ConfirmDialog.dismiss()
                finish()
            })
        }
    }


    private fun queryBtc() {
        val request = QueryBtcRateRequest()
        request.amount = BigDecimal(mt_input_amount.getEditTextContent())
        ApiClient.instance.service.queryBtcRate(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryBtcRateResponse>(this, true) {
                    override fun businessFail(data: QueryBtcRateResponse) {

                        NotifyDialog.show(this@WithdrawActivity, data.head.errMsg)

                    }

                    override fun businessSuccess(data: QueryBtcRateResponse) {
                        showOnlinePopWindow(data)
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@WithdrawActivity, apiErrorModel.message)
                    }

                })
    }

    /**
     * 比特币取款确认弹窗
     */

    fun showOnlinePopWindow(data: QueryBtcRateResponse) {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.btc_withdraw_confirm_view, null)

        val mPopupWindow = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT, true)
        mPopupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow.isOutsideTouchable = true
        mPopupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        mPopupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val close: ImageView = view.findViewById(R.id.image_close)
        val cancle: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val bankMsg: TextView = view.findViewById(R.id.tv_bank_msg)
        val tvMoney: TextView = view.findViewById(R.id.tv_money)
        bankMsg.text = "比特币(BTC) ${data.body.btcAmount}"
        sure.setOnClickListener {
            request(data.body.btcAmount)

        }

        tvMoney.text = "¥${Utils.formatMoney(data.body.amount)}"
        close.setOnClickListener { mPopupWindow.dismiss() }
        cancle.setOnClickListener { mPopupWindow.dismiss() }


        mPopupWindow.showAtLocation(sv_withdraw, Gravity.BOTTOM, 0, 0)
        view_bg.visibility = View.VISIBLE
        mPopupWindow.setOnDismissListener { view_bg.visibility = View.GONE }
    }


}