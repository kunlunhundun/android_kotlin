package com.ksmobile.app.data

data class PostMapObject(val gameID: String,
                         val gameType: String,
                         val password: String,
                         val username: String
)