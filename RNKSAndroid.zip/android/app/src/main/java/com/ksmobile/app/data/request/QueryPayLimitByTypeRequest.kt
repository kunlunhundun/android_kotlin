package com.ksmobile.app.data.request



class QueryPayLimitByTypeRequest : BaseRequestObject(){
    var payType:Int?=null //支付类型[0:BQ; 1:PC网银; 3:手机网银; 5:支付宝扫码; 6:微信扫码; 7:QQ扫码; 15:银联扫码; 16:京东扫码; 20:比特币支付; 22:BQ微信转账]
}