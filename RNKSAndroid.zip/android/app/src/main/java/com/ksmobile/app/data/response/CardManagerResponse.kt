package com.ksmobile.app.data.response

import com.ksmobile.app.data.BankCardObj
import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class CardManagerResponse : BaseResponseObject() {

    val body:Body = Body()

      class Body{
          var btcRate: BigDecimal = BigDecimal(1)
          var accounts = mutableListOf<BankCardObj>()
      }


}
