package com.ksmobile.app.activity.reactnative

import android.os.Bundle
import android.os.Handler
import android.view.View
import com.ksmobile.app.MyApplication
import com.ksmobile.app.R
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.manager.AppInitManager
import kotlinx.android.synthetic.main.activity_rn_view.*

class MyRnPageActivity : RNPageActivity() {

    var promoTag = false
    override fun getLayoutId(): Int {
        return R.layout.activity_rn_view
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detachView(AppInitManager.getMainReactRootView())
        fl_container.addView(AppInitManager.getMainReactRootView())
        navigation_bar.visibility = View.GONE
        promoTag = intent.getBooleanExtra("promoTag", false)


    }


    override fun handleGame() {
        detachView(AppInitManager.getMainReactRootView())
        Handler().postDelayed({
            MyApplication.getinstance().showAg = true
            AppInitManager.getActivityListManager().killAll()
            finish()
        }, 300)

    }


    override fun reloadGame() {
    }

    override fun initView() {

    }

    override fun initListener() {

    }

    override fun onBackPressed() {

        if (promoTag) {
            AppInitManager.getReactPackage().openNativeModule?.resetWebView()
//            Handler().postDelayed({
//                finish()
//            },200)

        }

        finish()


    }


}