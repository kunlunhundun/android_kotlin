package com.ksmobile.app.data.request



class QueryPayRequest : BaseRequestObject() {

    var payType: String = "0"
    var depositorType: Int = 0
    var depositor: String? = null

}