package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/19.
 */
class QueryDomainListResponse : BaseResponseObject() {
    val body: Body? = null


    class Body {
        val domainList: MutableList<String>? = null

    }


}
