package com.ksmobile.app.data

data class PromoObject (val abstractText:String,val beginDate:String,val configId:String,
                        val endDate:String,val imgTip:String,val imgUrl:String,val isTop:Int,
                        val linkUrl:String,val promoCode:String,val promoFlag:Int,val promoKind:Int,
                        val title:String
                        )

