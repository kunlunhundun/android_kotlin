package com.ksmobile.app.data.request



class BaseMsgRequest : BaseRequestObject() {

    var depositor: String? = null
    var  depositorType = 0
}