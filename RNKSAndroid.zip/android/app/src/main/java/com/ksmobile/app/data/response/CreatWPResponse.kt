package com.ksmobile.app.data.response

import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class CreatWPResponse : BaseResponseObject() {
    val body = Body()

    class Body {
        var loginName: String? = null
        var referenceId: String? = null
        var type: Int? = null
        var amount: BigDecimal? = null

    }
}
