package com.ksmobile.app.data.request

class GetByCardBinRequest : BaseRequestObject() {

    var bankCardNo:String?=null

}
