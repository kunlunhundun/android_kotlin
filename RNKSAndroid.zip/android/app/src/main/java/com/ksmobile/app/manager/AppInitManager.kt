package com.ksmobile.app.manager

import android.app.Application
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.app.FragmentActivity
import android.text.TextUtils
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.BV.LinearGradient.LinearGradientPackage
import com.brentvatne.react.ReactVideoPackage
import com.facebook.react.ReactInstanceManager
import com.facebook.react.ReactRootView
import com.facebook.react.common.LifecycleState
import com.facebook.react.shell.MainReactPackage
import com.github.yamill.orientation.OrientationPackage
import com.ivi.library.statistics.ThreeStatisticsManager
import com.ivi.library.statistics.tools.DeviceInfo
import com.jxccp.lib.sip.CallApi
import com.rea.push.helper.PushHelper
import com.ksmobile.app.BuildConfig
import com.ksmobile.app.MyApplication
import com.ksmobile.app.MyApplication.Companion.getinstance
import com.ksmobile.app.activity.reactnative.OpenNativePackage
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.IPushConfig
import com.ksmobile.app.config.ProjectUtils
import com.ksmobile.app.data.ThreeStatisticsObject
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.util.ACache
import com.ksmobile.app.util.CrashDiary
import com.ksmobile.app.util.LogUtils
import org.litepal.LitePal
import java.io.File
import java.util.zip.ZipFile
import com.microsoft.codepush.react.CodePush
import com.networkbench.agent.impl.NBSAppAgent
import com.oblador.vectoricons.VectorIconsPackage
import com.reactnativecommunity.webview.RNCWebViewPackage
import com.ksmobile.app.view.CommonDialog
import com.ksmobile.app.view.hybride.MyWebView


object AppInitManager {

    @JvmStatic
    fun initApp(application: Application) {

        //初始化缓存
        MyApplication.getinstance().mAcach = ACache.get(application)
        //初始化Activity管理类
        MyApplication.getinstance().activityListManager = ActivityListManager()
        MyApplication.getinstance().reactPackage = OpenNativePackage()
        MyApplication.getinstance().mMainRootView = ReactRootView(application)
        MyApplication.getinstance().mReactInstanceManager = ReactInstanceManager.builder()
                .setApplication(application)
                .setBundleAssetName("index.android.bundle")
                .setJSMainModulePath("index")
                .addPackage(MainReactPackage())
                .addPackage(AppInitManager.getReactPackage())
                .addPackage(LinearGradientPackage())
                .addPackage(RNCWebViewPackage())
                .addPackage(ReactVideoPackage())
                .addPackage(VectorIconsPackage())
                .addPackage(OrientationPackage())
                .addPackage(CodePush(BuildConfig.CODEPUSH_KEY, application, BuildConfig.DEBUG))
                .setJSBundleFile(CodePush.getJSBundleFile())
                .setUseDeveloperSupport(BuildConfig.DEBUG)
                .setInitialLifecycleState(LifecycleState.RESUMED)
                .build()
        //数据库初始化
        LitePal.initialize(application)
        //建立数据库
        DataBaseHelper.creatDataBase()
        ApiClient.instance.init()

        //记录崩溃日志
        if (!BuildConfig.DEBUG) {
            CrashDiary.instance.init(application)
            NBSAppAgent.setLicenseKey(BuildConfig.TINGYUN_KEY).setRedirectHost("app.tingyunfenxi.com").withLocationServiceEnabled(true)
                    .start(application)


        }

        CallApi.initialize(application)
        //初始化push系统
        if (null != getAcache().getAsString("customerId")) {
            ConfigUtils.customerId = getAcache().getAsString("customerId")
        }
        PushHelper.start(MyApplication.getinstance(), IPushConfig())
        ConfigUtils.parentId = getIDFromApkComment()
        ThreeStatisticsManager.init(application, ProjectUtils.PID, ConfigUtils.loginName)
        MyApplication.getinstance().threeStatisticsObject = ThreeStatisticsObject()
        MyApplication.getinstance().threeStatisticsObject.time1 = System.currentTimeMillis()

    }

    @JvmStatic
    fun loginOut() {
        AppInitManager.getActivityListManager().killAll()
        AppInitManager.getReactPackage().openNativeModule?.logOut()

    }

    @JvmStatic
    fun loginOutLocal() {
        AppInitManager.getActivityListManager().killAll()
        AppInitManager.getReactPackage().openNativeModule?.logOutLocal()

    }

    val dialog = CommonDialog()
    @JvmStatic
    fun showServiceDialog(activity: FragmentActivity) {

        if (dialog.dialog != null && dialog.dialog!!.isShowing) {
            return
        }
        val bundle = Bundle()
        bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_BLACK_LIST)
        bundle.putBoolean(CommonDialog.CANBACKCANCEL, false)
        dialog.arguments = bundle
        dialog.show(activity.supportFragmentManager, "backlist")

    }

    @JvmStatic
    fun getActivityListManager(): ActivityListManager {

        return MyApplication.getinstance().activityListManager
    }

    @JvmStatic
    fun getAcache(): ACache {

        return MyApplication.getinstance().mAcach
    }

    @JvmStatic
    fun getReactPackage(): OpenNativePackage {
        return MyApplication.getinstance().reactPackage
    }

    @JvmStatic
    fun getMainReactRootView(): ReactRootView {
        return MyApplication.getinstance().mMainRootView
    }


    @JvmStatic
    fun getReactInstanceManager(): ReactInstanceManager {
        return MyApplication.getinstance().mReactInstanceManager
    }

    @JvmStatic
    fun getThreeStatisticsObject(): ThreeStatisticsObject {
        return MyApplication.getinstance().threeStatisticsObject
    }

    @JvmStatic
    fun getWebUUID(): String? {
        return MyApplication.getinstance().webViewUUID
    }

    private fun getIDFromApkComment(): String {

        try {

            val file = File(getinstance().packageCodePath)

            val zipFile = ZipFile(file)

            val comment = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                zipFile.comment
            } else {
                return ConfigUtils.DOMAIN_NAME
            }

            zipFile.close()

            return if (TextUtils.isEmpty(comment)) ConfigUtils.DOMAIN_NAME else comment
        } catch (ignored: Exception) {
        }

        return ConfigUtils.DOMAIN_NAME
    }

    @JvmStatic
    fun createUUID(application: Application) {

        val webView = MyWebView(application)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean {
                try {

                    if (!TextUtils.isEmpty(url) && url.startsWith("http://app/agqj?uuid=")) {
                        val uri = Uri.parse(url)
                        MyApplication.getinstance().webViewUUID = uri.getQueryParameters("uuid")[0]

                        LogUtils.d("uuid------>${MyApplication.getinstance().webViewUUID}")
                    }

                } catch (e: Throwable) {

                }

                return super.shouldOverrideUrlLoading(view, url)
            }

            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                try {
                    var url = request?.url?.toString()

                    if (!TextUtils.isEmpty(url) && url!!.startsWith("http://app/agqj?uuid=")) {
                        val uri = Uri.parse(url)
                        MyApplication.getinstance().webViewUUID = uri.getQueryParameters("uuid")[0]
                        LogUtils.d("uuid------>${MyApplication.getinstance().webViewUUID}")
                    }

                } catch (e: Throwable) {

                }

                return super.shouldOverrideUrlLoading(view, request)
            }

        }

        webView.loadUrl("file:///android_asset/3s.html")
    }


}