package com.ksmobile.app.fragment.recharge

import android.app.ActionBar
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.annotation.UiThread
import android.text.*
import android.view.*
import android.widget.*
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderDetailActivity
import com.ksmobile.app.activity.RechargeActivity
import com.ksmobile.app.adapter.RechargeFastSelectionListAdapter
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.BankInfo
import com.ksmobile.app.data.PointCardObject
import com.ksmobile.app.data.request.PayPromoRequest
import com.ksmobile.app.data.response.*
import com.ksmobile.app.fragment.LazyLoadFragment
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.GlideUtils
import com.ksmobile.app.util.KeyBoardUtils
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.hybride.BrowserActivity
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent

import kotlinx.android.synthetic.main.fragment_recharge_base_view.*
import kotlinx.android.synthetic.main.recharge_window_services.*


import me.everything.android.ui.overscroll.OverScrollDecoratorHelper
import java.math.BigDecimal

/**
 * Created by ward.y on 2018/6/9.
 */
abstract class BaseRechargeFragment : LazyLoadFragment(), TextWatcher {
    private var glView: View? = null
    private var TAG: String? = null
    var datas: QueryPayWaysV3Response? = null
    var payKind: QueryPayWaysV3Response.PayWayObject? = null
    var position: Int = 0
    var BQdatas: QureyPayResponse? = null
    var HandQBData: QueryBanksResponse? = null
    var onlinedatas: OnlineBanksResponse? = null
    var onlineChargeResponse: CreateOnlineResponse? = null
    var pointcardData: QueryPointCardListResponse? = null
    var pointCardPaymentResponse: PointCardPaymentResponse? = null
    var wheelPosition: Int = 0
    var qOBankNameList: MutableList<BankInfo>? = null
    var onlineBanksName = mutableListOf<String>()
    private var endNumber: String? = ""
    var maxAmount: BigDecimal = BigDecimal(1000000)
    var minAmount: BigDecimal = BigDecimal(10)
    var reChargeActivity: RechargeActivity? = null
    var mAdapter: RechargeFastSelectionListAdapter? = null
    var oldSelectedView: CheckedTextView? = null
    var payType = ""
    var curPayTypeOb: QueryPayWaysV3Response.PayType? = null
    val payWay = arrayOf(
            "支付宝",
            "微信",
            "银行卡",
            "其他"
    )


    var baseContext: Context? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if (null == glView) {
            glView = inflater.inflate(R.layout.fragment_recharge_base_view, null)
        }
        reChargeActivity = activity as RechargeActivity
        baseContext = activity?.baseContext
        return glView
    }

    override fun requestData() {
        initData()
        initView()
        initEventListener()
    }

    override fun repeat() {

    }


    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            et_recharge_amount.setEditText("")
            recharge_account_payment_name.setEditText("")
            if (baseContext != null) {
                KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
            }

        } else {
            recharge_account_payment_name.setEditText(reChargeActivity?.name)
            if (mAdapter != null) {
                mAdapter?.notifyDataSetChanged()
            }

            defaultSelectedAmount()
        }
    }

    open fun initData() {
        val bundle = arguments
        if (bundle != null) {
            datas = Gson().fromJson(bundle.getString("datas"), QueryPayWaysV3Response::class.java)
            payKind = Gson().fromJson(bundle.getString("pay"), QueryPayWaysV3Response.PayWayObject::class.java)
        }
        //预留信息的展示
        showPayWay()


    }

    open fun showPayWay() {
//        recharge_account_payment_name.setEditText(reChargeActivity?.name)
        et_recharge_amount.requestFocus()


    }

    private fun initView() {
        et_recharge_amount.getEditText().addTextChangedListener(this)
        OverScrollDecoratorHelper.setUpOverScroll(sv_recharge)
        if (reChargeActivity?.showList!!) {
            showpopupWindow(rl_transfer_account)
            reChargeActivity?.showList = false
        }

    }

    fun hideFastSelections() {
        lv_selections.visibility = View.GONE
    }

    fun setFastSelections(selections: MutableList<String>?) {
        if (selections == null || selections.isEmpty()) {
            return
        }
        lv_selections.visibility = View.VISIBLE
        mAdapter = RechargeFastSelectionListAdapter(baseContext!!, selections)
        mAdapter?.setClickCallBack(object : RechargeFastSelectionListAdapter.ItemClickCallBack {
            override fun onItemClick(pos: Int, textView: CheckedTextView) {
                et_recharge_amount.setEditText(selections[pos])
                et_recharge_amount.getEditText().setSelection(et_recharge_amount.getEditTextContent().length)
                textView.isChecked = true
                if (oldSelectedView != null && oldSelectedView != textView) {
                    oldSelectedView?.isChecked = false
                }
                oldSelectedView = textView
            }

        })

        lv_selections.adapter = mAdapter

        defaultSelectedAmount()


    }


    open fun initEventListener() {
        //点击切换
        rl_transfer_account.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
            showpopupWindow(rl_transfer_account)
        }


        et_recharge_amount.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (TextUtils.isEmpty(et_recharge_amount.getEditTextContent())) {
                    et_recharge_amount.showError("请输入金额")

                }
            }

        }

        recharge_account_payment_name.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (TextUtils.isEmpty(recharge_account_payment_name.getEditTextContent())) {
                    recharge_account_payment_name.showError("请正确填写付款账户名")

                }
            }

        }

//        recharge_account_payment_name.getEditText().addTextChangedListener(textWatcher)


        tv_next.setOnClickListener {
            if (Utils.isFastDoubleClick()) {
                return@setOnClickListener
            }
            et_recharge_amount.hideError()
            recharge_account_payment_name.hideError()
            pay_bank_layout.hideError()
            et_point_card_number.hideError()
            et_point_card_password.hideError()
            et_bit_hand_amount.hideError()
            error_no_selected.visibility = View.GONE
            KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
            if (payType == "100" || payType == "101" || payType == "102") {
                val intent = Intent(activity, BrowserActivity::class.java)
                intent.putExtra(BrowserActivity.PARAM_URL,curPayTypeOb?.liveUrl)
                intent.putExtra(BrowserActivity.PARAM_QK_CHARGE_BAR,true)
                startActivity(intent)
            }else {
                goPay()
            }
        }

    }

    abstract fun goPay()
    override fun onTextChanged(result: CharSequence?, start: Int, before: Int, count: Int) {
        if (TextUtils.isEmpty(result.toString())) {
            return
        }
        var number = BigDecimal(result.toString())
        if (number == BigDecimal(0)) {
            et_recharge_amount.setEditText("")
            return
        }
        if (number <= maxAmount) {
            if (payType == "15" || payType == "16") {
                showPromoMoney(number)
            }


        } else {
            if (endNumber == "" || BigDecimal(endNumber) > maxAmount) {
                et_recharge_amount.setEditText("")
                Toast.makeText(context, "单笔限额${minAmount}元~${maxAmount}元", Toast.LENGTH_SHORT).show()
            } else {
                et_recharge_amount.setEditText(endNumber)
                et_recharge_amount.getEditText().setSelection(endNumber!!.length - 1)
                Toast.makeText(context, "单笔限额${minAmount}元~${maxAmount}元", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun afterTextChanged(p0: Editable?) {
        if (oldSelectedView != null) {
            oldSelectedView?.isChecked = false
            oldSelectedView = null
        }
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        endNumber = p0.toString()
    }

    fun disableSubmit() {
        tv_next.isEnabled = false
    }

    fun enableSubmit() {
        tv_next.isEnabled = true
    }


    private fun showpopupWindow(v: View) {
        val layoutInflater = LayoutInflater.from(activity)
        val view = layoutInflater.inflate(R.layout.popup_window_recharge_payment_view, null)

        val listview: ListView = view.findViewById(R.id.lv_payment_channel)
        val cancel: TextView = view.findViewById(R.id.tv_cancel)
        val tv_promo_tip: TextView = view.findViewById(R.id.tv_promo_tip)
        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        // 如果不设置PopupWindow的背景，无论是点击外部区域还是Back键都无法dismiss弹框
        popupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        popupWindow.isOutsideTouchable = true
        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        popupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        if (datas?.body?.promoTag == 1) {
            tv_promo_tip.visibility = view.visibility
            tv_promo_tip.setOnClickListener {
                val intent = Intent(reChargeActivity, BrowserActivity::class.java)
                intent.putExtra(BrowserActivity.PARAM_URL, "https://billcloud.unionpay.com/upwxs-mktc/web/mapp/wxe990cdbcc189456e/custom/alllist")
                intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
                startActivity(intent)
            }
        }


        listview.adapter = ListViewAdapter(activity!!.baseContext, datas?.body?.payList!!)
        listview.onItemClickListener = AdapterView.OnItemClickListener { p0, p1, position, p3 ->
            //付款方式条目点击
            if (rl_transfer_account.getEditTextContent() == (datas!!.body.payList[position].payKindName)) {
                popupWindow.dismiss()
                return@OnItemClickListener
            }
            reChargeActivity?.name = recharge_account_payment_name.getEditTextContent().trim()
            reChargeActivity?.showPayWay(datas!!.body.payList[position])
            load_error_view.visibility = View.GONE
            popupWindow.dismiss()
        }

        // PopupWindow弹出位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)

        reChargeActivity?.toggleViewBg(true)
        popupWindow.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
        cancel.setOnClickListener { popupWindow.dismiss() }
    }

    fun setLimit(min: Double, max: Double) {
        if (max < 0.0 || min < 0.0) {
            maxAmount = BigDecimal(1000000)
            minAmount = BigDecimal(10)
//            et_recharge_amount.hint = "请输入金额"
        } else {
            maxAmount = BigDecimal(max)
            minAmount = BigDecimal(min)
        }
        if (maxAmount > BigDecimal(10000)) {
            et_recharge_amount.getEditText().hint = "请输入${minAmount}元~${maxAmount.divide(BigDecimal(10000))}万元之间的数值"
        } else {
            et_recharge_amount.getEditText().hint = "请输入${minAmount}元~${maxAmount}元之间的数值"
        }

        enableSubmit()
    }


    private class ListViewAdapter(context: Context, datas: MutableList<QueryPayWaysV3Response.PayWayObject>) : BaseAdapter() {
        var mContext: Context = context
        var datas: MutableList<QueryPayWaysV3Response.PayWayObject> = datas

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var holder: MyViewHolder
            var v: View
            if (convertView == null) {
                holder = MyViewHolder()
                v = LayoutInflater.from(mContext).inflate(R.layout.item_list_payment_channel_view, parent, false)
                holder.iv_icon = v.findViewById(R.id.iv_icon)
                holder.tv_payment_name = v.findViewById(R.id.tv_payment_name)
                holder.tv_payment_channel_des = v.findViewById(R.id.tv_payment_channel_des)
                holder.image_correct = v.findViewById(R.id.image_correct)
                holder.iv_promo = v.findViewById(R.id.iv_promo)
                holder.line = v.findViewById(R.id.line)
                v.tag = holder

            } else {
                v = convertView
                holder = v.tag as MyViewHolder
            }

            GlideUtils.load(mContext, datas[position].payKindIcon).into(holder.iv_icon)
            holder.tv_payment_name.text = (datas[position].payKindName)

            if (datas[position].promoTag == 1) {
                holder.iv_promo.visibility = View.VISIBLE
            } else {
                holder.iv_promo.visibility = View.GONE
            }

            holder.image_correct.visibility = View.INVISIBLE
            return v
        }

        override fun getItem(p0: Int): Any {
            return datas[p0]
        }

        override fun getItemId(p0: Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return datas.size
        }

        class MyViewHolder {
            lateinit var iv_icon: ImageView
            lateinit var tv_payment_name: TextView
            lateinit var tv_payment_channel_des: TextView
            lateinit var line: TextView
            lateinit var image_correct: ImageView
            lateinit var iv_promo: ImageView
        }
    }


    inner class BankListAdapter(bankInfos: MutableList<BankInfo>?) : BaseAdapter() {
        private val mBankInfos = bankInfos
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var holder: MyViewHolder
            var v: View
            if (convertView == null) {
                holder = MyViewHolder()
                v = LayoutInflater.from(baseContext).inflate(R.layout.item_bank_list_view, parent, false)
                holder.iv_icon = v.findViewById(R.id.iv_icon)
                holder.tv_bank_name = v.findViewById(R.id.tv_bank_name)
                holder.image_selected = v.findViewById(R.id.image_selected)
                v.tag = holder

            } else {
                v = convertView
                holder = v.tag as MyViewHolder
            }
            GlideUtils.load(baseContext!!, mBankInfos!![position].bankIcon).into(holder.iv_icon)
            holder.tv_bank_name.text = mBankInfos[position].bankName
            if (position == wheelPosition) {
                holder.image_selected.visibility = View.VISIBLE
            } else {
                holder.image_selected.visibility = View.GONE
            }


            return v
        }

        override fun getItem(p0: Int): Any {
            return mBankInfos!![p0]
        }

        override fun getItemId(p0: Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return mBankInfos!!.size
        }

        inner class MyViewHolder {
            lateinit var iv_icon: ImageView
            lateinit var tv_bank_name: TextView
            lateinit var image_selected: ImageView
        }
    }


    inner class PointCardListAdapter(bankInfos: MutableList<PointCardObject>?) : BaseAdapter() {
        private val mBankInfos = bankInfos
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var holder: MyViewHolder
            var v: View
            if (convertView == null) {
                holder = MyViewHolder()
                v = LayoutInflater.from(baseContext).inflate(R.layout.item_bank_list_view, parent, false)
                holder.iv_icon = v.findViewById(R.id.iv_icon)
                holder.tv_bank_name = v.findViewById(R.id.tv_bank_name)
                holder.image_selected = v.findViewById(R.id.image_selected)
                v.tag = holder

            } else {
                v = convertView
                holder = v.tag as MyViewHolder
            }

            holder.iv_icon.visibility = View.GONE
            holder.tv_bank_name.text = mBankInfos!![position].name
            if (position == wheelPosition) {
                holder.image_selected.visibility = View.VISIBLE
            } else {
                holder.image_selected.visibility = View.GONE
            }


            return v
        }

        override fun getItem(p0: Int): Any {
            return mBankInfos!![p0]
        }

        override fun getItemId(p0: Int): Long {
            return p0.toLong()
        }

        override fun getCount(): Int {
            return mBankInfos!!.size
        }

        inner class MyViewHolder {
            lateinit var iv_icon: ImageView
            lateinit var tv_bank_name: TextView
            lateinit var image_selected: ImageView
        }
    }


    var mPopupWindow: PopupWindow? = null

    private fun showConfirmDialog(isCardPoint: Boolean) {
        if (mPopupWindow == null) {
            val layoutInflater = LayoutInflater.from(baseContext)
            val view = layoutInflater.inflate(R.layout.view_recharge_confirm, null)
            mPopupWindow = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT, true)
            mPopupWindow?.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
            mPopupWindow?.isOutsideTouchable = true
            mPopupWindow?.animationStyle = R.style.MyPopupWindow_anim_style
            mPopupWindow?.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            val close: ImageView = view.findViewById(R.id.image_close)
            val cancle: TextView = view.findViewById(R.id.tv_cancle)
            val sure: TextView = view.findViewById(R.id.tv_sure)


            close.setOnClickListener {
                pointCardPaymentResponse = null
                onlineChargeResponse = null
                mPopupWindow?.dismiss()

            }
            cancle.setOnClickListener {
                pointCardPaymentResponse = null
                onlineChargeResponse = null
                Utils.goOnlineCustomerService()
                mPopupWindow?.dismiss()
            }
            sure.setOnClickListener {
                val intent = Intent(reChargeActivity, OrderDetailActivity::class.java)
                if (isCardPoint) {
                    intent.putExtra("referenceId", pointCardPaymentResponse?.body?.billNo)
                } else {
                    intent.putExtra("referenceId", onlineChargeResponse?.body?.billNo)
                }

                intent.putExtra("type", 1)
                intent.putExtra("showButton", true)
                startActivity(intent)
                pointCardPaymentResponse = null
                onlineChargeResponse = null
                mPopupWindow?.dismiss()
            }
        }


        mPopupWindow?.showAtLocation(rl_transfer_account, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow?.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }

    override fun onResume() {
        super.onResume()
        if (onlineChargeResponse != null) {
            showConfirmDialog(false)
        }

        if (pointCardPaymentResponse != null) {
            showConfirmDialog(true)
        }
    }


    /**
     * 展示客服弹窗
     */

    fun showServicesPopupWindow() {

        load_error_view.visibility = View.VISIBLE

        tv_sure.setOnClickListener {
            showpopupWindow(rl_transfer_account)

        }


    }


    private val textWatcher = object : TextWatcher {
        var beforeText = ""

        override fun afterTextChanged(s: Editable?) {
            val temp = s.toString()
            if (!TextUtils.isEmpty(temp)) {

                if (!Utils.checkStringFullChinese(temp)) {
                    if (!TextUtils.isEmpty(beforeText) && Utils.checkPoint(temp[temp.lastIndex].toString())) {
                        if (!beforeText.endsWith("·")) {
                            beforeText = "$beforeText·"
                        }

                    }
                    recharge_account_payment_name.setEditText(beforeText)
                    recharge_account_payment_name.getEditText().setSelection(recharge_account_payment_name.getEditTextContent().length)
                } else {

                    if (beforeText.endsWith("·") && s.toString().endsWith("·") && (beforeText.length + 1 == s.toString().length)) {
                        recharge_account_payment_name.setEditText(beforeText)
                        recharge_account_payment_name.getEditText().setSelection(recharge_account_payment_name.getEditTextContent().length)
                    }


                }
            }

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            beforeText = s.toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {


        }


    }

    var restPromoAmount = BigDecimal(1888)

    fun queryPromo() {

        val request = PayPromoRequest()
//        if (ConfigUtils.testUrl.contains(ConfigUtils.DOMAIN_NAME)) {
//            request.referenceId = "10000018786"
//        }
        ApiClient.instance.service.queryPayPromo(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<PayPromoResponse>(activity!!, false) {
                    override fun businessFail(data: PayPromoResponse) {
                        ToastUtils.show(data.head.errMsg)
                    }

                    override fun businessSuccess(data: PayPromoResponse) {

                        data.body?.data?.forEach {
                            restPromoAmount -= it.amount

                        }

                        if (restPromoAmount > BigDecimal(0)) {

                        } else {
                            tv_promo_money.visibility = View.GONE
                            tv_arrival_money.visibility = View.GONE
                            tv_no_promo.visibility = View.VISIBLE
                        }


                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        ToastUtils.show(apiErrorModel.message)
                    }

                })

    }


    private fun showPromoMoney(amount: BigDecimal) {

        when {
            amount < BigDecimal(99) -> {
                tv_promo_money.text = String.format(getString(R.string.promo_money), "0")
                tv_arrival_money.text = String.format(getString(R.string.arrival_money), "0")
                ll_show_money_promo.visibility = View.GONE
            }
            else -> {

                Handler().post {
                    ll_show_money_promo.visibility = View.VISIBLE
                    if (restPromoAmount > BigDecimal(0)) {
                        val extraMoney = amount.divide(BigDecimal(100)).multiply(BigDecimal(0.5)).setScale(2,BigDecimal.ROUND_HALF_UP)
                        when {
                            extraMoney < restPromoAmount -> {
                                tv_promo_money.text = String.format(getString(R.string.promo_money), extraMoney)
                                tv_arrival_money.text = String.format(getString(R.string.arrival_money), amount.add(extraMoney))
                            }

                            else -> {
                                tv_promo_money.text = String.format(getString(R.string.promo_money), restPromoAmount)
                                tv_arrival_money.text = String.format(getString(R.string.arrival_money), amount.add(restPromoAmount))
                            }
                        }


                    }
                }


            }
        }

    }


    private fun defaultSelectedAmount() {
        Handler().postDelayed({
            if (payType == "15" || payType == "16") {
                mAdapter?.selectBigger99()
            }
        }, 100)
    }

}