package com.ksmobile.app.activity

import android.app.Activity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.view.animation.AnimationUtils
import com.aigestudio.wheelpicker.utils.LocalJsonResolutionUtils
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent

import com.ksmobile.app.R
import com.ksmobile.app.adapter.SelectorViewAdapter
import com.ksmobile.app.data.*
import com.ksmobile.app.data.request.QueryAreaLimitRequest
import com.ksmobile.app.data.request.QueryBanksRequest
import com.ksmobile.app.data.response.QueryBankListResponse
import com.ksmobile.app.data.response.QueryCitiesResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import kotlinx.android.synthetic.main.activity_custom_selector.*

class CustomSelectorActivity : BaseToolBarActivity() {
    var type = 0
    var datas: List<SelectorItem>? = null
    var hasParent = false
    var parentString = ""

    companion object {
        const val SELECTOR_TYPE = "selector_type"
        const val DATA = "data"
        const val TITLE = "title"
        const val CITY = 1  //城市选择列表
        const val BANKCARD = 2  //银行卡列表
        const val BANKCARDTYPE = 3  //银行卡列表
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_custom_selector
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = intent.getIntExtra(SELECTOR_TYPE, 0)
        val title: String

        when (type) {
            CITY -> {
                title = "省份与城市"
                datas = getJsonDataFromAssets()
                defaultShow()
            }
            BANKCARD -> {
                title = "选择银行"
//                datas = getBankCards()
                queryBanks()

            }
            BANKCARDTYPE -> {
                title = "银行卡类型"
                datas = getBankCardType()
                defaultShow()


            }
            else -> {
                title = "省份与城市"
                datas = getJsonDataFromAssets()
                defaultShow()
            }
        }

        setTile(title)

    }

    override fun initView() {

    }

    override fun initListener() {
        setBackListener(View.OnClickListener {
            if (hasParent) {
                showParent()
            } else {
                finish()
            }

        })
    }


    private fun defaultShow() {
        val layoutManager = LinearLayoutManager(baseContext)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        rv_selector_first.layoutManager = layoutManager
        rv_selector_first.setLoadingMoreEnabled(false)
        rv_selector_first.setPullRefreshEnabled(false)
        val adapter = SelectorViewAdapter(baseContext, datas!!)
        adapter.setClickCallBack(object : SelectorViewAdapter.ItemClickCallBack {
            override fun onItemClick(pos: Int) {
                if (datas!![pos].hasChild()) {

                    parentString = datas!![pos].getTitle()
                    showChildView(datas!![pos].getChildItems()!!)
                } else {
                    resultBack(datas!![pos])
                }


            }

        })
        rv_selector_first.adapter = adapter
    }


    private fun getJsonDataFromAssets(): List<ProvinceData>? {
        var provinceList: List<ProvinceData>?
        val fileName = "city.json"
        val provinceJson = LocalJsonResolutionUtils.getJson(baseContext, fileName)
        provinceList = LocalJsonResolutionUtils.JsonToObject(provinceJson, ProviceDatas::class.java).provinces
        return provinceList
    }


    private fun getBankCards(): List<BankCardData>? {
        val list = arrayListOf("工商银行", "农业银行", "建设银行", "交通银行", "民生银行", "光大银行", "兴业银行", "浦东发展银行", "广东发展银行", "深圳发展银行",
                "平安银行", "邮政银行", "华夏银行", "农村信用社", "中信银行", "招商银行", "中国银行")

        val banks = mutableListOf<BankCardData>()

        list.forEach {
            banks.add(BankCardData(it, "",""))
        }
        return banks

    }


    private fun getBankCardType(): List<BankCardTypeData>? {

        return listOf(BankCardTypeData("储蓄卡"), BankCardTypeData("信用卡"))

    }

    private fun showChildView(datas: List<SelectorItem>) {
        hasParent = true
        val layoutManager = LinearLayoutManager(baseContext)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        rv_selector_second.layoutManager = layoutManager
        rv_selector_second.setLoadingMoreEnabled(false)
        rv_selector_second.setPullRefreshEnabled(false)
        val adapter = SelectorViewAdapter(baseContext, datas)
        adapter.setClickCallBack(object : SelectorViewAdapter.ItemClickCallBack {
            override fun onItemClick(pos: Int) {
                resultBack(datas[pos])

            }

        })
        rv_selector_second.adapter = adapter
        val animation = AnimationUtils.loadAnimation(baseContext, R.anim.right_slide_in)
        rv_selector_second.startAnimation(animation)
        rv_selector_second.visibility = View.VISIBLE

        val animation2 = AnimationUtils.loadAnimation(baseContext, R.anim.left_slide_out)
        rv_selector_first.startAnimation(animation2)
        rv_selector_first.visibility = View.GONE

    }

    private fun showParent() {
        val animation = AnimationUtils.loadAnimation(baseContext, R.anim.right_slide_out)
        rv_selector_second.startAnimation(animation)
        rv_selector_second.visibility = View.GONE

        val animation2 = AnimationUtils.loadAnimation(baseContext, R.anim.left_slide_in)
        rv_selector_first.startAnimation(animation2)
        rv_selector_first.visibility = View.VISIBLE
        hasParent = false
    }


    private fun resultBack(data: SelectorItem) {
        if (hasParent) {
            if (parentString==data.getTitle()){
                intent.putExtra("value", "$parentString")
            }else{
                intent.putExtra("value", "$parentString  ${data.getTitle()}")
            }

        } else {
            intent.putExtra("value", data.getTitle())
        }

        intent.putExtra("img", data.getImageLeft())
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun queryCities() {

        val request = QueryAreaLimitRequest()
        ApiClient.instance.service.queryCities(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryCitiesResponse>(this, true) {
                    override fun businessFail(data: QueryCitiesResponse) {

                        defaultShow()
                    }

                    override fun businessSuccess(data: QueryCitiesResponse) {
                        datas = data.body
                        defaultShow()

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        datas = getJsonDataFromAssets()
                        defaultShow()
                    }

                })

    }

    private fun queryBanks() {

        val request = QueryBanksRequest()
        ApiClient.instance.service.queryBanks(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryBankListResponse>(this, true) {
                    override fun businessFail(data: QueryBankListResponse) {
                        datas = getBankCards()
                        defaultShow()
                    }

                    override fun businessSuccess(data: QueryBankListResponse) {
                        datas = data.body
                        defaultShow()

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        datas = getBankCards()
                        defaultShow()
                    }

                })

    }

}