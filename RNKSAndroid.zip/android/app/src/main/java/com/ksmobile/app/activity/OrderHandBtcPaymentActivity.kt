package com.ksmobile.app.activity

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.ksmobile.app.R
import com.ksmobile.app.fragment.payment.*
import com.ksmobile.app.util.Utils
import kotlinx.android.synthetic.main.activity_order_payment.*
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper

class OrderHandBtcPaymentActivity : BaseToolBarActivity() {
    private var handBtcPaymentFragment: HandBtcPaymentFragment? = null
    override fun getLayoutId(): Int {
        return R.layout.activity_order_payment
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.order_payment_title))
        setActionIcon(R.mipmap.icon_customer_service)
        setActionText("客服")
        OverScrollDecoratorHelper.setUpOverScroll(sv_order_payment)


    }

    override fun initView() {
        val dataString = intent.getStringExtra("data")
        if (!TextUtils.isEmpty(dataString)) {
            showFragment(dataString)
        } else {
            finish()
        }


    }


    override fun initListener() {
        setBackListener(View.OnClickListener {
            top_notify.show()
            top_notify.setTipTitle("确定返回上一步？")
            top_notify.setTipContent("如果尚未完成支付，当前充值订单将失效。\n" +
                    "已完成的支付，可在交易记录中查询状态。")

        })

        top_notify.setCancelListener(View.OnClickListener {
            top_notify.hidden()
        })

        top_notify.setSureListener(View.OnClickListener {
            finish()
        })
        getActionView()?.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
    }

    private fun showFragment(datas: String) {
        val fragmentTransaction = supportFragmentManager.beginTransaction()
        val bundle = Bundle()
        bundle.putString("datas", datas)
        handBtcPaymentFragment = HandBtcPaymentFragment()
        handBtcPaymentFragment?.arguments = bundle
        fragmentTransaction.replace(R.id.fl_container, handBtcPaymentFragment).commitAllowingStateLoss()


    }


    override fun onBackPressed() {
        if (top_notify.isShown) {
            top_notify.hidden()

        } else {
            top_notify.show()
            top_notify.setTipTitle("确定返回上一步？")
            top_notify.setTipContent("如果尚未完成支付，当前充值订单将失效。\n" +
                    "已完成的支付，可在交易记录中查询状态。")


        }
    }


}