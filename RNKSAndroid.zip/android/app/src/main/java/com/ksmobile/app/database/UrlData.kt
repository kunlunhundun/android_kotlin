package com.ksmobile.app.database

import org.litepal.crud.DataSupport

/**
 * Created by ward.y on 2018/4/2.
 */

class UrlData : DataSupport() {
    var url:String? = null
    var frontUrl:String? = null
    var addUrl:String? = null
    var domain:String? = null
    val urlId = "1"


}