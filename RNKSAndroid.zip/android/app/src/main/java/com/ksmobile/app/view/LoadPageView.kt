package com.ksmobile.app.view

import android.content.Context
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.widget.LinearLayout
import com.ksmobile.app.R
import com.ksmobile.app.util.MyYAnimation
import kotlinx.android.synthetic.main.loading_page.view.*
import kotlin.random.Random


/**
 * Created by ward.y on 2018/4/28.
 */
class LoadPageView(context: Context?, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {
    private var nowProgress = 0


    init {
        LayoutInflater.from(context).inflate(R.layout.loading_page, this, true)
        this.visibility = View.GONE
        val spadeAnimation = MyYAnimation()
        val heartAnimation = MyYAnimation()
        val clubAnimation = MyYAnimation()
        val diamondAnimation = MyYAnimation()
        spadeAnimation.repeatCount = 0
        heartAnimation.repeatCount = 0
        clubAnimation.repeatCount = 0
        diamondAnimation.repeatCount = 0
        spadeAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {

            }

            override fun onAnimationEnd(animation: Animation?) {
                iv_spade?.visibility = View.INVISIBLE
                iv_spade_shadow?.visibility = View.VISIBLE
                iv_heart?.startAnimation(heartAnimation)

            }

            override fun onAnimationStart(animation: Animation?) {
                iv_spade?.visibility = View.VISIBLE
                iv_spade_shadow?.visibility = View.INVISIBLE
                tv_progress?.text = getRandom()
            }


        })


        heartAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {
            }

            override fun onAnimationEnd(animation: Animation?) {
                iv_heart?.visibility = View.INVISIBLE
                iv_heart_shadow?.visibility = View.VISIBLE
                iv_club?.startAnimation(clubAnimation)

            }

            override fun onAnimationStart(animation: Animation?) {
                iv_heart?.visibility = View.VISIBLE
                iv_heart_shadow?.visibility = View.INVISIBLE
                tv_progress?.text = getRandom()
            }

        })


        clubAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {
            }

            override fun onAnimationEnd(animation: Animation?) {
                iv_club?.visibility = View.INVISIBLE
                iv_club_shadow?.visibility = View.VISIBLE
                iv_diamond?.startAnimation(diamondAnimation)
            }

            override fun onAnimationStart(animation: Animation?) {
                iv_club?.visibility = View.VISIBLE
                iv_club_shadow?.visibility = View.INVISIBLE
                tv_progress?.text = getRandom()
            }

        })


        diamondAnimation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {
            }

            override fun onAnimationEnd(animation: Animation?) {
                iv_diamond?.visibility = View.INVISIBLE
                iv_diamond_shadow?.visibility = View.VISIBLE
                iv_spade?.startAnimation(spadeAnimation)
            }

            override fun onAnimationStart(animation: Animation?) {
                iv_diamond?.visibility = View.VISIBLE
                iv_diamond_shadow?.visibility = View.INVISIBLE
                tv_progress?.text = getRandom()
            }

        })
        iv_spade?.startAnimation(spadeAnimation)
    }


    fun show(des: String?) {
        if (this.visibility == View.VISIBLE) {
            return
        }
        this.visibility = View.VISIBLE
        nowProgress = 0
        if (!TextUtils.isEmpty(des)) {
            tv_des?.text = des
        }


    }


    private fun getRandom(): String {
        nowProgress += Random.nextInt(10)
        if (nowProgress > 99) {
            nowProgress = 99
        }
        return "$nowProgress%"
    }

    fun hidden() {
        this.visibility = View.GONE

    }

}