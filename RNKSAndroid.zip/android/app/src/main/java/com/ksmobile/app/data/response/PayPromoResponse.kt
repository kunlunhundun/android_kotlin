package com.ksmobile.app.data.response

import java.math.BigDecimal


/**
 * Created by ward.y on 2018/3/19.
 */
class PayPromoResponse : BaseResponseObject() {

    var body: Body? = null

    class Body{
        var data = mutableListOf<PromoItem>()
        var pageNo:Int?=1
        var pageSize = 0
        var totalPage = 0
        var totalRow = 0
    }


    data class PromoItem(var amount:BigDecimal,var betAmount:String,var createDate:String,var deleteFlag:Boolean,var flag:Int,

                         var flagDesc:String,
                         var itemIcon:String,
                         var remark:String,
                         var requestId:String,
                         var title:String,
                         var updateDate:String
                         )

}
