package com.ksmobile.app.util

interface CommonCallback{

    fun onCalled()
}