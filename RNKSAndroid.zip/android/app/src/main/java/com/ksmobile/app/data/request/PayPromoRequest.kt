package com.ksmobile.app.data.request



class PayPromoRequest : BaseRequestObject() {
    var referenceId: String? =  "1000002002"
    var pageNo  = 1
    var pageSize = 1000
    var lastDays = "0"


}