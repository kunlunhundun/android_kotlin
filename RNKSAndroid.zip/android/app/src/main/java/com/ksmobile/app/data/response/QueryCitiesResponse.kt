package com.ksmobile.app.data.response

import com.ksmobile.app.data.ProvinceData

/**
 * Created by ward.y on 2018/3/19.
 */
class QueryCitiesResponse : BaseResponseObject() {

    var body = mutableListOf<ProvinceData>()


}

