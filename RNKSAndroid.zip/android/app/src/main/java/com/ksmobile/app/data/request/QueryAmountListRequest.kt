package com.ksmobile.app.data.request



class QueryAmountListRequest : BaseRequestObject() {

    var payType: String? = null
}