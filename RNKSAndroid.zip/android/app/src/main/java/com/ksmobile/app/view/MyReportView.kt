package com.ksmobile.app.view

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderDetailActivity
import com.ksmobile.app.data.OrderObject
import com.ksmobile.app.util.Utils
import kotlinx.android.synthetic.main.item_report_view.view.*
import java.math.BigDecimal

class MyReportView(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {

    init {
        LayoutInflater.from(context).inflate(R.layout.item_report_view, this, true)
        val a = context.obtainStyledAttributes(attrs, R.styleable.reportView)
        val icon = a.getDrawable(R.styleable.reportView_icon)
        val type = a.getString(R.styleable.reportView_type)

        if (null != icon) {
            iv_type_icon.setImageDrawable(icon)
        }

        if (null != type) {
            tv_type.text = type
        }

        a.recycle()

    }

    fun setData(data: OrderObject?) {
        if (data != null) {
            tv_no_record.visibility = View.GONE
            setAmount(data.amount.toString())
            setDate(data.createDate)
            setType(data.title)
            setFlagDes(data.flagDesc)
            when (data.flag) {
                0, 9, 1, 97-> {
                    tv_state.setTextColor(Color.parseColor("#E9664B"))

                }

                2 -> {
                    tv_state.setTextColor(Color.parseColor("#50E3C2"))
                }
                else -> {
                    tv_state.setTextColor(Color.parseColor("#999999"))

                }

            }
        }

        this.setOnClickListener {
            val intent = Intent(context, OrderDetailActivity::class.java)
            intent.putExtra("referenceId", data?.requestId)
            intent.putExtra("type", data?.type)
            context.startActivity(intent)


        }
    }


    fun setDate(date: String) {
        var day =  date.split(" ")[0]
        var hour =  date.split(" ")[1]

        tv_deposit_date.text =day.substring(day.indexOf("-")+1)
        tv_deposit_hour.text = hour.substring(0,hour.lastIndexOf(":"))
    }

    @SuppressLint("SetTextI18n")
    fun setAmount(amount: String) {
        tv_amount.text = "${Utils.formatMoney(BigDecimal(amount),false)}元"
    }

    fun setType(type: String) {
        tv_deposit_type.text = type
    }

    fun setFlagDes(flag: String) {

        tv_state.text = flag
    }
}