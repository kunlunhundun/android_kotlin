package com.ksmobile.app.data

data class WheelTextObjet (val text:String)