package com.ksmobile.app.data.request

class QueryCountUnreadRequest : BaseRequestObject(){
    val onlyCount = 1
    val flag = 0
}