package com.ksmobile.app.view

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Handler
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import com.ksmobile.app.R
import java.lang.ref.WeakReference

object NotifyDialog {
    private var dialog: Dialog? = null
    private var hiddenCallback: HiddenCallback? = null
    lateinit var notify: MyTopNotifyView
    var mActivity: WeakReference<Activity>? = null
    fun show(activity: Activity?, message: String) {
        if (activity == null) {
            return
        }
        cancel()
        mActivity = WeakReference(activity)
        if (mActivity == null) {
            return
        }
        dialog = Dialog(mActivity?.get(), R.style.LoadingDialog)
        dialog?.setContentView(R.layout.dialog_notify)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setTranslucentStatus(dialog?.window)
        dialog?.setCancelable(true)
        dialog?.setCanceledOnTouchOutside(false)
        if (!activity.isDestroyed&&!activity.isFinishing){
            dialog?.show()
        }

        notify = dialog?.findViewById(R.id.notify)!!
        notify.setTip(message)
        notify.setIcon(R.mipmap.icon_error_tip)
        notify.show()
        notify.setOnHiddenCallBack(object : MyTopNotifyView.IHinddenCallback {
            override fun onHidden() {

                Handler().postDelayed({
                    hiddenCallback?.onHidden()
                    cancel()
                }, 200)

            }

        })


    }




    fun cancel() {
        if (dialog != null && dialog?.isShowing!!) {
            dialog?.dismiss()
        }

        dialog = null
        hiddenCallback = null
    }


    fun setOnHiddenCallback(callback: HiddenCallback) {
        hiddenCallback = callback
    }


    fun setIcon(id: Int) {
        notify.setIcon(id)
    }

    interface HiddenCallback {
        fun onHidden()
    }


    private fun setTranslucentStatus(window: Window?) {
        if (null == window) {
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }

    }

}
