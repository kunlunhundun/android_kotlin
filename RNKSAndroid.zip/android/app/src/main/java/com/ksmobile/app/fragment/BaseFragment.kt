package com.ksmobile.app.fragment

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.trello.rxlifecycle2.components.support.RxFragment

abstract class BaseFragment :RxFragment() {

    abstract fun getContentViewId(): Int
    protected var mRootView: View? = null
    private val isAddActivityList = "isAddActivityList"
    override fun getContext(): Context {
        checkActivityAttached()
        return activity!!.baseContext
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        mRootView = inflater.inflate(getContentViewId(), container, false)
        return mRootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        initView()
        initData()
        initListener()

    }

    abstract fun initView()

    abstract fun initListener()

    abstract fun initData()

    /**
     * 跳转页面方法，方便加入Activity管理
     * @param isAdd false 为不加入管理
     */

    fun goToPage(intent: Intent, isAdd: Boolean) {
        checkActivityAttached()
        intent.putExtra(isAddActivityList, isAdd)
        startActivity(intent)

    }

    /**
     * 跳转页面方法，方便加入Activity管理
     */

    fun goToPage(intent: Intent) {

        goToPage(intent, true)

    }

    fun goToPageForResult(intent: Intent, isAdd: Boolean, requstCode: Int) {
        intent.putExtra(isAddActivityList, isAdd)
        startActivityForResult(intent, requstCode)
    }

    /**
     * 检查activity连接情况
     */
    fun checkActivityAttached() {
        if (activity == null) {
            throw ActivityNotAttachedException()
        }
    }

    protected fun isAttachedContext(): Boolean {
        return activity != null
    }

    class ActivityNotAttachedException : RuntimeException("Fragment has disconnected from Activity ! - -.")
}