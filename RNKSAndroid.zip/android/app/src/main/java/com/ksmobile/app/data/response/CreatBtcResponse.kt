package com.ksmobile.app.data.response

class CreatBtcResponse : BaseResponseObject() {

    var body:Body?=null

    data class Body(
           var realName:String = ""
    )


}
