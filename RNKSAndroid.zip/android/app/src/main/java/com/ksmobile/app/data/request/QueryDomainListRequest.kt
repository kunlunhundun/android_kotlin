package com.ksmobile.app.data.request


class QueryDomainListRequest : BaseRequestObject()
