package com.ksmobile.app.data.response


/**
 * Created by ward.y on 2018/3/26.
 */
open class BaseResponseObject {
    var success: Boolean = false
    val head = Head()

    data class Head(var errCode: String = "",
                    var errMsg: String = "")


}