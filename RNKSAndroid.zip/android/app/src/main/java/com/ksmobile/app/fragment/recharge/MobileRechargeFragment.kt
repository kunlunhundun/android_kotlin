package com.ksmobile.app.fragment.recharge

import android.annotation.SuppressLint
import android.app.ActionBar
import android.content.Intent
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.*
import com.google.gson.Gson
import com.trello.rxlifecycle2.android.FragmentEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.activity.OrderPaymentActivity
import com.ksmobile.app.adapter.RechargeTypeAdapter
import com.ksmobile.app.data.*
import com.ksmobile.app.data.request.BaseMsgRequest
import com.ksmobile.app.data.request.QueryAmountListRequest
import com.ksmobile.app.data.request.QueryPayRequest
import com.ksmobile.app.data.response.QueryAmountListResponse
import com.ksmobile.app.data.response.QueryBanksResponse
import com.ksmobile.app.data.response.QueryPayWaysV3Response
import com.ksmobile.app.data.response.QureyPayResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.GlideUtils
import com.ksmobile.app.util.KeyBoardUtils
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.CustomHorizeView
import com.ksmobile.app.view.NotifyDialog
import com.ksmobile.app.view.hybride.BrowserActivity
import kotlinx.android.synthetic.main.fragment_recharge_base_view.*


abstract class MobileRechargeFragment : BaseOnlineRechargeFragment() {

    private val normalBQ = 90
    private val alipayBQ = 92
    private val wechatBQ = 91
    private val bankList = mutableListOf<BankInfo>()
    var depositorId = ""

    override fun showPayWay() {
        super.showPayWay()
        rl_pay_type.setOnClickListener {
            showPayWayPopWindow()
        }

        recharge_account_payment_name.getEditText().addTextChangedListener(textWatcher)
    }

    /**
     * BQ存款查询限额
     */

    fun queryPayLimit(payType: String) {
        var request = QueryAmountListRequest()
        request.payType = payType
        ApiClient.instance.service.queryAmountList(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryAmountListResponse>(reChargeActivity!!, true) {
                    override fun businessFail(data: QueryAmountListResponse) {
                        if (data.head.errCode == "GW_801102") {
                           NotifyDialog.show(activity!!, "支付渠道暂不可用，请更换支付渠道或者重试")
                        } else {
                           NotifyDialog.show(reChargeActivity!!, data.head.errMsg)
                        }

                    }

                    override fun businessSuccess(data: QueryAmountListResponse) {
                        //手工存款前端设置限额
                        if (payType == "0") {
                            setLimit(100.0, 1000000.0)
                        } else {
                            setLimit(data.body?.minAmount!!, data.body?.maxAmount!!)
                        }
                        val amountType = AmountType(data.body?.fix!!, data.body?.amounts!!)
                        showFastSelectAmount(amountType)
                        //显示最近存款人
                        if (data.body?.depositorList != null && !data.body?.depositorList!!.isEmpty()) {
                            ll_deposit_name.visibility = View.VISIBLE
                            deposit_name_1.visibility = View.VISIBLE
                            deposit_name_1.text = data.body?.depositorList!![0].depositor
                            deposit_name_1.setOnClickListener {
                                recharge_account_payment_name.getEditText().removeTextChangedListener(textWatcher)
                                deposit_name_2.isChecked = false

                                deposit_name_1.isChecked = !deposit_name_1.isChecked
                                depositorId = if (deposit_name_1.isChecked) {
                                    recharge_account_payment_name.setEditText(deposit_name_1.text.toString())
                                    data.body?.depositorList!![0].id
                                } else {
                                    recharge_account_payment_name.setEditText("")
                                    ""
                                }

                                recharge_account_payment_name.getEditText().addTextChangedListener(textWatcher)
                            }

                            if (data.body?.depositorList!!.size > 1) {
                                deposit_name_2.visibility = View.VISIBLE
                                deposit_name_2.text = data.body?.depositorList!![1].depositor
                                deposit_name_2.setOnClickListener {
                                    recharge_account_payment_name.getEditText().removeTextChangedListener(textWatcher)
                                    deposit_name_1.isChecked = false

                                    deposit_name_2.isChecked = !deposit_name_2.isChecked
                                    depositorId = if (deposit_name_2.isChecked) {
                                        recharge_account_payment_name.setEditText(deposit_name_2.text.toString())
                                        data.body?.depositorList!![1].id
                                    } else {
                                        recharge_account_payment_name.setEditText("")
                                        ""
                                    }

                                    recharge_account_payment_name.getEditText().addTextChangedListener(textWatcher)
                                }
                            }

                        }

                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })
    }

    /**
     * 查询BQ银行列表
     */
    fun requestBQBank(payType: String) {
        var request = QueryPayRequest()
        if (TextUtils.isEmpty(depositorId)) {
            request.depositor = recharge_account_payment_name.getEditTextContent().trim()
        } else {
            request.depositor = depositorId
            request.depositorType =1
        }

        request.payType = payType
        ApiClient.instance.service.quireBank(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<QureyPayResponse>(reChargeActivity!!, true) {
                    override fun businessFail(data: QureyPayResponse) {
                        KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                        showServicesPopupWindow()
                    }

                    override fun businessSuccess(data: QureyPayResponse) {
                        wheelPosition = 0
                        onlineBanksName.clear()
                        BQdatas = data
                        if (data.body?.bankList?.size!! > 0) {
                            var list = data.body?.bankList
                            list?.forEach {
                                onlineBanksName.add(it.bankName)
                            }
                            showFastSelectAmount(data.body?.amountType)
                            pay_bank_layout.setEditText(onlineBanksName[wheelPosition])
                            showPopWindow()

                        } else {
                            KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                            showServicesPopupWindow()
                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                        showServicesPopupWindow()
                    }

                })
    }


    abstract fun showPopWindow()

    /**
     * 查询手工存款银行列表
     */

    fun requestHandDeposit() {
        val request = BaseMsgRequest()
        if (TextUtils.isEmpty(depositorId)) {
            request.depositor = recharge_account_payment_name.getEditTextContent().trim()

        } else {
            request.depositor = depositorId
            request.depositorType =1
        }
        ApiClient.instance.service.queryRequestBanks(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, FragmentEvent.DESTROY)
                .subscribe(object : ApiResponse<QueryBanksResponse>(reChargeActivity!!, true) {
                    override fun businessFail(data: QueryBanksResponse) {
                        KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                        showServicesPopupWindow()
                    }

                    override fun businessSuccess(data: QueryBanksResponse) {

                        wheelPosition = 0
                        onlineBanksName.clear()
                        HandQBData = data
                        if (data.body?.bankCards?.size!! > 0) {
                            var list = data.body?.bankCards
                            list?.forEach {
                                onlineBanksName.add(it.bankName)
                            }
                            pay_bank_layout.setEditText(onlineBanksName[wheelPosition])
                            showFastSelectAmount(data.body?.amountType)
                            showPopWindow()

                        } else {
//                            Toast.makeText(activity, "没有银行卡，请更换支付渠道或者重试", Toast.LENGTH_SHORT).show()
                            KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                            showServicesPopupWindow()

                        }
                    }

                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        KeyBoardUtils.closeKeybord1(et_recharge_amount, baseContext!!)
                        showServicesPopupWindow()
                    }
                })
    }


    /**
     * 展示充值子类型
     */

    private fun showPayWayPopWindow() {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.popup_window_bank_pick, null)
        val mPopupWindow1 = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style

        var listView: ListView = view.findViewById(R.id.gender_picker)
        val cancel: TextView = view.findViewById(R.id.tv_cancel)
        val tv_promo_tip: TextView = view.findViewById(R.id.tv_promo_tip)
        cancel.setOnClickListener { mPopupWindow1.dismiss() }

        if (datas?.body?.promoTag==1){
            tv_promo_tip.visibility =View.VISIBLE
            tv_promo_tip.setOnClickListener {
                val intent = Intent(reChargeActivity, BrowserActivity::class.java)
                intent.putExtra(BrowserActivity.PARAM_URL, "https://billcloud.unionpay.com/upwxs-mktc/web/mapp/wxe990cdbcc189456e/custom/alllist")
                intent.putExtra(BrowserActivity.PARAM_SHOW_ACTION_BAR, true)
                startActivity(intent)
            }
        }else{
            tv_promo_tip.visibility =View.GONE
        }
        listView.adapter = RechargeTypeAdapter(activity!!.baseContext, payNames,payTypes,payKind?.payTypeList)
        listView.setOnItemClickListener { parent, view, position, id ->
            mPopupWindow1.dismiss()
            rl_pay_type.setEditText(payNames[position])

            togglePayType(payTypes[position])
        }

        mPopupWindow1.showAtLocation(rl_transfer_account, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }




    open fun togglePayType(onlinePayType: String) {
        if (onlinePayType=="15"||onlinePayType=="16"){
            queryPromo()
            rl_pay_type.setDrawablePromo(R.mipmap.promo_1888)

        }else{
            ll_show_money_promo.visibility =View.GONE
            rl_pay_type.hiddenDrawablePromo()
        }

        if ( payTypes.contains(onlinePayType) ) {
            val index =  payTypes.indexOf(onlinePayType)
            val payTypeObj = payKind?.payTypeList?.get(index)
            if (payTypeObj?.promoTag == 1) {
                rl_pay_type.setDrawablePromo(R.mipmap.promo_1888)
            }else if (payTypeObj?.typeTip?.recommend == 1) {
                rl_pay_type.setDrawablePromo(R.mipmap.icon_recharge_recomend)
            }
            curPayTypeOb = payTypeObj
        }

//        if (onlinePayType == "101" || onlinePayType == "102" || onlinePayType == "100") {
//            if ( payTypes.contains(onlinePayType) ) {
//                val index =  payTypes.indexOf(onlinePayType)
//                val payTypeObj = payKind?.payTypeList?.get(index)
//                if (payTypeObj?.typeTip?.recommend == 1) {
//                    rl_pay_type.setDrawablePromo(R.mipmap.icon_recharge_recomend)
//                }
//                curPayTypeOb = payTypeObj
//            }
//        }
        et_recharge_amount.setEditText("")
        load_error_view.visibility =View.GONE
        tv_qrcode_tip.visibility = View.GONE
        if (!TextUtils.isEmpty(depositorId)){
            recharge_account_payment_name.setEditText("")
            depositorId = ""
            deposit_name_1.isChecked = false
            deposit_name_2.isChecked = false
        }


    }

    @SuppressLint("SetTextI18n")
    fun showBQPopWindow(v: View, i: Int) {
        bankList.clear()
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_transfer, null)
        val height = if (i == 4) {
            Dip2PixleUtil.dp2px(context, 375f)
        } else {
            Dip2PixleUtil.dp2px(context, 315f)
        }
        val mPopupWindow1 = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, height, true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        val close: ImageView = view.findViewById(R.id.image_close)
        val bankIcon: ImageView = view.findViewById(R.id.image_bank_icon)
        val cancle: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val tvMoney: TextView = view.findViewById(R.id.tv_money)
        val bankName: TextView = view.findViewById(R.id.tv_bank_name)
        val rl_bank_select: RelativeLayout = view.findViewById(R.id.rl_bank_select)
        val pop_bank_list: ConstraintLayout = view.findViewById(R.id.pop_bank_list)
        val pop_confirm: LinearLayout = view.findViewById(R.id.pop_confirm)
        val back: ImageView = view.findViewById(R.id.iv_back)
        val listview: ListView = view.findViewById(R.id.lv_bank_list)
        val tv_bank_msg: TextView = view.findViewById(R.id.tv_bank_msg)
        val cv_card_holder: CustomHorizeView = view.findViewById(R.id.cv_card_holder)
        var adapter: BankListAdapter
        var payType = -1

        when (i) {
            1 -> {
                tv_bank_msg.text = "请使用${rl_pay_type.getEditTextContent()}"
                payType = alipayBQ


            }
            2 -> {
                tv_bank_msg.text = "请使用${rl_pay_type.getEditTextContent()}"
                payType = wechatBQ

            }

            3 -> {
                tv_bank_msg.text = "使用银行卡转账"
                payType = normalBQ

            }

            4 -> {
                tv_bank_msg.text = "支持网银、支付宝、ATM机、柜台等方式存款"
                cv_card_holder.visibility = View.VISIBLE
                cv_card_holder.setContent(recharge_account_payment_name.getEditTextContent())
            }
        }

        if (i == 4) {
            HandQBData?.body?.bankCards?.forEach {
                val bankInfo = BankInfo(it.bankName, it.accountNo, it.bankIcon)
                bankList.add(bankInfo)

            }
        } else {
            if (BQdatas?.body?.bankList != null) {
                bankList.addAll(BQdatas?.body?.bankList!!)
            }

        }

        if (bankList.size > 0) {
            adapter = BankListAdapter(bankList)
        } else {
            NotifyDialog.show(reChargeActivity!!, "当前充值渠道无可用银行卡，请更换其他充值渠道")
            return
        }

        bankName.text = bankList[wheelPosition].bankName


        var url = bankList[wheelPosition].bankIcon
        bankName.text = bankList[wheelPosition].bankName
        listview.adapter = adapter

        rl_bank_select.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(baseContext, R.anim.right_slide_in)
            pop_bank_list.startAnimation(animation)
            pop_bank_list.visibility = View.VISIBLE

            val animation2 = AnimationUtils.loadAnimation(baseContext, R.anim.left_slide_out)
            pop_confirm.startAnimation(animation2)
            pop_confirm.visibility = View.GONE

            listview.setOnItemClickListener { _, _, position, _ ->
                wheelPosition = position
                url = bankList[wheelPosition].bankIcon
                GlideUtils.load(baseContext,url)
                        .placeholder(R.mipmap.insted_imag_smarll)
                        .error(R.mipmap.insted_imag_smarll)
                        .into(bankIcon)
                adapter.notifyDataSetChanged()
                bankName.text = bankList[wheelPosition].bankName
                val animation = AnimationUtils.loadAnimation(baseContext, R.anim.right_slide_out)
                pop_bank_list.startAnimation(animation)
                pop_bank_list.visibility = View.GONE

                val animation2 = AnimationUtils.loadAnimation(baseContext, R.anim.left_slide_in)
                pop_confirm.startAnimation(animation2)
                pop_confirm.visibility = View.VISIBLE
            }

        }

        back.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(baseContext, R.anim.right_slide_out)
            pop_bank_list.startAnimation(animation)
            pop_bank_list.visibility = View.GONE

            val animation2 = AnimationUtils.loadAnimation(baseContext, R.anim.left_slide_in)
            pop_confirm.startAnimation(animation2)
            pop_confirm.visibility = View.VISIBLE

        }

        GlideUtils.load(baseContext,url)
                .placeholder(R.mipmap.insted_imag_smarll)
                .error(R.mipmap.insted_imag_smarll)
                .into(bankIcon)

        tvMoney.text = "¥${Utils.formatMoney(et_recharge_amount.getEditTextContent())}"
        close.setOnClickListener { mPopupWindow1.dismiss() }
        cancle.setOnClickListener {
            mPopupWindow1.dismiss()
        }
        sure.setOnClickListener {
            val intent = Intent()
            intent.setClass(baseContext, OrderPaymentActivity::class.java)
            val depositor = recharge_account_payment_name.getEditTextContent()

            //手工存款
            if (i == 4) {
                val payment = OrderPayment(et_recharge_amount.getEditTextContent(),
                        rl_transfer_account.getEditTextContent(),
                        depositor,
                        depositorId,
                        payType,
                        i,
                        bankList[wheelPosition],
                        HandQBData?.body!!.bankCards[wheelPosition]
                )

                intent.putExtra("data", Gson().toJson(payment))
            } else {
                //BQ存款
                val payment = OrderPayment(et_recharge_amount.getEditTextContent(),
                        rl_transfer_account.getEditTextContent(),
                        depositor,
                        depositorId,
                        payType,
                        i,
                        bankList[wheelPosition],
                        null
                )
                intent.putExtra("data", Gson().toJson(payment))
            }
            goToPage(intent)
            mPopupWindow1.dismiss()
        }

        mPopupWindow1.showAtLocation(rl_transfer_account, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }


  val textWatcher = object:TextWatcher{
      override fun afterTextChanged(s: Editable?) {
          depositorId = ""
          deposit_name_1.isChecked = false
          deposit_name_2.isChecked = false

      }

      override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

      }

      override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
      }

  }

}