package com.ksmobile.app.fragment.payment

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.View
import com.google.gson.Gson
import com.ksmobile.app.R
import com.ksmobile.app.activity.CreateHandDepositActivity
import com.ksmobile.app.data.OrderPayment
import com.ksmobile.app.fragment.BaseFragment
import com.ksmobile.app.util.CountDownTimer
import com.ksmobile.app.util.GlideUtils
import com.ksmobile.app.util.ToastUtils
import com.ksmobile.app.util.Utils
import kotlinx.android.synthetic.main.fragment_order_pay_bank.*

/**
 * 银行卡手工存款订单页面
 */
class BankPaymentFragment : BaseFragment() {

    var datas: OrderPayment? = null
    override fun getContentViewId(): Int {
        return R.layout.fragment_order_pay_bank
    }

    override fun initView() {
//        timer.start()
    }

    override fun initListener() {
        copy_name.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = user_card.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }
        copy_bank_number.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = number_card.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }

        copy_bank_address.setOnClickListener {
            val cmb: ClipboardManager? = activity?.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager?
            cmb?.text = tv_bank_address.text.toString()
            ToastUtils.show("复制 " + cmb?.text)
        }


        btn_goto_detail.setOnClickListener {
            val intent = Intent(activity, CreateHandDepositActivity::class.java)
            intent.putExtra("bankInfo", Gson().toJson(datas?.bankInfo))
            intent.putExtra("money", datas?.money)
            goToPage(intent)

        }

        tv_go_online_customer.setOnClickListener {
            Utils.goOnlineCustomerService()
        }
    }

    override fun initData() {
        val bundle = arguments
        if (bundle != null) {
            datas = Gson().fromJson(bundle.getString("datas"), OrderPayment::class.java)
        }

        tv_pay_person.text = datas?.depositor
        tv_money.text = Utils.formatMoney(datas?.money)
        user_card.text = datas?.handBankInfo?.accountName
        GlideUtils.load(context,datas?.bankInfo?.bankIcon)
                .placeholder(R.mipmap.insted_imag_smarll)
                .error(R.mipmap.insted_imag_smarll)
                .into(icon_bank)
        tv_bank_name.text = datas?.handBankInfo?.bankName
        if (datas?.handBankInfo?.showFlag==0){
            number_card.text = "**** **** **** ****"
            ll_cv_tip.visibility =View.VISIBLE
            tv_go_online_customer.visibility =View.VISIBLE

        }else{
            number_card.text = datas?.handBankInfo?.accountNo
        }

        tv_bank_address.text = datas?.handBankInfo?.bankBranchName

    }


//    private val timer = object : CountDownTimer(10 * 60 * 1000, 1000) {
//        override fun onTick(millisUntilFinished: Long) {
//            tv_count_down_time.text = (Utils.secToTime(millisUntilFinished / 1000))
//
//        }
//
//        override fun onFinish() {
//
//        }
//    }


    override fun onDestroy() {
        super.onDestroy()
//        timer.cancel()
    }
}