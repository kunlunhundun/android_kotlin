package com.ksmobile.app

import android.app.Activity
import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.os.Bundle
import android.support.multidex.MultiDexApplication
import com.bumptech.glide.Glide
import com.facebook.react.ReactInstanceManager
import com.facebook.react.ReactRootView
import com.ksmobile.app.activity.reactnative.OpenNativePackage
import com.ksmobile.app.data.ThreeStatisticsObject
import com.ksmobile.app.manager.ActivityListManager
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.ACache

class MyApplication : MultiDexApplication(), ComponentCallbacks2 {
    lateinit var activityListManager: ActivityListManager
    lateinit var mAcach: ACache
    lateinit var reactPackage: OpenNativePackage
    lateinit var mMainRootView: ReactRootView
    lateinit var mReactInstanceManager: ReactInstanceManager
    lateinit var threeStatisticsObject: ThreeStatisticsObject
    var showAg = false
    var mActivityCount = 0
    var webViewUUID = ""

    companion object {
        var instance: MyApplication? = null
        fun getinstance() = instance!!
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        AppInitManager.initApp(this)
        registerActivityLifecycleCallbacks(object :ActivityLifecycleCallbacks{
            override fun onActivityPaused(activity: Activity?) {
            }

            override fun onActivityResumed(activity: Activity?) {

            }

            override fun onActivityStarted(activity: Activity?) {
                mActivityCount++
            }

            override fun onActivityDestroyed(activity: Activity?) {
            }

            override fun onActivitySaveInstanceState(activity: Activity?, outState: Bundle?) {
            }

            override fun onActivityStopped(activity: Activity?) {
                mActivityCount--
            }

            override fun onActivityCreated(activity: Activity?, savedInstanceState: Bundle?) {
            }

        })

    }



    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)

        if (level == ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            Glide.get(this).clearMemory()
        }
        Glide.get(this).trimMemory(level)

    }

    override fun onLowMemory() {
        super.onLowMemory()
        Glide.get(this).clearMemory()
    }



}
