package com.ksmobile.app.data.request


/**
 * Created by ward.y on 2018/3/19.
 */
class ModifyRealNameRequest : BaseRequestObject() {

    var realName: String? = null
    var reservedInfo: String? = null
    var address: String? = null
    var avatar: String? = null
    var birth: String? = null
    var gender: String? = null
    var remark: String? = null


}
