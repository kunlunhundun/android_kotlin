package com.ksmobile.app.data.response

class GetByCardBinResponse : BaseResponseObject() {

    var body:CardBinInfo?=null


    data class CardBinInfo(
           var bankCode:String = "",
           var bankName:String = "",
           var cardBin:String = "",
           var cardName:String = "",
           var cardNoLength:Int = 0,
           var cardType:Int = 0,
           var cardTypeDesc:String = "",
           var bankIcon:String = ""

    )


}
