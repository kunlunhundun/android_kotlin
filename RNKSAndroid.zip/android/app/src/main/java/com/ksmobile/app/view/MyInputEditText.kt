package com.ksmobile.app.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.support.constraint.ConstraintLayout
import android.text.InputFilter
import android.text.InputType
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import com.ksmobile.app.R
import com.ksmobile.app.util.GlideUtils
import kotlinx.android.synthetic.main.my_input_edittext.view.*

class MyInputEditText(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {
    private val TYPE_NUMBER = "number"
    private val TYPE_TEXT = "text"
    private val TYPE_PASSWORD = "password"
    private val TYPE_PHONE = "phone"
    private var toggleListener: ItoggleListener? = null

    init {
        LayoutInflater.from(context).inflate(R.layout.my_input_edittext, this, true)
        val a = context.obtainStyledAttributes(attrs, R.styleable.customInput)
        val inputType = a.getString(R.styleable.customInput_inputType)
        val et_hint = a.getString(R.styleable.customInput_et_hint)
        val show_toggle = a.getBoolean(R.styleable.customInput_show_toggle, false)
        val edit_able = a.getBoolean(R.styleable.customInput_input_enable, true)
        val max_lenth = a.getInt(R.styleable.customInput_max_length, 0)
        val drawable_left = a.getDrawable(R.styleable.customInput_drawable_left)
        val drawable_right = a.getDrawable(R.styleable.customInput_drawable_right)


        if (null != et_hint) {
            et_input.hint = et_hint
        }


        if (null != drawable_left) {
            setDrawableLeft(drawable_left)
        }
        if (null != drawable_right) {
            img_right.setImageDrawable(drawable_right)
            img_right.visibility = View.VISIBLE
        }

        if (max_lenth != 0) {
            et_input.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(max_lenth))
        }

        if (show_toggle) {
            cb_pwd.visibility = View.VISIBLE

        }
        cb_pwd.setOnCheckedChangeListener { _, b ->
            val passwordLength = et_input.text.length
            et_input.inputType = if (b)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            et_input.setSelection(passwordLength)

            if (null != toggleListener) {
                toggleListener?.callBack(b)
            }
        }

        if (!edit_able) {
            et_input.isFocusable = false
            et_input.isFocusableInTouchMode = false
        }

        when {
            TYPE_NUMBER == inputType -> et_input.inputType = InputType.TYPE_CLASS_NUMBER
            TYPE_PASSWORD == inputType -> et_input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            TYPE_TEXT == inputType -> et_input.inputType = InputType.TYPE_CLASS_TEXT
            TYPE_PHONE == inputType -> et_input.inputType = InputType.TYPE_CLASS_PHONE
            null==inputType ->{
                et_input.inputType = InputType.TYPE_CLASS_TEXT
            }
        }

        et_input.setOnFocusChangeListener { v, hasFocus ->

            if (hasFocus) {
                ll_my_input.setBackgroundResource(R.drawable.my_input_edittext_active_bg)

            } else {
                ll_my_input.setBackgroundResource(R.drawable.my_input_edittext_bg)

            }
        }


        a.recycle()
    }


    fun setEditText(text: String) {
        et_input.setText(text)
    }

    fun getEditTextContent(): String {

        return et_input.text.toString()
    }

    fun getEditText(): EditText {

        return et_input
    }

    fun getToggle(): CheckBox {

        return cb_pwd
    }


    fun setToggleListener(listener: ItoggleListener) {
        toggleListener = listener
    }

    fun showError(errorId: Int) {
        tv_error.setText(errorId)
        tv_error.visibility = View.VISIBLE
        ll_my_input.setBackgroundResource(R.drawable.my_input_edittext_error_bg)
    }

    fun showError(error: String?) {
        tv_error.text = error
        tv_error.visibility = View.VISIBLE
        ll_my_input.setBackgroundResource(R.drawable.my_input_edittext_error_bg)
    }

    fun hideError() {
        tv_error.text = ""
        tv_error.visibility = View.GONE
        ll_my_input.setBackgroundResource(R.drawable.my_input_edittext_bg)

    }


    fun setDrawableLeft(drawable: Drawable) {
        img_left.setImageDrawable(drawable)
        img_left.visibility = View.VISIBLE
        tv_label.visibility = View.VISIBLE
    }

    fun setDrawableLeft(id: Int) {
        img_left.setImageResource(id)
        img_left.visibility = View.VISIBLE
        tv_label.visibility = View.VISIBLE
    }

    fun setDrawableLeft(url: String) {
        GlideUtils.load(context,url).into(img_left)
        img_left.visibility = View.VISIBLE
        tv_label.visibility = View.VISIBLE
    }

    fun setDrawableRight(id: Int) {
        img_right.setImageResource(id)
        img_right.visibility = View.VISIBLE
    }

    fun setDrawableRight(drawable: Drawable) {
        img_right.setImageDrawable(drawable)
        img_right.visibility = View.VISIBLE
    }

    fun setLength(length: Int?) {
        if (length != 0) {
            et_input.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(length!!))
        }
    }

    interface ItoggleListener {
        fun callBack(isShow: Boolean)
    }
}