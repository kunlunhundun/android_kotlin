package com.ksmobile.app.view.hybride

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.text.TextUtils
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import com.ksmobile.app.database.DataBaseHelper
import com.ksmobile.app.util.LogUtils
import com.ksmobile.app.util.ToastUtils
import java.net.URISyntaxException

open class BaseWebViewClient(activity: Activity) : WebViewClient() {

    var mActivity = activity

    override fun shouldOverrideUrlLoading(webview: WebView?, url: String?): Boolean {
        if (TextUtils.isEmpty(url)) {
            return false
        }


        try {
            //处理intent协议
            if (url!!.startsWith("intent://")) {
                val intent: Intent
                try {
                    intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    intent.addCategory("android.intent.category.BROWSABLE")
                    intent.component = null
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
                        intent.selector = null
                    }
                    val resolves = mActivity.getPackageManager().queryIntentActivities(intent, 0)
                    if (resolves.size > 0) {
                        mActivity.startActivityIfNeeded(intent, -1)
                    }
                    return true
                } catch (e: URISyntaxException) {
                    e.printStackTrace()
                }

            }
            // 处理自定义scheme协议
            if (!url.startsWith("http")) {
                try {
                    // 以下固定写法
                    val intent = Intent(Intent.ACTION_VIEW,
                            Uri.parse(url))
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    mActivity.startActivity(intent)
                } catch (e: Exception) {
                    // 防止没有安装的情况
                    e.printStackTrace()
                    ToastUtils.show("您所打开的第三方App未安装！")
                }

                return true
            }

            if (url == "https://www.ks015.com/chat/chatClient/www.pt-gateway.com") {
                mActivity.finish()
                return true
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }

        val uri = Uri.parse(url) ?: return false
        //点击回退键
        if (DataBaseHelper.getUrl()?.domain?.equals(uri.host) == true) {
            if (url=="https://m.0799ks.com/#/ground/type/1"){
                return false
            }
            if (url!!.contains("loginGame.html")){
                return false
            }

            webview?.reload()
            mActivity.finish()
            return true
        }
        return super.shouldOverrideUrlLoading(webview, url)
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        handler?.proceed()
    }


}