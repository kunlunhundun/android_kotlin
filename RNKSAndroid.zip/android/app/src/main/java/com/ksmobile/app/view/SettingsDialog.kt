package com.ksmobile.app.view

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.view.*
import android.widget.TextView
import com.ksmobile.app.BuildConfig
import com.trello.rxlifecycle2.components.support.RxDialogFragment
import com.ksmobile.app.R
import com.ksmobile.app.activity.MainActivity
import com.ksmobile.app.activity.reactnative.MyRnPageActivity
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.config.RouteConfig
import com.ksmobile.app.data.RnRouter
import com.ksmobile.app.manager.AppInitManager
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.NavigationBarUtils
import com.ksmobile.app.util.StatusBarUtil
import com.ksmobile.app.view.iview.IDialog


/**
 * Created by ward.y on 2018/11/09.
 */

class SettingsDialog : RxDialogFragment(), IDialog {


    lateinit var tv_cancel: TextView
    lateinit var cl_download: ConstraintLayout
    lateinit var cl_partner: ConstraintLayout
    lateinit var cl_subscription: ConstraintLayout
    lateinit var cl_modify_pwd: ConstraintLayout
    lateinit var cl_login_out: ConstraintLayout
    lateinit var view_padding: TextView
    lateinit var tv_change_gateway: TextView
    lateinit var view_bg: RealtimeBlurView


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(activity, R.style.MyDialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE) // 设置Content前设定
        dialog.setContentView(R.layout.view_settings_dialog)
        initCommonView(dialog)
        dialog.setCanceledOnTouchOutside(true) // 外部点击取消

        // 设置宽度为屏宽, 靠近屏幕底部。
        val window = dialog.window
        setTranslucentStatus(window)
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = window.attributes
        lp.width = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.height = WindowManager.LayoutParams.MATCH_PARENT // 宽度持平
        lp.gravity = Gravity.CENTER
        window.attributes = lp
        return dialog
    }


    private fun initCommonView(dialog: Dialog) {

        tv_cancel = dialog.findViewById(R.id.tv_cancel)
        tv_change_gateway = dialog.findViewById(R.id.tv_change_gateway)
        cl_download = dialog.findViewById(R.id.cl_download)
        cl_partner = dialog.findViewById(R.id.cl_partner)
        cl_subscription = dialog.findViewById(R.id.cl_subscription)
        cl_modify_pwd = dialog.findViewById(R.id.cl_modify_pwd)
        cl_login_out = dialog.findViewById(R.id.cl_login_out)
        view_padding = dialog.findViewById(R.id.view_padding)
        view_bg = dialog.findViewById(R.id.view_bg)

        if (TextUtils.isEmpty(ConfigUtils.loginName)) {
            cl_subscription.visibility = View.GONE
            cl_modify_pwd.visibility = View.GONE
            cl_login_out.visibility = View.GONE
        }
        if (BuildConfig.DEBUG){
            tv_change_gateway.visibility =View.VISIBLE
        }

        if (NavigationBarUtils.isNavigationBarShow(activity!!)) {
            view_padding.height = Dip2PixleUtil.dp2px(context, 50f)
        }
        tv_cancel.setOnClickListener { dismiss() }
        view_bg.setOnClickListener { dismiss() }

        cl_partner.setOnClickListener {

            if (activity !is MainActivity) {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.PARTNER, false))
                jumpRn()
            } else {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.PARTNER, true))
            }
            dismiss()
        }

        cl_download.setOnClickListener {

            if (activity !is MainActivity) {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.DOWNLOAD, false))
                jumpRn()
            } else {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.DOWNLOAD, true))
            }
            dismiss()
        }
        cl_subscription.setOnClickListener {

            if (activity !is MainActivity) {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.SUBSCRIBE, false))
                jumpRn()
            } else {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.SUBSCRIBE, true))
            }
            dismiss()
        }
        cl_modify_pwd.setOnClickListener {

            if (activity !is MainActivity) {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.CHANGEPASSWORD, false))
                jumpRn()
            } else {
                AppInitManager.getReactPackage().openNativeModule?.jumpToPage(RnRouter(RouteConfig.CHANGEPASSWORD, true))
            }
            dismiss()
        }
        cl_login_out.setOnClickListener {
            AppInitManager.loginOut()
            dismiss()
        }

        tv_change_gateway.setOnClickListener {
            val bundle = Bundle()
            bundle.putInt(CommonDialog.TYPE, CommonDialog.TYPE_DEBUG)
            val dialog = CommonDialog()
            dialog.arguments = bundle
            dialog.show(activity!!.supportFragmentManager, "debug")
            dismiss()
        }

    }


    override fun onLayoutChange(show: Boolean) {


    }


    private fun setTranslucentStatus(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        } else {//4.4 全透明状态栏
            window.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        }

        StatusBarUtil.StatusBarLightMode(window)
    }

    private fun jumpRn() {
        var mActivity = activity
        val intent = Intent(activity, MyRnPageActivity::class.java)
        Handler().postDelayed({
            mActivity?.startActivity(intent)
        }, 100)
    }

}

