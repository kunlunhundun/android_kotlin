package com.ksmobile.app.view

import android.content.Context
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.ksmobile.app.R
import kotlinx.android.synthetic.main.top_confirm_dialog.view.*

class MyTopComfirmDialog(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {
    var hiddenCallback:IHinddenCallback?=null

    init {

        LayoutInflater.from(context).inflate(R.layout.top_confirm_dialog, this, true)
        visibility = View.GONE
        tv_cancel.setOnClickListener {
            hidden()
        }

    }

    fun show() {
        Handler().postDelayed({
            val animation = AnimationUtils.loadAnimation(context, R.anim.popupwindow_show_anim)
            this.startAnimation(animation)
            visibility = View.VISIBLE

        }, 200)

    }

    fun hidden() {
        val animation = AnimationUtils.loadAnimation(context, R.anim.popupwindow_hidden_anim)
        this.startAnimation(animation)
        visibility = View.GONE

        animation.setAnimationListener(object : Animation.AnimationListener{
            override fun onAnimationRepeat(animation: Animation?) {
            }

            override fun onAnimationStart(animation: Animation?) {
            }

            override fun onAnimationEnd(animation: Animation?) {
                if (hiddenCallback!=null){
                    hiddenCallback?.onHidden()
                }
            }

        })
    }

    fun setTipTitle(title:String) {
        if (TextUtils.isEmpty(title)){
            tv_notify_title.visibility = View.GONE
        }else{
            tv_notify_title.text = title
        }

    }

    fun setIcon(id:Int) {
        iv_notify.setImageResource(id)
    }

    fun setTipContent(content:String) {
        tv_notify_content.text = content
    }

    fun setCancelText(cancel:String) {
        tv_cancel.text = cancel
    }

    fun setSureText(sure:String) {
        tv_sure.text = sure
    }

    fun setSureListener(listener:OnClickListener) {
        tv_sure.setOnClickListener(listener)
    }

    fun setCancelListener(listener:OnClickListener) {
        tv_cancel.setOnClickListener(listener)
    }

    interface IHinddenCallback{
        fun onHidden()
    }


    fun setOnHiddenCallBack(callback: IHinddenCallback){
        hiddenCallback = callback
    }


}