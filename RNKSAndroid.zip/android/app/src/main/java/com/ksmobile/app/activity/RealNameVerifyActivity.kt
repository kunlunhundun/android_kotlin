package com.ksmobile.app.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.aigestudio.wheelpicker.WheelPicker
import com.aigestudio.wheelpicker.widgets.WheelDatePicker
import com.trello.rxlifecycle2.android.ActivityEvent
import com.trello.rxlifecycle2.kotlin.bindUntilEvent
import com.ksmobile.app.R
import com.ksmobile.app.config.ConfigUtils
import com.ksmobile.app.data.request.GetByLoginNameRequest
import com.ksmobile.app.data.request.ModifyRealNameRequest
import com.ksmobile.app.data.response.GetByLoginNameResponse
import com.ksmobile.app.data.response.ModifyRealNameResponse
import com.ksmobile.app.net.ApiClient
import com.ksmobile.app.net.ApiErrorModel
import com.ksmobile.app.net.ApiResponse
import com.ksmobile.app.net.NetworkScheduler
import com.ksmobile.app.util.Utils
import com.ksmobile.app.view.MyLineInputEditText
import com.ksmobile.app.view.NotifyDialog
import kotlinx.android.synthetic.main.activity_real_name_verify.*

class RealNameVerifyActivity : BaseToolBarActivity() {
    var jumpTo: String? = null

    override fun getLayoutId(): Int {
        return R.layout.activity_real_name_verify
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTile(getString(R.string.real_name_verify_title))
        jumpTo = intent.getStringExtra("jumpTo")

    }

    override fun initView() {
        getUserInfo()

    }

    override fun initListener() {
        et_birth_date.setOnClickListener {
            showPopupWindow(it, 0)
        }

        et_sex.setOnClickListener {
            showPopupWindow(it, 1)
        }


        btn_commit.setOnClickListener {
            checkRequest()

        }


    }


    private val textWatcher = object : TextWatcher {
        var beforeText = ""

        override fun afterTextChanged(s: Editable?) {
            val  temp = s.toString()
            if (!TextUtils.isEmpty(temp)) {

                if (!Utils.checkStringFullChinese(temp)) {
                    if (!TextUtils.isEmpty(beforeText) && Utils.checkPoint(temp[temp.lastIndex].toString())) {
                        if (!beforeText.endsWith("·")){
                            beforeText = "$beforeText·"
                        }

                    }
                    et_real_name.setEditText(beforeText)
                    et_real_name.getEditText().setSelection(et_real_name.getEditTextContent().length)
                } else {

                    if (beforeText.endsWith("·") && s.toString().endsWith("·") && (beforeText.length + 1 == s.toString().length)) {
                        et_real_name.setEditText(beforeText)
                        et_real_name.getEditText().setSelection(et_real_name.getEditTextContent().length)
                    }


                }
            }

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            beforeText = s.toString()
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {


        }


    }

    private fun checkRequest() {

        var cancel = false
        var error = ""
        var inputView: MyLineInputEditText? = null
        et_real_name.hideError()
        et_birth_date.hideError()
        et_sex.hideError()

        when {
            TextUtils.isEmpty(et_real_name.getEditTextContent()) -> {
                cancel = true
                error = "真实姓名不能为空"
                inputView = et_real_name
            }
            et_real_name.getEditText().isFocusable && !Utils.checkRealName(et_real_name.getEditTextContent()) -> {
                cancel = true
                error = "请输入与您的取款银行卡一致的真实姓名"
                inputView = et_real_name
            }

            TextUtils.isEmpty(et_birth_date.getEditTextContent()) -> {
                cancel = true
                error = "请选择您的生日"
                inputView = et_birth_date
            }

            TextUtils.isEmpty(et_sex.getEditTextContent()) -> {
                cancel = true
                error = "请选择您的性别"
                inputView = et_sex
            }

        }

        if (cancel) {
            inputView?.showError(error)
        } else {
            modifyUserInfo()
        }


    }

    private fun modifyUserInfo() {
        val request = ModifyRealNameRequest()
        request.gender = if ("男" == et_sex.getEditTextContent()) {
            "M"
        } else {
            "F"
        }
        request.birth = et_birth_date.getEditTextContent()
        var temp = et_real_name.getEditTextContent()
        if (temp.endsWith("·")) {
            request.realName = temp.substring(0, temp.lastIndex - 1)
        }
        if (temp.contains("*")) {
            temp = ""
        }
        request.realName = temp
        ApiClient.instance.service.modifyRealName(request)
                .compose(NetworkScheduler.compose())
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .subscribe(object : ApiResponse<ModifyRealNameResponse>(this, true) {
                    override fun businessFail(data: ModifyRealNameResponse) {
                        when(data.head.errCode){
                            "GW_800710" ->{
                                NotifyDialog.show(this@RealNameVerifyActivity, "您已完成实名认证，请勿重复操作")
                                NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                                    override fun onHidden() {
                                        finish()
                                    }

                                })
                            }
                            else ->{
                                NotifyDialog.show(this@RealNameVerifyActivity, data.head.errMsg)
                            }
                        }


                    }

                    override fun businessSuccess(data: ModifyRealNameResponse) {
                        ConfigUtils.realName = request.realName
                        NotifyDialog.show(this@RealNameVerifyActivity, "实名认证成功！")
                        NotifyDialog.setIcon(R.mipmap.icon_tip_ok)
                        NotifyDialog.setOnHiddenCallback(object : NotifyDialog.HiddenCallback {
                            override fun onHidden() {
                                finish()
                            }

                        })

                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                        NotifyDialog.show(this@RealNameVerifyActivity, apiErrorModel.message)
                    }

                })

    }

    private fun showPopupWindow(v: View, type: Int) {
        val layoutInflater = LayoutInflater.from(this@RealNameVerifyActivity)
        val view = layoutInflater.inflate(R.layout.view_popup_window_date_picker, null)
        val cancel: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val title: TextView = view.findViewById(R.id.title)
        val ll_bottom_date_picker: RelativeLayout = view.findViewById(R.id.ll_bottom_date_picker)
        val popupWindow = PopupWindow(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        popupWindow.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        popupWindow.isOutsideTouchable = true
        popupWindow.animationStyle = R.style.MyPopupWindow_anim_style
        popupWindow.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        if (type == 0) {
            val datePicker: WheelDatePicker = view.findViewById(R.id.datePicker)
            datePicker.visibility = View.VISIBLE
            datePicker.ClassicModel()
            sure.setOnClickListener {
                et_birth_date.setEditText(datePicker.selectDate)
                popupWindow.dismiss()
            }
        } else {
            val genderPicker: WheelPicker = view.findViewById(R.id.gender_picker)
            genderPicker.visibility = View.VISIBLE
            genderPicker.selectedItemPosition = 1
            genderPicker.data = arrayListOf("男", "女")
            sure.setOnClickListener {
                et_sex.setEditText(genderPicker.data[genderPicker.currentItemPosition].toString())
                popupWindow.dismiss()
            }
        }

        // PopupWindow弹出位置
        popupWindow.showAtLocation(v, Gravity.BOTTOM, 0, 0)

        cancel.setOnClickListener { popupWindow.dismiss() }
//        ll_bottom_date_picker.setOnClickListener { popupWindow.dismiss() }

    }

    private fun getUserInfo() {
        val request = GetByLoginNameRequest()
        request.inclRealName = 1
        ApiClient.instance.service.getByLoginName(request)
                .bindUntilEvent(this, ActivityEvent.DESTROY)
                .compose(NetworkScheduler.compose())
                .subscribe(object : ApiResponse<GetByLoginNameResponse>(this, false) {
                    override fun businessFail(data: GetByLoginNameResponse) {
                    }

                    override fun businessSuccess(data: GetByLoginNameResponse) {
                        ConfigUtils.realName = data.body?.realName

                        if (!TextUtils.isEmpty(ConfigUtils.realName)) {
                            et_real_name.setEditText(ConfigUtils.realName)
                            et_real_name.setEnable(false)
                        } else {
                            et_real_name.getEditText().addTextChangedListener(textWatcher)
                            et_real_name.setOnFocusChangeListener { _, hasFocus ->
                                if (!hasFocus) {
                                    when {
                                        TextUtils.isEmpty(et_real_name.getEditTextContent()) -> {
                                            et_real_name.showError("真实姓名不能为空")
                                        }
                                        !Utils.checkRealName(et_real_name.getEditTextContent()) -> {
                                            et_real_name.showError("请输入与您的取款银行卡一致的真实姓名")
                                        }
                                    }
                                }

                            }
                        }

                        if (!TextUtils.isEmpty(data.body?.birthday)) {
                            et_birth_date.setEditText(data.body?.birthday)
                            et_birth_date.setOnClickListener(null)
                            et_birth_date.setDrawableRight(null)
                            btn_commit.visibility = View.GONE
                        }

                        if (!TextUtils.isEmpty(data.body?.birthday)) {
                            et_sex.setEditText(if ("M" == data.body?.gender) {
                                "男"
                            } else {
                                "女"
                            })
                            et_sex.setOnClickListener(null)
                            et_sex.setDrawableRight(null)
                        }
                    }


                    override fun failure(statusCode: Int, apiErrorModel: ApiErrorModel) {
                    }

                })

    }

}