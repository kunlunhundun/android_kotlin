package com.ksmobile.app.fragment.recharge

import android.app.ActionBar
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.ksmobile.app.R
import com.ksmobile.app.data.response.QueryPayWaysV3Response
import com.ksmobile.app.util.Dip2PixleUtil
import com.ksmobile.app.util.Utils
import kotlinx.android.synthetic.main.fragment_recharge_base_view.*
import java.math.BigDecimal

class AlipayRechargeFragment : MobileRechargeFragment() {


    val WAP = "9"
    val BQ = "92"
    var QKDeposit = "102"
    val QRCODE = "5"
    override fun showPayWay() {
        super.showPayWay()
        rl_transfer_account.setDrawableLeft(R.mipmap.icon_payment_alipay)
        rl_transfer_account.setEditText(payWay[0])
        linear_visible.visibility = View.VISIBLE
        recharge_account_payment_name.visibility = View.VISIBLE
        pay_bank_layout.visibility = View.GONE
        qrcode_pay_layout.visibility = View.GONE
        rl_pay_type.visibility = View.VISIBLE
        initPayType(payKind)

    }

    override fun goPay() {

        if (TextUtils.isEmpty(et_recharge_amount.getEditTextContent())) {
            if (et_recharge_amount.visibility ==View.VISIBLE){
                et_recharge_amount.showError( "请输入金额")
            }else{
                error_no_selected.visibility =View.VISIBLE
            }

            return
        }

        if (BigDecimal(et_recharge_amount.getEditTextContent()) < minAmount
                || BigDecimal(et_recharge_amount.getEditTextContent()) > maxAmount) {
            et_recharge_amount.showError( "单笔限额${minAmount}元~${maxAmount}元")
            return
        }
        if (payType == BQ) {
            if (Utils.checkRealName(recharge_account_payment_name.getEditTextContent())) {
                requestBQBank(BQ)

            } else {
                if (!TextUtils.isEmpty(depositorId)  && recharge_account_payment_name.getEditTextContent().contains("*")) {
                    requestBQBank(BQ)
                } else {
                    recharge_account_payment_name.showError("请输入真实有效的存款人姓名")
                }
            }
        } else {
            showOnlinePopWindow(rl_transfer_account)
        }

    }

    /**
     * 初始化充值方式
     */
    private fun initPayType(payWayObject: QueryPayWaysV3Response.PayWayObject?) {
        payNames.clear()
        payTypes.clear()
        payWayObject?.payTypeList?.forEach {
                payTypes.add(it.payType)
                payNames.add(it.payTypeName)

        }

        togglePayType(payTypes[0])
        rl_pay_type.setEditText(payNames[0])
        recharge_account_payment_name.getEditText().hint = "请输入支付宝绑定的姓名"
    }

    /**
     * 切换充值方式
     */
    override fun togglePayType(onlinePayType: String) {
        super.togglePayType(onlinePayType)

        ll_qk_customer.visibility = View.GONE
        tv_next.text = "下一步"

        if (onlinePayType == BQ) {
            queryPayLimit(BQ)
            recharge_account_payment_name.visibility = View.VISIBLE
            ll_amount.visibility = View.VISIBLE
            recharge_account_payment_name.setText("支付宝姓名")
            recharge_account_payment_name.getEditText().hint = "请输入支付宝绑定的姓名"

        }else if (onlinePayType == QKDeposit ) {
            ll_amount.visibility = View.GONE

            recharge_account_payment_name.visibility = View.GONE
            ll_deposit_name.visibility = View.GONE

            ll_qk_customer.visibility = View.VISIBLE
            tv_next.text = "联系专员存款"
            tx_qk_channel.text = "支付宝专用通道"
        }
        else  {
            if (onlinePayType==QRCODE){
                tv_qrcode_tip.visibility = View.VISIBLE
            }
            ll_amount.visibility = View.VISIBLE
            queryOnlineBanks(onlinePayType)
            recharge_account_payment_name.visibility = View.GONE
            ll_deposit_name.visibility = View.GONE
        }

        payType = onlinePayType
    }

    /**
     * 展示充值确认弹窗
     */
    override fun showPopWindow() {
        showBQPopWindow(rl_transfer_account, 1)
    }


    override fun showOnlinePopWindow(v: View) {
        val layoutInflater = LayoutInflater.from(baseContext)
        val view = layoutInflater.inflate(R.layout.pop_window_query_online, null)

        val mPopupWindow1 = PopupWindow(view, ActionBar.LayoutParams.MATCH_PARENT, Dip2PixleUtil.dp2px(context,260f), true)
        mPopupWindow1.setBackgroundDrawable(resources.getDrawable(R.drawable.popup_window_transparent))
        mPopupWindow1.isOutsideTouchable = true
        mPopupWindow1.animationStyle = R.style.MyPopupWindow_anim_style
        mPopupWindow1.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val close: ImageView = view.findViewById(R.id.image_close)
        val cancle: TextView = view.findViewById(R.id.tv_cancle)
        val sure: TextView = view.findViewById(R.id.tv_sure)
        val bankMsg: TextView = view.findViewById(R.id.tv_bank_msg)
        val tvMoney: TextView = view.findViewById(R.id.tv_money)
        val linear: LinearLayout = view.findViewById(R.id.linear_bank_msg)

        linear.visibility = View.GONE
        sure.text = "前往支付"
        bankMsg.text = "请使用${rl_pay_type.getEditTextContent()}"

        sure.setOnClickListener {
            createOnlineOrderRequest("alipay",payType)
            mPopupWindow1.dismiss()
        }

        tvMoney.text = "¥${Utils.formatMoney(et_recharge_amount.getEditTextContent())}"
        close.setOnClickListener { mPopupWindow1.dismiss() }
        cancle.setOnClickListener { mPopupWindow1.dismiss() }


        mPopupWindow1.showAtLocation(v, Gravity.BOTTOM, 0, 0)
        reChargeActivity?.toggleViewBg(true)
        mPopupWindow1.setOnDismissListener { reChargeActivity?.toggleViewBg(false) }
    }
}
