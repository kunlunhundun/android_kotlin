package com.ksmobile.app.data.request

import java.math.BigDecimal


class QueryBtcRateRequest : BaseRequestObject() {

    var amount: BigDecimal? = BigDecimal(0)
}