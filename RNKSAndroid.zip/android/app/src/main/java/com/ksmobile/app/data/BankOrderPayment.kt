package com.ksmobile.app.data

import com.ksmobile.app.data.response.QueryBanksResponse

data class BankOrderPayment(val money: String,
                            val title: String,
                            val depositor: String,
                            val PayWay: Int,
                            val bankInfo: QueryBanksResponse.Bean
)