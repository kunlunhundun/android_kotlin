package com.rea.push.requests;


public interface IRequest {

    byte[] getBody();
}
