package com.rea.push.services;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;

import com.rea.commonUtils.log.LogUtil;
import com.rea.push.heartbeat.HeartbeatHelper;
import com.rea.push.utils.Utils;

/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class PushService extends Service{
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
//        startForeground(1,new Notification());
        LogUtil.e("-------->PushService onCreate<--------");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        LogUtil.e("-------->PushService onStartCommand<--------");
        HeartbeatHelper.startHeartbeat(this.getApplicationContext());
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            Utils.startService(this);
        }catch (Throwable e){}
    }



}
