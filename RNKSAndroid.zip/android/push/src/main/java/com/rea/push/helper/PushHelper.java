package com.rea.push.helper;


import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

import com.rea.commonUtils.log.LogUtil;
import com.rea.push.config.PushConfig;
import com.rea.push.utils.Utils;


import static com.rea.push.utils.Cons.ACTION_ALAMER;

/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class PushHelper {

    public static PushConfig pushConfig;

    public static void start(Application context, PushConfig config) {
        LogUtil.e("PushHelper start config:"+config.getIP());
        pushConfig = config;
        LogUtil.setLogEnable(config.showLog());
        if (Utils.pushServiceIsWork(context) == false) {
            LogUtil.e("start service:"+config.getPort()+" "+config.getProgectId());
            Utils.startService(context);
        }
        startAlame(context);
    }


    private static void startAlame(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent();
        intent.setAction(ACTION_ALAMER);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context.getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        long time = SystemClock.elapsedRealtime() + 5 * 1000;
        alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, time, 10 * 1000, pendingIntent);
    }

    public static void restartService(Application context){
        Utils.restartService(context);
    }
}
