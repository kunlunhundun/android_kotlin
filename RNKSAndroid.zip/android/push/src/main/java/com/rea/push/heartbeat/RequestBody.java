package com.rea.push.heartbeat;

import android.content.Context;

import com.rea.push.helper.PushHelper;
import com.rea.push.requests.ScheduleRequestBody;
import com.rea.push.config.PushConfig;

import java.util.concurrent.TimeUnit;

/**
 * author: Rea.X
 * date: 2017/3/10.
 */

public class RequestBody extends ScheduleRequestBody {
    public RequestBody(Context context) {
        super(context, 0, PushHelper.pushConfig.getHeartBeatTime(), TimeUnit.MILLISECONDS);
    }
}
