package com.rea.push.model;

/**
 * author: Rea.X
 * date: 2017/3/10.
 */

public class ShowMessage {
    private String messageid;
    private String message;

    public String getMessageid() {
        return messageid;
    }

    public void setMessageid(String messageid) {
        this.messageid = messageid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
