package com.rea.push.callback;

import android.content.Context;

import com.rea.commonUtils.log.LogUtil;
import com.rea.push.Push;
import com.rea.push.heartbeat.RequestBody;
import com.rea.push.helper.PushPreferenceHelper;
import com.rea.push.helper.UUIDUtils;
import com.rea.push.utils.Utils;
import com.rea.push.utils.Error;
import com.rea.push.utils.Message;


/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class PushCallBack extends AsyncCallback {

    private Context context;
    private Push push;
    private RequestBody mScheduleRequestBody;

    public PushCallBack(Context context, RequestBody mScheduleRequestBody, Push push) {
        this.context = context;
        this.mScheduleRequestBody = mScheduleRequestBody;
        this.push = push;
    }





    @Override
    public void onSuccess(byte[] t) {
        Utils.logByteArray("接收数组》》", t);
        boolean isUUid = UUIDUtils.checkIsUUIDPackage(t[0]);
        if (isUUid) {
            if (!UUIDUtils.isUsedUUID(t)) {
                PushPreferenceHelper.clearUUID(context);
            } else {
                PushPreferenceHelper.saveUUIDBytes(context, UUIDUtils.getUUIDBytes(t));
            }
            push.refreshData(mScheduleRequestBody);
        } else {
            Message.parse(context, t);
        }
    }


    @Override
    public void onFailure(Error error) {
        LogUtil.e("失败》》》》》" + error.toString());
    }

    @Override
    public void onSend(byte[] t) {
//        Utils.logByteArray("发送数组", t);
    }

    @Override
    public void onBeforeSend(byte[] t) {
        Utils.logByteArray("准备发送数组", t);
//        push.refreshData(mScheduleRequestBody);
    }
}
