package com.rea.push.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.rea.commonUtils.log.LogUtil;
import com.rea.push.utils.Cons;
import com.rea.push.utils.Utils;

/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class PushReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        LogUtil.e("接收到广播：：：："+action);
        if(action.equals(Intent.ACTION_BOOT_COMPLETED)){
            LogUtil.e("ACTION_BOOT_COMPLETED");
        }
        if(action.equals(Cons.ACTION_ALAMER)){
            LogUtil.e("ACTION_ALAMER");
        }
        Utils.startService(context);
    }
}
