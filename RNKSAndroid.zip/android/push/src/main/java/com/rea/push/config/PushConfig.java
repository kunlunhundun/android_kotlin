package com.rea.push.config;

import com.rea.push.utils.Cons;

/**
 * author: Rea.X
 * date: 2017/3/10.
 */

public abstract class PushConfig {
//    public static final String IP = "10.66.69.32";
//    public static final int PORT = 6587;

//    public static final String IP = "10.66.66.62";
//    public static final int PORT = 8090;
//
//    public static final long HEARTBEAT = 5 * 1000;

    public abstract String getIP();

    public abstract int getPort();

    public abstract long getHeartBeatTime();

    public abstract String getCustomerId();

    public abstract String getProgectId();

    public abstract
    @Cons.PushModel
    int configPushModel();

    public abstract int getAppIcon();

    public abstract boolean openPush();

    public abstract boolean showLog();


    /**
     * app在前台的时候是否显示通知
     * @return
     */
    public boolean isShowNotifyWhenAppInFront(){
        return true;
    }
}
