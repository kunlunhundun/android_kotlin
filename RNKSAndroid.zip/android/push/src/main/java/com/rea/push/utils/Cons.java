package com.rea.push.utils;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class Cons {

    public static final String SERVICE_ACTION = "com.rea.push.service";

    public static final String ACTION_ALAMER = "com.rea.push.alarm";

    public static final String ACTION_CLICK = "com.rea.push.CLICK_BOTIFY";

    public static final String ACTION_MESSAGE = "com.rea.push.RECEIVER_MESSAGE";

    /**
     * 通知
     */
    public static final int NOTIFY = 1;
    /**
     * 透传消息
     */
    public static final int MESSAGE = 2;

    @Retention(RetentionPolicy.RUNTIME)
    @IntDef({NOTIFY,MESSAGE})
    public @interface PushModel {
    }
}
