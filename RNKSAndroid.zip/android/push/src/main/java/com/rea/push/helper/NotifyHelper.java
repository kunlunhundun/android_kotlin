package com.rea.push.helper;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.rea.commonUtils.common.CommonUtils;
import com.rea.commonUtils.log.LogUtil;
import com.rea.commonUtils.notify.NotifyUtil;
import com.rea.push.config.PushConfig;
import com.rea.push.model.ShowMessage;

import base.rea.com.push.R;

import static com.rea.push.utils.Cons.ACTION_CLICK;
import static com.rea.push.utils.Cons.ACTION_MESSAGE;
import static com.rea.push.utils.Cons.MESSAGE;
import static com.rea.push.utils.Cons.NOTIFY;

/**
 * author: Rea.X
 * date: 2017/3/11.
 */

public class NotifyHelper {

    private static int messageid;

    public static int showNotify(Context context, ShowMessage showMessage) {
        String message = showMessage.getMessage();
        LogUtil.e("推送消息-_" + message);
        if (TextUtils.isEmpty(message)) return -1;
        String id = "";
        String title = "    ";
        String content;
        String url = "";
        String type = "";
        if (message.contains("|")) {
            String[] strs = message.split("\\|");
            id = strs[0];
            title = strs[1];
            content = strs[2];
            if (strs.length > 3) {
                url = strs[3];
                type = strs[4];

            }
        } else {
            content = message;
        }
        distri(context, id, title, content, url, type);
        QueueHelper.clearMessage(showMessage.getMessageid());
        return messageid;
    }

    private static void distri(Context context, String id, String title, String content, String url, String type) {
        PushConfig config = PushHelper.pushConfig;
        boolean appIsFront = CommonUtils.isAppInTheForeground(context);
        if(appIsFront){
            sendMessage(context, id, title, content, url, type);
            return;
        }
        switch (config.configPushModel()) {
            case MESSAGE:
                sendMessage(context, id, title, content, url, type);
                break;
            case NOTIFY:
                showNotify(context, id, title, content, url, type);
                break;
        }
    }

    /**
     * 发送透传消息
     *
     * @param context
     * @param id
     * @param title
     * @param content
     */
    private static void sendMessage(Context context, String id, String title, String content, String url, String type) {
        Intent intent = new Intent();
        intent.setAction(ACTION_MESSAGE);
        intent.setPackage(context.getPackageName());
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("content", content);
        intent.putExtra("url", url);
        intent.putExtra("type", type);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        int smallIcon = PushHelper.pushConfig.getAppIcon();

        //实例化工具类，并且调用接口
        NotifyUtil notify1 = new NotifyUtil(context, 1);
        notify1.notify_normal_singline(pendingIntent, smallIcon, context.getString(R.string.newMessage), title, content, true, true, false);
    }


    private static void showNotify(Context context, String id, String title, String content, String url, String type) {
        //设置想要展示的数据内容
        Intent intent = new Intent(ACTION_CLICK);
        intent.setPackage(context.getPackageName());
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("content", content);
        intent.putExtra("url", url);
        intent.putExtra("type", type);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        int smallIcon = PushHelper.pushConfig.getAppIcon();

        //实例化工具类，并且调用接口
        NotifyUtil notify1 = new NotifyUtil(context, 1);
        notify1.notify_normal_singline(pendingIntent, smallIcon, context.getString(R.string.newMessage), title, content, true, true, false);
    }
}
