package com.rea.push.utils;

public class Error extends Exception{

    public Error(String message) {
      super(message);
    }
}
