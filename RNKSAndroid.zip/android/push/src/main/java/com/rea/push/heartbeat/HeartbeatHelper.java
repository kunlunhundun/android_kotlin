package com.rea.push.heartbeat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.widget.TextView;

import com.rea.commonUtils.log.LogUtil;
import com.rea.push.Push;
import com.rea.push.callback.PushCallBack;
import com.rea.push.config.InitConfig;
import com.rea.push.helper.PushHelper;


import java.util.UUID;


/**
 * author: Rea.X
 * date: 2017/3/9.
 */

public class HeartbeatHelper {
    private static Push push;
    private static boolean isInit = false;
    private static RequestBody mScheduleRequestBody;

    private static Context application;
    private static Receiver receiver;

    public static void startHeartbeat(Context context) {
        if (isInit) return;
        isInit = true;
        application = context.getApplicationContext();
        regReceiver();
        push = Push.getInstance();
        push.init(new InitConfig.Builder().CorePoolSize(5).Ip(PushHelper.pushConfig.getIP()).Port(PushHelper.pushConfig.getPort()).build());
        mScheduleRequestBody = new RequestBody(context);
        push.newScheduleRequest(mScheduleRequestBody, new PushCallBack(context, mScheduleRequestBody, push));

    }

    private static void regReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("loginSuccess");
        filter.addAction("loginOut");
        filter.addAction("applicationGotoBack");
        filter.addAction("applicationGotoFont");
        receiver = new Receiver();
        application.registerReceiver(receiver, filter);
    }

    private static void unRegReceiver() {
        if (receiver != null) {
            try {
                application.unregisterReceiver(receiver);
            } catch (Exception e) {
            }
        }
    }


    public static void stop() {
        push.stop();
        unRegReceiver();
    }

    private static class Receiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            LogUtil.e("guangbo >>>>" + intent.getAction());
            push.refreshData(mScheduleRequestBody);
        }
    }


    private static String getUUID(byte[] bs) {
        return UUID.nameUUIDFromBytes(bs).toString();
    }
}
