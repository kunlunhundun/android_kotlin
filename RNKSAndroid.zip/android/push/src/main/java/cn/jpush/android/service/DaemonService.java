package cn.jpush.android.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;

import com.rea.push.helper.PushHelper;

/**
 * author: Rea.X
 * date: 2017/3/13.
 */

public class DaemonService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (PushHelper.pushConfig != null)
            PushHelper.start(getApplication(), PushHelper.pushConfig);
        return super.onStartCommand(intent, flags, startId);
    }
}
