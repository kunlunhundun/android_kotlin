## 执行流程
``` bash
# 安装依赖包
npm i
# link
react-native link
# start server
npm start
# 新开窗口运行
react-native run-ios
# 关闭所有8081端口
kill $(lsof -t -i:8081)
# 拿到所有权限安装node包
npm install --unsafe-perm=true --allow-root
```
