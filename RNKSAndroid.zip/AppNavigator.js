import React from 'react'
import {
  Text, StyleSheet, TouchableHighlight, View, Image, TouchableOpacity, Platform,
} from 'react-native'
import { createStackNavigator } from 'react-navigation'
import { connect } from 'react-redux'
import {
  reduxifyNavigator,
  createReactNavigationReduxMiddleware
} from 'react-navigation-redux-helpers'
import ignoreWarnings from 'react-native-ignore-warnings'
import Login from './src/js/page/front/Login'
import Register from './src/js/page/front/Register'
import RegisterResult from './src/js/page/front/ResgisterResult'
import FindPassword from './src/js/page/front/FindPassword'
import ResetPassword from './src/js/page/front/ResetPassword'
import ChangePassword from './src/js/page/front/ChangePassword'
import Main from './src/js/page/front/Main'
import Games from './src/js/page/front/Games'
import Promo from './src/js/page/front/Promo'
import Legend from './src/js/page/front/Legend'
import Brand from './src/js/page/front/Brand'
import BrandContent from './src/js/page/front/BrandContent'
import Subscribe from './src/js/page/front/Subscribe'
import Download from './src/js/page/front/Download'
import PrivacyPolicy from './src/js/page/front/PrivacyPolicy'
import Message from './src/js/page/front/Message'
import MessageDetail from './src/js/page/front/MessageDetail'
import MyWebView from './src/js/page/front/MyWebView'
import LoadingPage from './src/js/page/front/LoadingPage';
<script src="http://localhost:8097" />;
ignoreWarnings([
  'Warning: isMounted(...) is deprecated',
  'Module RCTImageLoader',
  'Remote debugger',
  'Unable to symbolicate',
  'Not Found!',
  'Could not find image',
  'Require cycle',
  'Did not receive response',
  'Can\'t call setState',
  'ListView'
])
// refers to bug in React Navigation which should be fixed soon
// https://github.com/react-navigation/react-navigation/issues/3956

const middleware = createReactNavigationReduxMiddleware('root', state => state.nav)

const SCREENS = {
  Login: {
    screen: Login,
    title: 'login page and front ',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent',
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
      },
      headerBackTitleStyle: {
        marginTop: 40,
        paddingTop: 120
      },
      headerRight: (
        <Text
          style={[styles.headerRight,{
            marginTop: Platform.OS === 'ios' ? 0 : 30,
            textAlign: 'right',
            lineHeight: 40,
            width:60,
            height:40
          }]}
          onPress={() => {
            navigation.navigate('Register')
          }}
        >
          注册
        </Text>
      ),
      headerTintColor: 'white'
    })
  },
  Register: {
    screen: Register,
    title: 'Register',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerRight: (
        <Text
          style={[styles.headerRight,{
            marginTop: Platform.OS === 'ios' ? 0 : 30,
            textAlign: 'right',
            lineHeight: 40,
            width:60,
            height:40
          }]}
          onPress={() => {
            navigation.navigate('Login')
          }}
        >
          登录
        </Text>
      ),
      headerTintColor: 'white'
    })
  },
  RegisterResult: {
    screen: RegisterResult,
    title: '注册成功',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white',
      headerLeft: (
        <TouchableOpacity
          style={{
            width: 40,
            height: 66,
            paddingTop: 10,
          }}
          onPress={() => {
          navigation.navigate('Main')
          }}>
          <Image
            style={{
              width: 22,
              height: 22,
              marginLeft: 15,
              marginTop: Platform.OS === 'ios' ? 10 : 25
            }}
            source={require('./src/images/common/goBackIcon.png')}
          />
        </TouchableOpacity>
      ),
    })
  },
  FindPassword: {
    screen: FindPassword,
    title: '找回密码',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '找回密码',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  ResetPassword: {
    screen: ResetPassword,
    title: '设置新密码',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '设置新密码',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  ChangePassword: {
    screen: ChangePassword,
    title: '修改密码',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '修改密码',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Message: {
    screen: Message,
    title: '消息',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '消息',
      // header: null,
      headerBackTitle: null,
      header: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  MessageDetail: {
    screen: MessageDetail,
    title: '消息详情',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '消息详情',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  MyWebView: {
    screen: MyWebView,
    title: 'MyWebView',
    headerMode: 'none', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerLeft: null
      // headerStyle: {
      //   backgroundColor: 'transparent',
      //   borderBottomWidth: 0,
      //   headerTintColor: 'transparent'
      // },
      // headerTransparent: {
      //   position: 'absolute',
      //   top: 0,
      //   left: 0,
      //   right: 0,
      //   zIndex: 100
      // },
      // headerTintColor: 'white'
    })
    // navigationOptions: ({ navigation }) => ({
    //   headerBackTitle: null,
    //   headerStyle: {
    //     backgroundColor: 'transparent',
    //     borderBottomWidth: 0,
    //     headerTintColor: 'transparent'
    //   },
    //   headerLeft: (
    //     <TouchableOpacity
    //     style={{
    //       width: 40,
    //       height: 66,
    //       paddingTop: 10,
    //     }}
    //     onPress={() => {
    //     console.log(navigation)
    //     navigation.pop()
    //     }}>
    //     <Image
    //       style={{
    //         width: 15,
    //         height: 15,
    //         marginLeft: 15,
    //         marginTop: Platform.OS === 'ios' ? 10 : 25
    //       }}
    //       source={require('./src/images/common/goBackGray.png')}
    //     />
    //   </TouchableOpacity>
    //   ),
    //   headerTransparent: {
    //     position: 'absolute',
    //     top: 0,
    //     left: 0,
    //     right: 0,
    //     zIndex: 100
    //   },
    //   headerTintColor: 'white'
    // })
  },
  Games: {
    screen: Games,
    title: '老虎机游戏',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Promo: {
    screen: Promo,
    title: '福利列表',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Legend: {
    screen: Legend,
    title: '凯时英雄榜',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      headerBackTitle: null,
      header: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Brand: {
    screen: Brand,
    title: '凯时品牌',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  BrandContent: {
    screen: BrandContent,
    title: '凯时详情',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Subscribe: {
    screen: Subscribe,
    title: '订阅',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '订阅',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent'
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  Download: {
    screen: Download,
    title: '下载中心',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '下载中心',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent',
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  PrivacyPolicy: {
    screen: PrivacyPolicy,
    title: '隐私条例',
    headerMode: 'screen', // <-- should allow you to change the styles of the header
    navigationOptions: ({ navigation }) => ({
      // title: '下载中心',
      header: null,
      headerBackTitle: null,
      headerStyle: {
        backgroundColor: 'transparent',
        borderBottomWidth: 0,
        headerTintColor: 'transparent',
      },
      headerTitleStyle: {
        color: '#fff'
      },
      headerTransparent: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100
      },
      headerTintColor: 'white'
    })
  },
  LoadingPage: {
    screen: LoadingPage,
    headerMode: 'none',
    navigationOptions: {
      header: null,
      headerBackTitle: null
    }
  }
}

const RootNavigator = createStackNavigator({
  Main: {
    screen: Main,
    title: '主页',
    headerMode: 'none', // <-- should allow you to change the styles of the header
    // navigationOptions: ({ navigation }) => ({
    //   header: null,
    //   headerBackTitle: null,
    //   headerStyle: {
    //     backgroundColor: 'transparent',
    //     borderBottomWidth: 0,
    //     headerTintColor: 'transparent'
    //   },
    //   headerTransparent: {
    //     position: 'absolute',
    //     top: 0,
    //     left: 0,
    //     right: 0,
    //     zIndex: 100
    //   },
    //   headerTintColor: 'white'
    // })
  },
  ...SCREENS,
},
{
  initialRouteName: 'Main',
  navigationOptions: {
    gesturesEnabled: false,
    headerLeft: (
      <TouchableOpacity
        style={{
          width: 40,
          height: 66,
          paddingTop: 10,
        }}
        onPress={() => {
        navigation.pop()
        }}>
        {/* <Image
          style={{
            width: 22,
            height: 22,
            marginLeft: 15,
            marginTop: Platform.OS === 'ios' ? 10 : 25
          }}
          source={require('./src/images/common/goBackIcon.png')}
        /> */}
      </TouchableOpacity>
    ),
  }
}
)

const styles = StyleSheet.create({
  headerRight: {
    color: 'white',
    fontSize: 14,
    marginRight: 25,
    marginTop: 5
  }
});

const AppWithNavigationState = reduxifyNavigator(RootNavigator, 'root')

const mapStateToProps = state => ({
  state: state.nav
})
const AppNavigator = connect(mapStateToProps)(AppWithNavigationState)

export { RootNavigator, AppNavigator, middleware }
