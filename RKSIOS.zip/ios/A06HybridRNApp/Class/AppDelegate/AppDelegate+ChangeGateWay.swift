//
//  ChangeGateWay.swift
//  A06HybridRNApp
//
//  Created by kunlun on 18/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

extension AppDelegate {

  @objc func requestWelcome(gateWayAdd:String?){
    
    if requestTime >= 3 {
      if dynamicGwArr != nil && dynamicGwArr.count > selectGatewayIndex+1 {
        selectGatewayIndex = selectGatewayIndex + 1
        let selectGateWay = dynamicGwArr[safe:selectGatewayIndex] as? String
        requestWelcome(gateWayAdd: selectGateWay)
      }else{
        requestTime = 0
        selectGatewayIndex = 0
        requestNewAddressForApp()
      }
      return
    }
    
    requestTime = requestTime + 1
    let  paramDic = ManagerModel.configBasicParamDic()
    let gateWayAddress = gateWayAdd ?? EnviromentManager.gatewayAddressRequet_domain
    if gateWayAdd != nil {
    let  domainName = gateWayAddress.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "")
      ManagerModel.instanse.domainName = domainName
    }
   
    CaseyNetwork().requestJsonPost(gateWayAddress + Router.welcome.rawValue, parameters: paramDic) { [weak self] (result, error, isCache) in
      
      if  let _ = result {
        if (gateWayAdd?.count ?? 0 ) > 1 {
          EnviromentManager.saveGatewayAddress(gatewayAddress: gateWayAdd!)
        }
      }else{
        self?.requestWelcome(gateWayAdd: nil)
      }
    }
  }
  
  @objc func requestNewAddressForApp(){
    
    var  paramDic = ManagerModel.configBasicParamDic()
    paramDic["url"] = EnviromentManager.gatewayAddressRequet_domain

   _ =  CaseyNetwork().requestJsonPost("http://addr.neptuneapi.com:8888/getDsGwAddress", parameters: paramDic) { [weak self] (result, error, isCahce) in
      
      if  let jsonDic = result {
          let bodyArr = jsonDic["result"] as? Array<String>
          if bodyArr != nil {
            self?.dynamicGwArr = bodyArr
            let dynamicGWAddress = bodyArr?[safe:0] ?? ""
            self?.requestWelcome(gateWayAdd: dynamicGWAddress)
          }
      }else{
        
      }
    }
  }
  
}
