/**
 * Copyright (c) 2015-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import "AppDelegate.h"
#import "A06HybridRNApp-Swift.h"
#import <UIKit/UIKit.h>
#import <CodePush/CodePush.h>
#import <IQKeyboardManager/IQKeyboardManager.h>
#import "RNSplashScreen.h"
#import "PushNotificationCenter.h"
#import "HeartSocketManager.h"
#import "ThreeSTool.h"


@import Firebase;

@interface AppDelegate()

/** YES 点击通知栏启动app的推送消息, NO 相反 */
@property (assign, nonatomic) BOOL isLaunchPush;
/** 推送的消息 */
@property (strong, nonatomic) NSDictionary *pushUserInfo;

@property (assign,nonatomic) BOOL isRNLandcapeLeft;

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{

    _requestTime = 0;
    _selectGatewayIndex = 0;

    [FIRApp configure];
    [self configNet];
    [self configViewStyle];
    [self configRN];

    // 3s计划
    [ThreeSTool appdidFinishLaunching];
    [self configRootViewController];
    [RNSplashScreen show];

    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = YES;
    manager.shouldResignOnTouchOutside = YES;
    manager.shouldToolbarUsesTextFieldTintColor = YES;
    manager.enableAutoToolbar = NO;

  // 通知栏点击消息
  NSDictionary *userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
  if (userInfo) {
    application.applicationIconBadgeNumber = 0;
    self.isLaunchPush = YES;
    self.pushUserInfo = userInfo;
  }
  // 注册推送
  [RecivePushInfoCenter registerPushService:application didFinishLaunchingWithOptions:launchOptions];
  // 初始化心跳包
  [self configInitHeartSocketConfigWithIpAddress];

  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self requestWelcomeWithGateWayAdd:nil];
  });
  return YES;
}

+ (void)load{

}

- (void)requestWelcome{

}

+ (instancetype)sharedAppDelegate {
   return (AppDelegate *)[UIApplication sharedApplication].delegate;
}

- (UIViewController*)getParViewController:(UIView*)view {
  for (UIView* nextVC = [view superview];nextVC; nextVC = nextVC.superview) {
    UIResponder* nextResponder = [nextVC nextResponder];
    if ([nextResponder isKindOfClass:[UIViewController class]]) {
      return (UIViewController*)nextResponder;
    }
  }
  return nil;
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
  if (_isRNLandcapeLeft) {
    return UIInterfaceOrientationMaskLandscapeRight;
  }else if (_allowRotation == 1) {
    UIDeviceOrientation oriention = [UIDevice currentDevice].orientation;
    UIInterfaceOrientation interfaceOriention = (UIInterfaceOrientation)oriention;
    if (interfaceOriention == UIInterfaceOrientationPortrait) {

    }else{
    }
    return UIInterfaceOrientationMaskAllButUpsideDown;
  }else {
    return (UIInterfaceOrientationMaskPortrait);
  }

//  if (_allowRotation == 1) {
//    UIDeviceOrientation oriention = [UIDevice currentDevice].orientation;
//    UIInterfaceOrientation interfaceOriention = (UIInterfaceOrientation)oriention;
//    if (interfaceOriention == UIInterfaceOrientationPortrait) {
//
//    }else{
//    }
//    return UIInterfaceOrientationMaskAllButUpsideDown;
//  }else{
//    return (UIInterfaceOrientationMaskPortrait);
//  }
}


// 支持设备自动旋转
- (BOOL)shouldAutorotate{
  if (_allowRotation == 1) {
    return YES;
  }
  return NO;
}

- (void)setRNAllowRotation:(BOOL)allowRotation
{
  _isRNLandcapeLeft = allowRotation;
  if (allowRotation) {
    [[UIDevice currentDevice] setValue:@(UIDeviceOrientationLandscapeRight) forKey:@"orientation"];
  } else {
    [[UIDevice currentDevice] setValue:@(UIDeviceOrientationPortrait) forKey:@"orientation"];
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue: orientationTarget forKey:@"orientation"];
  }
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
  [ThreeSTool appDidEnterBackground];
}

#pragma mark 推送回调
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
  // 发送deveiceToken给服务器
  [self configSendHeartPacketWithApnsTokenWithDataToken:deviceToken];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
  if (!self.isLaunchPush) {
    [RecivePushInfoCenter receivedNotificationUserInfoWithUserInfo:userInfo isLaunching:self.isLaunchPush];
  }
}

// 在 iOS8 系统中，还需要添加这个方法。通过新的 API 注册推送服务
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings{
  [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
  if (!self.isLaunchPush) {
    [RecivePushInfoCenter receivedNotificationUserInfoWithUserInfo:userInfo isLaunching:self.isLaunchPush];
  }
  completionHandler(UIBackgroundFetchResultNewData);
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
  NSLog(@"didFailToRegisterForRemoteNotificationsWithError error:%@",error);
}

- (void)applicationWillResignActive:(UIApplication *)application {

}

- (void)configRN{

  NSURL *jsCodeLocation;
#ifdef DEBUG

 // jsCodeLocation = [NSURL URLWithString:@"http://10.71.66.111:8081/index.bundle?platform=ios&dev=true"]; //10.71.66.27 localhost
 jsCodeLocation = [NSURL URLWithString:@"http://10.62.64.104:8081/index.bundle?platform=ios&dev=true"];

#else
// jsCodeLocation = [CodePush bundleURLForResource:@"main" withExtension:@"jsbundle" subdirectory:@"Bundle/"]; // 10.71.66.59
#endif

  // jsCodeLocation = [NSURL URLWithString:@"http://10.71.241.25:8081/index.bundle?platform=ios&dev=true"];
  // jsCodeLocation = [NSURL URLWithString:@"http://10.71.66.27:8081/index.bundle?platform=ios&dev=true"];
  // jsCodeLocation = [NSURL URLWithString:@"http://10.71.66.59:8081/index.bundle?platform=ios&dev=true"];

  jsCodeLocation = [CodePush bundleURLForResource:@"main" withExtension:@"jsbundle" subdirectory:@"Bundle/"];

  RCTBridge *bridge = [[RCTBridge alloc] initWithBundleURL:jsCodeLocation
                                            moduleProvider:nil
                                             launchOptions:nil];
  self.rootView = [[RCTRootView alloc] initWithBridge:bridge moduleName:@"A06HybridRNApp" initialProperties:nil];
  [[ReactInteraction shareInstance] setValue:bridge forKey:@"bridge"];
}

@end
