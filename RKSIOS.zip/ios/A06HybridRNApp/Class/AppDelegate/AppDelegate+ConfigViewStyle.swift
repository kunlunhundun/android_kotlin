//
//  AppDelegate+ConfigViewStyle.swift
//  A06HybridRNApp
//
//  Created by Casey on 19/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

extension AppDelegate {
  @objc func configViewStyle()  {
      UIViewController.initializeOfSwift()
  }
}
