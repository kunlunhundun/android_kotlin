//
//  AppDelegate+ConfigRootViewCtr.swift
//  A06HybridRNApp
//
//  Created by Casey on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

extension AppDelegate {
  @objc func configRootViewController()  {
    
    let sandboxVersion = UserDefaults.standard.object(forKey: "CFBundleShortVersionString") as? String ?? ""
    let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
    
    if sandboxVersion.isEqual(currentVersion as String) == true && !sandboxVersion.isEqual("" as String){
      
      UIApplication.shared.statusBarStyle = .lightContent
      self.window = UIWindow.init(frame: UIScreen.main.bounds)
      self.window.backgroundColor = UIColor.black
      let tabBarVC = ManagerModel.shareInstanse().mainTabBarViewCtrl ?? MainTabBarViewCtroller()
      ManagerModel.shareInstanse().mainTabBarViewCtrl = tabBarVC
      self.window?.rootViewController = tabBarVC
      self.window.makeKeyAndVisible()
      
    }else{
      
      UIApplication.shared.statusBarStyle = .lightContent
      self.window = UIWindow.init(frame: UIScreen.main.bounds)
      self.window.rootViewController = SplashViewController()
      self.window.makeKeyAndVisible()
      self.window.backgroundColor = UIColor.black
    }
    CustomerViewModel.requestUpdateApp()
  }
  
  @objc func configInitHeartSocketConfigWithIpAddress(){
    HeartSocketManager.initHeartSocketConfig(withIpAddress: EnviromentManager.heartPacket_socket_ip, port: EnviromentManager.heartPacket_socket_port, porductId: "A06_KSZH")
  }
  
  @objc func configSendHeartPacketWithApnsToken(dataToken:Data){
    let customerId = ManagerModel.instanse.loginSuccessModel?.customerId?.toIntValue() ?? 0
    HeartSocketManager.shareInstance()?.sendHeartPacket(withApnsToken: dataToken, userid: Int32(customerId))
  }
}
