//
//  ConfigNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 19/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import XCGLogger
import SignCore
import Alamofire

let ServiceRootPath =  EnviromentManager.gatewayAddressRequet_domain //"http://www.pt-gateway.com" //

extension AppDelegate {
  
  @objc func configNet()  {
    
    let manager = NetworkReachabilityManager()//host:"https://www.baidu.com"
    EnviromentManager.networkReachabilitManager = manager
    EnviromentManager.networkReachabilitManager?.startListening()
    EnviromentManager.startNetworkReachabilityObserver()
    
    // 异常处理
    CaseyNetwork.exceptionHandleOfData = {  result  in
      
      if let headInfo = result?["head"] as? [String:Any]{
        
        if let errcode = headInfo["errCode"] as? String {
          
          print("exceptionHandleOfData---->\(String(describing: result))")
          if Int(errcode) == 0 { // 成功
            
            // 数据格式异常处理
            if let dataResult = result?["body"] as? [Any] {
              // 服务返回的是数组类型格式
              return (["result":dataResult] , nil)
            }else {
              return (result?["body"] as? [String:Any] , nil)
            }
          }else{ // 异常Code处理
            
            if errcode == SingleDeviceLogin_ErrorCode  {
              
             ManagerModel.singleDeviceLogout()
            }
            else if errcode == TokenExpired_ErrorCode || errcode == TokenInvalid_ErrorCode || errcode == TokenNotMatch_ErrorCode || errcode == TokenBad_ErrorCode {
              
                ManagerModel.tokenExpiredExitLogin()
              
            }
            
            let netErr = CaseyNetError.init(errcode, headInfo["errMsg"] as? String ?? "网络错误")
            return(nil, netErr)
          }
        }
      }
      return nil
    }
    
    // 公共参数头
    CaseyNetwork.requestHeaderParamCommon = { (newparam, bodyParam) in
      
      var preMd5Str = ""
      let domainName =   ManagerModel.getDomainNameInfo()
      let tempDeviceId = KeyChain.getKeychainIdentifierUUID()
      let deviceId:String = tempDeviceId ?? ""
      var  token = ""
      token =  ManagerModel.instanse.token
      if token.count < 1 {
        token = ManagerModel.instanse.infoModel?.token ?? ""
      }
      let qid = ManagerModel.creatUUID()
      if let param = bodyParam {
        let paramJson = BaseJsonTool.dictionaryToString(param as [String : AnyObject])
        preMd5Str = paramJson + qid + config_appId + DeviceTool.getAppVersion() + ReadChannelDomain.getParentId() + domainName + token + deviceId
      }else{
        preMd5Str = qid + config_appId + DeviceTool.getAppVersion() + ReadChannelDomain.getParentId() + domainName + token  + deviceId
      }
      
      let keyEnum = (EnviromentManager.currentEnvironment == .Local_Environment) ? "1" : "0"
      let finalMd5Str =  SignUtil.getSign(preMd5Str, qid: qid , keyEnum: keyEnum)
      
      var  headers = ["pid":config_pid]
      headers["appId"] = config_appId
      headers["sign"] = finalMd5Str
      headers["qid"] = qid
      headers["v"] = DeviceTool.getAppVersion()
      headers["domainName"] = domainName
      headers["deviceId"] = deviceId
      headers["token"] = token
      headers["parentId"] = ReadChannelDomain.getParentId()
      headers["Content-Type"] = "application/json"
      return headers
    }
    
    // 公共参数体
    CaseyNetwork.requestBodyParamCommon = { (oldParam) in
      
      var newParam = [String:Any]()
      
      if (oldParam != nil) {
        for param in oldParam! {
          newParam[param.key] = param.value
        }
      }
      
      let commonParam =  ManagerModel.configLoginNameParamDic()
      
      for param in commonParam {
        newParam[param.key] = param.value
      }
      
      return newParam
    }
  }
}
