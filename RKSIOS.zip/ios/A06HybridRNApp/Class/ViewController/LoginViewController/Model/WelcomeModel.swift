//
//  WelcomModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/6.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class WelcomeModel:HandyJSON{

  var image:String?
  var key0: String?
  var link: String?
  var addrServiceUrl:String?
  var mWebUrl:String?
  var h5DownUrl:String?
  var h5VersionId:String?
  var h5Md5 : String?
  var publicKey: String?
  var info: String?
  var webInfo:String?
  
  required init() { }
}

class InfoModel:HandyJSON{
  
  var token:String?
  var u2token: String?
 
  required init() { }
}


class UpdateVersionModel:HandyJSON {

  var appDownUrl:String?
  var versionCode:String?
  var versionId:String?
  var flag:String?

  required init() {
    
  }
}
