//
//  HomeRNViewController.m
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//
#import "HomeRNViewController.h"
#import "A06HybridRNApp-Swift.h"
#import "DataPickerView.h"
#import "RNSplashScreen.h"
#import "AppInitializeValueConfig.h"
#import "PopoverViewController.h"
#import "UIViewController+YCPopover.h"

@interface HomeRNViewController ()

@property (nonatomic, assign) BOOL hasRecord;

@end

@implementation HomeRNViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  
  self.navigationItem.title = @"首页";
  self.navigationItem.leftBarButtonItem = nil;
  
  NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
  [storage setCookieAcceptPolicy:NSHTTPCookieAcceptPolicyAlways];
  self.view = [AppDelegate sharedAppDelegate].rootView;
  
  [NBSAppAgent setRedirectURL:@"app.tingyunfenxi.com"];
  [NBSAppAgent startWithAppID:@"7f815140b0654e43be6413bb5de41ffb"];
  
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if ([ManagerModel shareInstanse].curLoginName.length > 1){
        [NBSAppAgent setUserIdentifier:[ManagerModel shareInstanse].curLoginName];
    }
  });
  //[self advertisingAlert];
}

#pragma mark - life cycle
- (void)viewWillAppear:(BOOL)animated{
  [super viewWillAppear:animated];
  self.navigationController.navigationBar.hidden = true;
  [[ManagerModel shareInstanse] showHidenTabbar:true];
}
- (void)viewDidAppear:(BOOL)animated{
  [super viewDidAppear:animated];
  [RNSplashScreen hide];
  if (!_hasRecord) {
    [IN3SAnalytics launchFinished];
    _hasRecord = YES;
  }
}

- (void)viewWillDisappear:(BOOL)animated{
  [super viewWillDisappear:animated];
  self.navigationController.navigationBar.hidden = false;
}

#pragma mark - 活动
- (void)advertisingAlert{
  UIView *view = [[UIView alloc]init];
  view.frame = CGRectMake(0, 0, IPHONE_WIDTH, IPHONE_HEIGHT);
  view.backgroundColor = [UIColor redColor];
  UIWindow *window = [UIApplication sharedApplication].delegate.window;
  [window addSubview:view];
  
//  PopoverViewController *vc = [PopoverViewController new];
//  [self yc_bottomPresentController:vc presentedHeight:IPHONE_HEIGHT completeHandle:^(BOOL presented) {
//    if (presented) {
//      NSLog(@"弹出了");
//    }else{
//      NSLog(@"消失了");
//    }
//  }];

}

@end
