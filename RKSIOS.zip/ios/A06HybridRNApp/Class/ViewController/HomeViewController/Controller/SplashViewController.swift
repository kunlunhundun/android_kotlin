//
//  SplashViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 13/02/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController,UIScrollViewDelegate {
  
  var count:Int = 0
  var timer:Timer!
  var hasRecord:Bool = false
  var threeStool:ThreeSTool = ThreeSTool()
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    creatFeaturesUI()
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    destoryTimer()
    doSomething()
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    if (!hasRecord) {
      ThreeSTool.filshedLanch()
      hasRecord = true
    }
  }
  
  @objc func creatFeaturesUI(){
    self.view.backgroundColor = UIColor.view_backBlack
    let imgView = UIImageView.init(frame: .zero)
    self.view.addSubview(imgView)
    imgView.contentMode = UIViewContentMode.scaleAspectFill
    imgView.image = UIImage.init(named: "start_guiding")
    imgView.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
    }
    let nextBtn = UIButton.init(frame: .zero)
    self.view.addSubview(nextBtn)
    nextBtn.layer.cornerRadius = 6
    nextBtn.setTitle("立即体验", for: .normal)
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.titleLabel?.font = UIFont.PFMXL_Font
    nextBtn.setTitleColor(UIColor.init(byteRed: 255, green: 255, blue: 255, alpha: 1), for: .normal)
    nextBtn.addTarget(self, action: #selector(goToHomeStart), for: .touchUpInside)
    nextBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-20)
      make.left.equalToSuperview().offset(20)
      make.bottom.equalToSuperview().offset(-45)
      make.height.equalTo(45)
    }
  }

  @objc func timerEvent(_ timer:Timer){
    count = count + 1
    let timecount = 5-count >= 0 ?  5-count : 0
    if timecount == 0 {
      goToHomeStart()
    }
  }
  
  @objc func goToHomeStart(){
    destoryTimer()
    let tabBarVC = ManagerModel.shareInstanse().mainTabBarViewCtrl  ?? MainTabBarViewCtroller()
    let transtition = CATransition()
    transtition.duration = 1.5
    transtition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut)
    UIApplication.shared.keyWindow?.layer.backgroundColor = UIColor.black.cgColor
    UIApplication.shared.keyWindow?.layer.add(transtition, forKey: "animation")
    UIApplication.shared.keyWindow?.rootViewController = tabBarVC
    let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
    UserDefaults.standard.set(currentVersion, forKey: "CFBundleShortVersionString")
    UserDefaults.standard.synchronize()
  }

  @objc func destoryTimer(){
    if timer != nil {
      if timer!.isValid {
        timer?.invalidate()
        timer = nil
      }
    }
  }
  
 @objc func doSomething() {
    if ManagerModel.shareInstanse().mainTabBarViewCtrl == nil {
      let tabBarVC = MainTabBarViewCtroller()
      ManagerModel.shareInstanse().mainTabBarViewCtrl = tabBarVC
    }
  }

 @objc func creatTimer() {
    timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerEvent(_ : )), userInfo: nil, repeats: true)
    timer.fire()
    RunLoop.current.add(timer!, forMode: .commonModes)
  }
}
