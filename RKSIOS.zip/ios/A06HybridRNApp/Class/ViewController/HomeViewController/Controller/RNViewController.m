//
//  RNViewController.m
//  A06HybridRNApp
//
//  Created by kunlun on 12/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "RNViewController.h"

@interface RNViewController ()

@end

@implementation RNViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated{
  [super viewWillAppear:animated];
  self.navigationController.navigationBar.hidden = true;
}

- (void)viewWillDisappear:(BOOL)animated{
  [super viewWillDisappear:animated];
  self.navigationController.navigationBar.hidden = false;
}

@end
