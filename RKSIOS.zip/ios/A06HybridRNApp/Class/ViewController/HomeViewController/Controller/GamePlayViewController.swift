//
//  GameplayViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 02/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit
import WebKit
import RxSwift
import XCGLogger

enum GameNameType:Int {
  case sportGame = 1
  case agGame = 2
  case ptGame = 3
  case elecGame = 4
}

class GamePlayViewController: UIViewController,WKUIDelegate,WKNavigationDelegate,WKScriptMessageHandler,UIGestureRecognizerDelegate  {

  var webView:WKWebView!
  var gameWebUrl:String?
  var refreshBtn:UIButton?
  let disposeBag = DisposeBag()
  var viewModel:GamePlayViewModel?
  var requestGameModel:RequestGameModel?
  var gameNameType:GameNameType = .agGame
  var screenOrientation:Bool = false //检测屏幕方向的改变 true 为横屏， false 竖屏
  var isLandscape:Bool = false       //true 为横屏, false 竖屏
  var isAgDidFinish:Bool = false
  var isAgDidFailProvisional:Bool = false
  var threeStool:ThreeSTool = ThreeSTool()
  var isPreloading:Bool = false
  
  let loadingView:GameLoadingView = GameLoadingView.getLoadingView()

  convenience init(requestModel:RequestGameModel?){
    self.init()
    self.requestGameModel = requestModel
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    if requestGameModel?.fakeGameComeFrom.contains("Main") == false {
      ManagerModel.instanse.showHidenTabbar(true)
    }
  }
  
  override func viewDidLoad() {
      super.viewDidLoad()
      initData()
      setupWKwebView()
      setAGRightBtnView()
  }
  
  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    AppDelegate.shared()?.allowRotation = false
    pausePlay()
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = false
    ManagerModel.instanse.showHidenTabbar(false)
  }
  
  override func viewDidDisappear(_ animated: Bool) {
    super.viewDidDisappear(animated)
    
  }
  
  func initData(){
    
    if requestGameModel?.gameCode.contains("6031") == true ||
      requestGameModel?.gameCode.contains("A06062") == true ||
      requestGameModel?.gameCode.contains("A06004") == true {
      AppDelegate.shared()?.allowRotation = false
      gameNameType = .sportGame
    }
    else if requestGameModel?.gameType.contains("BAC") == true &&
      requestGameModel?.gameCode.contains("A06003") == true {
      AppDelegate.shared()?.allowRotation = false
      gameNameType = .agGame
      self.title = "AG旗舰"
    }
    else if requestGameModel?.gameCode.contains("A06026") == true {
      self.title = "AG国际"
      gameNameType = .elecGame
      AppDelegate.shared()?.allowRotation = true
    }
    else{
      gameNameType = .elecGame
      AppDelegate.shared()?.allowRotation = true
      self.title = "电子游戏"
    }
    
    viewModel = GamePlayViewModel()
    requestGameData()
    
    viewModel?.gameModelSubject.subscribe(onNext: {[weak self] (gameModel:GameModel) in
    
      let domian = EnviromentManager.gatewayAddressRequet_domain
      let url = domian + "/_glaxy_a06_/game/inGame"
      
      // 获取url的时长
      if gameModel.error == nil {
        
        if self?.requestGameModel?.gameType.contains("BAC") == true &&
          self?.requestGameModel?.gameCode.contains("A06003") == true {
          self?.threeStool.endRequest(withUrl: url, code: 200, message: nil)
          //let start:String = self?.threeStool.start ?? ""
          //let end:String = self?.threeStool.end ?? ""
          //print("获取url的开始时间" + start )
          //print("获取url结束的时间" + end )
        }
        
      }else{
        
        if self?.requestGameModel?.gameType.contains("BAC") == true &&
          self?.requestGameModel?.gameCode.contains("A06003") == true {

          let code:String = gameModel.error?.kl_code ?? ""
          let codeInt = integer_t(code)
          self?.threeStool.endRequest(withUrl: url, code: codeInt ?? 0, message:"请求失败，网络故障")
        }
      }
      
      if gameModel.error?.kl_code?.contains("GW_800605") == true {
        self?.requestGameData()
      }else{
        LoadingView.hideLoadingView(for: self?.view)
        self?.jumpInGame(gameModel: gameModel)
      }
      
      },onError: {  [weak self] (error ) in
        
        LoadingView.hideLoadingView(for: self?.view)
    }).disposed(by:disposeBag)
  }
  
  func setupWKwebView() {
  
    self.edgesForExtendedLayout = UIRectEdge.init(rawValue: 0)
    UIApplication.shared.isIdleTimerDisabled = true
    self.automaticallyAdjustsScrollViewInsets = false;
    let webConfiguration = WKWebViewConfiguration()
    webConfiguration.preferences = WKPreferences()
    webConfiguration.preferences.javaScriptEnabled = true
    webConfiguration.preferences.javaScriptCanOpenWindowsAutomatically = true
    webConfiguration.processPool = WKProcessPool()
    webConfiguration.allowsInlineMediaPlayback = true
    webConfiguration.mediaPlaybackRequiresUserAction = true;

    webConfiguration.userContentController = WKUserContentController()
    webView = WKWebView(frame: view.bounds, configuration: webConfiguration)
    webView.uiDelegate = self
    webView.navigationDelegate = self
    view.addSubview(webView)
    
    let swipeDown = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeDownAction(_:)))
    swipeDown.direction = .down
    swipeDown.delegate = self
    webView.addGestureRecognizer(swipeDown)
    let swipeUp = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeDownAction(_:)))
    swipeUp.direction = .up
    swipeUp.delegate = self
    webView.addGestureRecognizer(swipeUp)
    
    webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
    webView.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
      make.top.equalToSuperview().offset((gameNameType == .agGame) ? 0 : 0)
    }
    
    if #available(iOS 11.0, *) {
      webView.scrollView.contentInsetAdjustmentBehavior = .never
    }
    loadingView.backgroundColor = color2a2e32
    loadingView.setLabtext("正在为您跳转游戏界面，请稍后……")
    loadingView.defautProgress()
    self.view.addSubview(loadingView)
  }
  
  override func viewWillLayoutSubviews() {
    super.viewWillLayoutSubviews()
    let interfaceOrientation = UIApplication.shared.statusBarOrientation
   
    if gameNameType == .agGame {
      if interfaceOrientation == .portrait || interfaceOrientation == .portraitUpsideDown {
        self.navigationController?.setNavigationBarHidden(false, animated: true )
        webView.snp.remakeConstraints { (make) in
          make.edges.equalToSuperview()
          make.top.equalToSuperview().offset(-32 )
        }
      }else if interfaceOrientation == .landscapeLeft || interfaceOrientation == .landscapeRight {
        self.navigationController?.setNavigationBarHidden(true , animated: true )
        webView.snp.remakeConstraints { (make) in
          make.edges.equalToSuperview()
          make.top.equalToSuperview().offset(0)
        }
      }
      return
    }
    //横屏第一次进入
    if screenOrientation == false && (interfaceOrientation == .landscapeLeft || interfaceOrientation == .landscapeRight)
    {
      screenOrientation = true
      self.navigationController?.setNavigationBarHidden(true , animated: true )
    }//竖屏第一次进入
    else if screenOrientation == false && (interfaceOrientation == .portrait || interfaceOrientation == .portraitUpsideDown ){
      
    }//有横屏切换到竖屏显示导航栏
    else if screenOrientation == true && (interfaceOrientation == .portrait || interfaceOrientation == .portraitUpsideDown ){
      self.navigationController?.setNavigationBarHidden(false, animated: true )
      screenOrientation = false
    }
  }

  @objc func swipeDownAction(_ swipeGesture:UISwipeGestureRecognizer){
  
    if gameNameType == .agGame || gameNameType == .sportGame {
      return
    }
    if swipeGesture.direction == .down {
      self.navigationController?.setNavigationBarHidden(false, animated: true)
    }else if swipeGesture.direction == .up {
      self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
  }
  
  func requestGameData(){
    guard let requestDataModel = requestGameModel else {
      return
    }
    
    if self.requestGameModel?.gameType.contains("BAC") == true &&
      self.requestGameModel?.gameCode.contains("A06003") == true {
      self.threeStool.startRequestWithUrl()
    }
    
    viewModel?.requestGameUrl(requestGameModel: requestDataModel)
  }
  
  // gameCode
  func transTogame(){
    viewModel?.transferToGame(gameCode: requestGameModel?.gameCode ?? "")
  }
  
  func jumpInGame(gameModel:GameModel){
    
    if gameModel.postMap?.gameType?.contains("PT") == true {
      gameNameType = .ptGame
      let gameID = (gameModel.url ?? "") + "?gameID=" + (gameModel.postMap?.gameID ?? "")
      let gameType = "&gameType=" + (gameModel.postMap?.gameType ?? "")
      let username = "&username=" + (gameModel.postMap?.username ?? "")
      let password = "&password=" + (gameModel.postMap?.password ?? "")
      let gameStr = gameID + gameType + username + password
      let  objGameUrl = NSString(string: gameStr)
      let  gameUrlStr = objGameUrl.addingPercentEscapes(using: String.Encoding.utf8.rawValue) ?? ""
      gameWebUrl = gameUrlStr
      
      let str = "/game"
      let deRange = gameUrlStr.range(of: str)
      let backNumbers = gameUrlStr.suffix(from: deRange!.lowerBound)
      
      gameWebUrl = EnviromentManager.gatewayAddressRequet_domain + backNumbers
      guard  let gameURL = URL(string: gameWebUrl ?? "" ) else {
        return
      }
    
      webView.load(URLRequest(url: gameURL ))
    }else if gameNameType == .agGame {
      AppDelegate.shared()?.allowRotation = false
      let agWebUrlStr = (gameModel.url ?? "") + "&webApp=true"
       let objGameUrlStr = NSString(string: agWebUrlStr  )
      let gameUrlStr = objGameUrlStr.addingPercentEscapes(using: String.Encoding.utf8.rawValue) ?? ""
      guard  let gameURL = URL(string: gameUrlStr ) else {
        return
      }
      gameWebUrl = gameUrlStr
      webView.load(URLRequest(url: gameURL ))
    
    } else {
      
      let objGameUrl = NSString(string: gameModel.url ?? "" )
       let  gameUrlStr = objGameUrl.addingPercentEscapes(using: String.Encoding.utf8.rawValue) ?? ""
      guard  let gameURL = URL(string: gameUrlStr ) else {
        return
      }
      gameWebUrl = objGameUrl as String
      webView.load(URLRequest(url: gameURL))
    }
  }
  
  func refreshAnimation(){
    let rotationAnimation = CABasicAnimation.init(keyPath: "transform.rotation.z")
    rotationAnimation.toValue = NSNumber.init(value: Double.pi*2.0)
    rotationAnimation.duration = 0.5
    rotationAnimation.repeatCount = 8
    refreshBtn!.layer.add(rotationAnimation, forKey: "rotationAnimation")
  }
  
  @objc func refreshAction(){
    guard  let gameURL = URL(string: gameWebUrl ?? "" ) else {
      return
    }
    refreshAnimation()
    webView.load(URLRequest.init(url: gameURL))
  }
  
  // 客服和刷新
  func setAGRightBtnView(){
    let customerBtn = UIButton.init(frame: CGRect.init(x: 50, y: 0, width: 40, height: 44))
    customerBtn.setImage(UIImage.init(named: "icon_customer"), for: .normal)
    customerBtn.contentHorizontalAlignment = .right
    customerBtn.addTarget(self, action: #selector(rightBtnAction), for: .touchUpInside)
    
    refreshBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 40, height: 44))
    refreshBtn!.setImage(UIImage.init(named: "icon_refresh"), for: .normal)
    refreshBtn!.addTarget(self, action: #selector(refreshAction), for: .touchUpInside)
    
    let barBtnView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 100, height: 44) )
    barBtnView.addSubview(customerBtn)
    barBtnView.addSubview(refreshBtn!)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.rightBarButtonItem  = barButtonItem
  }
  
  // 客服
  func setRightBtnView(){
    let rightBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 80, height: 44))
    rightBtn.setImage(UIImage.init(named: "icon_customer"), for: .normal)
    rightBtn.contentHorizontalAlignment = .right
    let barBtnView = UIView.init(frame: rightBtn.bounds)
    barBtnView.addSubview(rightBtn)
    rightBtn.addTarget(self, action: #selector(rightBtnAction), for: .touchUpInside)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.rightBarButtonItem  = barButtonItem
  }
  
  @objc func rightBtnAction(){
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = true
    self.navigationController?.pushViewController(CustomerOnlineHtmlViewController(), animated: true)
  }
  
  func pausePlay(){
    webView.evaluateJavaScript("pauseVideo()") { (data, error) in
    }
    webView.evaluateJavaScript("pauseAudio()") { (data, error) in
    }
  }
  
  func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
    return true
  }
  
  override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    var progressValue:Float = 0
    if keyPath == "estimatedProgress"{
      progressValue = Float(CGFloat(webView.estimatedProgress))
      let pross = CGFloat(webView.estimatedProgress) * 100
      loadingView.setProgress(CGFloat(pross))
    }
    if progressValue >= 0.95{
      if self.isAgDidFinish == false {
        if self.isAgDidFailProvisional == true {
          self.refreshAction()
        }
      }
      let time: TimeInterval = 0.5
      DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) { [weak self] in
        if self?.isAgDidFinish != false {
          self?.loadingView.cancelrimer()
          self?.loadingView.removeFromSuperview()
        }
      }
    }
  }
  
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    XCGLogger.debug("\(message)")
  }
  
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    isAgDidFinish = true
    XCGLogger.debug("didFinish")
    if self.requestGameModel?.gameType.contains("BAC") == true &&
      self.requestGameModel?.gameCode.contains("A06003") == true {
      self.threeStool.agqjWebViewDidFinishLoad(webView)
      self.threeStool.endPreload()
    }
  }
  func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
    isAgDidFailProvisional = true
    XCGLogger.debug("didFailProvisionalNavigation")
  }
  func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
    XCGLogger.debug("didFail navigation")
    if self.requestGameModel?.gameType.contains("BAC") == true &&
      self.requestGameModel?.gameCode.contains("A06003") == true {
      self.threeStool.agqjWebViewDidFailLoad(webView, error: error)
    }
  }
  func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    XCGLogger.debug("didStartProvisionalNavigation")
    if self.requestGameModel?.gameType.contains("BAC") == true &&
      self.requestGameModel?.gameCode.contains("A06003") == true {
      self.threeStool.agqjWebViewStartLoad()
      self.threeStool.startPreload()
    }
    
    if gameNameType == .sportGame {
      if webView.url?.absoluteString.contains("stoken=logout") == true {
        return
      }
      if webView.url?.absoluteString.contains("logout") == true {
        self.navigationController?.popViewController(animated: true)
      }
    }
    
   let gatewayAddressDomain_http =  EnviromentManager.gatewayAddressRequet_domain.replacingOccurrences(of: "https", with: "http") + "/"
    let gatewayAddressDomain_https = EnviromentManager.gatewayAddressRequet_domain + "/"
    
    if gameNameType != .agGame {
      if webView.url?.absoluteString.hasPrefix("\((gatewayAddressDomain_https + "game/fslotgame"))") == true ||
        webView.url?.absoluteString.hasPrefix("\((gatewayAddressDomain_http + "game/fslotgame"))") == true {
        self.navigationController?.popViewController(animated: true)
      }
    }

    if gameNameType != .ptGame && ( webView.url?.absoluteString.contains(gatewayAddressDomain_https) == true || webView.url?.absoluteString.contains(gatewayAddressDomain_http) == true ) {
      self.navigationController?.popViewController(animated: true)
      return
    }
  
    let absolutString = webView.url?.absoluteString
    if absolutString?.contains("landscape.html") == true || absolutString?.contains("portrait.html") == true
      || absolutString?.contains("sensor.html") == true || absolutString?.contains("disconnect.html") == true {
      refreshBtn?.layer.removeAllAnimations()
    }
    if absolutString?.contains("landscape.html") == true {
      refreshBtn?.isHidden = true
      AppDelegate.shared()?.allowRotation = true
    }
    if absolutString?.contains("portrait.html") == true {
      DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1) { [weak self] in
          self?.refreshBtn?.isHidden = false
      }
      AppDelegate.shared()?.allowRotation = false
    }
    if absolutString?.contains("sensor.html") == true {
      refreshBtn?.isHidden = true
      AppDelegate.shared()?.allowRotation = true
    }
    if absolutString?.contains("disconnect.html") == true {
      refreshBtn?.isHidden = false
      pausePlay()
      refreshAction()
      XCGLogger.debug("ProvisionalNavigati--->absolutString------->\(absolutString)")
    }
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
   // print("navigationAction.request.url?.absoluteString----->\(navigationAction.request.url?.absoluteString)")
    decisionHandler(WKNavigationActionPolicy.allow)
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
    decisionHandler(WKNavigationResponsePolicy.allow)
  }
  
  func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
    
    // 判断是否是信任服务器证书
    if challenge.protectionSpace.authenticationMethod
      == NSURLAuthenticationMethodServerTrust {
      // 告诉服务器，客户端信任证书
      // 创建凭据对象
      let card = URLCredential.init(trust: challenge.protectionSpace.serverTrust!)
      // 告诉服务器信任证书
      completionHandler(URLSession.AuthChallengeDisposition.useCredential, card)
    }
  }
  
  func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
    XCGLogger.debug("\(message)")
    
    let alertController = UIAlertController.init(title: message, message: nil, preferredStyle: .alert)
    alertController.addAction(UIAlertAction.init(title: "确定", style: .cancel, handler: { (action) in
      completionHandler()
    }))
    self.present(alertController, animated: true) {
      alertController.view.backgroundColor = UIColor.clear
    }
  }
  
  func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
    
    XCGLogger.debug("\(message)")
    let alertController = UIAlertController.init(title: "网络不稳定", message: nil, preferredStyle: .alert)
    alertController.addAction(UIAlertAction.init(title: "返回", style: .default, handler: { (action) in
      completionHandler(true)
      self.navigationController?.popViewController(animated: true)
    }))
  
    alertController.addAction(UIAlertAction.init(title: "刷新", style: .cancel, handler: { (action) in
      completionHandler(true)
      self.refreshAction()
    }))
    self.present(alertController, animated: true) {
      alertController.view.backgroundColor = UIColor.clear
    }
  }
  
  deinit{
     XCGLogger.debug("deinit ----> \(self.classForCoder)")
  }
  
//  ProgressTopPopView.showPopViewCallBack(content: "您还未绑定手机号,请绑定后再操作", popStyle: .oneTitleConfirm, confirmTitle:"去绑定" ,callBackBlock: { [weak self] (isConfirm) in
//  if isConfirm {
//  let bindPhoneVC = BindPhoneViewController()
//  self?.nearNav()?.pushViewController(bindPhoneVC, animated: true)
//  bindPhoneVC.finishBindCallBackBlock = {
//  self?.needBindBankCard()
//  }
//  }else{
//  self?.navigationController?.popViewController(animated: true)
//  }
//  })

}
