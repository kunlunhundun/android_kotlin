//
//  GamePlayViewModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 02/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit
import HandyJSON
import RxSwift

class GameModel: HandyJSON {
  
  var gameType:String?
  var gameCode:String?

  var url:String?
  var formMethod:String?
  var postMap:PostMapModel?
 
  
  var error:APIError?
  
  required init() {}
}
class PostMapModel: HandyJSON {
  
  var gameID:String?
  var gameType:String?
  var password:String?
  var username:String?
  
  required init() {}
}

class RequestGameModel: HandyJSON {
  
  var gameCode:String = ""
  var gameId:String = ""
  var gameName:String = ""
  var gameType:String = ""
  
  var comeFrom:String = ""
  var fakeGameComeFrom = ""
  
  var gameUrl:String?
  var loginName:String = ""
  var loginStateChange:Bool = false
  
  required init() {}
}


class GamePlayViewModel: NSObject {

  let gameModelSubject = PublishSubject<GameModel>()

   func requestGameUrl(requestGameModel:RequestGameModel) {
    
    var paramDic = ManagerModel.configLoginNameParamDic()
    paramDic["gameCode"] = requestGameModel.gameCode
    paramDic["gameType"] = requestGameModel.gameType
    paramDic["gameId"] = requestGameModel.gameId
    paramDic["gameName"] = requestGameModel.gameName
    
    APITool.request(.comeInGame, parameters: paramDic, successHandle: { [weak self] (gameModel : GameModel) in
      
      gameModel.gameType = requestGameModel.gameType
      gameModel.gameCode = requestGameModel.gameCode
      self?.gameModelSubject.onNext(gameModel)
      
    }) { [weak self] (apiError) in
      
      let error = apiError ?? APIError()
      let gameModel = GameModel()
      gameModel.error = error
      self?.gameModelSubject.onNext(gameModel)
    }
  }
  

  func transferToGame(gameCode:String) {
    
    var paramDic:[String:String] = [:]
    paramDic["gameCode"] = gameCode
    paramDic["domainName"] = ManagerModel.getDomainNameInfo()
    paramDic["loginName"] = ManagerModel.instanse.curLoginName
    paramDic["productId"] = "A06"
    
    APITool.request(.transferToGame, parameters: paramDic, successHandle: { (gameModel : GameModel) in

    }) { (apiError) in

    }
  }
}
