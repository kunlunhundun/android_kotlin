//
//  WithDrawViewModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 17/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import XCGLogger

class WithDrawViewModel: NSObject {

  override init() {
    super.init()
  }
  
  
 class func requestQueryByKeyList(){
    
    var param = ManagerModel.configLoginNameParamDic()
    param["keys"] = ["cdnDomainNames"]
    APITool.request(.queryByKeyList, parameters: param, successHandle: {  (cdnDomainNameModel:CDNDomainNameModel) in
      
      ManagerModel.instanse.cdnDomainNameModel = cdnDomainNameModel
      ManagerModel.instanse.fastCdnDomainName = cdnDomainNameModel.cdnDomainNames?[safe:0] ?? ""
      XCGLogger.debug("fastCdnDomainName------>\(ManagerModel.instanse.fastCdnDomainName )")
      
    }) { (error) in
      print("requestQueryByKeyList error \n")
      //failureHandleBlok(error)
    }
  }
  
  func requestGetBalance( finishHandleBlock:@escaping (_ withDrawModel:WithDrawModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    var param = ManagerModel.configLoginNameParamDic()
    param["flag"] = "1"
    APITool.request(.getBalance, parameters: param, successHandle: {  (withDrawModel : WithDrawModel) in
      
      ManagerModel.instanse.totalAmount = withDrawModel.balance ?? ""
      finishHandleBlock(withDrawModel)
      
    }) { (apiError) in
      print("queryOnlineBanks error \n")
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func rquestQueryBankAndBit( finishHandleBlock:@escaping (_ bankCardBtcListModel:BankCardBtcModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    let param = ManagerModel.configLoginNameParamDic()
    
    APITool.request(.queryBankAndBit, parameters: param, successHandle: {  (bankCardBtcListModel : BankCardBtcModel) in
      
      finishHandleBlock(bankCardBtcListModel)
      
    }) { (apiError) in
      print("queryOnlineBanks error \n")
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  
  }
  
  func rquestWithDrawQueryBtcRate(amount:String,finishHandleBlock:@escaping (_ btcRateModel:QueryBtcRateModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    var param = ManagerModel.configLoginNameParamDic()
    param["amount"] = amount
    APITool.request(.queryBtcRate, parameters: param, successHandle: {  (btcRateModel : QueryBtcRateModel) in
      
      finishHandleBlock(btcRateModel)
      
    }) { (apiError) in
      print("queryOnlineBanks error \n")
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
    
  }
  
  func rquestCreateRequest(param:[String:Any],finishHandleBlock:@escaping (_ createRequestModel:CreateRequestModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    APITool.request(.createRequest, parameters: param, successHandle: {  (createRequestModel : CreateRequestModel) in
      finishHandleBlock(createRequestModel)
      
    }) { (apiError) in
      print("queryOnlineBanks error \n")
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
    
  }
  
  
}
