//
//  WashCodeViewModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 19/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class WashCodeViewModel: NSObject {

  var washCodeModel:WashCodeModel?
  
  override init() {
    super.init()
  }
  
 
  
  func requestXmCalcAmountV2( finishHandleBlock:@escaping (_ washCodeModel:WashCodeModel)->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    let param = ManagerModel.configLoginNameParamDic()

    APITool.request(.xmCalcAmountV2, parameters: param, successHandle: { [ weak self ] (codeModel:WashCodeModel) in
      
      self?.washCodeModel = codeModel
      finishHandleBlock(codeModel)

    }) { (error) in
      print("queryOnlineBanks error \n")
      let error = error ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestXmCreateRequest( finishHandleBlock:@escaping (_ xmCreateRequestModel:XmCreateRequestModel)->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    var param = ManagerModel.configLoginNameParamDic()
    
    guard let xmListModel = washCodeModel?.xmList else {
      return
    }
    if xmListModel.count < 1 {
      return
    }
    var xmListArr:[Any] = []
    for xmModel in xmListModel {
      guard let xmTypeArr = xmModel.xmTypes else{
        break
      }
      for xmTypeDic in xmTypeArr  {
        let xmTypeAmount = xmTypeDic["betAmount"]
        if xmTypeAmount == nil {
          break
        }
        guard  let typeAmont = "".anyToString(value: xmTypeAmount!) else{
          break
        }
        if (Double(typeAmont) ?? 0 )  >= (Double(washCodeModel?.minBetAmount ?? "0.1") ?? 0.1 )  {
          xmListArr.append(xmTypeDic)
        }
      }
    }

    let xmBeginDate = washCodeModel?.xmBeginDate ?? ""
    let xmEndDate = washCodeModel?.xmEndDate ?? ""
    param["xmBeginDate"] = xmBeginDate
    param["xmEndDate"] = xmEndDate
    param["xmRequests"] = xmListArr
    
    
    
    
    APITool.request(.xmCreateRequest, parameters: param, successHandle: { (xmCreateRequestModel:XmCreateRequestModel) in
      
      finishHandleBlock(xmCreateRequestModel)
      
    }) { (error) in
      print("queryOnlineBanks error \n")
      let error = error ?? APIError()
      failureHandleBlok(error)
    }
    
   
  }
  
  
  

}
