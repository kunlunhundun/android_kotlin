//
//  WashCodeAlertView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 19/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class WashCodeAlertView: UIView {

  let washHeight:CGFloat = 220

  static var  washCodeAlertView:WashCodeAlertView?
  private var callbackBlock: ((_ sureAction:Int)->Void)?
  private var selectIndex:Int = 0
  private var tipPaywayLab:UILabel!
  var washCodeModel:WashCodeModel?
  var xmCreateRequestModel:XmCreateRequestModel?

  var moneyLab:UILabel!
  var minXMAmountTipLab:UILabel!
  var loadingView:UIView!
  var listTableView:WashCodeListTableView!
  var viewModel:WashCodeViewModel!
  var disposeBag = DisposeBag()
  let detailExpendBtn = ActivityAllButton()
  
  override  init(frame: CGRect) {
    super.init(frame: frame)
    
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-washHeight-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: washHeight)
    self.layer.cornerRadius = 10.0
    
    setupView()
    initData()
  }

  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func initData(){
    
    viewModel = WashCodeViewModel()
    loadingView.isHidden = false
    LoadingView.showLoadingViewForWithDraw(to: self.loadingView)
    viewModel.requestXmCalcAmountV2(finishHandleBlock: { [weak self] (codeModel) in
      LoadingView.hideLoadingView(for: self?.loadingView)
      self?.washCodeModel = codeModel
      self?.refreshXmCodeModelData()
      self?.loadingView.isHidden = true

    }) { [weak self] (error) in
      LoadingView.hideLoadingView(for: self?.loadingView)
      self?.loadingView.isHidden = true
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
 
  func refreshXmCodeModelData(){
    moneyLab.text = "¥ " + (self.washCodeModel?.totalXmAmount ?? "" )
    
    let count:Double = self.washCodeModel?.totalXmAmount?.toDoubleValue() ?? 0
    if count >= "300".toDoubleValue() {
      minXMAmountTipLab.text = "洗码金额会在提交后10分钟内到账"
    }else{
      minXMAmountTipLab.text =  "单一类型可洗码投注额需≥" + (self.washCodeModel?.minBetAmount ?? "") + "元"
    }
    
    listTableView.minBetAmount = self.washCodeModel?.minBetAmount
  }
  
  func setupView(){
    self.backgroundColor = UIColor.view_popBlackColor
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "全部洗码"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    
    let washCodeMoneyView = UIView.init(frame: .zero)
    self.addSubview(washCodeMoneyView)
    washCodeMoneyView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(lineView.snp.bottom)
      make.height.equalTo(110)
    }
    
    moneyLab = UILabel.init(frame: .zero)
    washCodeMoneyView.addSubview(moneyLab)
    moneyLab.textAlignment = .center
    moneyLab.textColor = UIColor.view_white
    moneyLab.font = UIFont.PFM30_Font
   
    moneyLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview().offset(33)
      make.height.equalTo(30)
      make.right.equalToSuperview().offset(-100)
      make.left.equalToSuperview().offset(100)
    }
    
    detailExpendBtn.setTitle("详细展开", for: .normal)
    detailExpendBtn.setImage(UIImage.init(named: "arrow_down"), for: .normal)
    detailExpendBtn.setImage(UIImage.init(named: "arrow_up"), for: .selected)
    detailExpendBtn.addTarget(self, action: #selector(detailExpendBtnAction(_:)), for: .touchUpInside)
    washCodeMoneyView.addSubview(detailExpendBtn)
    detailExpendBtn.snp.makeConstraints { (make) in
      make.bottom.equalTo(moneyLab.snp.bottom).offset(0)
      make.right.equalToSuperview().offset(-20)
      make.width.equalTo(80)
      make.height.equalTo(28)
    }
    
    minXMAmountTipLab = UILabel.init(color: UIColor.font_purplishRedColor, font: UIFont.PFML_Font)
    washCodeMoneyView.addSubview(minXMAmountTipLab)
    minXMAmountTipLab.textAlignment = .center
    minXMAmountTipLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(moneyLab.snp.bottom)
      make.bottom.equalToSuperview()
    }
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((self.newWidth-10*3)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("确认洗码", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(10)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
    
    listTableView =  WashCodeListTableView.init(frame: .zero)
    self.addSubview(listTableView)
    listTableView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(washCodeMoneyView.snp.bottom)
      make.height.equalTo(0)
    }
    
    loadingView = UIView.init(frame: CGRect.init(x: 0, y: 40, width: self.newWidth, height: self.newHeight-40))
    loadingView.backgroundColor = UIColor.view_popBlackColor
    self.addSubview(loadingView)
    loadingView.isHidden = false
    loadingView.layer.cornerRadius = 10.0
  }
  
  
  func showWashCodeSuccessView(){
    
    let washCodeSuccessView = WashCodeSuccessInfoView.init(xmRequestModel: self.xmCreateRequestModel)
    
    MaskView.show(subView: washCodeSuccessView)
    
    let walltime = DispatchWallTime.now() + 5
    DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
      let detailAmountView =  WashCodeDetailAmountView.init(frame: CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 0), xmRequestModel: self.xmCreateRequestModel)
    
      detailAmountView.knowBtn.rx.tap.asObservable().subscribe(onNext: {
        MaskView.hiden()
        }).disposed(by: self.disposeBag)
      detailAmountView.isHidden = true
      MaskView.maskView?.addSubview(detailAmountView)
      
      UIView.animate(withDuration: 0.8, animations: {
        washCodeSuccessView.frame =  CGRect.init(x: CGFloat(View_Margin), y: STATUS_NAV_BAR_Y, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 220)
      }, completion: { (isSuccess) in
        detailAmountView.isHidden = false
        UIView.animate(withDuration: 0.5, animations: {
          detailAmountView.frame =   CGRect.init(x: CGFloat(View_Margin), y: STATUS_NAV_BAR_Y + 220 + 10, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 360)
        })
      })
    }
  }

  class func showPopView(sureBlock:@escaping (_ sureAction:Int)->Void ) {
    washCodeAlertView = WashCodeAlertView.init(frame: .zero )
    washCodeAlertView?.callbackBlock = sureBlock
    washCodeAlertView?.showView()
  }
  
  func showView(){
    MaskView.show(subView: self)
  }
  
  func hidenView(){
    MaskView.hiden()
  }
  
  @objc func detailExpendBtnAction(_ btn:UIButton){
    
    btn.isSelected = !btn.isSelected
    if btn.isSelected {
      var count = self.washCodeModel?.xmList?.count ?? 0
      if count > 0 {
        count = count > 4 ? 4 : count
        let tabHeight = (count + 1) * 40
        
        UIView.animate(withDuration: 0.3) {
          self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-self.washHeight-BOTTOM_MARGIN-CGFloat(tabHeight), width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: self.washHeight + CGFloat(tabHeight) )
          self.listTableView.snp.updateConstraints { (make) in
            make.height.equalTo(tabHeight)
          }
          self.listTableView.refreshData(xmListModel: self.washCodeModel?.xmList)
          self.listTableView.setNeedsUpdateConstraints()
          // 调用此方法告诉self.view检测是否需要更新约束，若需要则更新，下面添加动画效果才起作用
          self.listTableView.updateConstraintsIfNeeded()
          self.layoutIfNeeded()
        }
        detailExpendBtn.setTitle("点击收起", for: .normal)
      }
  
    }else{ 
      
      UIView.animate(withDuration: 0.3) {
        self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-self.washHeight-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: self.washHeight)
        self.listTableView.snp.updateConstraints { (make) in
          make.height.equalTo(0)
        }
        self.listTableView.setNeedsUpdateConstraints()
        // 调用此方法告诉self.view检测是否需要更新约束，若需要则更新，下面添加动画效果才起作用
        self.listTableView.updateConstraintsIfNeeded()
        self.layoutIfNeeded()
      }
      detailExpendBtn.setTitle("详细展开", for: .normal)
    }
  }
  
  @objc func cancelAction(){
    if callbackBlock != nil {
      callbackBlock?(-1)  //取消
    }
    hidenView()
  }
  
  @objc func sureAction(){
    
    let totalBetAmount = (self.washCodeModel?.totalBetAmount ?? "" )
    let minBetAmount =  (self.washCodeModel?.minBetAmount ?? "")
    let content = "单一游戏类型投注额不足" + minBetAmount + "元，请投注满额后再试"
    if totalBetAmount.toIntValue() < minBetAmount.toIntValue() {
      ProgressTopPopView.showPopView(content:  content, popStyle: .errorMsgToast)
      DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1.5) {
        self.closeAction()
      }
      return
    }
  
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-washHeight-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: washHeight)
    listTableView.snp.updateConstraints { (make) in
      make.height.equalTo(0)
    }
    loadingView.isHidden = false
    LoadingView.showLoadingViewForWithDraw(to: self.loadingView)
    viewModel.requestXmCreateRequest(finishHandleBlock: { [weak self] (xmRequestModel) in
      LoadingView.hideLoadingView(for: self?.loadingView)
      self?.loadingView.isHidden = true
      self?.xmCreateRequestModel = xmRequestModel
      self?.showWashCodeSuccessView()
      
    }) { [weak self] (error) in
      LoadingView.hideLoadingView(for: self?.loadingView)
      self?.loadingView.isHidden = true
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1.5) {
        self?.closeAction()
      }
    }
  
    if callbackBlock != nil {
      callbackBlock?(selectIndex)
    }
    //  hidenView()
  }
  @objc private func closeAction(){
    hidenView()
  }
}
