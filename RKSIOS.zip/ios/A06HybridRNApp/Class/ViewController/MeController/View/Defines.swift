//
//  Defines.swift
//  A06App
//
//  Created by bux on 2018/11/6.
//  Copyright © 2018 James. All rights reserved.
//

import Foundation
import UIKit

//let View_Margin:CGFloat = 20.0


let fontSegSemiBold16:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 16)
let fontSegSemiBold20:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 20)
let fontSegSemiBold28:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 28)

let fontpfl14:UIFont? = UIFont.init(name: "PingFangSC-Light", size: 14)
let fontpfr14:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 14)
let fontpfr15:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 15)
let fontpfr16:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 16)
let fontpfm16:UIFont? = UIFont.init(name: "PingFangSC-Medium", size: 16)

let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height


let color2a2e32 = UIColor.init(hex: 0x2A2E32)
let color292d30 = UIColor.init(hex: 0x292D30)
let color2c2e38 = UIColor.init(hex: 0x2C2E38)
let color888888 = UIColor.init(hex: 0x888888)
let color333333 = UIColor.init(hex: 0x333333)
let colorc0c0c0 = UIColor.init(hex: 0xc0c0c0)
