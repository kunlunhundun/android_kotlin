//
//  WashCodeSuccessInfoView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 20/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class WashCodeSuccessInfoView: UIView {

  var  xmAmountLab:UICountingLabel!
  
  convenience init(xmRequestModel:XmCreateRequestModel?) {
    self.init()
    self.backgroundColor = UIColor.view_popBlackColor

    self.frame = CGRect.init(x: CGFloat(View_Margin), y: (SCREEN_HEIGHT-220)/2.0, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 220)
    self.layer.cornerRadius = 5.0
    
    let userNameLab = UILabel.init(color: UIColor.view_white, font: UIFont.SF24_Font)
    self.addSubview(userNameLab)
    userNameLab.text = xmRequestModel?.loginName
    userNameLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.top.equalToSuperview().offset(20)
      make.width.equalTo(self.newWidth-100)
      make.height.equalTo(30)
    }
    let vipLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    self.addSubview(vipLab)
    vipLab.text =  ManagerModel.instanse.loginSuccessModel?.starLevelName
    let vipsize = vipLab.sizeThatFits(CGSize.init(width: 60, height: 30))
    vipLab.textAlignment = .right
    vipLab.snp.makeConstraints { (make) in
      make.top.equalTo(userNameLab.snp.top)
      make.right.equalToSuperview().offset(-View_Margin)
      make.width.equalTo(vipsize.width)
      make.height.equalTo(30)
    }
    let vipImgView = UIImageView.init(frame: .zero)
    self.addSubview(vipImgView)
    
    let path = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/VIP", ofType: "png")
    let image = UIImage.init(contentsOfFile: path ?? "")
    vipImgView.image = image
    vipImgView.snp.makeConstraints { (make) in
      make.right.equalTo(vipLab.snp.left).offset(-10)
      make.centerY.equalTo(vipLab.snp.centerY)
      make.width.equalTo(26)
      make.height.equalTo(21)
    }
    
    let amountDesLab = UILabel.init(color: UIColor.view_white, font: UIFont.L_Font)
    self.addSubview(amountDesLab)
    amountDesLab.text = "总资产"
    amountDesLab.snp.makeConstraints { (make) in
      make.left.equalTo(userNameLab.snp.left)
      make.top.equalToSuperview().offset(100)
      make.width.equalTo(100)
      make.height.equalTo(20)
    }
    
    let moneyImgView = UIImageView.init(frame: .zero)
    let pathStr = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/RMB", ofType: "png")
    let images = UIImage.init(contentsOfFile: pathStr ?? "")
    self.addSubview(moneyImgView)
    moneyImgView.image = images
    
    moneyImgView.snp.makeConstraints { (make) in
      make.left.equalTo(userNameLab.snp.left)
      make.top.equalTo(amountDesLab.snp.bottom).offset(20)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let totalAmountLab = UICountingLabel.init(frame: .zero)
    totalAmountLab.textColor = UIColor.view_white
    totalAmountLab.font = UIFont.SF28_Font
    totalAmountLab.format = "%.2f"
    self.addSubview(totalAmountLab)
    totalAmountLab.text =  ManagerModel.instanse.totalAmount  //xmRequestModel?.xmAmount //"5052.35"
    var fromAmount = Double(ManagerModel.instanse.totalAmount) ?? 0.0
    var toAmount = (Double(xmRequestModel?.xmAmount ?? "0") ?? 0.0) + fromAmount
    let fromAmountStr = String(format: "%.2f", fromAmount)
    let toAmountStr = String(format: "%.2f", toAmount)
    fromAmount = Double(fromAmountStr) ?? 0.0
    toAmount = Double(toAmountStr) ?? 0.0
    
    print("fromAmount---->\(fromAmount) toAmount----->\(toAmount) fromAmountStr--->\(fromAmountStr) toAmountStr--->\(toAmountStr)")
    print("cgfloatFromamount---->\(CGFloat(fromAmount))  CGFloat(toAmount)---->\(CGFloat(toAmount))")
    DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now() + 1.5) {
      totalAmountLab.count(from: CGFloat(fromAmount) , to: CGFloat(toAmount), withDuration: 3)
    }
    
   // totalAmountLab.count(from: CGFloat(fromAmount) , to: CGFloat(toAmount), withDuration: 2)
    let size = totalAmountLab.sizeThatFits(CGSize.init(width: 180, height: 30))
    totalAmountLab.snp.makeConstraints { (make) in
      make.left.equalTo(moneyImgView.snp.right).offset(10)
      make.top.equalTo(moneyImgView.snp.top)
      make.width.equalTo(size.width+20)
      make.height.equalTo(30)
    }
    
   // let xmAmountLab = UILabel.init(color: UIColor.font_pinkRedColor, font: UIFont.SF24_Font)
     xmAmountLab = UICountingLabel.init(frame: .zero)
    xmAmountLab.textColor = UIColor.font_pinkRedColor
    xmAmountLab.font = UIFont.SF24_Font
//    let formatter = NumberFormatter.init()
//    formatter.numberStyle = .decimal
//    xmAmountLab.formatBlock = { (value) in
//      return "+" + String(format: "%.2f", value)
//    }
    self.addSubview(xmAmountLab)
    xmAmountLab.text = "+" + (xmRequestModel?.xmAmount ?? "")
    
  //  let dxmAmount = Double(xmRequestModel?.xmAmount ?? "0")!
   // let fxmAmount = CGFloat(dxmAmount)
   // xmAmountLab.count(from: fxmAmount , to: 0.0, withDuration: 5)
    
    let walltime = DispatchWallTime.now() + 1.5
    DispatchQueue.main.asyncAfter(wallDeadline: walltime) { [weak self] in
      self?.xmAmountLab.isHidden = true
    }
   
    xmAmountLab.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.left.equalTo(totalAmountLab.snp.right).offset(15)
      make.top.equalTo(moneyImgView.snp.top)
      make.height.equalTo(30)
    }
  
  }
  
}


class WashCodeDetailAmountView:UIView {
  
  var knowBtn:UIButton!
  var listTableView:WashCodeListTableView!
  
  var xmCreateRequestModel:XmCreateRequestModel?
  convenience  init(frame: CGRect,xmRequestModel:XmCreateRequestModel?) {
    self.init(frame: frame)
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: (SCREEN_HEIGHT+220)/2.0 + 10, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 10)
    self.clipsToBounds = true
    xmCreateRequestModel = xmRequestModel
    setupView()
  }
  
  func setupView(){
    self.backgroundColor = UIColor.view_popBlackColor
    self.layer.cornerRadius = 5.0
    
    let xmAmountDesLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    xmAmountDesLab.frame = CGRect.init(x: View_Margin, y: 30, width: 90, height: 30)
    self.addSubview(xmAmountDesLab)
    xmAmountDesLab.text = "实际洗码金额"
   
    let xmAmountLab = UILabel.init(color: UIColor.view_white, font: UIFont.SF28_Font)
    xmAmountLab.frame =  CGRect.init(x: xmAmountDesLab.newRight + 20, y: 30, width: self.newWidth-15-90-15-20, height: 32)
    self.addSubview(xmAmountLab)
    
    let dxmAmount = Double(xmCreateRequestModel?.xmAmount ?? "0")!
    let fxmAmount = CGFloat(dxmAmount)
    xmAmountLab.text = "¥ " + String(format: "%.2f", fxmAmount)
  
    listTableView = WashCodeListTableView.init(frame: .zero)
    listTableView.frame = CGRect.init(x: 0, y: xmAmountLab.newBottom+30, width: self.newWidth , height: 200)
    self.addSubview(listTableView)
    listTableView.refreshSuccessInfoData(xmListResultModel: xmCreateRequestModel?.xmResult)
  //  listTableView.refreshData(xmListModel: T##[XMListModel]?)
    
    knowBtn = UIButton.init(frame: CGRect.init(x: 10, y: listTableView.newBottom+10, width: self.newWidth-10*2 , height: 48))
    self.addSubview(knowBtn)
    knowBtn.backgroundColor = UIColor.btn_rightRed
    knowBtn.setTitle("我知道了", for: .normal)
    knowBtn.layer.cornerRadius = 5.0
    
  }
  
  
}



