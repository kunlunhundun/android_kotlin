//
//  UpDateVersionPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 07/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class UpDateVersionPopView: UIView {

  private var callbackBlock: ((_ cancel:Bool)->Void)?
  var contentView:UIView!
  var backView:UIView!
  override init(frame: CGRect) {
    super.init(frame: frame)
    self.frame =  UIScreen.main.bounds
    self.backgroundColor = UIColor.view_backBlack.withAlphaComponent(0.7)
    setupView()
  }

  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  private func setupView()  {
    
    contentView = UIView.init(frame: .zero)
    contentView.layer.cornerRadius = 10
    contentView.layer.masksToBounds = true
    
    self.addSubview(contentView)
    contentView.backgroundColor = UIColor.init(colorValue: 0x1F2337)  //1F2337
    contentView.snp.makeConstraints { (make) in
//      make.left.equalToSuperview().offset(15)
//      make.right.equalToSuperview().offset(-15)
      make.center.equalToSuperview()
      make.height.equalTo(422)
      make.width.equalTo(300)
    }
    
    let imageView = UIImageView.init(frame: .zero)
    imageView.image = UIImage.init(named: "icon_update")
    contentView.addSubview(imageView)
    imageView.snp.makeConstraints { (make) in
      make.top.equalToSuperview().offset(30)
      make.width.equalTo(133)
      make.height.equalTo(151)
      make.centerX.equalToSuperview()
    }
    
    let titleLab = UILabel.init(color: UIColor.white, font: UIFont.PFML_Font)
    contentView.addSubview(titleLab)
    titleLab.textAlignment = .center
    titleLab.text = "发现新版本"
    titleLab.snp.makeConstraints { (make) in
      make.top.equalTo(imageView.snp.bottom).offset(15)
      make.left.right.equalToSuperview()
      make.height.equalTo(20)
    }
    
    let contentLab = UILabel.init(color: UIColor.white, font: UIFont.M_Font)
    contentView.addSubview(contentLab)
    contentLab.textAlignment = .center
    contentLab.numberOfLines = 0
    contentLab.text = "为了加强应用稳定性，确保账户安全，请您立即更新应用"
    contentLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.top.equalTo(titleLab.snp.bottom).offset(15)
    }
    
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    contentView.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(confirmAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("立即升级", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-20)
      make.left.equalToSuperview().offset(20)
      make.height.equalTo(48)
      make.bottom.equalToSuperview().offset(-20)
    }
  }

  @objc func confirmAction(){
    callbackBlock?(true)
    self.removeFromSuperview()
  }
  
  func showView(){
    UIApplication.shared.delegate?.window??.addSubview(self)
  }
  
  class func showPopViewCallBack(cancelTitle:String, callBackBlock:@escaping (_ cancel:Bool)->Void){
    let popView = UpDateVersionPopView.init()
    popView.callbackBlock = callBackBlock
    popView.showView()
  }
}
