//
//  BtcRateToastView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 18/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class BtcRateToastView: UIView {

  var toastLab:UILabel!
  override init(frame: CGRect) {
    super.init(frame: frame)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    
    self.isHidden = true

    let  btcToastView = UIView.init(frame: CGRect.init(x: 15, y: 10, width: SCREEN_WIDTH-30, height: 50))
    self.addSubview(btcToastView)
    btcToastView.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
    btcToastView.layer.cornerRadius = 6
    btcToastView.layer.borderColor = UIColor.init(colorValue: 0x515C5F).cgColor
    btcToastView.layer.borderWidth = 1.0
    toastLab = UILabel.init(frame: btcToastView.bounds)
    btcToastView.addSubview(toastLab)
    toastLab.textColor = UIColor.white
    toastLab.font = UIFont.M_Font
    toastLab.textAlignment = .center
    //toastLab.text = "= 0.14537 比特币(BTC)"
    
  }
  func setToastLabContent(content:String){
    
    toastLab.text = "= " + content +  " 比特币(BTC)"
    NSString.changeUILablePartColor(toastLab, change: content, andAllColor: UIColor.white, andMark: UIColor.font_purplishRedColor, andMark: UIFont.M_Font)
    
  }
  
  
}
