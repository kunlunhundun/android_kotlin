//
//  ProgressTopPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 11/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

enum ProgressPopStyle:Int {
  case chargeOrder = 0
  case errorMsgToast = 1
  case successMsgToast = 2
  case oneTitleConfirm = 3
}

class ProgressTopPopView: UIView {

  var toastLabel:UILabel!
  var popStyle:ProgressPopStyle = .chargeOrder
  var contentView:UIView!
  var oneTitleBackBtn:UIButton?
  private let visualEfView = UIVisualEffectView.init(effect: UIBlurEffect.init(style: UIBlurEffect.Style.extraLight)) //

  
  private var callbackBlock: ((_ cancel:Bool)->Void)?

  convenience init( style:ProgressPopStyle){
    self.init()
    self.frame =  UIScreen.main.bounds
    popStyle = style

    contentView = UIView.init(frame: .zero)
    self.addSubview(contentView)
    contentView.addSubview(visualEfView)
    contentView.backgroundColor = UIColor.clear
    
    var height = 80
    if style == .chargeOrder {
      setupChargeOrderView()
      height = 140
    }else if style == .errorMsgToast{
      setupErrorView()
    }
    else if style == .successMsgToast {
      setupSuccessView()
    }
    else if style == .oneTitleConfirm {
      setupOneTitleConfirmView()
      height = 104
    }
    
    contentView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalToSuperview().offset(STATUSBAR_HEIGHT)
      make.height.equalTo(height)
    }
    visualEfView.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
    }
  }
  

  func setupSuccessView(){
    let successIcon = UIImageView(image: UIImage.init(named:"正确提示icon"))
    contentView.addSubview(successIcon)
    successIcon.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(15)
      make.centerY.equalTo(contentView)
    }
    let successLabel = UILabel.init(color: color333333,font: fontpfr14)
    successLabel.text="您的取款将在XX分钟后到账。"
    successLabel.numberOfLines = 0
    toastLabel = successLabel
    contentView.addSubview(successLabel)
    successLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(contentView)
      make.left.equalTo(contentView).offset(50)
      make.right.equalToSuperview().offset(-20)
    }
  }
  
  func setupErrorView(){
    let errorIcon = UIImageView(image: UIImage.init(named:"错误提示icon.png"))
    contentView.addSubview(errorIcon)
    errorIcon.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(15)
      make.centerY.equalTo(contentView)
    }
    toastLabel = UILabel.init(color: color333333,font: fontpfr14)
    toastLabel.text = ""
    toastLabel.numberOfLines = 0
    contentView.addSubview(toastLabel)
    toastLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(contentView)
      make.left.equalTo(contentView).offset(50)
      make.right.equalToSuperview().offset(-20)
    }
  }
  
  
  func setupOneTitleConfirmView(){
    
    let errorIcon = UIImageView(image: UIImage.init(named:"错误提示icon.png"))
    contentView.addSubview(errorIcon)
    errorIcon.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(15)
      make.centerY.equalTo(contentView)
    }
    let titleLabel = UILabel.init(color: color333333,font: fontpfr14)
    titleLabel.text = ""
    titleLabel.numberOfLines = 0
    toastLabel = titleLabel
    contentView.addSubview(titleLabel)
    titleLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(contentView)
      make.left.equalTo(contentView).offset(50)
      make.right.equalToSuperview().offset(-20)
    }
    
    let backBtn = UIButton.init(frame: .zero)
    contentView.addSubview(backBtn)
    oneTitleBackBtn = backBtn
    backBtn.addTarget(self, action: #selector(confirmAction), for: .touchUpInside)
    backBtn.setTitle("确定", for: .normal)
    backBtn.setTitleColor(color333333, for: .normal)
    backBtn.titleLabel?.font = UIFont.PFMM_Font
    backBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-20)
      make.width.equalTo(60)
      make.height.equalTo(30)
      make.bottom.equalToSuperview().offset(-10)
    }
    
    let cancelBan = UIButton.init(frame: .zero)
    contentView.addSubview(cancelBan)
    cancelBan.addTarget(self, action: #selector(cancelAction(_ : )), for: .touchUpInside)
    cancelBan.setTitle("取消", for: .normal)
    cancelBan.setTitleColor(color333333, for: .normal)
    cancelBan.titleLabel?.font = UIFont.M_Font
    cancelBan.snp.makeConstraints { (make) in
      make.right.equalTo(backBtn.snp.left).offset(-10)
      make.width.equalTo(40)
      make.height.equalTo(30)
      make.bottom.equalToSuperview().offset(-10)
    }
  }
  
  
  func setupChargeOrderView(){
    
    let leftIcon = UIImageView(image: UIImage.init(named:"错误提示icon.png"))
    contentView.addSubview(leftIcon)
    leftIcon.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(30)
      make.top.equalToSuperview().offset(20)
      make.width.equalTo(20)
      make.height.equalTo(20)
    }
    let headLab = UILabel.init(color: color333333,font: UIFont.PFML_Font)
    headLab.text="确定返回上一步？"
    contentView.addSubview(headLab)
    headLab.snp.makeConstraints { (make) in
      make.left.equalTo(leftIcon.snp.right).offset(15)
      make.right.equalToSuperview().offset(-15)
      make.top.equalTo(leftIcon.snp.top)
      make.height.equalTo(20)
    }
    
    let oneLab = UILabel.init(color: color333333, font: UIFont.M_Font)
    contentView.addSubview(oneLab)
    oneLab.text = "如果尚未完成支付，当前充值订单将失效。"
    oneLab.snp.makeConstraints { (make) in
      make.left.equalTo(headLab.snp.left)
      make.right.equalToSuperview().offset(-20)
      make.top.equalTo(headLab.snp.bottom).offset(10)
      make.height.equalTo(20)
    }
    let twoLab = UILabel.init(color: color333333, font: UIFont.M_Font)
    contentView.addSubview(twoLab)
    twoLab.text = "已完成的支付，可在交易记录中查询状态。"
    twoLab.snp.makeConstraints { (make) in
      make.left.equalTo(headLab.snp.left)
      make.right.equalToSuperview().offset(-20)
      make.top.equalTo(oneLab.snp.bottom).offset(5)
      make.height.equalTo(20)
    }
    
    let backBtn = UIButton.init(frame: .zero)
    contentView.addSubview(backBtn)
    backBtn.addTarget(self, action: #selector(backAction(_ : )), for: .touchUpInside)
    backBtn.setTitle("返回", for: .normal)
    backBtn.setTitleColor(color333333, for: .normal)
    backBtn.titleLabel?.font = UIFont.PFMM_Font
    backBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-20)
      make.width.equalTo(60)
      make.height.equalTo(30)
      make.bottom.equalToSuperview().offset(-10)
    }
    
    let cancelBtn = UIButton.init(frame: .zero)
    contentView.addSubview(cancelBtn)
    cancelBtn.addTarget(self, action: #selector(cancelAction(_ : )), for: .touchUpInside)
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.setTitleColor(color333333, for: .normal)
    cancelBtn.titleLabel?.font = UIFont.M_Font
    cancelBtn.snp.makeConstraints { (make) in
      make.right.equalTo(backBtn.snp.left).offset(-10)
      make.width.equalTo(40)
      make.height.equalTo(30)
      make.bottom.equalToSuperview().offset(-10)
    }
  }
  
  @objc func backAction(_ sendBtn:UIButton) {
    UIViewController.getCurrentShow()?.navigationController?.popViewController(animated: true)
    self.removeFromSuperview()
  }
  
  @objc func cancelAction(_ sendBtn:UIButton){
    callbackBlock?(false)
    self.removeFromSuperview()
  }
  
  @objc func confirmAction(){
    callbackBlock?(true)
    self.removeFromSuperview()
  }

  func showView(){
    UIApplication.shared.delegate?.window??.addSubview(self)
    if popStyle != .chargeOrder && popStyle != .oneTitleConfirm {
      let walltime = DispatchWallTime.now() + 1.5
      DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
        self.removeFromSuperview()
      }
    }
  }
  
  class func showPopViewCallBack(content:String = "", popStyle:ProgressPopStyle = .chargeOrder, confirmTitle:String = "确定" , callBackBlock:@escaping (_ cancel:Bool)->Void){
    let popView = ProgressTopPopView.init(style: popStyle)
    if popStyle == .chargeOrder {
      
    }else{
      popView.toastLabel.text = content
      popView.oneTitleBackBtn?.setTitle(confirmTitle, for: .normal)
    }
    popView.callbackBlock = callBackBlock
    popView.showView()
  }
  
  class func showPopView(content:String = "", popStyle:ProgressPopStyle = .chargeOrder){
    let popView = ProgressTopPopView.init(style: popStyle)
    if popStyle == .chargeOrder {
      
    }else{
      popView.toastLabel.text = content
    }
    popView.showView()
  }
}
