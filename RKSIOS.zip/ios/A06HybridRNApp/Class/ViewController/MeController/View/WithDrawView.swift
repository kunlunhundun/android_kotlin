//
//  WithDrawView.swift
//  A06App
//
//  Created by bux on 2018/11/6.

import Foundation
import UIKit
import SnapKit
import ReactiveSwift
import RxCocoa
import RxSwift
import ReactiveCocoa


class WithDrawView: UIView , UITextFieldDelegate {
  
  var totalMoneyLabel:UILabel!
  var refreshBtn:UIButton!
  var withDrawLabel:UILabel!
  var btcRateTipLab:UILabel!
  var drawToImgView:UIImageView!
  var drawToLabel:UILabel!
  var expandBtn:UIButton!
  var drawBackBtn:UIButton!
  
  var pswField:BaseTextfiled!
  var amountField:BaseTextfiled!
  
  var amountTipLab:UILabel!
  var amountLineView:UIView!
  var drawAmountView:UIView!
  var pswView:UIView!
  var pswLineView:UIView!
  var pswErrorTipLab:UILabel!
  var confirmBtn:UIButton!
  var btcRateToastView:BtcRateToastView!
  var drawToBackView:UIView!
  var disposeBag:DisposeBag = DisposeBag()
  var bottomConstraint:Constraint?
  var accountType:String? //BTC为比特取款,其他为银行取款
  var btcRate:String?
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    buildViews()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setDataDrawModel(dataDrawModel:WithDrawModel?){
    if dataDrawModel != nil {
      totalMoneyLabel.text = dataDrawModel?.balance
      let value = dataDrawModel?.withdrawBal?.toIntValue()
      withDrawLabel.text = String(format: "%d", value ?? "")
    }
  }
  
  func setDataBankListModel(dataDrawModel:WithDrawModel){
    totalMoneyLabel.text = dataDrawModel.balance
    withDrawLabel.text = dataDrawModel.withdrawBal
  }
  
  func buildViews() {
    
    let scrollView = UIScrollView.init(frame: .zero)
    self.addSubview(scrollView)
    scrollView.translatesAutoresizingMaskIntoConstraints = false
    scrollView.snp.makeConstraints { (make) in
      make.top.left.right.height.equalTo(self)
    }
    let contentView = UIView.init(frame: .zero)
    scrollView.addSubview(contentView)
    contentView.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
      make.width.equalTo(SCREEN_WIDTH)
    }
    
    let tipTotalMoneyLabel = UILabel.init(color: UIColor.white,font: fontSegSemiBold16)
    contentView.addSubview(tipTotalMoneyLabel)
    tipTotalMoneyLabel.text = "总资产"
    tipTotalMoneyLabel.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(20)
      make.top.equalTo(contentView).offset(15)
    }
    
    let path = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/RMB", ofType: "png")
    let image = UIImage.init(contentsOfFile: path ?? "")
    let coinImgView = UIImageView.init(image: image)
    contentView.addSubview(coinImgView)
    coinImgView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(View_Margin)
      make.top.equalTo(contentView).offset(52)
      make.width.height.equalTo(30)
    }
    
    totalMoneyLabel = UILabel.init(color: .white,font: fontSegSemiBold28)
    contentView.addSubview(totalMoneyLabel)
    totalMoneyLabel.snp.makeConstraints { (make) in
      make.left.equalTo(coinImgView.snp.right).offset(10)
      make.centerY.equalTo(coinImgView)
    }
    
    refreshBtn = UIButton.init(type: .custom)
    refreshBtn.setImage(UIImage.init(named: "icon_refresh"), for: .normal)
    contentView.addSubview(refreshBtn)
    refreshBtn.snp.makeConstraints { (make) in
      make.right.equalTo(contentView).offset(-View_Margin);
      make.centerY.equalTo(coinImgView)
      make.width.height.equalTo(40)
    }
    
    let availableView = UIView.init()
    contentView.addSubview(availableView)
    availableView.backgroundColor = color2a2e32
    availableView.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView)
      make.top.equalTo(contentView).offset(137)
      make.height.equalTo(65)
    }
    let canWithDrawTipLabel = UILabel.init(color: .white,font: fontpfr15)
    availableView.addSubview(canWithDrawTipLabel)
    canWithDrawTipLabel.text = "可取金额"
    canWithDrawTipLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(availableView)
      make.left.equalTo(availableView).offset(View_Margin)
    }
    let withPrefixLabel = UILabel.init(color: .white,font: fontSegSemiBold20)
    availableView.addSubview(withPrefixLabel)
    withPrefixLabel.text = "￥"
    withPrefixLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(availableView)
      make.left.equalTo(availableView).offset(144)
    }
    withDrawLabel = UILabel.init(color: .white,font: fontSegSemiBold20)
    availableView.addSubview(withDrawLabel)
    withDrawLabel.text = "0"
    withDrawLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(availableView)
      make.left.equalTo(withPrefixLabel.snp.right).offset(2)
      make.right.lessThanOrEqualTo(availableView).offset(-View_Margin)
    }
    
    drawToBackView = UIView.init(frame: .zero)
    contentView.addSubview(drawToBackView)
    drawToBackView.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView)
      make.top.equalTo(availableView.snp.bottom).offset(30)
      make.height.equalTo(60)
    }
    btcRateToastView = BtcRateToastView.init(frame: .zero)
    drawToBackView.addSubview(btcRateToastView)
    btcRateToastView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalToSuperview()
      make.height.equalTo(0)
    }
    btcRateToastView.setToastLabContent(content: "" )

    let drawToView = UIView.init()
    drawToBackView.addSubview(drawToView)
    drawToView.snp.makeConstraints { (make) in
      make.left.right.equalTo(drawToBackView)
      make.top.equalTo(btcRateToastView.snp.bottom)
      make.height.equalTo(60)
    }
    drawBackBtn = UIButton.init(type: .custom)
    drawToView.addSubview(drawBackBtn)
    drawBackBtn.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
    }
    let drawToTipLabel = UILabel.init(color: .white,font: fontpfr15)
    drawToTipLabel.text = "取款至"
    drawToView.addSubview(drawToTipLabel)
    drawToTipLabel.snp.makeConstraints { (make) in
      make.left.equalTo(drawToView).offset(View_Margin)
      make.centerY.equalTo(drawToView)
    }
    drawToImgView = UIImageView.init()
    drawToImgView.image = UIImage.init(named: "logo")
    drawToView.addSubview(drawToImgView)
    drawToImgView.snp.makeConstraints { (make) in
      make.centerY.equalTo(drawToView)
      make.left.equalTo(drawToView).offset(105)
      make.width.height.equalTo(24)
    }
    drawToLabel = UILabel.init(color: .white,font: fontpfr14)
    drawToView.addSubview(drawToLabel)
    drawToLabel.snp.makeConstraints { (make) in
      make.left.equalTo(drawToImgView.snp.right).offset(5)
      make.top.bottom.equalTo(drawToView)
    }
    expandBtn = UIButton.init(type: .custom)
    expandBtn.isUserInteractionEnabled = false
    expandBtn.setImage(UIImage.init(named: "arrow_down"), for: .normal)
    drawToView.addSubview(expandBtn)
    expandBtn.snp.makeConstraints { (make) in
      make.left.equalTo(drawToLabel.snp.right)
      make.right.bottom.top.equalTo(drawToView)
      make.width.equalTo(60)
    }
    let line = UIView.init()
    line.backgroundColor = UIColor.line_lightBlack
    drawToView.addSubview(line)
    line.snp.makeConstraints { (make) in
      make.left.right.equalTo(availableView).offset(View_Margin)
      make.height.equalTo(1)
      make.bottom.equalTo(drawToView)
    }
  
    drawAmountView = UIView.init()
    contentView.addSubview(drawAmountView)
    drawAmountView.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView)
      make.top.equalTo(drawToView.snp.bottom)//.offset(30)
      make.height.equalTo(60)
    }
    let drawTipLabel = UILabel.init(color: .white,font: fontpfr15)
    drawTipLabel.text = "取款金额"
    drawAmountView.addSubview(drawTipLabel)
    drawTipLabel.snp.makeConstraints { (make) in
      make.left.equalTo(drawAmountView).offset(View_Margin)
      make.top.equalToSuperview()
      make.height.equalTo(60)
    }
    
    amountField = BaseTextfiled.init()
    amountField.font = fontpfr16
    amountField.placeholder = "请输入20元-1000万元之内的数值"
    amountField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    amountField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    amountField.textColor = .white
    amountField.keyboardType = UIKeyboardType.numberPad
    drawAmountView.addSubview(amountField)
    amountField.snp.makeConstraints { (make) in
      make.left.equalTo(drawAmountView).offset(105)
      make.top.equalTo(drawAmountView)
      make.height.equalTo(60)
      make.right.equalTo(drawAmountView).offset(-View_Margin)
    }
    
    amountLineView = UIView.init(frame: .zero)
    drawAmountView.addSubview(amountLineView)
    amountLineView.backgroundColor = UIColor.view_lineColor
    amountLineView.snp.makeConstraints { (make) in
      make.left.equalTo(drawAmountView.snp.left).offset(View_Margin)
      make.right.equalTo(drawAmountView.snp.right)
      make.height.equalTo(1)
      make.top.equalTo(drawAmountView.snp.top).offset(59)
    }
    
    amountTipLab = UILabel.init(color: UIColor.font_errorRedColor, font: UIFont.M_Font)
    amountTipLab.isHidden = true
    drawAmountView.addSubview(amountTipLab)
    amountTipLab.snp.makeConstraints { (make) in
      make.left.equalTo(drawTipLabel.snp.left)
      make.right.right.equalTo(amountField.snp.right)
      make.top.equalTo(amountField.snp.bottom)
      make.height.equalTo(30)
    }
    
    btcRateTipLab = UILabel.init(frame: .zero)
    btcRateTipLab.isHidden = true
    btcRateTipLab.textAlignment = .right
    btcRateTipLab.textColor = UIColor.font_purplishRedColor
    btcRateTipLab.font = UIFont.S_Font
    drawAmountView.addSubview(btcRateTipLab)
    btcRateTipLab.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.width.equalTo(150)
      make.centerY.equalToSuperview()
    }
    
    pswView = UIView.init()
    contentView.addSubview(pswView)
    pswView.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView)
      make.top.equalTo(drawAmountView.snp.bottom)
      make.height.equalTo(60)
    }
    let pswTipLabel = UILabel.init(color: .white,font: fontpfr15)
    pswTipLabel.text = "登录密码"
    pswView.addSubview(pswTipLabel)
    pswTipLabel.snp.makeConstraints { (make) in
      make.left.equalTo(pswView).offset(View_Margin)
      make.top.equalToSuperview()
      make.height.equalTo(60)
    }
    pswField = BaseTextfiled.init()
    pswField.delegate = self
    pswView.addSubview(pswField)
    pswField.font = fontpfr16
    pswField.placeholder = "请输入登录密码"
    pswField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    pswField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    pswField.textColor = .white
    pswField.isSecureTextEntry = true
    pswField.snp.makeConstraints { (make) in
      make.left.equalTo(pswView).offset(105)
      make.top.equalTo(pswView)
      make.right.equalTo(pswView).offset(-View_Margin)
      make.height.equalTo(60)
    }
    pswLineView = UIView.init(frame: .zero)
    pswView.addSubview(pswLineView)
    pswLineView.backgroundColor = UIColor.view_lineColor
    pswLineView.snp.makeConstraints { (make) in
      make.left.equalTo(pswView.snp.left).offset(View_Margin)
      make.right.equalTo(pswView.snp.right)
      make.height.equalTo(1)
      make.top.equalTo(pswView.snp.top).offset(59)
    }
    
    pswErrorTipLab = UILabel.init(color: UIColor.font_errorRedColor, font: UIFont.M_Font)
    pswErrorTipLab.isHidden = true
    pswView.addSubview(pswErrorTipLab)
    pswErrorTipLab.snp.makeConstraints { (make) in
      make.left.equalTo(pswTipLabel.snp.left)
      make.right.right.equalTo(pswField.snp.right)
      make.top.equalTo(pswField.snp.bottom)
      make.height.equalTo(30)
    }
    
    confirmBtn = UIButton.init(type: .custom)
    confirmBtn.layer.masksToBounds = true
    confirmBtn.layer.cornerRadius = 8
    confirmBtn.titleLabel?.font = fontpfm16
    confirmBtn.setTitle("确定", for: .normal)
    confirmBtn.backgroundColor =  UIColor.btn_rightRed
    confirmBtn.setTitleColor(UIColor.view_white, for: .normal)
    contentView.addSubview(confirmBtn)
    confirmBtn.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(15)
      make.right.equalTo(contentView).offset(-15)
      make.height.equalTo(54)
      make.top.equalTo(pswView.snp.bottom).offset(53)
      bottomConstraint = make.bottom.equalTo(contentView.snp.bottom).offset(-30).constraint
    }
    
    withDrawLabel.text = "0"
    drawToImgView.image = UIImage.init(named: "logo")
    drawToLabel.text = ""
    totalMoneyLabel.text = "0.00"
    
    amountField.rx.controlEvent(.allEditingEvents).asObservable().subscribe(onNext: { [weak self] in
      if self?.amountField.isFirstResponder ?? false  {
        self?.amountLineView.backgroundColor = UIColor.white
        self?.drawAmountView.snp.updateConstraints({ (make) in
          make.height.equalTo(60)
        })
       self?.amountTipLab.isHidden = true
      }else{
        self?.amountLineView.backgroundColor = UIColor.line_lightBlack
        let amountText = self?.amountField.text ?? ""
        if amountText.count < 1 {
          self?.amountLineView.backgroundColor = UIColor.line_redColor
          self?.amountTipLab.text = "取款金额不能为空"
          self?.amountTipLab.isHidden = false
          self?.drawAmountView.snp.updateConstraints({ (make) in
            make.height.equalTo(90)
          })
        }else{
          self?.drawAmountView.snp.updateConstraints({ (make) in
            make.height.equalTo(60)
          })
          self?.amountTipLab.isHidden = true
          if self?.accountType != "BTC" {
            let yue = self?.withDrawLabel.text ?? ""
            let yueint:Int64 = yue.toIntValue()
            if amountText.toIntValue() > yueint  {
              self?.amountTipLab.text = "您的可取金额不足"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
               return
            }
            if amountText.toIntValue() < 20  {
              self?.amountTipLab.text = "取款金额不得低于20元"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
              return
            }
            if amountText.toIntValue() > 10000000  {
              self?.amountTipLab.text = "取款金额不得高于1000万元"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
               return
            }
          }
          
          if self?.accountType == "BTC" {
            
            let yue = self?.withDrawLabel.text ?? ""
            let yueint:Int64 = yue.toIntValue()
          
            if amountText.toIntValue() > yueint  {
              self?.amountTipLab.text = "您的可取金额不足"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
              return
            }
            if amountText.toIntValue() < 20  {
              self?.amountTipLab.text = "取款金额不得低于20元"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
              return
            }
            if amountText.toIntValue() > 10000000  {
              self?.amountTipLab.text = "取款金额不得高于1000万元"
              self?.amountTipLab.isHidden = false
              self?.drawAmountView.snp.updateConstraints({ (make) in
                make.height.equalTo(90)
              })
              return
            }
            
            
//            guard let curBtcRate = self?.btcRate else {
//              return
//            }
//            let dBtcRate = Double(curBtcRate) ?? 0
//            if dBtcRate < 1 {
//              return
//            }
//            let btcResultAmount = (Double(amountText) ?? 0 ) / (Double( curBtcRate )! )
//
//            if btcResultAmount < 0.01  {
//              self?.amountTipLab.text = "取款币数不得低于0.01"
//              self?.amountTipLab.isHidden = false
//              self?.drawAmountView.snp.updateConstraints({ (make) in
//                make.height.equalTo(90)
//              })
//               return
//            }
//            if btcResultAmount > 30  {
//              self?.amountTipLab.text = "取款币数不得高于30"
//              self?.amountTipLab.isHidden = false
//              self?.drawAmountView.snp.updateConstraints({ (make) in
//                make.height.equalTo(90)
//              })
//               return
//            }
            
          }
          
          guard let curBtcRate = self?.btcRate else {
            return
          }
          let dBtcRate = Double(curBtcRate) ?? 0
          if dBtcRate < 1 {
            return
          }
          let btcResultAmount = (Double(amountText) ?? 0 ) / (Double( curBtcRate )! )
          let content = String(format:"%.5f",btcResultAmount)
          self?.btcRateTipLab.text = "≈" + content + "BTC"
        }
      }
    }).disposed(by: self.disposeBag)
    
    amountField.rx.text.orEmpty.changed.subscribe(onNext: { [weak self]   contentText in
      if contentText.count > 8 {
        self?.amountField.text = String(contentText.prefix(8) )
      }
    }).disposed(by: self.disposeBag)
    
    amountField.rx.text.orEmpty.changed
      .throttle(0.3, scheduler: MainScheduler.instance)
      .distinctUntilChanged().subscribe(onNext: {[weak self]   text in
        if self?.accountType != "BTC" {
          return
        }
        guard let curBtcRate = self?.btcRate else {
          return
        }
        let dBtcRate = Double(curBtcRate) ?? 0
        if dBtcRate < 1 {
          return
        }
        
        let btcResultAmount = (Double(text) ?? 0 ) / (Double( curBtcRate )! )
        let content = String(format:"%.5f",btcResultAmount)
        self?.btcRateTipLab.text = "≈" + content + "BTC"
        
      }).disposed(by: disposeBag)
    
    pswField.rx.controlEvent(.allEditingEvents).asObservable().subscribe(onNext: { [weak self] in
      if self?.pswField.isFirstResponder ?? false  {
        self?.pswLineView.backgroundColor = UIColor.white
        self?.pswView.snp.updateConstraints({ (make) in
          make.height.equalTo(60)
        })
        self?.pswErrorTipLab.isHidden = true
        
      }else{
        let pswText = self?.pswField.text ?? ""
        if pswText.count < 1 {
          self?.pswLineView.backgroundColor = UIColor.line_redColor
          self?.pswErrorTipLab.text = "登录密码不能为空"
          self?.pswErrorTipLab.isHidden = false
          self?.pswView.snp.updateConstraints({ (make) in
            make.height.equalTo(90)
          })
        }
        else{
          
          let pswText = self?.pswField.text ?? ""
          let isOK = RegularExp.checkPassword(pswText)
          if isOK?.isEqual("" as String) == false {
            self?.pswLineView.backgroundColor = UIColor.line_redColor
            self?.pswErrorTipLab.text = isOK
            self?.pswErrorTipLab.isHidden = false
            self?.pswView.snp.updateConstraints({ (make) in
              make.height.equalTo(90)
            })
            return
          }
          
          self?.pswView.snp.updateConstraints({ (make) in
            make.height.equalTo(60)
          })
          self?.pswErrorTipLab.isHidden = true
          self?.pswLineView.backgroundColor = UIColor.line_lightBlack
        }
      }
    }).disposed(by: self.disposeBag)
    
    
  
    
    
 
    
  /*  let amountFieldValid = amountField.rx.text
      .map{$0?.count ?? 0 >= 1}  //map函数 对text进行处理
      .share(replay: 1)
    let pwdFieldValid = pswField.rx.text
      .map{$0?.count ?? 0 >= 1}  //map函数 对text进行处理
      .share(replay: 1)
    let everythingValid = Observable.combineLatest(amountFieldValid, pwdFieldValid) { (amountFieldValid, pwdFieldValid)  in
      amountFieldValid && pwdFieldValid
      }.distinctUntilChanged()
    
    everythingValid.asObservable().subscribe(onNext: { [weak self] valid  in
      
      if valid {
        self?.confirmBtn.backgroundColor =  UIColor.btn_rightRed
        self?.confirmBtn.setTitleColor(UIColor.view_white, for: .normal)
        
      }else{
        self?.confirmBtn.backgroundColor =  UIColor.btn_leftLightBlack
        self?.confirmBtn.setTitleColor(color888888, for: .normal)
      }
      self?.confirmBtn.isEnabled = valid
      
    }).disposed(by: disposeBag)
    //    Observable.combineLatest(amountField.rx.text.orEmpty,pswField.rx.text.orEmpty){
    //      text1,text2 -> String in
    //      return String(format: "前1个值：%@, 后1个值：%@",text1,text2)
    //      }*/
 
  }
  
  func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    guard let text = textField.text else{
      return true
    }
    let textLength = text.characters.count + string.characters.count - range.length
    return textLength<=16
  }
  
 public func showAmountTextFieldErrorTip(){
    amountLineView.backgroundColor = UIColor.line_redColor
    amountTipLab.text = "取款金额不能为空"
    amountTipLab.isHidden = false
    drawAmountView.snp.updateConstraints({ (make) in
      make.height.equalTo(90)
    })
  }
  
 public func showPswTextFieldErrorTip(){
    pswLineView.backgroundColor = UIColor.line_redColor
    pswErrorTipLab.text = "登录密码不能为空"
    pswErrorTipLab.isHidden = false
    pswView.snp.updateConstraints({ (make) in
      make.height.equalTo(90)
    })
  }
  
  
  func refreshBitRateView(btcRateModel:QueryBtcRateModel){
    
    btcRate = btcRateModel.btcRate
    let dBtcRate = Double(btcRate ?? "0") ?? 0
    let fBtcRate = String(format:"%.2f",dBtcRate)
   // btcRateTipLab.text = "1BTC≈" + fBtcRate + "CNY"
    amountField.placeholder = "1BTC≈" + fBtcRate + "CNY"
  }
  
  func selectIndexBank(drawBankModel:PersonInfoCardModel? ){
    
    accountType = drawBankModel?.accountType
    if drawBankModel?.accountType == "BTC" {
      
      drawToLabel.text = "比特币账户"
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (drawBankModel?.bankIcon ?? "")
      drawToImgView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: "logo"))
//      drawToBackView.snp.updateConstraints { (make) in
//        make.height.equalTo(60+60)
//      }
//      btcRateToastView.snp.updateConstraints { (make) in
//        make.height.equalTo(60)
//      }
      amountField.placeholder = ""
      // btcRateToastView.isHidden = false
      btcRateTipLab.isHidden = false
    }else{
      
      let accountNo = drawBankModel?.accountNo?.suffix(4) ?? ""
      let qian = "("
      let hou = ")"
      let cuohao:String = qian + accountNo + hou
      
      drawToLabel.text = (drawBankModel?.bankName ?? "") + cuohao
      
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (drawBankModel?.bankIcon ?? "")
      drawToImgView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: "logo"))
      drawToBackView.snp.updateConstraints { (make) in
        make.height.equalTo(60)
      }
      btcRateToastView.snp.updateConstraints { (make) in
        make.height.equalTo(0)
      }
      amountField.placeholder = "请输入20元-1000万元之内的数值"
      btcRateToastView.isHidden = true
      btcRateTipLab.isHidden = true
    }
  }
}

class PopSuccessView:UIView {
  
  var successLabel:UILabel!
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    
    self.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
    
    let successIcon = UIImageView(image: UIImage.init(named:"正确提示icon"))
    self.addSubview(successIcon)
    successIcon.snp.makeConstraints { (make) in
      make.left.equalTo(self).offset(15)
      make.centerY.equalTo(self)
    }
    successLabel = UILabel.init(color: color333333,font: fontpfr14)
    successLabel.text="您的取款将在XX分钟后到账。"
    self.addSubview(successLabel)
    successLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(self)
      make.left.equalTo(self).offset(50)
    }
    
  }
  
  class func showPopView(currentView:UIView?,content:String?){
    if currentView == nil {
      return
    }
    let successView = PopSuccessView()
    currentView?.addSubview(successView)
    successView.snp.makeConstraints { (make) in
      make.left.right.top.equalTo(currentView!)
      make.height.equalTo(80)
    }
    successView.successLabel.text = content
    
    let walltime = DispatchWallTime.now() + 1.5
    DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
      successView.removeFromSuperview()
    }
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}


extension UIView{
  func addIndicatLineForTextfield(textField:UITextField!) {
    let line = UIView.init()
    line.alpha = 0.5
    line.backgroundColor = color292d30
    self.addSubview(line)
    line.snp.makeConstraints { (make) in
      make.left.right.equalTo(self)
      make.height.equalTo(1)
      make.bottom.equalTo(self)
    }
    let lineHighlight = UIView.init()
    lineHighlight.backgroundColor = .white
    self.addSubview(lineHighlight)
    lineHighlight.snp.makeConstraints { (make) in
      make.right.equalTo(self)
      make.left.equalTo(self).offset(View_Margin)
      make.height.equalTo(1)
      make.bottom.equalTo(self)
    }
    lineHighlight.isHidden = true
    
    textField.reactive.controlEvents(.allEditingEvents).observeValues { (tfield) in
      lineHighlight.isHidden = !textField.isFirstResponder
      line.isHidden = textField.isFirstResponder
    }
  }
}

class BankCardCell: UITableViewCell {
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
  }
  override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    
    buildViews()
  }
  var imgView :UIImageView!
  var label : UILabel!
  func buildViews() {
    imgView = UIImageView()
    contentView.addSubview(imgView)
    
    label = UILabel.init(color: color333333,font: fontpfr15)
    contentView.addSubview(label)
    label.snp.makeConstraints { (make) in
      make.centerX.equalTo(contentView)
      make.top.bottom.equalTo(contentView)
    }
    
    imgView.snp.makeConstraints { (make) in
      make.centerY.equalTo(contentView)
      make.width.height.equalTo(28)
      make.right.equalTo(label.snp.left).offset(-6)
    }
    
    let line = UIView.init()
    line.backgroundColor = color292d30
    contentView.addSubview(line)
    line.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView)
      make.height.equalTo(0.5)
      make.bottom.equalTo(contentView)
    }
  }
}
