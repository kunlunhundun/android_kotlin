//
//  SetBottomPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 12/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit


class SetBottomPopView: UIView,UITableViewDataSource,UITableViewDelegate {

  var tableView:UITableView?
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT, width: SCREEN_WIDTH, height: 0)
    self.clipsToBounds = true
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  private func setupView()  {
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.separatorStyle = .none
    
    self.addSubview(tableView!)
    
    var tabHeight = 240
    if ManagerModel.instanse.loginSuccessModel == nil {
      tabHeight = 60
    }
    
    tableView?.snp.makeConstraints({ (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.equalToSuperview()
      make.height.equalTo(tabHeight)
    })
    
    tableView?.backgroundColor = UIColor.view_popBlackColor
    tableView?.layer.cornerRadius = 5.0
    
    let cancelBtn = UIButton.init(frame: .zero);
    self.addSubview(cancelBtn)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.backgroundColor = UIColor.view_popBlackColor
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.setTitleColor(UIColor.view_white, for: .normal)
    cancelBtn.titleLabel?.font = UIFont.M_Font
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.equalTo(tableView!.snp.bottom).offset(10)
      make.height.equalTo(60)
    }
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if ManagerModel.instanse.loginSuccessModel == nil {
      return 1
    }else{
      return 4
    }
  }
  func numberOfSections(in tableView: UITableView) -> Int {
     return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "NormalSetBottomCell") as? CustomerViewCell
    if cell == nil {
      cell = CustomerViewCell.init(style: .default, reuseIdentifier: "CustomerViewCell",isShowImg:false)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    
    if indexPath.row == 0 {
      cell?.contentLab.text = "下载中心"
    }else if indexPath.row == 1 {
      cell?.contentLab.text = "订阅"
    }else if indexPath.row == 2 {
      cell?.contentLab.text = "修改密码"
    }else if indexPath.row == 3 {
      cell?.contentLab.text = "退出登录"
    }
    return cell!
  }

  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
     return 60
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    self.frame =  CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 0)
    
    var isNewVC = true
    let topViewController = ManagerModel.instanse.getTopViewController()
    if topViewController.isKind(of: HomeRNViewController.classForCoder())  {
      isNewVC = false
    }
    
    if indexPath.row == 0 {
       ManagerModel.jumpRNPage(pageName: RNPageDownload, needBack: !isNewVC,isNewVC:isNewVC )
    }
    else if indexPath.row == 1 {
       ManagerModel.jumpRNPage(pageName: RNPageSubscribe, needBack: !isNewVC , isNewVC: isNewVC)
    }
    else if indexPath.row == 2 {
       ManagerModel.jumpRNPage(pageName: RNPageChangePassword, needBack: !isNewVC, isNewVC: isNewVC)
    }
    else if indexPath.row == 3 {
      ReactInteraction.shareInstance()?.logOut()
      ManagerModel.instanse.clearLogout()
      ManagerModel.instanse.clearLogoutView()
      hidenView()
      return
    }
    
    MaskView.hiden()
    return
  }
  
  class func showPopView() {
    let  setBottomPopView = SetBottomPopView.init(frame: .zero)
    setBottomPopView.showView()
  }
  
  func showView(){
    MaskView.show(subView: self)
    var viewHeight:CGFloat = 310.0
    if  ManagerModel.instanse.loginSuccessModel == nil {
      viewHeight = 120+10
    }
    UIView.animate(withDuration: 0.3) {
      self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT - viewHeight - BOTTOM_MARGIN, width: SCREEN_WIDTH, height: viewHeight + BOTTOM_MARGIN)
    }
  }
  
  func hidenView(){
    UIView.animate(withDuration: 0.3, animations: {
      self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT, width: SCREEN_WIDTH, height: 0)
    }) { ( isFinished) in
      MaskView.hiden()
    }
  }
  
  @objc func cancelAction(){
    hidenView()
  }
}

