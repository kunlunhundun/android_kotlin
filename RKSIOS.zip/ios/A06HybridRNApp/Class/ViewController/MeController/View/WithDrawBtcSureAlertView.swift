//
//  WithDrawBtcSureAlertView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 19/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class WithDrawBtcSureAlertView: UIView {

  static var  btcSureAlertView:WithDrawBtcSureAlertView?
  private var callbackBlock: ((_ sureAction:Int)->Void)?
  private var selectIndex:Int = 0
  private var tipPaywayLab:UILabel!
  var queryBtcRateModel:QueryBtcRateModel?
  
  convenience  init(frame: CGRect , btcRateModel:QueryBtcRateModel ) {
    self.init(frame: frame)
    
    let height:CGFloat = 220
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-height-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: height)
    self.layer.cornerRadius = 5.0
    
    queryBtcRateModel = btcRateModel
    setupView()
  }
  
  func setupView(){
    self.backgroundColor = UIColor.view_backBlack
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "确认取款"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    
    let moneyLab = UILabel.init(frame: .zero)
    self.addSubview(moneyLab)
    moneyLab.textAlignment = .center
    moneyLab.textColor = UIColor.view_white
    moneyLab.font = UIFont.L_Font
    moneyLab.text = "取款金额 " + (queryBtcRateModel?.amount ?? "") + " CNY"
    NSString.changeUILablePartColor(moneyLab, change: (queryBtcRateModel?.amount ?? ""), andAllColor: UIColor.view_white, andMark: UIColor.view_white, andMark: UIFont.PFM30_Font)
    
    moneyLab.snp.makeConstraints { (make) in
      make.top.equalTo(lineView.snp.bottom).offset(22)
      make.height.equalTo(30)
      make.left.right.equalToSuperview()
    }
    let paywayLab = UILabel.init(frame: .zero)
    self.addSubview(paywayLab)
    tipPaywayLab = paywayLab
    paywayLab.textColor = UIColor.font_purplishRedColor
    paywayLab.font = UIFont.M_Font
    paywayLab.textAlignment = .center
    paywayLab.text = "比特币(BTC) " + (queryBtcRateModel?.btcAmount ?? "")
    paywayLab.snp.makeConstraints { (make) in
      make.top.equalTo(moneyLab.snp.bottom).offset(8)
      make.left.right.equalToSuperview()
      make.height.equalTo(20)
    }
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((self.newWidth-10*3)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("确定", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(10)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }

  
  }
  
  class func showPopView(btcRateModel:QueryBtcRateModel, sureBlock:@escaping (_ sureAction:Int)->Void ) {
    btcSureAlertView = WithDrawBtcSureAlertView.init(frame: .zero, btcRateModel: btcRateModel)
    btcSureAlertView?.callbackBlock = sureBlock
    btcSureAlertView?.showView()
    
  }
  
  func showView(){
    MaskView.show(subView: self)
    
  }
  
  func hidenView(){
    MaskView.hiden()
  }
  
  @objc func cancelAction(){
    
    if callbackBlock != nil {
      callbackBlock?(-1)  //取消
    }
    hidenView()
  }
  
  @objc func sureAction(){
    
    if callbackBlock != nil {
      callbackBlock?(selectIndex)
    }
    hidenView()
    
  }
  
  @objc private func closeAction(){
    hidenView()
  }
}
