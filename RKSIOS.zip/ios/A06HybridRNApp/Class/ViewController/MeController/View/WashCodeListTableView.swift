//
//  WashCodeListTableView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 19/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class WashCodeListTableView: UIView,UITableViewDataSource,UITableViewDelegate {

  var tableView:UITableView?
  var xmListDataModel:[XMListModel]?
  var xmListResultDataModel:[XMResultModel]?
  var isSuccessResult:Bool = false
  var minBetAmount:String?
  
  override init(frame: CGRect ) {
    super.init(frame: frame)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.backgroundColor = .clear
    tableView?.separatorStyle = .none
    self.addSubview(tableView!)
    tableView?.snp.makeConstraints({ (make) in
      make.left.right.bottom.equalToSuperview()
      make.top.equalTo(self)
    })
  }
  
  func refreshData(xmListModel:[XMListModel]?){
    xmListDataModel = xmListModel
    tableView?.reloadData()
  }
  
  func refreshSuccessInfoData(xmListResultModel:[XMResultModel]?){
    xmListResultDataModel = xmListResultModel
    isSuccessResult = true
    tableView?.reloadData()
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if isSuccessResult {
      let count = xmListResultDataModel?.count ?? 0
      return count > 0 ? count + 1 : 0
    }
    let count = xmListDataModel?.count ?? 0
    return count > 0 ? count + 1 : 0
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "XMListTableCell") as? XMListTableCell
    if cell == nil {
      cell = XMListTableCell.init(style: .default, reuseIdentifier: "XMListTableCell")
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    
    var count = 0
    if !isSuccessResult {
      if indexPath.row == 0 {
        cell?.gameNameLab.text = "游戏"
        cell?.betAmountLab.text = "投注额"
        cell?.xmRateLab.text = "洗码比例"
        cell?.xmAmountLab.text = "洗码金额"
        cell?.gameNameLab.textColor = UIColor.view_white
        cell?.betAmountLab.textColor = UIColor.view_white
        cell?.xmRateLab.textColor = UIColor.view_white
        cell?.xmAmountLab.textColor = UIColor.view_white
      }else{
        let xmListModel =  xmListDataModel?[safe: (indexPath.row - 1) ]
        cell?.gameNameLab.text = xmListModel?.xmName
        cell?.betAmountLab.text = xmListModel?.betAmount
        cell?.xmRateLab.text = (xmListModel?.xmRate ?? "") + "%"
        cell?.xmAmountLab.text = xmListModel?.xmAmount
        
        let total:String = xmListModel?.totalBetAmont ?? ""
        
        let totalFloat = total.toDoubleValue()
        if totalFloat < minBetAmount?.toDoubleValue() ?? 0 {
          cell?.gameNameLab.textColor = UIColor.font_lightBlackWhiteColor
          cell?.betAmountLab.textColor = UIColor.font_lightBlackWhiteColor
          cell?.xmRateLab.textColor = UIColor.font_lightBlackWhiteColor
          cell?.xmAmountLab.textColor = UIColor.font_lightBlackWhiteColor
        }
      }
      count = xmListDataModel?.count ?? 0

    }else if  isSuccessResult {
       cell?.xmAmountLab.textColor = UIColor.view_white
      if indexPath.row == 0 {
        cell?.gameNameLab.text = "游戏"
        cell?.betAmountLab.text = "洗码比例"
        cell?.xmRateLab.text = "洗码金额"
        cell?.xmAmountLab.text = "状态"
      }else{
        let xmResultModel =  xmListResultDataModel?[safe: (indexPath.row - 1) ]
        cell?.gameNameLab.text = xmResultModel?.xmTypeName
        cell?.betAmountLab.text = (xmResultModel?.xmRate ?? "") + "%"
        cell?.xmRateLab.text = xmResultModel?.xmAmount
       
        if xmResultModel?.flag == "1" {
          cell?.xmAmountLab.textColor = UIColor.font_brightBlueColor
          cell?.xmAmountLab.text = "成功"
        }else{
          cell?.xmAmountLab.textColor = UIColor.font_brightRedColor
          cell?.xmAmountLab.text = "获取失败"
        }
      }
      count = xmListResultDataModel?.count ?? 0
    }
    cell?.lineView.isHidden = true
    if indexPath.row == count {
      cell?.lineView.isHidden = false
    }
    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 40
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
  }
}


class XMListTableCell:UITableViewCell{
  
  var gameNameLab:UILabel!
  var betAmountLab:UILabel!
  var xmRateLab:UILabel!
  var xmAmountLab:UILabel!
  var lineView:UIView!
  
  override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    
    
    let subWidth = (screenWidth - 15*2 - 15*2)/4.0
    
     gameNameLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    contentView.addSubview(gameNameLab)
    gameNameLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.width.equalTo(subWidth)
      make.centerY.equalToSuperview()
      
    }
    betAmountLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    contentView.addSubview(betAmountLab)
    betAmountLab.textAlignment = .center
    betAmountLab.snp.makeConstraints { (make) in
      make.left.equalTo(gameNameLab.snp.right)
      make.width.equalTo(subWidth)
      make.centerY.equalToSuperview()
    }
    xmRateLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    contentView.addSubview(xmRateLab)
    xmRateLab.textAlignment = .center
    xmRateLab.snp.makeConstraints { (make) in
      make.left.equalTo(betAmountLab.snp.right)
      make.width.equalTo(subWidth)
      make.centerY.equalToSuperview()
    }
    xmAmountLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    contentView.addSubview(xmAmountLab)
    xmAmountLab.textAlignment = .center
    xmAmountLab.snp.makeConstraints { (make) in
      make.left.equalTo(xmRateLab.snp.right)
      make.width.equalTo(subWidth)
      make.centerY.equalToSuperview()
    }
    
    lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.bottom.equalToSuperview()
      make.height.equalTo(1)
    }
    lineView.isHidden = true
    
  }

}
