//
//  ManualBtcOrderViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 23/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class ManualBtcOrderViewController: UIViewController {

  
  var timerView:AlipayTimerView!
  
  var queryBtcModel:QueryBtcRateModel?
  
  convenience init(btcRateModel:QueryBtcRateModel?){
    self.init()
    queryBtcModel = btcRateModel
  }
  
    override func viewDidLoad() {
        super.viewDidLoad()
      self.title = "存款订单"
      setupView()
    }
  
  override func navBackAction() {
    
    ProgressTopPopView.showPopView(content: "", popStyle: .chargeOrder)
    
  }
  
  
  func setupView(){
    
    self.view.addSubview(backScrollView)
    if #available(iOS 11.0, *) {
      backScrollView.contentInsetAdjustmentBehavior = .never
    } else {
      
    }
    backScrollView.snp.makeConstraints { (make) in
      make.top.bottom.left.right.equalTo(self.view)
    }
    
    let limitTime =  "13:00"
    timerView = AlipayTimerView.init(frame: .zero, timeStr: limitTime)
    backScrollView.addSubview(timerView)
    backScrollView.addSubview(amountLabel)
    backScrollView.addSubview(amountTipLabel)
    backScrollView.addSubview(orderTipImageView)
  
    orderTipImageView.addSubview(orderTipLabel)
    
    
    backScrollView.addSubview(bankCardInfoImageView)
    bankCardInfoImageView.addSubview(btcDesAdrrLabel)
    bankCardInfoImageView.addSubview(btcAdrrLabel)
    bankCardInfoImageView.addSubview(lineView)
    bankCardInfoImageView.addSubview(btcAddrCopyBtn)
    
    backScrollView.addSubview(openDetailInputBtn)
  //  backScrollView.addSubview(queryOrderBtn)
    
    timerView.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.equalTo(5)
      make.width.equalTo(100)
      make.height.equalTo(30)
    }
    
    amountLabel.snp.makeConstraints { (make) in
      make.top.equalTo(timerView.snp.bottom).offset(5)
      make.left.equalToSuperview().offset(0)
      make.right.equalToSuperview().offset(0)
      make.height.equalTo(30);
    }
    
    amountTipLabel.snp.makeConstraints { (make) in
      make.top.equalTo(amountLabel.snp.bottom).offset(10);
      make.left.equalToSuperview().offset(0)
      make.right.equalToSuperview().offset(0)
      make.height.equalTo(20);
    }
    
    orderTipImageView.snp.makeConstraints { (make) in
      make.top.equalTo(amountTipLabel.snp.bottom).offset(10);
      make.left.equalToSuperview().offset(View_Margin);
      make.right.equalToSuperview().offset(-View_Margin);
      make.height.equalTo(60);
    }
    
    orderTipLabel.snp.makeConstraints { (make) in
      make.left.right.top.bottom.equalToSuperview()
    }
    
    bankCardInfoImageView.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipImageView.snp.bottom).offset(15);
      make.left.equalToSuperview().offset(View_Margin);
      make.right.equalToSuperview().offset(-View_Margin);
      make.height.equalTo(196);
    }
    
    
    btcDesAdrrLabel.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.top.equalToSuperview()
      make.height.equalTo(40)
    }
    
    lineView.snp.makeConstraints { (make) in
      make.top.equalTo(btcDesAdrrLabel.snp.bottom).offset(0);
      make.left.equalTo(bankCardInfoImageView.snp.left).offset(View_Margin);
      make.right.equalTo(bankCardInfoImageView.snp.right).offset(-View_Margin);
      make.height.equalTo(1);
    };
    
    
    btcAdrrLabel.snp.makeConstraints { (make) in
      make.top.equalTo(lineView.snp.bottom)
      make.left.equalTo(lineView.snp.left)
      make.right.equalTo(lineView.snp.right)
      make.bottom.equalToSuperview().offset(-60)
    }
    
    btcAddrCopyBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-15)
      make.bottom.equalToSuperview().offset(-20)
      make.width.equalTo(60);
      make.height.equalTo(30);
    }
    
    openDetailInputBtn.snp.makeConstraints { (make) in
      make.top.equalTo(bankCardInfoImageView.snp.bottom).offset(60);
      make.left.equalToSuperview().offset(View_Margin);
      make.right.equalToSuperview().offset(-View_Margin)
      make.height.equalTo(52);
    }
    
//    queryOrderBtn.snp.makeConstraints { (make) in
//      make.top.equalTo(openDetailInputBtn.snp.bottom).offset(25);
//      make.left.equalToSuperview().offset(View_Margin);
//      make.right.equalToSuperview().offset(-View_Margin);
//      make.height.equalTo(20);
//    }
    
    amountLabel.text =  "比特币" + (queryBtcModel?.inputAmount ?? "")
    amountTipLabel.text = queryBtcModel?.rmbAmount
    btcAdrrLabel.text = queryBtcModel?.btcAddress
    
    
  }

  
  lazy var backScrollView:UIScrollView = {
    
    var scrollView = UIScrollView.init(frame: .zero)
    scrollView.showsVerticalScrollIndicator = false
    scrollView.showsHorizontalScrollIndicator = false
    scrollView.isScrollEnabled = true
    return scrollView
    
  }()

  lazy var amountLabel:UILabel = {
    var amountLab = UILabel.init(frame: .zero)
    amountLab.font = UIFont.PFM30_Font
    amountLab.textColor = UIColor.view_white
    amountLab.textAlignment = .center
    return amountLab
  }()
  
  lazy var amountTipLabel:UILabel = {
    var amountTipLab = UILabel.init(frame: .zero)
    amountTipLab.font = UIFont.M_Font
    amountTipLab.textColor = UIColor.init(colorValue: 0xE14040)
    amountTipLab.textAlignment = .center
    amountTipLab.text = ""
    return amountTipLab
  }()
  

  lazy var orderTipImageView:UIImageView = {
    var orderTipImgView = UIImageView.init(frame: .zero)
    orderTipImgView.image = UIImage.init(named: "bg_payment_guide")
    return orderTipImgView
  }()
  
  
  lazy var orderTipLabel:UILabel = {
    var orderTipLab = UILabel.init(frame: .zero)
    orderTipLab.font = UIFont.PFMM_Font
    orderTipLab.textColor = UIColor.view_white
    orderTipLab.textAlignment = .center
    orderTipLab.text = "请复制地址，并前往比特币网站汇款"
    return orderTipLab
  }()
  
  
  lazy var bankCardInfoImageView:UIImageView = {
    var bankCardInfoImgView = UIImageView.init(frame: .zero)
    bankCardInfoImgView.image = UIImage.init(named: "bg_bankcard")
    bankCardInfoImgView.contentMode = .scaleToFill
    bankCardInfoImgView.isUserInteractionEnabled = true
    return bankCardInfoImgView
  }()
  

  lazy var btcDesAdrrLabel:UILabel = {
    var btcDesAdrrLab = UILabel.init(frame: .zero)
    btcDesAdrrLab.font = UIFont.PFML_Font
    btcDesAdrrLab.textColor = UIColor.view_white
    btcDesAdrrLab.text = "比特币收款地址"
    return btcDesAdrrLab
  }()
  
  lazy var lineView:UIView = {
    var lineV = UIView.init(frame: .zero)
    lineV.backgroundColor = UIColor.init(colorValue: 0x535C8B)
    return lineV
  }()
  
  
  lazy var btcAdrrLabel:UILabel = {
  
    var btcAdrrLab = UILabel.init(frame: .zero)
    btcAdrrLab.font = UIFont.PFML_Font
    btcAdrrLab.textColor = UIColor.view_white
    btcAdrrLab.text = ""
    btcAdrrLab.numberOfLines = 0
    return btcAdrrLab
  }()
  
  
  
  lazy var btcAddrCopyBtn:UIButton = {
    var btcCopyBtn = UIButton.init(frame: .zero)
    btcCopyBtn.setTitle("复制", for: .normal)
    btcCopyBtn.setTitleColor(UIColor.init(colorValue: 0xffffff), for: .normal)
    btcCopyBtn.backgroundColor = UIColor.init(colorValue: 0x8095ff)
    btcCopyBtn.layer.cornerRadius = 15
    btcCopyBtn.clipsToBounds = true
    btcCopyBtn.addTarget(self, action: #selector(copyBtnAction), for: .touchUpInside)
    return btcCopyBtn
    
  }()
  
  
  lazy var openDetailInputBtn:UIButton = {
    var openBtn = UIButton.init(frame: .zero)
    openBtn.setTitle("我已支付，填写明细", for: .normal)
    openBtn.setTitleColor(UIColor.view_white, for: .normal)
    openBtn.backgroundColor = UIColor.btn_rightRed
    openBtn.titleLabel?.font =  UIFont.PFML_Font
    openBtn.layer.cornerRadius = 5
    openBtn.clipsToBounds = true
    openBtn.addTarget(self, action: #selector(detailBtnAction), for: .touchUpInside)
    return openBtn
    
  }()
  
  
  lazy var queryOrderBtn:UIButton = {
    var queryBtn = UIButton.init(frame: .zero)
    queryBtn.setTitle("已完成支付？查询订单进度", for: .normal)
    queryBtn.titleLabel?.font =  UIFont.PFMM_Font
    queryBtn.setTitleColor(UIColor.font_blueColor, for: .normal)
    queryBtn.addTarget(self, action: #selector(queryOrderBtnAction), for: .touchUpInside)
    return queryBtn
    
  }()
  
  
  @objc func copyBtnAction(){
    
    let pBoard = UIPasteboard.general
    pBoard.string = queryBtcModel?.btcAddress
    ProgressTopPopView.showPopView(content: "已复制地址", popStyle: .successMsgToast)

  }
  
  @objc func detailBtnAction(){
    
    let manualBtcInputVC = ManualBtcInputDetailViewController.init(btcRateModel: queryBtcModel)
    self.navigationController?.pushViewController(manualBtcInputVC, animated: true)
    
  }
  
  @objc func queryOrderBtnAction(){
    
    
  }
  
  

}
