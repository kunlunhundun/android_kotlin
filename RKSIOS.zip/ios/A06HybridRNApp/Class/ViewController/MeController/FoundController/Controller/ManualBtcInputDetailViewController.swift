//
//  ManualBtcInputDetailViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 23/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class ManualBtcInputDetailViewController: UIViewController,CaseyTableViewDelegate {

  
  var queryBtcModel:QueryBtcRateModel?
  var manualBtcField:UITextField!
  var btcToastView:BtcToastView!
  var dateTextField:UITextField!
  var addressTextField:UITextField!
  var selectDateTime:Date = Date.init()
  let disposeBag = DisposeBag()

  var amountTableViewCell:ChargeTableViewCell?
  var addressTableViewCell:ChargeTableViewCell?

  let tableView = CaseyTableView()
  
  convenience init(btcRateModel:QueryBtcRateModel?){
    self.init()
    queryBtcModel = btcRateModel
  }
  
    override func viewDidLoad() {
        super.viewDidLoad()

      self.title = "填写明细"
      
      setupView()
        // Do any additional setup after loading the view.
    }
  
  func setupView(){
    
    btcToastView = BtcToastView.init(frame: .zero)
    let text = queryBtcModel?.inputAmount ?? ""
    setBtcAmount(text: text)
    
    tableView.cyDelegate = self
    self.view.addSubview(tableView)
    tableView.snp.makeConstraints { (make) in
      make.edges.equalTo(self.view)
    }

    let nextBtn = UIButton.init(frame: .zero);
    self.view.addSubview(nextBtn)
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.setTitle("提交", for: .normal)
    nextBtn.layer.cornerRadius = 5.0
    nextBtn.setTitleColor(UIColor.view_white, for: .normal)
    nextBtn.titleLabel?.font = UIFont.PFML_Font
    nextBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    nextBtn.snp.makeConstraints { (make) in
      
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.bottom.equalToSuperview().offset(-30)
      make.height.equalTo(54)
    }
    
  }
  
  
  
  func tableView(_ tableView: CaseyTableView, numberOfRowsInSection section: Int) -> Int {
    return 4
  }
  func numberOfSections(in tableView: CaseyTableView) -> Int {
    return 1
  }
  
  
  func tableView(_ tableView: CaseyTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    if indexPath.row == 0 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "AmountIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
         cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "AmountIndentifierInputContentCell", cellMode: CellMode.manualInputContentMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        cell?.ic_textField?.keyboardType = .decimalPad
        cell?.ic_desLab?.text = "比特币"
        cell?.ic_textField?.placeholder = "请输入实际支付比特币"
        manualBtcField = cell?.ic_textField
        amountTableViewCell = cell
        cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
          if self == nil{
            return
          }
          if !isEndEdit  {
            cell?.ic_lineView?.backgroundColor = UIColor.view_white
            cell?.ic_errorTipLab?.isHidden = true
            cell?.cellHeight = 60
            
          }else{
            cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
            let contentText = cell?.ic_textField?.text ?? ""
            if contentText.count < 1 {
              cell?.showErrorMsg(msg: "比特币不能为空")
              cell?.cellHeight = 80
            }
          }
          tableView.reloadData()
        }
        
        
        cell?.ic_textField?.text = queryBtcModel?.inputAmount
        cell?.ic_textField?.isEnabled = false
        
        manualBtcField.rx.text.orEmpty.changed  //搜索框文字改变事件
          .throttle(0.3, scheduler: MainScheduler.instance)
          .distinctUntilChanged().subscribe(onNext: {[weak self]   text in
            
            self?.setBtcAmount(text: text);
            
          }).disposed(by: disposeBag)
        
      }
      return cell!
    }
    if indexPath.row == 1 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "ToastContentCell")
      if cell == nil {
        cell =  UITableViewCell.init(style: .default, reuseIdentifier: "ToastContentCell")
        cell?.selectionStyle = .none
        cell?.addSubview(btcToastView)
        btcToastView.snp.makeConstraints { (make) in
          make.left.equalToSuperview().offset(View_Margin)
          make.right.equalToSuperview().offset(-View_Margin)
          make.top.equalToSuperview().offset(10)
          make.height.equalTo(50)
        }
      }
      return cell!
    }
    if indexPath.row == 2 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "timeIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "timeIndentifierInputContentCell", cellMode: CellMode.inputAndRightArrow)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      cell?.ira_desLab?.text = "存款时间"
      cell?.ira_textField?.placeholder = "年/月/日 --:--"
      let formatter = ManagerModel.configDateFormatter()
      formatter.dateFormat = "YYYY/MM/dd HH:mm"
      let dateTime = formatter.string(from: Date.init())
      cell?.ira_textField?.text = dateTime
      dateTextField = cell?.ira_textField
      return cell!
    }
  
   
      var cell = tableView.dequeueReusableCell(withIdentifier: "addressIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "addressIndentifierInputContentCell", cellMode: CellMode.manualInputContentMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        cell?.ic_desLab?.text = "支付地址"
        cell?.ic_textField?.placeholder = "实际支付的账户地址"
        addressTextField = cell?.ic_textField
        addressTableViewCell = cell
        cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
          if !isEndEdit{
            cell?.ic_lineView?.backgroundColor = UIColor.view_white
            cell?.ic_errorTipLab?.isHidden = true
            cell?.cellHeight = 60
          }else{
            let contentText = cell?.ic_textField?.text ?? ""
            if contentText.count < 1 {
              cell?.ic_errorTipLab?.text = "支付地址不能为空"
              cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
              cell?.ic_errorTipLab?.isHidden = false
              cell?.cellHeight = 80
            }else if contentText.count < 23 {
              cell?.ic_errorTipLab?.text = "支付地址不对"
              cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
              cell?.ic_errorTipLab?.isHidden = false
              cell?.cellHeight = 80
            }
          }
          self?.tableView.reloadData()
        }
      }
      return cell!
  }
  
  
  func tableView(_ tableView: CaseyTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if indexPath.row == 0 {
      return amountTableViewCell?.cellHeight ?? 60
    }
    if indexPath.row == 3 {
      return addressTableViewCell?.cellHeight ?? 60
    }
    return 60
  }
  
  func tableView(_ tableView: CaseyTableView, didSelectRowAt indexPath: IndexPath) {
    
     if indexPath.row == 2 {
      CustomPickerView.showView(pickerType: .dateType, pickerDataArr: []) {[weak self]  (selectedIndex, selectDate) in
        if selectDate == nil {
          return
        }
        let formatter = ManagerModel.configDateFormatter()
        formatter.dateFormat = "YYYY/MM/dd HH:mm"
        self?.selectDateTime = selectDate ?? Date.init()
        let dateTime = formatter.string(from: selectDate!)
        self?.dateTextField?.text = dateTime
        
      }
    }
    
  }
  
  func setBtcAmount(text:String){
    
    if self.btcToastView.toastLab == nil || text.count < 1 {
      return
    }
    let btcResultAmount = (Double(text) ?? 0 ) * (Double(queryBtcModel?.btcRate ?? "0" ) ?? 0 )
    let decBtcAmount =  String.init(format: "%.2f元", btcResultAmount)
    btcToastView?.toastLab.text =  "= " + "\(decBtcAmount)"  + "  人民币(RMB)"
    NSString.changeUILablePartColor(btcToastView!.toastLab, change: decBtcAmount, andAllColor: UIColor.white, andMark: UIColor.font_purplishRedColor, andMark: UIFont.M_Font)
    
  }
  

  @objc func sureAction(){
    
    let amount = manualBtcField?.text ?? ""
    let formatter = ManagerModel.configDateFormatter()
    formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
    var selectTime = formatter.string(from: selectDateTime)
    if amount.count < 1 {
      amountTableViewCell?.ic_errorTipLab?.text = "比特币不能为空"
      amountTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
      amountTableViewCell?.ic_errorTipLab?.isHidden = false
      amountTableViewCell?.cellHeight = 80
      tableView.reloadData()
      return
    }
    guard addressTextField.text?.count ?? 0 > 22 else {
      addressTableViewCell?.ic_errorTipLab?.text = "支付地址不对"
      addressTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
      addressTableViewCell?.ic_errorTipLab?.isHidden = false
      addressTableViewCell?.cellHeight = 80
       tableView.reloadData()
      return
    }
    var paramDic = ManagerModel.configLoginNameParamDic()
    let btcResultAmount = (Double(amount) ?? 0 ) * (Double(queryBtcModel?.btcRate ?? "0" ) ?? 0 )
    let decBtcAmount =  String.init(format: "%.2f", btcResultAmount)
    paramDic["amount"] = decBtcAmount
    paramDic["accountId"] = (queryBtcModel?.accountId ?? "")
    paramDic["btcAddress"] = (queryBtcModel?.btcAddress ?? "")
    paramDic["btcRate"] = (queryBtcModel?.btcRate ?? "")
    paramDic["btcUuid"] = (queryBtcModel?.btcUuid ?? "")
    paramDic["btcAmount"] = amount
    let systemVersion = Double(UIDevice.current.systemVersion) ?? 0.0
   
    paramDic["depositDate"] = selectTime
    
    APITool.request(.manualBtcPayment, parameters: paramDic, successHandle: {[weak self]  (payWaysModel : PayOnlineOrderModel) in
      
      ProgressTopPopView.showPopView(content: "存款成功", popStyle: .successMsgToast)
      DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1.5) {
        let transacDetailVC = TransactiontDetailViewController()
        payWaysModel.transaType = .deposit
        payWaysModel.title = "人工比特币"
        if payWaysModel.createDate?.count ?? 0 < 1 {
          payWaysModel.createDate = ManagerModel.getNowDateFormatStr()
        }
        transacDetailVC.transacDetailModel = payWaysModel
        self?.navigationController?.pushViewController(transacDetailVC, animated: true)
      }
    }) {  (apiError) in
      ProgressTopPopView.showPopView(content: apiError?.kl_tips ?? "", popStyle: .errorMsgToast)
    }
    
  }
 

}



class BtcToastView: UIView {
  
  var toastLab:UILabel!
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    let  btcToastView = UIView.init(frame:.zero)
    self.addSubview(btcToastView)
    btcToastView.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
    btcToastView.layer.cornerRadius = 6
    btcToastView.layer.borderColor = UIColor.init(colorValue: 0x515C5F).cgColor
    btcToastView.layer.borderWidth = 1.0
    toastLab = UILabel.init(frame: .zero)
    btcToastView.addSubview(toastLab)
    toastLab.textColor = UIColor.white
    toastLab.font = UIFont.M_Font
    toastLab.textAlignment = .center
    toastLab.text = "=     人民币(RMB)"
    btcToastView.snp.makeConstraints { (make) in
      make.left.top.bottom.right.equalToSuperview()
    }
    toastLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.centerY.equalToSuperview()
      make.height.equalTo(20)
    }
    
  }
    
    
}


