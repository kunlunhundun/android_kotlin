//
//  AlipayWeChatOrderViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/15.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class AlipayWeChatOrderViewController: UIViewController {

  var orderView:AlipayWechatOrderView!
  var paymentModel:BQPaymentModel?
  convenience  init(model:BQPaymentModel?) {
    self.init()
    paymentModel = model
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setRightBtnView()
    self.title = "存款订单"
    
    orderView = AlipayWechatOrderView.init(frame: self.view.bounds, model:paymentModel)
    self.view.addSubview(orderView)
    orderView.snp.makeConstraints { (make) in
      make.edges.equalTo(self.view)
    }
    
    orderView.copyNameOrCardOrAddrBlock = {  (index) in
    
      if index == 0 {
        ProgressTopPopView.showPopView(content: "已复制用户名", popStyle: .successMsgToast)
      }else if index == 1 {
        ProgressTopPopView.showPopView(content: "已复制卡号", popStyle: .successMsgToast)
      }else {
        ProgressTopPopView.showPopView(content: "已复制地址", popStyle: .successMsgToast)

      }
    }
    orderView.aliWxGuidBlock = { [weak self ] () in
      if self?.paymentModel?.payWayCode == .alipay {
        
        AliWxOrderGuidPopView.show(isAliPay: true)
        
      }else if self?.paymentModel?.payWayCode == .wxpay{
        
        AliWxOrderGuidPopView.show(isAliPay: false)
      }
    }
    
  }
  
  func setRightBtnView(){
    
    let rightBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 80, height: 44))
    rightBtn.setTitle("在线客服", for: .normal)
    rightBtn.titleLabel?.font = UIFont.L_Font
    rightBtn.setTitleColor(UIColor.white, for: .normal)
    rightBtn.contentHorizontalAlignment = .right
    let barBtnView = UIView.init(frame: rightBtn.bounds)
    barBtnView.addSubview(rightBtn)
    rightBtn.addTarget(self, action: #selector(rightBtnAction), for: .touchUpInside)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.rightBarButtonItem  = barButtonItem
  }
  
  
  override func navBackAction() {
    
   // ProgressTopPopView.showPopView(currentView: self.view)
    ProgressTopPopView.showPopView(content: "", popStyle: .chargeOrder)
    
  }
  
  @objc func rightBtnAction(){
    
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = true
    self.navigationController?.pushViewController(CustomerOnlineHtmlViewController(), animated: true)
    
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = false

  }
  
  
  deinit {
    orderView.timerView?.destoryTimer()
    
    print("deinit-->\(self.classForCoder)")

  }


}
