//
//  ChargeViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/7.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import SnapKit
import RxSwift

class ChargeViewController: UIViewController,DidSelectedPaywaysDelegate {

  var chargeAlipayView:ChargeAlipayView?
  var chargeWechatView:ChargeAlipayView?
  var chargeBankPayView:ChargeBankPayView?
  var chargeOtherPayView:ChargeOtherPayView?
  
  var chargeViewModel:ChargeViewModel?
  var curPayKindModel:PayKindModel?
  var payWaysModel:PayWaysModel?
  var isFirstLoad:Bool = true
  let disposeBag = DisposeBag()
  var hasRecord:Bool?
  var beginDate:NSDate? = nil
  var isComefromeActivity:Bool = false
  
  init(){
    super.init(nibName: nil, bundle: nil)
    beginDate = NSDate()
    ManagerModel.instanse.getActivityInfo() // 检查一下是否有扫码活动
  }
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    ThreeSTool.payVCDidAppearHasRecord(hasRecord ?? false, begin: beginDate! as Date)
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.title = "存款"
    relaodData()
    NotificationCenter.default.addObserver(self, selector: #selector(reloaUI), name: NSNotification.Name(rawValue:"continueCharge"), object: nil)
  }
  
  @objc func reloaUI(){
    selectedPaysIndex(0)
  }
  
  // MARK:获取电话号码
  func relaodData(){
    
    // MARK:拿回所有的支付方式
    chargeViewModel = ChargeViewModel.init()
    chargeViewModel?.chargeView = self.view
    chargeViewModel?.queryPayWaysV3()
    
    let defaultView = ChargeDefaultView()
    defaultView.backgroundColor = color2a2e32
    defaultView.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT)
    defaultView.layoutUI()
    self.view.addSubview(defaultView)
    defaultView.isHidden = false
    
    LoadingView.showLoadingViewWith(to: self.view)
    chargeViewModel?.queryPayWaysSubject.subscribe(onNext: {  [weak self] (rqPaywaysModel:PayWaysModel) in
      LoadingView.hideLoadingView(for: self?.view)
      self?.payWaysModel = rqPaywaysModel
      //chargeViewModel?.requestQueryBQAmountList(payType: "", finishHanleBlock: <#(Bool) -> ()#>)
      defaultView.isHidden = true
      defaultView.removeFromSuperview()
      self?.checkBindPhoneBankCard()
      
      }, onError: { [weak self] (error ) in
        defaultView.isHidden = false
        LoadingView.hideLoadingView(for: self?.view)
        let apiError = error as? APIError
        if apiError?.kl_code?.contains("GW_890407") == true {
          defaultView.isHidden = true
          defaultView.removeFromSuperview()
          let blankBlackGuidView = BlankBlackListGuidView.init(frame: .zero, content: "此功能暂不可用,请稍后再试")
          self?.view.addSubview(blankBlackGuidView)
          blankBlackGuidView.snp.makeConstraints({ (make) in
            make.left.right.top.bottom.equalToSuperview()
          })
          return
        }
        
        ProgressTopPopView.showPopView(content: apiError?.kl_tips ?? "", popStyle: .errorMsgToast)
        let message = apiError?.kl_tips ?? ""
        if message.isEqual("网络不稳定,请稍后再试" as String){
          let time: TimeInterval = 1.5
          DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
            self?.navBackAction()
          }
        }
    }).disposed(by:disposeBag)
  }
  
  

  // MARK:检查银行卡和电话号码
  func checkBindPhoneBankCard(){
    
    let rqPaywaysModel = payWaysModel
    if rqPaywaysModel?.blackFlag == "1" || rqPaywaysModel?.payList?.count == 0 || rqPaywaysModel?.payList == nil {
      let blankBlackGuidView = BlankBlackListGuidView.init(frame: .zero, content: "当前无可用存款方式，请联系客服或稍后重试")
      self.view.addSubview(blankBlackGuidView)
      blankBlackGuidView.snp.makeConstraints({ (make) in
        make.left.right.top.bottom.equalToSuperview()
      })
      return
    }
    if rqPaywaysModel?.bindMobile == "1" && ManagerModel.shareInstanse().personInfoModel?.mobileNoBind == 0 {
        bindPhoneProcess()
    }else if rqPaywaysModel?.bindBankCard == "1" && ManagerModel.shareInstanse().personInfoModel?.bankCardNum == 0 && ManagerModel.shareInstanse().personInfoModel?.btcNum == 0 {
        bindBankCardProcess()
    }
    if chargeAlipayView == nil {
        initDataView()
    }
  }
  
  // MARK:检查绑定手机号码
  func bindPhoneProcess(){
    ProgressTopPopView.showPopViewCallBack(content: "您还未绑定手机号，请绑定后再操作", popStyle: .oneTitleConfirm, confirmTitle:"去绑定" ,callBackBlock: { [weak self] (isConfirm) in
      if isConfirm {
        let persoinModel = ManagerModel.instanse.personInfoModel
        let bindPhoneVC = BindPhoneViewController()
        bindPhoneVC.personInfoModel = persoinModel
        self?.nearNav()?.pushViewController(bindPhoneVC, animated: true)
        bindPhoneVC.finishBindCallBackBlock = {
          if self?.payWaysModel?.bindBankCard == "1" && ManagerModel.shareInstanse().personInfoModel?.bankCardNum == 0 &&
             ManagerModel.shareInstanse().personInfoModel?.btcNum == 0  {
            return
          }
        }
      }else{
        self?.navigationController?.popViewController(animated: true)
        ManagerModel.instanse.isShowTopview = false
      }
    })
  }
  
  // MARK:检查银行卡
  func bindBankCardProcess(){
    ProgressTopPopView.showPopViewCallBack(content: "您还未绑定银行卡,请绑定后再操作", popStyle: .oneTitleConfirm, confirmTitle: "去绑定") {[weak self] (isConfrim) in
      if isConfrim {
        let addBankVC = AddBankCardViewController()
        self?.nearNav()?.pushViewController(addBankVC, animated: true)
        addBankVC.finishCallBack = { [weak self] in
          //self?.initDataView()
        }
      }else{
        self?.navigationController?.popViewController(animated: true)
        ManagerModel.instanse.isShowTopview = false
      }
    }
  }
  
  func initDataView(){
    setRightBtnView()
    setupView()
    setPayWaysData()
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = false
    
    if(payWaysModel == nil) {
      isFirstLoad = false
      return
    }
    let rqPaywaysModel = payWaysModel
    let isBindMobiel = !(rqPaywaysModel?.bindMobile == "1" && ManagerModel.shareInstanse().personInfoModel?.mobileNoBind == 0)
    let isBindCard = !(rqPaywaysModel?.bindBankCard == "1" && ManagerModel.shareInstanse().personInfoModel?.bankCardNum == 0 && ManagerModel.shareInstanse().personInfoModel?.btcNum == 0)
    let finishBind = (isBindMobiel && isBindCard)
    if !isFirstLoad && !finishBind{
      checkBindPhoneBankCard()
    }
    isFirstLoad = false
  }
  
  // MARK:在线客服按钮
  func setRightBtnView(){
     let rightBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 80, height: 44))
    rightBtn.setTitle("在线客服", for: .normal)
    rightBtn.titleLabel?.font = UIFont.L_Font
    rightBtn.setTitleColor(UIColor.white, for: .normal)
    rightBtn.contentHorizontalAlignment = .right
    let barBtnView = UIView.init(frame: rightBtn.bounds)
    barBtnView.addSubview(rightBtn)
    rightBtn.addTarget(self, action: #selector(rightBtnAction), for: .touchUpInside)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.rightBarButtonItem  = barButtonItem
  }
  
  // MARK:返回到首页
  override func navBackAction() {
    self.navigationItem.rightBarButtonItem?.customView?.isHidden = true
    if self.navigationController?.viewControllers.count == 2 {
      
      if isComefromeActivity == true {
        // MARK:活动过来返回逻辑
        DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+0.2) {
          self.navigationController?.popViewController(animated: true)
          ManagerModel.instanse.isShowTopview = false
        }
      }else{
        // MARK:原来的返回逻辑
        ManagerModel.jumpRNPage(pageName: RNPageHome, needBack: false)
        DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+0.2) {
          self.navigationController?.popViewController(animated: true)
          ManagerModel.instanse.isShowTopview = false
        }
      }
      return
    }
    self.navigationController?.popViewController(animated: true)
    ManagerModel.instanse.isShowTopview = false
  }
  
  // MARK:在线客服
  @objc func rightBtnAction(){
     self.navigationItem.rightBarButtonItem?.customView?.isHidden = true
     self.navigationController?.pushViewController(CustomerOnlineHtmlViewController(), animated: true)
  }
  
  // MARK:创建四种支付方式的view
  func setupView() {
    
    chargeAlipayView =  ChargeAlipayView.init(frame: self.view.bounds, aliwechatType: .alipay,isfomeActivity:isComefromeActivity)
    self.view.addSubview(chargeAlipayView!)
    chargeAlipayView?.viewModel = chargeViewModel
    chargeAlipayView?.isHidden = true
    chargeAlipayView?.delegate = self

    chargeWechatView = ChargeAlipayView.init(frame: self.view.bounds,aliwechatType: .wechatpay,isfomeActivity:isComefromeActivity)
    self.view.addSubview(chargeWechatView!)
    chargeWechatView?.viewModel = chargeViewModel
    chargeWechatView?.delegate = self
    chargeWechatView?.isHidden = true

    chargeBankPayView = ChargeBankPayView.init(frame: self.view.bounds,isfomeActivity:isComefromeActivity)
    self.view.addSubview(chargeBankPayView!)
    chargeBankPayView?.viewModel = chargeViewModel
    chargeBankPayView?.delegate = self
    chargeBankPayView?.isHidden = true
    chargeBankPayView?.backHomePage = {(str) in
      self.navBackAction()
    }

    chargeOtherPayView = ChargeOtherPayView.init(frame:self.view.bounds,isfomeActivity:isComefromeActivity)
    self.view.addSubview(chargeOtherPayView!)
    chargeOtherPayView?.viewModel = chargeViewModel
    chargeOtherPayView?.delegate = self
    chargeOtherPayView?.isHidden = true
  }
  
  func setPayWaysData(){
    chargeAlipayView?.paykindArr = self.payWaysModel?.payList
    chargeWechatView?.paykindArr = self.payWaysModel?.payList
    chargeBankPayView?.paykindArr = self.payWaysModel?.payList
    chargeOtherPayView?.paykindArr = self.payWaysModel?.payList
    selectedPaysIndex(0) // 默认银行
  }

  func selectedPaysIndex(_ index: Int) {
    
    let paykindArr = self.payWaysModel?.payList
    guard index < paykindArr?.count ?? 0  else {
      return
    }
    let kindModel = paykindArr?[index]
    curPayKindModel = kindModel
    chargeViewModel?.curKindModel = kindModel
    if let kindName = kindModel?.payKindCode {
      if kindName.contains("ALIPAY"){
        chargeAlipayView?.payWaysSubChange(indexPath: 0)
        chargeAlipayView?.isHidden = false
        chargeWechatView?.isHidden = true
        chargeBankPayView?.isHidden = true
        chargeOtherPayView?.isHidden = true

      }else if kindName.contains("WXAPY"){
        chargeWechatView?.payWaysSubChange(indexPath: 0)
        chargeWechatView?.isHidden = false
        chargeAlipayView?.isHidden = true
        chargeBankPayView?.isHidden = true
        chargeOtherPayView?.isHidden = true

      }else if kindName.contains("BANKPAY"){
        chargeBankPayView?.payWaysSubChange(indexPath: 0)
        chargeBankPayView?.isHidden = false
        chargeWechatView?.isHidden = true
        chargeAlipayView?.isHidden = true
        chargeOtherPayView?.isHidden = true
        
      }else if kindName.contains("OKPAY"){
        chargeOtherPayView?.payWaysSubChange(indexPath: 0)
        chargeWechatView?.isHidden = true
        chargeAlipayView?.isHidden = true
        chargeBankPayView?.isHidden = true
        chargeOtherPayView?.isHidden = false
      }
    }
  }
  
  deinit {
    /// 移除通知
    NotificationCenter.default.removeObserver(self)
  }
}
