//
//  ActivityWebViewController.swift
//  A06HybridRNApp
//
//  Created by hopper on 01/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class ActivityWebViewController: UIViewController,WKUIDelegate,WKNavigationDelegate {
  
    private lazy var webView : WKWebView = {
      let webView = WKWebView.init(frame: view.bounds, configuration: configutation)
      webView.allowsBackForwardNavigationGestures = true
      webView.navigationDelegate = self
      webView.uiDelegate = self
      return webView
    }()
  
    private lazy var configutation: WKWebViewConfiguration = {
      let config = WKWebViewConfiguration()
      return config
    }()
  
    var webUrl:String = "https://billcloud.unionpay.com/upwxs-mktc/web/mapp/wxe990cdbcc189456e/custom/alllist"
    var progress:UIProgressView!
  
    let loadingView:GameLoadingView = GameLoadingView.getLoadingView()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(webView)
        loadingView.backgroundColor = color2a2e32
        self.view.addSubview(loadingView)
      
        webView.load(URLRequest.init(url: URL(string: webUrl)!))
      
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
        progress = UIProgressView.init(frame: CGRect(x:0, y:0, width: SCREEN_WIDTH, height:1))
        progress.transform = CGAffineTransform.init(scaleX: 1, y: 0.5)
        progress.progressViewStyle = .bar
        self.view.addSubview(progress)
        progress.progressTintColor = color2a2e32
        progress.trackTintColor = color2a2e32
        progress.progress = 0
    }
  
  override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    if keyPath == "estimatedProgress"{
      progress.progress = Float(webView.estimatedProgress)
      //这里改变loading的进度
      let pross = CGFloat(webView.estimatedProgress) * 100
      loadingView.setProgress(pross)
    }
    //加载完成隐藏进度条
    if progress.progress >= 0.98 {
      let afterTime:DispatchTime = DispatchTime.now() + 0.5
      DispatchQueue.main.asyncAfter(deadline: afterTime) {
        self.progress.isHidden = true
        self.loadingView.cancelrimer()
        self.loadingView.removeFromSuperview()
        self.progress.progress = 0
      }
    }
  }
  
  /**
   *  根据webView、navigationAction相关信息决定这次跳转是否可以继续进行,这些信息包含HTTP发送请求，如头部包含User-Agent,Accept,refer
   *  在发送请求之前，决定是否跳转的代理
   *  @param webView
   *  @param navigationAction
   *  @param decisionHandler
   */
  public func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Swift.Void){
    _ = navigationAction.request.url?.absoluteString
    decisionHandler(WKNavigationActionPolicy.allow)
  }
  
  /**
   *  这个代理方法表示当客户端收到服务器的响应头，根据response相关信息，可以决定这次跳转是否可以继续进行。
   *  在收到响应后，决定是否跳转的代理
   *  @param webView
   *  @param navigationResponse
   *  @param decisionHandler
   */
  public func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Swift.Void){
    print("\(String(describing: navigationResponse.response.url?.absoluteString))")
    decisionHandler(WKNavigationResponsePolicy.allow);
  }
  
  /**
   *  准备加载页面。等同于UIWebViewDelegate: - webView:shouldStartLoadWithRequest:navigationType
   *
   *  @param webView
   *  @param navigation
   */
  public func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!){
    
  }
  
  /**
   *  这个代理是服务器redirect时调用
   *  接收到服务器跳转请求的代理
   *  @param webView
   *  @param navigation
   */
  public func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
    
    
  }
  
  public func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error){
    
    
  }
  
  /**
   *  内容开始加载. 等同于UIWebViewDelegate: - webViewDidStartLoad:
   *
   *  @param webView
   *  @param navigation
   */
  public func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!){
    
    
  }
  /**
   *  页面加载完成。 等同于UIWebViewDelegate: - webViewDidFinishLoad:
   *  一般在这个方法中，我们会获取加载的一些内容，比如title，另外WKWebView内部的方法canGoBack，canGoForward，都很容易让使用者控制当前页面的前进和回退交互
   *  @param webView
   *  @param navigation
   */
  public func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
    
    // self.title = webView.title
    if webView.canGoBack {
      // self.navigationItem.leftBarButtonItems = self.leftBarbuttonItems
    }
  }
  /**
   *  页面加载失败。 等同于UIWebViewDelegate: - webView:didFailLoadWithError:
   *
   *  @param webView
   *  @param navigation
   *  @param error
   */
  
  public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error){
    
    
  }
  
  func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Swift.Void) {
    
    // 判断是否是信任服务器证书
    if challenge.protectionSpace.authenticationMethod
      == NSURLAuthenticationMethodServerTrust {
      // 告诉服务器，客户端信任证书
      // 创建凭据对象
      let card = URLCredential.init(trust: challenge.protectionSpace.serverTrust!)
      // 告诉服务器信任证书
      completionHandler(URLSession.AuthChallengeDisposition.useCredential, card)
    }
  }
  
  deinit {
    print("deinit-->\(self.classForCoder)")
  }
}
