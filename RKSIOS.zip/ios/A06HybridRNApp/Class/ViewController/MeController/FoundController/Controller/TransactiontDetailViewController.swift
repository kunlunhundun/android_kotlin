//
//  TransactiontDetailViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
//case deposit = 1 // 充值 drawal wash discount

class TransactiontDetailViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

  var tableView:UITableView!
  var amountLab:UILabel!
  var amountTipLab:UILabel!
  var isFromPersonCenter = false
  var isFromReportJump:Bool = false
  var remindTag:Bool = false
  var referenceBillNo:String?
  var transacDetailModel:TransactionDetailModel?
  var firstState:OneState = .success
  var secondState:OneState = .normal
  var thirdState:OneState = .normal
  var jixuchongzhi:((_ property:String?)->(Void))!
  
  convenience init(billNo:String?, isPersonCenter:Bool = false,isFromReport:Bool = false ){
    self.init()
    referenceBillNo = billNo
    isFromPersonCenter = isPersonCenter
    isFromReportJump = isFromReport
  }

  override func viewDidLoad() {
      super.viewDidLoad()
    
      if isFromReportJump == true {
         setupView()
         reloadRequestData()
      }else{
         requestQueryDepositTrans()
      }
    
      if transacDetailModel?.transaType == .deposit {
        self.title = "存款详情"
      }else if transacDetailModel?.transaType == .drawal {
        self.title = "取款详情"
      }else if transacDetailModel?.transaType == .wash {
        self.title = "洗码详情"
      }else if transacDetailModel?.transaType == .discount {
        self.title = "优惠详情"
      }
  }
  
  override func navBackAction() {
    
    if isFromReportJump == true {
      if isFromPersonCenter == true {
        for viewcontroller in (self.navigationController?.viewControllers)! {
          if (viewcontroller.isKind(of: PersonCenterViewController.classForCoder()) ){
            self.navigationController?.popToViewControllerOfClassName(classType: PersonCenterViewController.classForCoder(), animated: true)
            break
          }
        }
      }else{
        self.navigationController?.popViewController(animated: true)
      }
    }else{
      for viewcontroller in (self.navigationController?.viewControllers)! {
        if (viewcontroller.isKind(of: PersonCenterViewController.classForCoder()) ){
          self.navigationController?.popToViewControllerOfClassName(classType: PersonCenterViewController.classForCoder(), animated: true)
          return
          break
        }
      }
      self.navigationController?.popToRootViewController(animated: true)
    }
  }
  
  func setupView(){
  
    tableView = UITableView.init(frame: .zero, style: .plain)
    self.view.addSubview(tableView)
    tableView.backgroundColor = UIColor.clear
    tableView.delegate = self
    tableView.dataSource = self
    tableView.separatorStyle = .none
    
    let headView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 80))
    amountLab = UILabel.init(frame: .zero)
    headView.addSubview(amountLab)
    amountLab.font = UIFont.PFM30_Font
    amountLab.textColor = UIColor.view_white
    amountLab.textAlignment = .center
    amountLab.text = "¥ 0.00"
    amountTipLab = UILabel.init(frame: .zero)
    headView.addSubview(amountTipLab)
    amountTipLab.font = UIFont.M_Font
    amountTipLab.textColor = UIColor.init(colorValue: 0xF7315F)
    amountTipLab.textAlignment = .center
    amountTipLab.text = "审核中"
    
    amountLab.snp.makeConstraints { (make) in
      make.top.equalTo(headView).offset(5)
      make.left.equalTo(headView)
      make.right.equalTo(headView)
      make.height.equalTo(30);
    }
    amountTipLab.snp.makeConstraints { (make) in
      make.top.equalTo(amountLab.snp.bottom).offset(10);
      make.left.equalTo(headView)
      make.right.equalTo(headView)
      make.height.equalTo(20);
    }
    tableView.tableHeaderView = headView
    tableView.snp.makeConstraints { (make) in
      make.edges.equalTo(self.view)
    }
  }
  
  func setupFooterView(){
    
    let footerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 230))
    let tdetailProgressView = TDetailProgressView.init(frame: .zero, oneState: firstState, twoState: secondState, threeState: thirdState, bigstate: transacDetailModel!.transaType ?? .deposit)
    footerView.addSubview(tdetailProgressView)
    tdetailProgressView.snp.makeConstraints { (make) in
      make.left.top.right.equalTo(footerView)
      make.height.equalTo(80)
    }
    
    if !(thirdState == .success) {
      
      let resultOneTip = UILabel.init(frame: .zero)
      footerView.addSubview(resultOneTip)
      resultOneTip.font = UIFont.M_Font
      resultOneTip.textColor = UIColor.font_lightWhiteColor
      resultOneTip.textAlignment = .center
      //resultOneTip.text = "在支付时限内，我们没有收到您的款项"
      resultOneTip.text = ""
      
      let resultTwoTip = UILabel.init(frame: .zero)
      footerView.addSubview(resultTwoTip)
      resultTwoTip.font = UIFont.M_Font
      resultTwoTip.textColor = UIColor.font_lightWhiteColor
      resultTwoTip.textAlignment = .center
      //resultTwoTip.text = "如您对此订单有任何疑问，请联系客服处理"
      resultTwoTip.text = ""
      
      resultOneTip.snp.makeConstraints { (make) in
        make.left.right.equalToSuperview()
        make.top.equalTo(tdetailProgressView.snp.bottom).offset(0)
        make.height.equalTo(20)
      }
      resultTwoTip.snp.makeConstraints { (make) in
        make.left.right.equalToSuperview()
        make.top.equalTo(resultOneTip.snp.bottom).offset(0)
        make.height.equalTo(20)
      }
    }
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    footerView.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("返回首页", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((SCREEN_WIDTH-15*2-20)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    footerView.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("继续充值", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.left.equalTo(cancelBtn.snp.right).offset(20)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
    
    if isFromReportJump != true {
      // 充值成功之后的提示
      let tishiLabel = UILabel.init(frame: .zero)
      tishiLabel.backgroundColor = UIColor.clear
      let tishiLabelText = "支付完成后一分钟左右,即可成功到账\n如遗忘收款信息,可重新提交充值订单"
      tishiLabel.textColor = UIColor.font_lightBlackWhiteColor
      tishiLabel.font = UIFont.systemFont(ofSize: 13)
      tishiLabel.numberOfLines = 2
      
      //设置行间距
      let attributedString = NSMutableAttributedString(string: tishiLabelText)
      let paragraphStyle = NSMutableParagraphStyle()
      paragraphStyle.lineSpacing = 4
      attributedString.addAttribute(NSAttributedStringKey.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, attributedString.length))
      tishiLabel.attributedText = attributedString
      tishiLabel.textAlignment = .center
      
      footerView.addSubview(tishiLabel)
      
      tishiLabel.snp.makeConstraints { (make) in
        make.right.equalTo(0)
        make.left.equalTo(0)
        make.bottom.equalTo(cancelBtn.snp.top).offset(-20)
      }
    }
    
    cancelBtn.isHidden = isFromReportJump
    sureBtn.isHidden = isFromReportJump
    tableView.tableFooterView = footerView
    tableView.reloadData()
  }
  

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    if transacDetailModel?.transaType == .deposit {
       return 4
    }else if transacDetailModel?.transaType == .drawal {
      if transacDetailModel?.title?.contains("比特币") == true {
        return 6
      }else {
        return 5
      }
    }else if transacDetailModel?.transaType == .wash {
      return 4
    }else if transacDetailModel?.transaType == .discount{
      
    }
    return 4
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    
    if transacDetailModel?.transaType == .deposit && indexPath.row == 3 ||
      transacDetailModel?.transaType == .drawal && indexPath.row == 4 && transacDetailModel?.title?.contains("比特币") == false
      || transacDetailModel?.transaType == .drawal && indexPath.row == 5 && transacDetailModel?.title?.contains("比特币") == true
      || transacDetailModel?.transaType == .wash && indexPath.row == 3 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "proChargeTableViewCellTitleAndDetail") as? ChargeTableViewCell
      if  cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "proChargeTableViewCellTitleAndDetail", cellMode: CellMode.titleAndDetailMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        cell?.td_detailLab?.isUserInteractionEnabled = true
        cell?.td_lineView?.isHidden = true
        cell?.td_detailLab?.textColor = UIColor.font_blueColor
        cell?.td_detailBtn?.addTarget(self, action: #selector(remindAndCustomerAction), for: .touchUpInside)
      }
      if transacDetailModel?.flag == "0" ||  transacDetailModel?.flag == "1" || transacDetailModel?.flag == "97"
      || transacDetailModel?.flag == "9" {
          cell?.td_detailLab?.text = "等不及了，催一下"
        remindTag = true
      }else{
        cell?.td_detailLab?.text = "有疑问? 联系客服"
        remindTag = false
      }
      cell?.td_desLab?.text = "处理进度"
  
      return cell!
    }
    
   /* if transacDetailModel?.transaType == .wash && indexPath.row == 3  {
      
      var cell = tableView.dequeueReusableCell(withIdentifier: "TransaWashCodeTableViewCell") as? TransaTableViewCell
      if cell == nil {
        cell = TransaTableViewCell.init(style: .default, reuseIdentifier: "TransaWashCodeTableViewCell", cellMode: .transactionWashCode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      return cell!
    } */
    
    if transacDetailModel?.transaType == .drawal && indexPath.row == 3 {
      
      var cell = tableView.dequeueReusableCell(withIdentifier: "TransaBankNameTableViewCell") as? TransaTableViewCell
      if cell == nil {
        cell = TransaTableViewCell.init(style: .default, reuseIdentifier: "TransaBankNameTableViewCell", cellMode: .transactionBankName)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (transacDetailModel?.itemIcon ?? "")
      cell?.drawToImgView.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
      let preBankName = (transacDetailModel?.bankName ?? "") + "("
      cell?.bankNameLab.text = preBankName + (transacDetailModel?.accountNo ?? "") + ")"
      return cell!
    }
    
    // TransaTableViewCell
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "ChargeTableViewCellTitleAndDetailNormal") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "ChargeTableViewCellTitleAndDetailNormal", cellMode: CellMode.titleAndDetailMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = .clear
    }
    if indexPath.row == 0 {
      cell?.td_desLab?.text = "类型"
     
      let transCode = transacDetailModel?.transCode
      
      if transCode?.isEqual("1" as String) == true { cell?.td_detailLab?.text = "人工存款" }
      if transCode?.isEqual("2" as String) == true { cell?.td_detailLab?.text = "网银在线存款"  }
      if transCode?.isEqual("3" as String) == true { cell?.td_detailLab?.text = "点卡存款"  }
      if transCode?.isEqual("4" as String) == true { cell?.td_detailLab?.text = "微信扫码" }
      if transCode?.isEqual("5" as String) == true { cell?.td_detailLab?.text = "支付宝扫码"  }
      if transCode?.isEqual("6" as String) == true {cell?.td_detailLab?.text = "银行卡转账"  }
      if transCode?.isEqual("7" as String) == true {cell?.td_detailLab?.text = "QQ扫码"  }
      if transCode?.isEqual("8" as String) == true {cell?.td_detailLab?.text = "微信支付" }
      if transCode?.isEqual("9" as String) == true {cell?.td_detailLab?.text = "支付宝支付" }
      if transCode?.isEqual("11" as String) == true {cell?.td_detailLab?.text = "QQ钱包支付"  }
      if transCode?.isEqual("15" as String) == true {cell?.td_detailLab?.text = "银联扫码"  }
      if transCode?.isEqual("16" as String) == true {cell?.td_detailLab?.text = "京东扫码"  }
      if transCode?.isEqual("17" as String) == true {cell?.td_detailLab?.text = "京东支付"  }
      if transCode?.isEqual("18" as String) == true {cell?.td_detailLab?.text = "银联在线存款"  }
      if transCode?.isEqual("19" as String) == true {cell?.td_detailLab?.text = "银联在线存款"  }
      if transCode?.isEqual("20" as String) == true {cell?.td_detailLab?.text = "比特币支付"  }
      if transCode?.isEqual("22" as String) == true {cell?.td_detailLab?.text = "微信转账"  }
      if transCode?.isEqual("26" as String) == true {cell?.td_detailLab?.text = "支付宝转账"  }
      
      if transCode?.isEqual("" as String) == true || transCode == nil{
         cell?.td_detailLab?.text = transacDetailModel?.title
      }
    
      cell?.td_detailLab?.textColor = UIColor.view_white
    }
    else if indexPath.row == 1 {
      cell?.td_desLab?.text = "流水号"
      cell?.td_detailLab?.text = transacDetailModel?.referenceId ??  transacDetailModel?.requestId ?? transacDetailModel?.billNo
      cell?.td_detailLab?.textColor = UIColor.view_white
    }else if indexPath.row == 2 {
      cell?.td_desLab?.text = "时间"
      cell?.td_detailLab?.text = transacDetailModel?.createDate
      cell?.td_detailLab?.textColor = UIColor.view_white
    }
    if transacDetailModel?.transaType == .drawal && indexPath.row == 4 && transacDetailModel?.title?.contains("比特币") == true{
      cell?.td_desLab?.text = "交易时汇率"
      let rateFormat = String(format: "%.2f", (transacDetailModel?.rate ?? "").toDoubleValue() )
      cell?.td_detailLab?.text =  "1BTC≈" + rateFormat + "元"
    }
    return cell!
  }
  
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 50
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
  }
  
  @objc func remindAndCustomerAction(){
    
    if remindTag == false {
      let customerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: false)
      self.navigationController?.pushViewController(customerOnlineVC, animated: true)
    }else{
      self.requestRemain()
    }
  }
  
  @objc func cancelAction(){
    
    self.navigationController?.popToRootViewController(animated: true)
  }
  
  @objc func sureAction(){
   
    guard (self.navigationController?.viewControllers) != nil else {
      return
    }
    for viewcontroller in (self.navigationController?.viewControllers)! {
      if (viewcontroller.isKind(of: ChargeViewController.classForCoder()) ){
          self.navigationController?.popToViewControllerOfClassName(classType: ChargeViewController.classForCoder(), animated: true)
          NotificationCenter.default.post(name: NSNotification.Name("continueCharge"), object: self, userInfo:nil)
        break
      }
    }
  }
  
  func reloadRequestData(){
    
    var mount = "¥ " +  NSString.changeformat(forNumber: (transacDetailModel?.amount ?? ""))
    if !mount.contains(".") {
      mount = mount + ".00"
    }
    amountLab.text = mount
    
    let flag = transacDetailModel?.flag ?? ""
    var stateDes = ""
    switch flag {
    case "0":
      stateDes = "审核中"
      firstState = .success
      secondState = .normal
      thirdState = .normal
      amountTipLab.textColor = UIColor.init(colorValue: 0xE9664B)
      break
    case "1","9","97":
      stateDes = "审核中"
      firstState = .success
      secondState = .success
      thirdState = .normal
      amountTipLab.textColor = UIColor.init(colorValue: 0xE9664B)

      break
    case "2":
      stateDes = "成功"
      firstState = .success
      secondState = .success
      thirdState = .success
      amountTipLab.textColor = UIColor.init(colorValue: 0x50E3C2)
      break
      
    case "-3","3","98","-1","-2","99":
      stateDes = "未通过"
      firstState = .failed
      secondState = .normal
      thirdState = .normal
      amountTipLab.textColor = UIColor.init(colorValue: 0x999999)
      break

    case "98","-1","-2":
      stateDes = "已关闭"
      firstState = .failed
      secondState = .normal
      thirdState = .normal
      amountTipLab.textColor = UIColor.font_lightWhiteColor
    case "99":
      stateDes = "超时关闭"
      firstState = .failed
      secondState = .normal
      thirdState = .normal
      amountTipLab.textColor = UIColor.font_lightWhiteColor
      break
    default:
      break
    }
    
    if transacDetailModel?.transaType == .drawal && flag == "1"{
      stateDes = "支付中"
    }
    if transacDetailModel?.transaType == .wash && flag == "2"{
      stateDes = "已派发"
    }
    if transacDetailModel?.transaType == .discount && flag == "2"{
      stateDes = "已派发"
    }
    
    amountTipLab.text = stateDes
    
    let desc = transacDetailModel?.flagDesc ?? ""
    if stateDes.isEqual("" as String) == true || stateDes == nil {
      amountTipLab.text = desc
    }
    
    let str:String = stateDes
    if(str.isEqual("审核中" as String)){
      amountTipLab.textColor = UIColor.init(colorValue : 0xE9664B)
    }
    if(str.isEqual("支付中" as String)){
      amountTipLab.textColor = UIColor.init(colorValue : 0xE9664B)
    }
    if(str.isEqual("未通过" as String)){
      amountTipLab.textColor = UIColor.init(colorValue : 0x999999)
    }
    if(str.isEqual("成功" as String)){
      amountTipLab.textColor = UIColor.init(colorValue : 0x50E3C2)
    }
    if(str.isEqual("已派发" as String)){
      amountTipLab.textColor = UIColor.init(colorValue : 0x50E3C2)
    }
    setupFooterView()
  }
  
  func requestRemain(){
    
   var tranType = "1"
    if transacDetailModel?.transaType == .deposit {
      tranType = "1"
    }
   if transacDetailModel?.transaType == .drawal {
      tranType = "2"
    }
    if transacDetailModel?.transaType == .wash {
      tranType = "3"
    }
    var parameters = ManagerModel.configLoginNameParamDic()
    referenceBillNo = transacDetailModel?.referenceId ??  transacDetailModel?.requestId ?? transacDetailModel?.billNo
    parameters["referenceId"] = referenceBillNo
    
    parameters["type"] = tranType
    LoadingView.showLoadingViewWith(to: self.view)
    APITool.request(.transactionRemain, parameters: parameters, successHandle: { [weak self]  (remainModel:LiveChatAddModel) in
      LoadingView.hideLoadingView(for:self?.view )
      if remainModel.body == "0" {
        
      }
      let customerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: false)
      self?.nearNav()?.pushViewController(customerOnlineVC, animated: true)
      // ProgressTopPopView.showPopView(content: "催单成功", popStyle: .successMsgToast)
      
    }) { [weak self] (error) in
      LoadingView.hideLoadingView(for:self?.view )
      ProgressTopPopView.showPopView(content: error?.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
  
  

  func requestQueryDepositTrans(){
    
    var parameters = ManagerModel.configLoginNameParamDic()
    parameters["requestId"] = transacDetailModel?.referenceId ??  transacDetailModel?.requestId ?? transacDetailModel?.billNo
    parameters["type"] = "1"
    LoadingView.showLoadingViewWith(to: self.view)
    APITool.request(.queryDepositTrans, parameters: parameters, successHandle: { [weak self] (tranDetailModel:TransactionDetailModel) in
      LoadingView.hideLoadingView(for:self?.view )

      self?.transacDetailModel = tranDetailModel
      self?.transacDetailModel?.transaType = .deposit
      self?.setupView()
      self?.reloadRequestData()
    }) {[weak self] (error) in
      LoadingView.hideLoadingView(for:self?.view )
      ProgressTopPopView.showPopView(content: error?.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
  
}
