//
//  ManualBankInputDetailViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 02/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class ManualBankInputDetailViewController: UIViewController,CaseyTableViewDelegate {
  

  var tableView:CaseyTableView!

  var manualPaymentOrder:BQPaymentModel?
  var amountTableViewCell:ChargeTableViewCell?
  var nameTableViewCell:ChargeTableViewCell?
  var provinceTableViewCell:ChargeTableViewCell?

  var provinceTextField:UITextField?
  var depositWaysTextField:UITextField?
  var dateTextField:UITextField?
  var depositNameTextField:UITextField?
  var amountTextFiled:UITextField?
  var depositWaysBtn:UIButton?
  var selectDateTime:Date = Date.init()
  var payWayDataArr:[String] = ["柜台转账","ATM转账","网银转账","电话转账","跨行转账","自动终端机","手机转账","其他方式"]
  
  let disposeBag = DisposeBag()

  convenience init ( paymentOrder:BQPaymentModel?){
    self.init()
    manualPaymentOrder = paymentOrder
  }
  
  override func viewDidLoad() {
      super.viewDidLoad()
      self.title = "填写明细"
      setupView()
    }
  
  func setupView(){
    
    tableView = CaseyTableView()
    tableView!.cyDelegate = self
    self.view.addSubview(tableView)
    tableView.snp.makeConstraints { (make) in
      make.edges.equalTo(self.view)
    }
    
    
    let nextBtn = UIButton.init(frame: .zero);
    self.view.addSubview(nextBtn)
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.setTitle("确定", for: .normal)
    nextBtn.layer.cornerRadius = 5.0
    nextBtn.setTitleColor(UIColor.view_white, for: .normal)
    nextBtn.titleLabel?.font = UIFont.PFML_Font
    nextBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    nextBtn.snp.makeConstraints { (make) in
      
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.bottom.equalToSuperview().offset(-53)
      make.height.equalTo(54)
    }
    
    
  }

  
  func tableView(_ tableView: CaseyTableView, numberOfRowsInSection section: Int) -> Int {
    return 5
  }
  func numberOfSections(in tableView: CaseyTableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: CaseyTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    if indexPath.row == 0 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "AmountIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "AmountIndentifierInputContentCell", cellMode: CellMode.manualInputContentMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        cell?.ic_textField?.isEnabled = false
        amountTableViewCell = cell
        cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
          if !isEndEdit{
            cell?.ic_lineView?.backgroundColor = UIColor.view_white
            cell?.ic_errorTipLab?.isHidden = true
            cell?.cellHeight = 60
          }else{
            let contentText = cell?.ic_textField?.text ?? ""
            if contentText.count < 1 {
              cell?.ic_errorTipLab?.text = "存款金额不能为空"
              cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
              cell?.ic_errorTipLab?.isHidden = false
              cell?.cellHeight = 80
            }
          }
          self?.tableView.reloadData()

        }
      }
      cell?.ic_textField?.text = manualPaymentOrder?.amount
      amountTextFiled = cell?.ic_textField
    return cell!
    }
    if indexPath.row == 1 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "AmountWaysIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "AmountWaysIndentifierInputContentCell", cellMode: CellMode.inputAndUpArrowMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        }
      cell?.iua_textField?.text = "网银转账"
      depositWaysTextField = cell?.iua_textField
      depositWaysBtn = cell?.iua_arrowBtn
      return cell!
    }
    if indexPath.row == 2 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "nameIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "nameIndentifierInputContentCell", cellMode: CellMode.manualInputContentMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        nameTableViewCell = cell
        cell?.ic_textField?.isEnabled = false

       // ChargeViewModel.checkChineseName(nameTextFieldCell: cell!, tableView:tableView,disposeBag: disposeBag)

        cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
          if !isEndEdit{
            cell?.ic_lineView?.backgroundColor = UIColor.view_white
            cell?.ic_errorTipLab?.isHidden = true
            cell?.cellHeight = 60
          }else{
            let contentText = cell?.ic_textField?.text ?? ""
            if contentText.count < 1 {
              cell?.ic_errorTipLab?.text = "存款人不能为空"
              cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
              cell?.ic_errorTipLab?.isHidden = false
              cell?.cellHeight = 80
            }else if contentText.count < 2 {
              cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
            }else if contentText.count > 21 {
              cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
            }else{
              let lastStr = String(contentText.last!)
              let isLastChinese = RegularExp.isChinese(lastStr)
              if isLastChinese == false {
                cell?.showErrorMsg(msg: "存款人姓名最后一位不能为特殊字符")
              }
              
              let firstChart = contentText.first
              if firstChart == "*" {
                return
              }
              let content =  contentText.replacingOccurrences(of: "·", with: "")
              if !RegularExp.isChinese(content){
                cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
              }
            }
          }
          self?.tableView.reloadData()
        }
        
      }
      cell?.ic_desLab?.text = "存款人"
      cell?.ic_textField?.placeholder = "请输入存款人姓名"
      cell?.ic_textField?.text = manualPaymentOrder?.realName
      depositNameTextField = cell?.ic_textField
      return cell!
    }
    if indexPath.row == 3 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "timeIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "timeIndentifierInputContentCell", cellMode: CellMode.inputAndRightArrow)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      cell?.ira_desLab?.text = "存款时间"
      cell?.ira_textField?.placeholder = "年/月/日 --:--"
      let formatter = ManagerModel.configDateFormatter()
      formatter.dateFormat = "YYYY/MM/dd HH:mm"
      let dateTime = formatter.string(from: Date.init())
      cell?.ira_textField?.text = dateTime
      dateTextField = cell?.ira_textField
      return cell!
    }
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "timeIndentifierInputContentCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "timeIndentifierInputContentCell", cellMode: CellMode.inputAndRightArrow)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
      provinceTableViewCell = cell
    }
    cell?.ira_desLab?.text = "地点"
    cell?.ira_textField?.placeholder = "省份    城市 "
    provinceTextField = cell?.ira_textField
    return cell!

  }
  
  
  func tableView(_ tableView: CaseyTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if indexPath.row == 0 {
      return amountTableViewCell?.cellHeight ?? 60
    }
    if indexPath.row == 2 {
      return nameTableViewCell?.cellHeight ?? 60
    }
    return 60
  }
  
  func tableView(_ tableView: CaseyTableView, didSelectRowAt indexPath: IndexPath) {
    
    
    if indexPath.row == 1 {
      depositWaysBtn?.isSelected = true
      CustomPickerView.showView(pickerType: .oneTitle, pickerDataArr: payWayDataArr) { [weak self] (selectedIndex, selectDate) in
        if ( selectedIndex == -1) {
          self?.depositWaysBtn?.isSelected = false
          return
        }
        self?.depositWaysBtn?.isSelected = false
        self?.depositWaysTextField?.text = self?.payWayDataArr[safe:selectedIndex ?? 0]
      }
    }
    else if indexPath.row == 3 {
      CustomPickerView.showView(pickerType: .dateType, pickerDataArr: []) {[weak self]  (selectedIndex, selectDate) in
        if selectDate == nil {
          return
        }
        let formatter = ManagerModel.configDateFormatter()
        formatter.dateFormat = "YYYY/MM/dd HH:mm"
        self?.selectDateTime = selectDate ?? Date.init()
        let dateTime = formatter.string(from: selectDate!)
        self?.dateTextField?.text = dateTime
        
      }
    }
    else if indexPath.row == 4 {
      
      let bankCardCityListVC = BankProvinceListViewController()
      bankCardCityListVC.completionSelect = {[weak self] (provinceName, cityName) in
        
        if provinceName == cityName {
          self?.provinceTextField?.text = provinceName
        }else{
          self?.provinceTextField?.text = provinceName! + " " + cityName!
        }
        self?.provinceTableViewCell?.ira_lineview?.backgroundColor = UIColor.view_lineColor
        self?.provinceTableViewCell?.cellHeight = 60
        self?.provinceTableViewCell?.ic_errorTipLab?.isHidden = true

        tableView.reloadData()
      }
      self.navigationController?.pushViewController(bankCardCityListVC, animated: true)
    }
    
  }
  
  
 @objc func sureAction(){

   let amount = amountTextFiled?.text ?? ""
   let depositWay = depositWaysTextField?.text ?? ""
   var depositName = depositNameTextField?.text ?? ""
  let formatter = ManagerModel.configDateFormatter()
  formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
  var selectTime = formatter.string(from: selectDateTime)
  let provinceAdd = provinceTextField?.text ?? ""
  if amount.count < 1 {
    amountTableViewCell?.ic_errorTipLab?.text = "存款金额不能为空"
    amountTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
    amountTableViewCell?.ic_errorTipLab?.isHidden = false
    amountTableViewCell?.cellHeight = 80
    tableView.reloadData()
    return
  }else if depositName.count < 1 {
    nameTableViewCell?.ic_errorTipLab?.text = "存款人不能为空"
    nameTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
    nameTableViewCell?.ic_errorTipLab?.isHidden = false
    nameTableViewCell?.cellHeight = 80
    tableView.reloadData()
    return
  }else if nameTableViewCell?.ic_errorTipLab?.isHidden == false {
    return
  }else if provinceAdd.count < 1 {
    
    provinceTableViewCell?.ira_lineview?.backgroundColor = UIColor.line_redColor
    provinceTableViewCell?.ic_errorTipLab?.text = "请选择地点"
    provinceTableViewCell?.cellHeight = 80
    provinceTableViewCell?.ic_errorTipLab?.isHidden = false
    tableView.reloadData()
    return
  }
  
  var depositorType = "0"
  if (manualPaymentOrder?.depositorId?.count ?? 0 > 1) {
    depositName =  (manualPaymentOrder?.depositorId ?? "")
    depositorType = "1"
  }
  let provinceCity = provinceAdd.replacingOccurrences(of: " ", with: "")
  var paramDic = ManagerModel.configLoginNameParamDic()
  paramDic["amount"] = amount
  paramDic["depositor"] = depositName
  paramDic["depositType"] = depositWay
  paramDic["depositorType"] = depositorType

  
  paramDic["depositLocation"] = provinceCity
  paramDic["bankCardId"] = manualPaymentOrder?.bankCardId ?? ""
  let systemVersion = Double(UIDevice.current.systemVersion) ?? 0.0
 
  paramDic["depositDate"] = selectTime

  APITool.request(.createRequestBank, parameters: paramDic, successHandle: {[weak self]  (payWaysModel : PayOnlineOrderModel) in
    
    ProgressTopPopView.showPopView(content: "存款成功", popStyle: .successMsgToast)
    DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1.5) {
      let transacDetailVC = TransactiontDetailViewController.init(billNo: payWaysModel.billNo)
      payWaysModel.transaType = .deposit
      payWaysModel.title = "人工存款"
      if payWaysModel.createDate?.count ?? 0 < 1 {
        payWaysModel.createDate = ManagerModel.getNowDateFormatStr()
      }
      transacDetailVC.transacDetailModel = payWaysModel
      self?.navigationController?.pushViewController(transacDetailVC, animated: true)
    }
  }) {  (apiError) in
    ProgressTopPopView.showPopView(content: apiError?.kl_tips ?? "", popStyle: .errorMsgToast)
  }
}
  
  deinit {
    
    print("deinit-->\(self.classForCoder)")

  }
  

  

}
