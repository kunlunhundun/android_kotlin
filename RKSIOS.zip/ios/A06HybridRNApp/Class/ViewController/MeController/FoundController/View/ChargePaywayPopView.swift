//
//  ChargePopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/7.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import SDWebImage

public enum PaywaysMode : Int {
  case  mainPaywaysMode = 0
  case  subPaywaysMode = 1
}


class ChargePaywayPopView: UIView,UITableViewDelegate,UITableViewDataSource,UITextViewDelegate {

  var tableView : UITableView?
  //var recommendedView: UIView？

  private var paywaysMode : PaywaysMode?
  var paykindArr:[PayKindModel]?
  var paykindSubjectArr = Variable<[PayKindModel]>([])
  let disposeBag = DisposeBag()
  
  var paySubTypeSubjectArr = Variable<[PayTypeModel]>([])
  var payTypeArr:[PayTypeModel]?
  var activtyLabel:UILabel = UILabel()
  var isShowTopview:Bool = false;
  
  var callbackBlock: ((_ indexPath:IndexPath)->Void)?
  var linkCallbackBlock: (()->Void)?
  
  convenience init(frame: CGRect, payways:PaywaysMode) {
    self.init(frame: frame)
    
    self.isShowTopview = false
    let selfHeight:CGFloat = 240 + 90 + 65
    self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT - selfHeight - 10 ,  width: SCREEN_WIDTH, height:selfHeight )
    self.backgroundColor = UIColor.clear
    paywaysMode = payways
    setupView()
    bindUI()
  }
  
  func bindUI(){
    
    paykindSubjectArr.asObservable().subscribe(onNext: { [weak self]  (paykindArr) in
      self?.paykindArr = paykindArr
     
      // 背景的尺寸和tableview尺寸的计算
      let tabHeight:CGFloat = CGFloat(paykindArr.count * 60)
      let selfHeight = tabHeight + 90 + 65
      self?.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT - selfHeight - 10 ,  width: SCREEN_WIDTH, height:selfHeight)
      
      self?.tableView?.snp.updateConstraints({ (make) in
        make.height.equalTo(tabHeight)
      })
      self?.tableView?.reloadData()
      
    }).disposed(by:disposeBag)
    
    paySubTypeSubjectArr.asObservable().subscribe(onNext: { [weak self] (payTypeArr) in
      self?.payTypeArr = payTypeArr
      let tabHeight:CGFloat = CGFloat(payTypeArr.count * 60)
      let selfHeight = tabHeight + 90 + 65
      
      if payTypeArr.count >= 1 {
        self?.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT - selfHeight - 10 ,  width: SCREEN_WIDTH, height:selfHeight )
        self?.tableView?.snp.updateConstraints({ (make) in
          make.height.equalTo(tabHeight)
        })
      }
      self?.tableView?.reloadData()
      
    }).disposed(by:disposeBag)
  }
  
 private func setupView()  {
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.separatorStyle = .none
    self.addSubview(tableView!)
  
    let cancelBtn = UIButton.init(frame: .zero);
    self.addSubview(cancelBtn)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.backgroundColor = UIColor.view_popBlackColor
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.setTitleColor(UIColor.view_white, for: .normal)
    cancelBtn.titleLabel?.font = UIFont.M_Font
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.bottom.equalTo(-15)
      make.height.equalTo(60)
    }

    tableView?.snp.makeConstraints({ (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.bottom.equalTo(-80)
      make.height.equalTo(240)
    })
    tableView?.backgroundColor = UIColor.view_popBlackColor
    tableView?.layer.cornerRadius = 5.0
  
    // 顶部的图标
    let recommendedView = UILabel.init(frame: .zero)
    let content = "推荐“银联扫码/京东扫码”:满99加送0.5%，单日累计最高赠送¥1888，支持300多家APP扫码存款  查看支持APP"
    let clcikContent = "查看支持APP"
    recommendedView.text = content
    recommendedView.textAlignment = .center
    recommendedView.font = fontpfl12
    recommendedView.textColor = .white
    recommendedView.numberOfLines = 2
    self.addSubview(recommendedView)
    activtyLabel = recommendedView
  
    let contentAttributedStr = NSString.clickLinKStr(clcikContent, contentStr: content)
    recommendedView.attributedText = contentAttributedStr
  
    recommendedView.backgroundColor = UIColor.view_popBlackColor
    recommendedView.layer.cornerRadius = 5.0
    recommendedView.layer.masksToBounds = true
    recommendedView.isUserInteractionEnabled = true
    recommendedView.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.bottom.equalTo(tableView!.snp.top).offset(-5)
      make.height.equalTo(60)
    }
  
    let clickButtion = UIButton.init(frame: .zero)
    clickButtion.backgroundColor = UIColor.clear
    recommendedView.addSubview(clickButtion)
    clickButtion.addTarget(self, action: #selector(clicklink), for: .touchUpInside)
    clickButtion.snp.makeConstraints { (make) in
      make.width.equalTo(100)
      make.right.equalTo(-25)
      make.bottom.equalTo(-10)
      make.height.equalTo(20)
    }
  }
  
  @objc func clicklink(){
    if callbackBlock != nil {
       linkCallbackBlock?()
    }
    hidenView()
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if paywaysMode == PaywaysMode.mainPaywaysMode {
      return paykindArr?.count ?? 0
    }else if paywaysMode == PaywaysMode.subPaywaysMode {
      return self.payTypeArr?.count ?? 0
    }
    return 4
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "ChargeWaysTableViewCell") as? ChargeWaysTableViewCell
    if cell == nil {
      cell = ChargeWaysTableViewCell.init(style: .default, reuseIdentifier: "ChargeWaysTableViewCell", payway: paywaysMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    
    if  paywaysMode == PaywaysMode.mainPaywaysMode {
      
      let payKindModel = paykindArr?[indexPath.row]
      if let  kindModel = payKindModel {
        let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (kindModel.payKindIcon ?? "")
        cell?.imgView.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
        cell?.contentLab.text = kindModel.payKindName
        
        // 控制活动图标的显示与否
        var pypeArr:[String] = []
        let payTypeList:[PayTypeModel] = kindModel.payTypeList ?? []
        for (_, element) in payTypeList.enumerated() {
          let model:PayTypeModel = element
          pypeArr.append(model.payType ?? "")
        }
        
        if pypeArr.contains("15") || pypeArr.contains("16"){
          cell?.markImage.isHidden = false
          self.isShowTopview = true
          ManagerModel.instanse.isShowTopview = true
        }else{
          cell?.markImage.isHidden = true
        }
        
        if self.isShowTopview == true {
          activtyLabel.isHidden = false
        }else{
          activtyLabel.isHidden = true
        }
      }
      cell?.lineView.isHidden = indexPath.row == (paykindArr?.count ?? 0) - 1 ? true : false
      
    }else{
      
      let payTypeModel = payTypeArr?[indexPath.row]
      if let typeModel = payTypeModel {
        cell?.contentLab.text = typeModel.payTypeName
        let paytype = typeModel.payType
        if (paytype?.isEqual("15" as String) == true || paytype?.isEqual("16" as String) == true){
          cell?.markImage.isHidden = false
        }else{
          cell?.markImage.isHidden = true
        }
        if ManagerModel.instanse.isShowTopview == true {
          activtyLabel.isHidden = false
        }else{
          activtyLabel.isHidden = true
        }
      }
      cell?.lineView.isHidden = indexPath.row == (payTypeArr?.count ?? 0) - 1 ? true : false
    }
    
    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 60
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    if callbackBlock != nil {
       callbackBlock?(indexPath)
    }
    hidenView()
  }
  

  func showView(){
    MaskView.show(subView: self)
  }
  
  func hidenView(){
    MaskView.hiden()
  }
  
  @objc func cancelAction(){
    hidenView()
  }
  
  
  class ChargeWaysTableViewCell:UITableViewCell {
    
    let lineView:UIView = UIView.init()
    let contentLab = UILabel.init(frame: .zero)
    let imgView = UIImageView.init(frame: .zero)
    
    var markImage:UIImageView = UIImageView()
  
    private var  subPaywayMode:PaywaysMode?
    
    convenience init(style: UITableViewCellStyle, reuseIdentifier: String?,payway:PaywaysMode?) {
      self.init(style: style, reuseIdentifier: reuseIdentifier)
      
      subPaywayMode = payway
      setupView()
    }
    
    func setupView(){

      let backView = UIView.init(frame: .zero)
      contentView.addSubview(backView)
      backView.snp.makeConstraints { (make) in
        make.width.equalTo(150)
        make.top.bottom.equalToSuperview()
        make.centerX.equalTo(contentView.snp.centerX)
      }
      backView.addSubview(imgView)
      
      backView.addSubview(contentLab)
      contentLab.text = "支付宝存款"
      contentLab.textColor = UIColor.view_white
      contentLab.font = UIFont.M_Font
      
      // 1888活动的标签
      let activityMark = UIImageView.init(frame: .zero)
      activityMark.image = UIImage(named: "activity1888")
      backView.addSubview(activityMark)
      markImage = activityMark
      markImage.isHidden = true
      
      if subPaywayMode == PaywaysMode.mainPaywaysMode {
        imgView.image = UIImage.init(named: "logo")
        imgView.snp.makeConstraints { (make) in
          make.left.equalTo(backView).offset(0)
          make.centerY.equalTo(backView.snp.centerY)
          make.size.equalTo(CGSize.init(width: 40, height: 40))
        }
        contentLab.snp.makeConstraints { (make) in
          make.left.equalTo(imgView.snp.right).offset(15)
          make.centerY.equalTo(imgView.snp.centerY)
        }
        // 活动的标签
        activityMark.snp.makeConstraints { (make) in
          make.left.equalTo(contentLab.snp.right).offset(5)
          make.centerY.equalTo(contentLab.snp.centerY)
          make.size.equalTo(CGSize.init(width: 68, height: 20))
        }
      }else{
        contentLab.textAlignment = .center
        contentLab.snp.makeConstraints { (make) in
          make.left.equalTo(backView)
          make.right.equalTo(backView)
          make.centerY.equalTo(backView.snp.centerY)
        }
        // 活动的标签
        activityMark.snp.makeConstraints { (make) in
          make.left.equalTo(contentLab.snp.right).offset(5)
          make.centerY.equalTo(contentLab.snp.centerY)
          make.size.equalTo(CGSize.init(width: 68, height: 20))
        }
      }
      contentView.addSubview(lineView)
      lineView.backgroundColor = UIColor.view_lineColor
      lineView.snp.makeConstraints { (make) in
        make.left.right.equalToSuperview()
        make.bottom.equalTo(contentView.snp.bottom)
        make.height.equalTo(1)
      }
    }
    
  }
}
