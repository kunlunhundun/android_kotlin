//
//  TDetailProgressView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

public enum OneState:Int {
  case normal = 0
  case success = 1
  case failed = 2
  case allSuccess = 3
}

public enum IndexPro:Int {  //设置第几个的样式
  case one = 0
  case two = 1
  case three = 2
}

class TDetailProgressView: UIView {
  
  convenience  init(frame: CGRect ,oneState:OneState ,twoState:OneState = OneState.normal , threeState:OneState = OneState.normal, bigstate:FundRecordType) {
    self.init(frame: frame)
    
    var type = bigstate
    var newOneState = oneState
    var newTwoState = twoState
    if threeState == .success {
      newOneState = .allSuccess
      newTwoState = .allSuccess
    }
    
    let leftProgressView = ProgressView.init(frame: .zero, index: IndexPro.one, bigstate:type)
    self.addSubview(leftProgressView)
    leftProgressView.reDrawView(index: IndexPro.one, state: newOneState,bigstate:type)
    leftProgressView.snp.makeConstraints { (make) in
      make.left.equalTo(self)
      make.top.bottom.equalTo(self)
      make.width.equalTo(SCREEN_WIDTH/3.0)
    }
    
    let middleProgressView = ProgressView.init(frame: .zero, index: IndexPro.two, bigstate:type)
    self.addSubview(middleProgressView)
    middleProgressView.reDrawView(index: IndexPro.two, state: newTwoState,bigstate:type)
    middleProgressView.snp.makeConstraints { (make) in
      make.left.equalTo(SCREEN_WIDTH/3.0)
      make.top.bottom.equalTo(self)
      make.width.equalTo(SCREEN_WIDTH/3.0)
    }
    
    let rightProgressView = ProgressView.init(frame: .zero, index: IndexPro.three, bigstate:type)
    self.addSubview(rightProgressView)
    rightProgressView.reDrawView(index: IndexPro.three, state: threeState,bigstate:type)
    rightProgressView.snp.makeConstraints { (make) in
      make.left.equalTo(SCREEN_WIDTH/3.0*2)
      make.top.bottom.equalTo(self)
      make.width.equalTo(SCREEN_WIDTH/3.0)
    }
  }
}

class ProgressView: UIView {

  var leftLineView:UIView!
  var centerImgView:UIImageView!
  var rightLineView:UIView!
  var titleLab:UILabel!
  var timeLab:UILabel!

  convenience  init(frame: CGRect , index:IndexPro, bigstate:FundRecordType) {
    self.init(frame: frame)
    setupView(index: index, bigstate:bigstate)
  }
  
  func setupView(index:IndexPro,bigstate:FundRecordType){
    
    leftLineView = UIView.init(frame: .zero)  //#F56262 100%
    self.addSubview(leftLineView)
    leftLineView.backgroundColor = UIColor.view_white
    centerImgView = UIImageView.init(frame: .zero)
    self.addSubview(centerImgView)
    centerImgView.image = UIImage.init(named: "TranDeNormal")
    rightLineView = UIView.init(frame: .zero)
    self.addSubview(rightLineView)
    rightLineView.backgroundColor = UIColor.view_orangeColor
    
    titleLab = UILabel.init(frame: .zero)
    self.addSubview(titleLab)
    
    var titleStr = ""
    if bigstate == .deposit{ // 充值
      if index == IndexPro.one {
        titleStr = "提交订单"
      }else if index == IndexPro.two {
        titleStr = "结算处理中"
      }else if index == IndexPro.three {
        titleStr = "到账成功"
      }
    }
    if bigstate == .drawal{ // 提现
      if index == IndexPro.one {
        titleStr = "提现请求"
      }else if index == IndexPro.two {
        titleStr = "结算处理中"
      }else if index == IndexPro.three {
        titleStr = "到账成功"
      }
    }
    if bigstate == .wash{  // 洗码
      if index == IndexPro.one {
        titleStr = "洗码请求"
      }else if index == IndexPro.two {
        titleStr = "结算处理中"
      }else if index == IndexPro.three {
        titleStr = "到账成功"
      }
    }
    if bigstate == .discount{ // 优惠
      if index == IndexPro.one {
        titleStr = "优惠请求"
      }else if index == IndexPro.two {
        titleStr = "结算处理中"
      }else if index == IndexPro.three {
        titleStr = "到账成功"
      }
    }
    
    titleLab.text = titleStr
    titleLab.textAlignment = .center
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.M_Font
    
    timeLab = UILabel .init(frame: .zero)
    self.addSubview(timeLab)
    timeLab.text = ""
    timeLab.textAlignment = .center
    timeLab.textColor = UIColor.init(colorValue: 0xCDCDCD)
    timeLab.font = UIFont.S_Font
    
    centerImgView.snp.makeConstraints { (make) in
      make.top.equalTo(self).offset(15)
      make.size.equalTo(CGSize.init(width: 20, height: 20))
      make.centerX.equalTo(self)
    }
    leftLineView.snp.makeConstraints { (make) in
      make.left.equalTo(self)
      make.top.equalTo(centerImgView.snp.centerY)
      make.right.equalTo(centerImgView.snp.left)
      make.height.equalTo(1)
    }
    rightLineView.snp.makeConstraints { (make) in
      make.right.equalTo(self)
      make.top.equalTo(centerImgView.snp.centerY)
      make.left.equalTo(centerImgView.snp.right)
      make.height.equalTo(1)
    }
    titleLab.snp.makeConstraints { (make) in
      make.left.equalTo(self)
      make.right.equalTo(self)
      make.top.equalTo(centerImgView.snp.bottom).offset(10)
      make.height.equalTo(20)
    }
    timeLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(titleLab.snp.bottom).offset(5)
      make.height.equalTo(16)
    }
    
    if  index == IndexPro.one {
      leftLineView.isHidden = true
      centerImgView.image = UIImage.init(named: "TranDeNormal")
      rightLineView.backgroundColor = UIColor.view_white
    }
    if index == IndexPro.two {
      leftLineView.backgroundColor = UIColor.view_white
      centerImgView.image = UIImage.init(named: "TranDeNormal")
      rightLineView.backgroundColor = UIColor.view_white
    }
    if index == IndexPro.three {
      leftLineView.backgroundColor = UIColor.view_white
      centerImgView.image = UIImage.init(named: "TranDeNormal")
      rightLineView.backgroundColor = UIColor.view_white
    }
  }
  
  
  public func reDrawView(index:IndexPro, state:OneState, bigstate:FundRecordType){
    
    
    if index == IndexPro.one && state == OneState.normal {
      leftLineView.isHidden = true
      centerImgView.image = UIImage.init(named: "IconOrderGray")
      rightLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
    }
    else if index == IndexPro.one && state == OneState.success{
      leftLineView.isHidden = true
      centerImgView.image = UIImage.init(named: "IconCheck")
      rightLineView.backgroundColor = UIColor.view_blueColor
    }
    else if index == IndexPro.one && state == OneState.failed {
      leftLineView.isHidden = true
      centerImgView.image = UIImage.init(named: "IconCaution")
      rightLineView.backgroundColor = UIColor.view_orangeColor
    }
    else if index == IndexPro.one && state == OneState.allSuccess {
      leftLineView.isHidden = true
      centerImgView.image = UIImage.init(named: "IconOrderBlue")
      rightLineView.backgroundColor = UIColor.font_blueColor
    }
    else if index == IndexPro.two && state == OneState.normal {
      leftLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
      centerImgView.image = UIImage.init(named: "IconOrderGray")
      rightLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
      titleLab.textColor = UIColor.font_lightBlackWhiteColor
    }
    else if index == IndexPro.two && state == OneState.success{
      leftLineView.backgroundColor = UIColor.view_blueColor
      centerImgView.image = UIImage.init(named: "IconCheck")
      rightLineView.backgroundColor = UIColor.view_blueColor
    }
    else if index == IndexPro.two && state == OneState.failed {
      leftLineView.backgroundColor = UIColor.view_orangeColor
      centerImgView.image = UIImage.init(named: "IconCaution")
      rightLineView.backgroundColor = UIColor.view_orangeColor
    } else if index == IndexPro.two && state == OneState.allSuccess {
      leftLineView.backgroundColor = UIColor.font_blueColor
      centerImgView.image = UIImage.init(named: "IconOrderBlue")
      rightLineView.backgroundColor = UIColor.font_blueColor
    }
    else if index == IndexPro.three && state == OneState.normal {
      leftLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
      centerImgView.image = UIImage.init(named: "IconOrderGray")
      rightLineView.isHidden = true
      titleLab.textColor = UIColor.font_lightBlackWhiteColor
    }
    else if index == IndexPro.three && state == OneState.success{
      leftLineView.backgroundColor = UIColor.font_blueColor
      centerImgView.image = UIImage.init(named: "IconOrderBlue")
      rightLineView.isHidden = true
    }
    else if index == IndexPro.three && state == OneState.failed {
      leftLineView.backgroundColor = UIColor.view_orangeColor
      centerImgView.image = UIImage.init(named: "IconCaution")
      rightLineView.isHidden = true
    }
    
    
    // 优惠
    if bigstate == .wash || bigstate == .discount{
      if index == IndexPro.one && state == OneState.normal {
        leftLineView.isHidden = true
        centerImgView.image = UIImage.init(named: "IconOrderGray")
        rightLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
      else if index == IndexPro.one && state == OneState.success{
        leftLineView.isHidden = true
        centerImgView.image = UIImage.init(named: "IconCheck")
        rightLineView.backgroundColor = UIColor.view_blueColor
        titleLab.textColor = UIColor.white
      }
      else if index == IndexPro.one && state == OneState.failed {
        leftLineView.isHidden = true
        centerImgView.image = UIImage.init(named: "IconCaution")
        rightLineView.backgroundColor = UIColor.view_orangeColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
      else if index == IndexPro.one && state == OneState.allSuccess {
        leftLineView.isHidden = true
        centerImgView.image = UIImage.init(named: "IconOrderBlue")
        rightLineView.backgroundColor = UIColor.font_blueColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
        
        
      else if index == IndexPro.two && state == OneState.normal {
        leftLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
        centerImgView.image = UIImage.init(named: "IconOrderGray")
        rightLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
      else if index == IndexPro.two && state == OneState.success{
        leftLineView.backgroundColor = UIColor.view_blueColor
        centerImgView.image = UIImage.init(named: "IconCheck")
        rightLineView.backgroundColor = UIColor.view_blueColor
        titleLab.textColor = UIColor.white
      }
      else if index == IndexPro.two && state == OneState.failed {
        leftLineView.backgroundColor = UIColor.view_orangeColor
        centerImgView.image = UIImage.init(named: "IconCaution")
        rightLineView.backgroundColor = UIColor.view_orangeColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
      else if index == IndexPro.two && state == OneState.allSuccess {
        leftLineView.backgroundColor = UIColor.font_blueColor
        centerImgView.image = UIImage.init(named: "IconOrderBlue")
        rightLineView.backgroundColor = UIColor.font_blueColor
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
        
      else if index == IndexPro.three && state == OneState.normal {
        leftLineView.backgroundColor = UIColor.font_lightBlackWhiteColor
        centerImgView.image = UIImage.init(named: "IconOrderGray")
        rightLineView.isHidden = true
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
      else if index == IndexPro.three && state == OneState.success{
        leftLineView.backgroundColor = UIColor.font_blueColor
        centerImgView.image = UIImage.init(named: "IconOrderBlue")
        rightLineView.isHidden = true
        titleLab.textColor = UIColor.white
      }
      else if index == IndexPro.three && state == OneState.failed {
        leftLineView.backgroundColor = UIColor.view_orangeColor
        centerImgView.image = UIImage.init(named: "IconCaution")
        rightLineView.isHidden = true
        titleLab.textColor = UIColor.font_lightBlackWhiteColor
      }
    }
    
  }
}
