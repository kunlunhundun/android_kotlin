//
//  BTCPayOrderPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 13/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class BTCPayOrderPopView:  UIView,UITableViewDataSource,UITableViewDelegate  {

  var tableView:UITableView?
  var backMaskView:MaskView?
  var backTableView:UIView?
  
  var btcPayOrderModel:PayOnlineOrderModel?
  var callbackBlock: (()->Void)?

  
  convenience init(frame: CGRect, btcOrderModel:PayOnlineOrderModel) {
    self.init(frame: frame)
    
    self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT-350-BOTTOM_MARGIN ,  width: SCREEN_WIDTH, height:350 )
    self.backgroundColor = UIColor.clear
 
    btcPayOrderModel = btcOrderModel
    setupView()
  }
  
  func setupView(){
    
    backTableView = UIView.init(frame: .zero)
    backTableView?.backgroundColor = UIColor.view_popBlackColor
    backTableView?.layer.cornerRadius = 5.0
    backTableView?.clipsToBounds = true
    self.addSubview(backTableView!)
    backTableView?.snp.makeConstraints({ (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.bottom.equalToSuperview()
    })
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.backgroundColor = .clear
    tableView?.separatorStyle = .none
    backTableView?.addSubview(tableView!)
    
    tableView?.snp.makeConstraints({ (make) in
      make.left.right.bottom.equalToSuperview()
      make.top.equalTo(self).offset(40)
    })
    
    let headView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH - CGFloat(View_Margin*2) , height: 40))
    backTableView?.addSubview(headView)
    headView.backgroundColor = UIColor.view_popBlackColor
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "确认存款"
    titleLab.textAlignment = .center
    headView.addSubview(titleLab)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(headView.snp.centerX)
    }
   
    let closeBtn = UIButton.init(frame: .zero)
    headView.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(headView.snp.right).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    
    let lineView = UIView.init(frame: .zero)
    headView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.bottom.equalTo(headView.snp.bottom)
    }
    
    let footerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 60))
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    footerView.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((footerView.newWidth-10*3)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    footerView.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("前往支付", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(10)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
    tableView?.tableFooterView = footerView
  }
  
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
  
    return 5
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "IndentifierTitleAndDetailModeCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "IndentifierTitleAndDetailModeCell", cellMode: CellMode.titleAndDetailMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
      cell?.td_desLab?.textColor = UIColor.view_white
    }
    if indexPath.row == 0 {
      cell?.td_desLab?.text = "订单号"
      cell?.td_detailLab?.text = btcPayOrderModel?.billNo
    }else if indexPath.row == 1 {
      cell?.td_desLab?.text = "存款金额"
      cell?.td_detailLab?.text = btcPayOrderModel?.amount
    }else if indexPath.row == 2 {
      cell?.td_desLab?.text = "存款方式"
      cell?.td_detailLab?.text = "比特币支付"
    }else if indexPath.row == 3 {
      cell?.td_desLab?.text = "存款账户"
      cell?.td_detailLab?.text = btcPayOrderModel?.name
    }else if indexPath.row == 4 {
      cell?.td_desLab?.text = "订单时间"
      cell?.td_detailLab?.text = btcPayOrderModel?.billDate
      cell?.td_lineView?.isHidden = true
    }
    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 50
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    
  }
  
  
  @objc func sureAction(){
    
    callbackBlock?()
    hidenView()
  }
  
  @objc func cancelAction(){
    
       hidenView()
  }
  
  @objc func closeAction(){
    
    hidenView()
  }
  
  func showView(){
    backMaskView = MaskView.init(frame: .zero);
    backMaskView?.showView(subView: self)
  }
  
  func hidenView(){
    backMaskView?.hidenView()
  }
}
