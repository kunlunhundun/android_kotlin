//
//  AlipayWechatOrderView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 17/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class AlipayWechatOrderView: UIView {

  var timerView:AlipayTimerView! = nil
  var bqPaymentModel:BQPaymentModel?
  var copyNameOrCardOrAddrBlock:((_ index:Int) -> Void)? // 0 name 1 card 1 address
  var aliWxGuidBlock:(() -> Void)? // 0 name 1 card 1 address


  convenience  init(frame: CGRect, model:BQPaymentModel? ) {
    self.init(frame: frame)
    
    bqPaymentModel = model
    
    setupView()
    
    if model?.payWayCode == .manualBankPay {
      amountTipLabel.text = "存款金额"
      amountTipLabel.textColor = UIColor.font_lightWhiteColor
    }
    orderTipRealNameLabel.text = model?.realName
    let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (model?.bankIcon ?? "")
    bankLogoImage.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
    bankNameLabel.text = model?.bankName
    realNameLabel.text = model?.accountName
    bankNumLabel.text = NSString.bankCardBlankFormat(model?.accountNo)
    bankAddressLabel.text = (model?.bankCity ?? "") + " " + (model?.bankBranchName ?? "")
  }
  
  
  lazy var backScrollView:UIScrollView = {
    
    var scrollView = UIScrollView.init(frame: .zero)
    scrollView.showsVerticalScrollIndicator = false
    scrollView.showsHorizontalScrollIndicator = false
    scrollView.isScrollEnabled = true
    return scrollView
    
  }()

  

  
  func setupView(){
    
    self.addSubview(backScrollView)
    
    if #available(iOS 11.0, *) {
      backScrollView.contentInsetAdjustmentBehavior = .never
    } else {
      
    }
    backScrollView.snp.makeConstraints { (make) in
      make.top.bottom.left.right.equalTo(self)
    }
  
    let limitTime = bqPaymentModel?.payLimitTime ?? "0"
    timerView = AlipayTimerView.init(frame: .zero, timeStr: limitTime)
    backScrollView.addSubview(timerView)
    timerView.isHidden = true
    backScrollView.addSubview(amountLabel)
    backScrollView.addSubview(amountTipLabel)
    backScrollView.addSubview(orderTipImageView)

    alipayTipView.addSubview(orderTipLabel)
    alipayTipView.addSubview(orderTipRealNameLabel)
    alipayTipView.addSubview(orderTipNameContentLabel)

    orderTipImageView.addSubview(alipayTipView)
    orderTipImageView.addSubview(orderContentLabel)
    
    backScrollView.addSubview(bankCardInfoImageView)
    bankCardInfoImageView.addSubview(bankLogoImage)
    bankCardInfoImageView.addSubview(bankNameLabel)
    bankCardInfoImageView.addSubview(lineView)
    bankCardInfoImageView.addSubview(realNameLabel)
    bankCardInfoImageView.addSubview(realNameCopyBtn)
    bankCardInfoImageView.addSubview(bankNumLabel)
    bankCardInfoImageView.addSubview(bankNumCopyBtn)
    bankCardInfoImageView.addSubview(bankAddressLabel)
    bankCardInfoImageView.addSubview(addressCopyBtn)
    
    backScrollView.addSubview(aliWxGuidBtn)
    backScrollView.addSubview(openAlipayBtn)
    backScrollView.addSubview(queryOrderBtn)
    
    if bqPaymentModel?.payWayCode == .bankBQPay {
      if bqPaymentModel?.amount?.contains(".") == false{
        bqPaymentModel?.amount = (bqPaymentModel?.amount ?? "") + ".00"
      }
    }
    amountLabel.text =  "¥ " + (bqPaymentModel?.amount ?? "")
    var amount = amountLabel.text ?? ""
    var decimal = ""
    let array = amountLabel.text?.components(separatedBy: ".")
    if let count =  array?.count  {
      if count > 1 {
        amount = array?[0] ?? ""
      }
      if count >= 2 {
        decimal = "." + (array?[1] ?? "")
      }
    }

      NSString.changeUILablePartColor(amountLabel, change: decimal, andAllColor: UIColor.view_white, andMark: UIColor.init(colorValue: 0xE9664B), andMark: UIFont.PFM30_Font)

    timerView.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalTo(5)
      make.width.equalTo(100)
      make.height.equalTo(30)
    }
    
    amountLabel.snp.makeConstraints { (make) in
      make.top.equalTo(timerView.snp.bottom).offset(5)
      make.left.equalTo(self).offset(0)
      make.right.equalTo(self).offset(0)
      make.height.equalTo(30);
    }
    
    amountTipLabel.snp.makeConstraints { (make) in
      make.top.equalTo(amountLabel.snp.bottom).offset(10);
      make.left.equalTo(self).offset(0)
      make.right.equalTo(self).offset(0)
      make.height.equalTo(20);
    }
    
    orderTipImageView.snp.makeConstraints { (make) in
      make.top.equalTo(amountTipLabel.snp.bottom).offset(10);
      make.left.equalTo(self.snp.left).offset(View_Margin);
      make.right.equalTo(self).offset(-View_Margin);
      make.height.equalTo(92);
      }
    alipayTipView.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipImageView.snp.top).offset(10);
      make.centerX.equalTo(orderTipImageView.snp.centerX).offset(0);
      make.width.equalTo(270);
      make.height.equalTo(25);
      }
    
    orderTipLabel.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipImageView.snp.top).offset(10);
      make.left.equalTo(alipayTipView.snp.left).offset(0);
      make.width.equalTo(50);
      make.height.equalTo(25);
      }
    
   orderTipRealNameLabel.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipLabel.snp.top).offset(0);
      make.left.equalTo(orderTipLabel.snp.right).offset(0);
      make.width.equalTo(52);
      make.height.equalTo(25);
      }
    
    orderTipNameContentLabel.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipLabel.snp.top).offset(0);
      make.left.equalTo(orderTipRealNameLabel.snp.right).offset(3);
      make.right.equalTo(orderTipImageView.snp.right).offset(0);
      make.height.equalTo(25);
      }
    
    orderContentLabel.snp.makeConstraints { (make) in
      make.top.equalTo(alipayTipView.snp.bottom).offset(10);
      make.left.equalTo(orderTipImageView.snp.left).offset(0);
      make.right.equalTo(orderTipImageView.snp.right).offset(0);
      make.height.equalTo(25);
      }
    
    
    bankCardInfoImageView.snp.makeConstraints { (make) in
      make.top.equalTo(orderTipImageView.snp.bottom).offset(15);
      make.left.equalTo(self.snp.left).offset(View_Margin);
      make.right.equalTo(self.snp.right).offset(-View_Margin);
      make.height.equalTo(196);
      }
    
   bankLogoImage.snp.makeConstraints { (make) in
      make.top.equalTo(bankCardInfoImageView.snp.top).offset(15);
      make.left.equalTo(bankCardInfoImageView.snp.left).offset(16);
      make.width.equalTo(24);
      make.height.equalTo(24);
      }
    
    bankNameLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(bankLogoImage.snp.centerY);
      make.left.equalTo(bankLogoImage.snp.right).offset(7);
      make.height.equalTo(30);
      }
    
    lineView.snp.makeConstraints { (make) in
      make.top.equalTo(bankNameLabel.snp.bottom).offset(15);
      make.left.equalTo(bankCardInfoImageView.snp.left).offset(View_Margin);
      make.right.equalTo(bankCardInfoImageView.snp.right).offset(-View_Margin);
      make.height.equalTo(1);
      };
    
   realNameCopyBtn.snp.makeConstraints { (make) in
      make.top.equalTo(lineView.snp.bottom).offset(8);
      make.right.equalTo(bankCardInfoImageView.snp.right).offset(-20);
      make.width.equalTo(60);
      make.height.equalTo(30);
      }
    
    realNameLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(realNameCopyBtn.snp.centerY);
      make.left.equalTo(bankLogoImage.snp.left);
      make.right.equalTo(realNameCopyBtn.snp.left);
      make.height.equalTo(30);
      }
    
    bankNumCopyBtn.snp.makeConstraints { (make) in
      make.top.equalTo(realNameCopyBtn.snp.bottom).offset(12);
      make.right.equalTo(bankCardInfoImageView.snp.right).offset(-20);
      make.width.equalTo(60);
      make.height.equalTo(30);
      }
    
    bankNumLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(bankNumCopyBtn.snp.centerY);
      make.left.equalTo(bankLogoImage.snp.left);
      make.right.equalTo(bankNumCopyBtn.snp.left).offset(-2);
      make.height.equalTo(30);
      }
    
    aliWxGuidBtn.snp.makeConstraints { (make) in
      make.left.equalTo(bankCardInfoImageView.snp.left)
      make.top.equalTo(bankCardInfoImageView.snp.bottom)
      make.width.equalTo(150)
      make.height.equalTo(50)
    }
    
    openAlipayBtn.snp.makeConstraints { (make) in
      make.top.equalTo(aliWxGuidBtn.snp.bottom).offset(20);
      make.left.equalTo(self.snp.left).offset(View_Margin);
      make.right.equalTo(self).offset(-View_Margin)
      make.height.equalTo(52);
      }
    
    queryOrderBtn.snp.makeConstraints { (make) in
      make.top.equalTo(openAlipayBtn.snp.bottom).offset(25);
      make.left.equalTo(self.snp.left).offset(View_Margin);
      make.right.equalTo(self).offset(-View_Margin);
      make.height.equalTo(20);
      }
    
    aliWxGuidBtn.isHidden = true
    
    if bqPaymentModel?.payWayCode == .alipay {
      aliWxGuidBtn.isHidden = false

    }else if bqPaymentModel?.payWayCode == .wxpay {
      aliWxGuidBtn.isHidden = false
      aliWxGuidBtn.setTitle("微信转账教程", for: .normal)
    }
    if bqPaymentModel?.payWayCode == .manualBankPay {
      openAlipayBtn.isHidden = true
      queryOrderBtn.isHidden = true
      backScrollView.addSubview(manualTipLabel)
      backScrollView.addSubview(manualOrderBtn)
      
     let width = SCREEN_WIDTH - CGFloat(View_Margin * 2)
      let tipSize = manualTipLabel.sizeThatFits(CGSize.init(width: width, height: 200))
      manualTipLabel.snp.makeConstraints { (make) in
        make.top.equalTo(bankCardInfoImageView.snp.bottom).offset(20);
        make.left.equalTo(self.snp.left).offset(View_Margin);
        make.right.equalTo(self).offset(-View_Margin)
        make.height.equalTo(tipSize.height);
      }
      manualOrderBtn.snp.makeConstraints { (make) in
        make.left.equalTo(self.snp.left).offset(View_Margin);
        make.right.equalTo(self).offset(-View_Margin)
        make.top.equalTo(manualTipLabel.snp.bottom).offset(20)
        make.height.equalTo(52)
      }
      self.layoutIfNeeded()
      backScrollView.layoutIfNeeded()
      let height:CGFloat =   manualOrderBtn.frame.maxY
      backScrollView.contentSize =  CGSize.init(width: SCREEN_WIDTH, height: height+20)
      
    }else if bqPaymentModel?.payWayCode == .bankBQPay {
      
      bankAddressLabel.snp.makeConstraints { (make) in
        make.top.equalTo(bankNumLabel.snp.bottom).offset(12);
        make.left.equalTo(bankLogoImage.snp.left);
        make.right.equalTo(bankCardInfoImageView.snp.right).offset(-90);
        make.height.equalTo(40);
      }
      addressCopyBtn.snp.makeConstraints { (make) in
        make.centerY.equalTo(bankAddressLabel.snp.centerY)
        make.right.equalTo(bankCardInfoImageView.snp.right).offset(-20);
        make.width.equalTo(60);
        make.height.equalTo(30);
      }
      
      backScrollView.addSubview(bankCodeBackView)
      bankCodeBackView.addSubview(warnImgView)
      bankCodeBackView.addSubview(codeDesLabel)
      bankCodeBackView.addSubview(codeContentLabel)
      bankCodeBackView.snp.makeConstraints { (make) in
        make.top.equalTo(bankCardInfoImageView.snp.bottom).offset(10)
        make.left.equalTo(bankCardInfoImageView.snp.left)
        make.right.equalTo(bankCardInfoImageView.snp.right)
        make.height.equalTo(50)
      }
      warnImgView.snp.makeConstraints { (make) in
        make.left.equalToSuperview().offset(20)
        make.centerY.equalToSuperview()
        make.width.height.equalTo(15)
      }
      codeDesLabel.snp.makeConstraints { (make) in
        make.left.equalTo(warnImgView.snp.right).offset(8)
        make.top.bottom.equalToSuperview()
      }
      codeContentLabel.snp.makeConstraints { (make) in
        make.right.equalToSuperview().offset(-20)
        make.top.bottom.equalToSuperview()
        make.width.equalTo(60);

      }
      codeContentLabel.text = bqPaymentModel?.postscript
      
      backScrollView.addSubview(manualTipLabel)
      manualTipLabel.text = "存款提示：支持网银、ATM机、电话银行等方式，存款成功后，1-3分钟内即可到账"
      let width = SCREEN_WIDTH - CGFloat(View_Margin * 2)
      let tipSize = manualTipLabel.sizeThatFits(CGSize.init(width: width, height: 200))
      manualTipLabel.snp.makeConstraints { (make) in
        make.top.equalTo(bankCodeBackView.snp.bottom).offset(8);
        make.left.equalTo(self.snp.left).offset(View_Margin);
        make.right.equalTo(self).offset(-View_Margin)
        make.height.equalTo(tipSize.height);
      }
      queryOrderBtn.snp.makeConstraints { (make) in
        make.top.equalTo(manualTipLabel.snp.bottom).offset(25);
        make.left.equalToSuperview().offset(View_Margin);
        make.right.equalToSuperview().offset(-View_Margin);
        make.height.equalTo(25);
      }
      
      self.layoutIfNeeded()
      backScrollView.layoutIfNeeded()
      openAlipayBtn.isHidden = true
      let height:CGFloat =   queryOrderBtn.frame.maxY
      backScrollView.contentSize =  CGSize.init(width: SCREEN_WIDTH, height: height+20)
    }
    
    if bqPaymentModel?.payWayCode == .wxpay {
      openAlipayBtn.backgroundColor = UIColor.init(colorValue: 0x24AB3A)
      openAlipayBtn.setTitle("启动微信客户端", for: .normal)
      openAlipayBtn.setImage(UIImage.init(named: "wechatpay"), for: .normal)
    }else if bqPaymentModel?.payWayCode == .alipay {
      
    }
    
    
  }
  
  
  
  lazy var amountLabel:UILabel = {
    var amountLab = UILabel.init(frame: .zero)
    amountLab.font = UIFont.PFM30_Font
    amountLab.textColor = UIColor.view_white
    amountLab.textAlignment = .center
    return amountLab
  }()
  
  lazy var amountTipLabel:UILabel = {
    var amountTipLab = UILabel.init(frame: .zero)
    amountTipLab.font = UIFont.M_Font
    amountTipLab.textColor = UIColor.init(colorValue: 0xE14040)
    amountTipLab.textAlignment = .center
    amountTipLab.text = "转账金额（须包含小数位）"
    return amountTipLab
  }()
  
  lazy var orderTipImageView:UIImageView = {
    var orderTipImgView = UIImageView.init(frame: .zero)
    orderTipImgView.image = UIImage.init(named: "bg_payment_guide")
    return orderTipImgView
  }()
  
  lazy var alipayTipView:UIView = {
    var aliTipView = UIView.init(frame: .zero)
    return aliTipView
  }()
  
  lazy var orderTipLabel:UILabel = {
    var orderTipLab = UILabel.init(frame: .zero)
    orderTipLab.font = UIFont.PFMM_Font
    orderTipLab.textColor = UIColor.view_white
    orderTipLab.text = "请使用"
    return orderTipLab
  }()
  
  lazy var orderTipRealNameLabel:UILabel = {
    var realNameLab = UILabel.init(frame: .zero)
    realNameLab.font = UIFont.PFMM_Font
    realNameLab.textColor = UIColor.view_white
    realNameLab.text = ""
    realNameLab.layer.cornerRadius = 3.0
    realNameLab.clipsToBounds = true
    realNameLab.backgroundColor = UIColor.init(colorValue: 0x8095FF)
    realNameLab.textAlignment = .center

    return realNameLab
  }()
  
  lazy var orderTipNameContentLabel:UILabel = {
    var orderNameContentLab = UILabel.init(frame: .zero)
    orderNameContentLab.font = UIFont.PFMM_Font
    orderNameContentLab.textColor = UIColor.view_white
    orderNameContentLab.text = "的账户转账到以下银行卡"
    return orderNameContentLab
  }()
  
  lazy var orderContentLabel:UILabel = {
    var orderContentLab = UILabel.init(frame: .zero)
    orderContentLab.font = UIFont.PFMM_Font
    orderContentLab.textAlignment = .center
    orderContentLab.textColor = UIColor.view_white
    orderContentLab.text = "转账金额须保持一致，以确保自动匹配到账"
    return orderContentLab
  }()
  
  lazy var bankCardInfoImageView:UIImageView = {
    var bankCardInfoImgView = UIImageView.init(frame: .zero)
    bankCardInfoImgView.image = UIImage.init(named: "bg_bankcard")
    bankCardInfoImgView.contentMode = .scaleToFill
    bankCardInfoImgView.isUserInteractionEnabled = true
    return bankCardInfoImgView
    }()
    
  lazy var bankLogoImage:UIImageView = {
    var bankLogoImg = UIImageView.init(frame: .zero)
    bankLogoImg.image = UIImage.init(named: "LogoCMB")
    return bankLogoImg
    }()
    
  lazy var bankNameLabel:UILabel = {
    var bankNameLab = UILabel.init(frame: .zero)
    bankNameLab.font = UIFont.PFML_Font
    bankNameLab.textColor = UIColor.view_white
    bankNameLab.text = "招商银行"
    return bankNameLab
    }()
    
  lazy var lineView:UIView = {
    var lineV = UIView.init(frame: .zero)
    lineV.backgroundColor = UIColor.init(colorValue: 0x535C8B)
    return lineV
    }()
    
  lazy var realNameLabel:UILabel = {
    var nameLab = UILabel.init(frame: .zero)
    nameLab.font = UIFont.PFMXL_Font
    nameLab.textColor = UIColor.view_white
    nameLab.text = ""
    return nameLab
    }()
  
  lazy var bankNumLabel:UILabel = {
    var bankNumLab = UILabel.init(frame: .zero)
    bankNumLab.font = UIFont.PFMXL_Font
    bankNumLab.textColor = UIColor.view_white
    bankNumLab.text = "6214 8300 5566 7788"
    return bankNumLab
    }()
 
  lazy var bankAddressLabel:UILabel = {
    var bankAddressLab = UILabel.init(frame: .zero)
    bankAddressLab.font = UIFont.M_Font
    bankAddressLab.textColor = UIColor.init(colorValue: 0x888888)
    bankAddressLab.numberOfLines = 0
    bankAddressLab.text = "北京市 北京分行朝阳支行"
    return bankAddressLab
    }()
    
    
  lazy var realNameCopyBtn:UIButton = {
    var nameCopyBtn = UIButton.init(frame: .zero)
    nameCopyBtn.setTitle("复制", for: .normal)
    nameCopyBtn.setTitleColor(UIColor.init(colorValue: 0xffffff), for: .normal)
    nameCopyBtn.backgroundColor = UIColor.init(colorValue: 0x8095ff)
    nameCopyBtn.layer.cornerRadius = 15
    nameCopyBtn.clipsToBounds = true
    nameCopyBtn.addTarget(self, action: #selector(copyBtnAction( _: )), for: .touchUpInside)
    return nameCopyBtn
    
    }()
  
  lazy var bankNumCopyBtn:UIButton = {
    var bankNumBtn = UIButton.init(frame: .zero)
    bankNumBtn.setTitle("复制", for: .normal)
    bankNumBtn.setTitleColor(UIColor.init(colorValue: 0xffffff), for: .normal)
    bankNumBtn.backgroundColor = UIColor.init(colorValue: 0x8095ff)
    bankNumBtn.layer.cornerRadius = 15
    bankNumBtn.clipsToBounds = true
    bankNumBtn.addTarget(self, action: #selector(copyBtnAction( _: )), for: .touchUpInside)
    return bankNumBtn
    
  }()
  
  lazy var addressCopyBtn:UIButton = {
    var copyBtn = UIButton.init(frame: .zero)
    copyBtn.setTitle("复制", for: .normal)
    copyBtn.setTitleColor(UIColor.init(colorValue: 0xffffff), for: .normal)
    copyBtn.backgroundColor = UIColor.init(colorValue: 0x8095ff)
    copyBtn.layer.cornerRadius = 15
    copyBtn.clipsToBounds = true
    copyBtn.addTarget(self, action: #selector(copyBtnAction( _: )), for: .touchUpInside)
    return copyBtn
    
  }()
  lazy var aliWxGuidBtn:UIButton = {
    var guidBtn = UIButton.init(frame: .zero)
    guidBtn.contentHorizontalAlignment = .left
    guidBtn.setTitle("支付宝转账教程", for: .normal)
    guidBtn.setTitleColor(UIColor.init(colorValue: 0x8095ff), for: .normal)
    guidBtn.clipsToBounds = true
    guidBtn.addTarget(self, action: #selector(aliWxGuidBtnAction), for: .touchUpInside)
    return guidBtn
    
  }()
  
  
  lazy var openAlipayBtn:UIButton = {
    var openBtn = UIButton.init(frame: .zero)
    openBtn.setTitle("启动支付宝客户端", for: .normal)
    openBtn.setTitleColor(UIColor.view_white, for: .normal)
    openBtn.backgroundColor = UIColor.init(colorValue: 0x3DA7F2)
    openBtn.titleLabel?.font =  UIFont.PFML_Font
    openBtn.layer.cornerRadius = 5
    openBtn.clipsToBounds = true
    openBtn.setImage(UIImage.init(named: "AlipayLogo"), for: .normal)
    openBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 10)
    openBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0)
    openBtn.addTarget(self, action: #selector(openAlipayBtnAction), for: .touchUpInside)
    return openBtn
    
  }()
  
  lazy var bankCodeBackView:UIView = {
    var codeBackView = UIView.init(frame: .zero)
    codeBackView.backgroundColor = UIColor.init(colorValue: 0x2C2F3E)
    codeBackView.layer.cornerRadius = 5.0
    codeBackView.layer.borderWidth = 1.0
    codeBackView.layer.borderColor = UIColor.init(colorValue: 0x4B537A).cgColor
    return codeBackView
  }()
  
  lazy var warnImgView:UIImageView = {
    
    var imageView = UIImageView.init(frame: .zero)
    imageView.image = Image.init(named:"icon_code_warn")
    return imageView
  }()
 
  lazy var codeDesLabel:UILabel = {
    var desLab = UILabel.init(frame: .zero)
    desLab.font = UIFont.M_Font
    desLab.textColor = UIColor.view_white
    desLab.text = "想加速到账？转账时备注："
    return desLab
  }()
  
  lazy var codeContentLabel:UILabel = {
    var codeLab = UILabel.init(frame: .zero)
    codeLab.font = UIFont.PFM20_Font
    codeLab.textAlignment = .center
    codeLab.textColor = UIColor.font_purplishRedColor
    codeLab.text = "9988"
    return codeLab
  }()
  
  lazy var queryOrderBtn:UIButton = {
    var queryBtn = UIButton.init(frame: .zero)
    queryBtn.setTitle("已完成支付？查询订单进度", for: .normal)
    queryBtn.titleLabel?.font =  UIFont.PFMM_Font
    queryBtn.setTitleColor(UIColor.font_blueColor, for: .normal)
    queryBtn.addTarget(self, action: #selector(queryOrderBtnAction), for: .touchUpInside)
    return queryBtn
    
  }()
  
  lazy var manualTipLabel:UILabel = {
    var manualLab = UILabel.init(frame: .zero)
    manualLab.font = UIFont.M_Font
    manualLab.numberOfLines = 10
    manualLab.textColor = UIColor.font_lightWhiteColor
    manualLab.text = "存款提示：支持网银、支付宝、ATM机、柜台等方式存款到以上银行卡（单笔存款不能低于100元），存款成功后请提交存款明细，以便为您处理到账"
    return manualLab
    
  }()
  
  lazy var manualOrderBtn:UIButton = {
    var sureBtn = UIButton.init(frame: .zero)
    sureBtn.setTitle("我已支付，填写明细", for: .normal)
    sureBtn.titleLabel?.font =  UIFont.PFML_Font
    sureBtn.setTitleColor(UIColor.view_white, for: .normal)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.backgroundColor = UIColor.btn_rightRed
    sureBtn.addTarget(self, action: #selector(manualOrderBtnAction), for: .touchUpInside)
    return sureBtn
    
  }()
  
  

  @objc func aliWxGuidBtnAction(){
    
    aliWxGuidBlock?()
    
  }
  
  @objc func manualOrderBtnAction(){
    
    self.nearNav()?.pushViewController(ManualBankInputDetailViewController.init(paymentOrder: bqPaymentModel), animated: true)
    
  }

  @objc func openAlipayBtnAction(){
    
    if bqPaymentModel?.payWayCode == .alipay {
    
      OpenOtherApp.openOtherApp(withURL: "alipayqr://platformapi/startapp?saId=20000116",complete: { (isSuccess) in
        if !isSuccess {
          ProgressTopPopView.showPopView(content: "您还未安装支付宝", popStyle: .errorMsgToast)
        }
      })
      
    }else if bqPaymentModel?.payWayCode == .wxpay{
      
      OpenOtherApp.openOtherApp(withURL: "wechat://",complete: { (isSuccess) in
        if !isSuccess {
          ProgressTopPopView.showPopView(content: "您还未安装微信", popStyle: .errorMsgToast)
        }
      })
    }
    
  }
  
  @objc func queryOrderBtnAction(){
    
    let transacDetailVC = TransactiontDetailViewController()
    transacDetailVC.transacDetailModel = bqPaymentModel
    self.nearNav()?.pushViewController(transacDetailVC, animated: true)
    
  }
  
  @objc func copyBtnAction(_ btn:UIButton){
    
    var copyStr = ""
    var index = 0
    if btn == realNameCopyBtn {
      copyStr = realNameLabel.text ?? ""
      index = 0
    }else if ( btn == bankNumCopyBtn ){
      copyStr = bankNumLabel.text ?? ""
      index = 1
    }
    else if (btn == addressCopyBtn) {
      copyStr = bankAddressLabel.text ?? ""
      index = 2
    }
    let pBoard = UIPasteboard.general
    pBoard.string = copyStr
    
    copyNameOrCardOrAddrBlock?(index)
  }
  
 

}
