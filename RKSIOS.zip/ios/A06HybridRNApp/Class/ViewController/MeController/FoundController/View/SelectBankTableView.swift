//
//  SelectBankTableView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/14.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

public enum BankDataType:Int {
  
  case BankType = 0
  case PointCardType = 1
  case withDrawCardType = 2
}

class SelectBankTableView: UIView,UITableViewDataSource,UITableViewDelegate {

  
  fileprivate static var selectBankTableView:SelectBankTableView?

  
  var tableView:UITableView?
  var backMaskView:MaskView?
  var backTableView:UIView?
  var dataBankArr:[AnyObject]?
  var dataPointCardArr:[AnyObject]?
  var dataDrawCardArr:[AnyObject]?

  var dataType:BankDataType = .BankType
  var lastSelectIndex:Int = 0
  
  
  var callbackBlock: (( _ indexPath: IndexPath)->Void)?

  
  convenience init(frame: CGRect, dataArr:Array<AnyObject>, bankDataType:BankDataType,defaultIndex:Int = 0) {
    self.init(frame: frame)
    
    self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT-340-BOTTOM_MARGIN ,  width: SCREEN_WIDTH, height:340 )
    self.backgroundColor = UIColor.clear
    dataType = bankDataType
    if bankDataType == .BankType {
      dataBankArr = dataArr
    }else if bankDataType == .PointCardType {
      dataPointCardArr = dataArr
    }else if bankDataType == .withDrawCardType {
      dataDrawCardArr = dataArr
    }
    lastSelectIndex = defaultIndex
  
    setupView()
  }
  
  
  private func setupView()  {
    
    backTableView = UIView.init(frame: .zero)
    backTableView?.backgroundColor = UIColor.view_popBlackColor
    backTableView?.layer.cornerRadius = 5.0
    backTableView?.clipsToBounds = true
    self.addSubview(backTableView!)
    backTableView?.snp.makeConstraints({ (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.bottom.equalToSuperview()
    })
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.backgroundColor = .clear
    tableView?.separatorStyle = .none
    backTableView?.addSubview(tableView!)

    tableView?.snp.makeConstraints({ (make) in
      make.left.right.bottom.equalToSuperview()
      make.top.equalTo(self).offset(40)
    })
   
    let headView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH - CGFloat(View_Margin*2) , height: 40))
    backTableView?.addSubview(headView)
    headView.backgroundColor = UIColor.view_popBlackColor
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "选择收款银行"
    titleLab.textAlignment = .center
    headView.addSubview(titleLab)

    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(headView.snp.centerX)
    }
    if dataType == .BankType {
      let backBtn = UIButton.init(frame: .zero)
      headView.addSubview(backBtn)
      backBtn.setImage(UIImage.init(named: "navBackArrow"), for: .normal)
      backBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
      backBtn.snp.makeConstraints { (make) in
        make.left.equalTo(headView).offset(15)
        make.centerY.equalTo(headView.snp.centerY)
        make.width.equalTo(22)
        make.height.equalTo(22)
      }
      
    }
    else if dataType == .PointCardType {
      titleLab.text = "选择点卡类型"
      let closeBtn = UIButton.init(frame: .zero)
      headView.addSubview(closeBtn)
      closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
      closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
      closeBtn.snp.makeConstraints { (make) in
        make.right.equalTo(headView.snp.right).offset(-View_Margin)
        make.top.equalToSuperview().offset(5)
        make.width.equalTo(30)
        make.height.equalTo(30)
      }
    }
    else if dataType == .withDrawCardType {
      titleLab.text = "选择收款银行"
      let closeBtn = UIButton.init(frame: .zero)
      headView.addSubview(closeBtn)
      closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
      closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
      closeBtn.snp.makeConstraints { (make) in
        make.right.equalTo(headView.snp.right).offset(-View_Margin)
        make.top.equalToSuperview().offset(5)
        make.width.equalTo(30)
        make.height.equalTo(30)
      }
    }
    let lineView = UIView.init(frame: .zero)
    headView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.bottom.equalTo(headView.snp.bottom)
    }
    
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if dataType == .PointCardType {
      return dataPointCardArr?.count ?? 0
    }else if dataType == .BankType {
       return dataBankArr?.count ?? 0
    }
    return dataDrawCardArr?.count ?? 0
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "BankTableViewCell") as? BankTableViewCell
    if cell == nil {
       cell = BankTableViewCell.init(style: .default, reuseIdentifier: "BankTableViewCell",dataType:dataType)
       cell?.selectionStyle = .none
       cell?.backgroundColor = UIColor.clear
    }
    
    if dataType == .BankType {
      let bankModel =  dataBankArr?[indexPath.row] as? BankListModel
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (bankModel?.bankIcon ?? "")
      cell?.bankImgView.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
      cell?.contentLab.text = bankModel?.bankName ?? ""
    }else if dataType == .PointCardType {
      let cardListModel = dataPointCardArr?[safe:indexPath.row] as? PointCardListModel
     cell?.contentLab.text =  cardListModel?.name
    }else if dataType == .withDrawCardType {
      let drawCardModel = dataDrawCardArr?[safe:indexPath.row] as? PersonInfoCardModel
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (drawCardModel?.bankIcon ?? "")
    
      cell?.bankImgView.sd_setImage(with: URL.init(string:cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
      if drawCardModel?.accountType == "BTC" {
        cell?.contentLab.text = "比特币账户"
      }else{
        let sufixCard = drawCardModel?.accountNo?.suffix(4) ?? ""
        cell?.contentLab.text = (drawCardModel?.bankName ?? "") + "(" + sufixCard + ")"
      }
      if drawCardModel?.flag == "0" {
        cell?.contentLab.textColor = UIColor.font_lightBlackWhiteColor
        cell?.maintainLab.isHidden = false
        cell?.selectImgView.isHidden = true
      }else{
        cell?.contentLab.textColor = UIColor.view_white
        cell?.maintainLab.isHidden = true
      }
    }
    
    if indexPath.row == lastSelectIndex {
      cell?.selectImgView.isHidden = false
    }else{
      cell?.selectImgView.isHidden = true
    }

    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 60
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
     if dataType == .withDrawCardType {
      let drawCardModel = dataDrawCardArr?[safe:indexPath.row] as? PersonInfoCardModel
      if drawCardModel?.flag == "0" {
        return
      }
    }
    callbackBlock?(indexPath)
    hidenView()
  }
  
  
  func showView(){
  //  MaskView.show(subView: self)
   backMaskView = MaskView.init(frame: .zero);
   backMaskView?.showView(subView: self)
  }
  
  class func showPopView( dataArr:Array<AnyObject>, bankDataType:BankDataType, selectIndex:Int = 0, sureBlock:@escaping (_ IndexPath:IndexPath)->Void ) {
    
    selectBankTableView = SelectBankTableView.init(frame: .zero, dataArr: dataArr, bankDataType: bankDataType)
    selectBankTableView?.callbackBlock = sureBlock
    selectBankTableView?.lastSelectIndex = selectIndex
    selectBankTableView?.showView()
    
  }
  
  func hidenView(){
  
    backMaskView?.hidenView()
    
    self.removeFromSuperview()
  }
  
  @objc func cancelAction(){
    
    hidenView()

  }
  
  @objc func closeAction(){
    
     hidenView()
  }
  
  
  fileprivate class BankTableViewCell: UITableViewCell {
    
    var bankImgView:UIImageView!
    var contentLab:UILabel!
    var selectImgView:UIImageView!
    var maintainLab:UILabel!
    var cellDataType:BankDataType = .BankType
    convenience init(style: UITableViewCellStyle, reuseIdentifier: String?, dataType:BankDataType = .BankType) {
      self.init(style: style, reuseIdentifier: reuseIdentifier)
      
      cellDataType = dataType
      setupView()
    }
    

    
    func setupView(){
    
      bankImgView = UIImageView.init(frame: .zero)
      contentView.addSubview(bankImgView)
      bankImgView.image = UIImage.init(named: "logo")
      if cellDataType == .BankType || cellDataType == .withDrawCardType {
        bankImgView.snp.makeConstraints { (make) in
          make.left.equalTo(self).offset(View_Margin+5)
          make.centerY.equalTo(self.snp.centerY)
          make.size.equalTo(CGSize.init(width: 22.5, height: 22.5))
        }
      }
      contentLab = UILabel.init(frame: .zero)
      contentView.addSubview(contentLab)
      contentLab.text = ""
      contentLab.textColor = UIColor.view_white
      contentLab.font = UIFont.M_Font
     
      selectImgView = UIImageView.init(frame: .zero)
      contentView.addSubview(selectImgView)
      selectImgView.image = UIImage.init(named: "bankSelect")
      
      maintainLab = UILabel.init(color: UIColor.font_purplishRedColor, font: UIFont.M_Font)
      contentView.addSubview(maintainLab)
      maintainLab.textAlignment = .right
      maintainLab.text = "维护中"
      maintainLab.isHidden = true
      
      selectImgView.snp.makeConstraints { (make) in
        make.right.equalTo(contentView.snp.right).offset(-20)
        make.centerY.equalTo(contentView.snp.centerY)
        make.width.equalTo(14)
        make.height.equalTo(14)
      }
      contentLab.snp.makeConstraints { (make) in
        make.left.equalTo(bankImgView.snp.right).offset(15)
        make.centerY.equalTo(contentView.snp.centerY)
        make.right.equalTo(selectImgView.snp.left).offset(-5)
      }
      maintainLab.snp.makeConstraints { (make) in
        make.right.equalToSuperview().offset(-15)
        make.centerY.equalToSuperview()
        make.height.equalTo(20)
      }
      
      let lineView = UIView.init(frame: .zero)
      contentView.addSubview(lineView)
      lineView.backgroundColor = UIColor.view_lineColor
      lineView.snp.makeConstraints { (make) in
        make.left.equalTo(contentView)
        make.right.equalTo(contentView)
        make.bottom.equalTo(contentView.snp.bottom)
        make.height.equalTo(1)
      }
      
    }
    
    
  }
  
  
  
  

}
