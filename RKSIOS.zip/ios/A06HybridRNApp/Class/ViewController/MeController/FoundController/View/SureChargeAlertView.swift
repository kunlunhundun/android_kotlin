//
//  SureChargeAlertView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/12.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class SureChargeAlertView: UIView {


  fileprivate static var sureChargeAlertView:SureChargeAlertView?

  private var chargeModel:ChargeAlerModel?

  private var callbackBlock: ((_ sureAction:Int)->Void)?

  private var tipPaywayLab:UILabel?
  private var titleLab:UILabel!
  private var amountLab:UILabel?
  
  private var selectIndex:Int = 0
  private var realNameLabel:UILabel?
  private var bankNamelabel:UILabel?
  private var bankImageView:UIImageView?
  var selfPayType:String = ""
  
  
  convenience  init(frame: CGRect , chargeAlerModel:ChargeAlerModel ) {
    self.init(frame: frame)
  
    var height:CGFloat = 220
    let payType = chargeAlerModel.paytype
    chargeModel = chargeAlerModel
    selfPayType = payType
    let haveActivity:Bool = ManagerModel.instanse.activityShow
    let amount:String = chargeModel?.amount ?? ""
    let DoubleAmount = Double(amount)
    if (payType.isEqual("15" as String) == true || payType.isEqual("16" as String) == true) && haveActivity == true && CGFloat(DoubleAmount ?? 0) >= 99.00{
      height = 310
    }
    
    if chargeModel?.containBankMode == true {
      height = 340-55
    }
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-height-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: height)
    self.layer.cornerRadius = 5.0
    setupView()
  }
  
  func setupView(){
    self.backgroundColor = UIColor.view_backBlack
    
    titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "确认存款"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
  
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    let moneyLab = UILabel.init(frame: .zero)
    self.addSubview(moneyLab)
    amountLab = moneyLab
    moneyLab.textAlignment = .center
    moneyLab.textColor = UIColor.view_white
    moneyLab.font = UIFont.PFM30_Font
    moneyLab.text = "¥ " + (chargeModel?.amount ?? "")
    moneyLab.snp.makeConstraints { (make) in
      make.top.equalTo(lineView.snp.bottom).offset(22)
      make.height.equalTo(30)
      make.left.right.equalToSuperview()
    }
    let paywayLab = UILabel.init(frame: .zero)
    self.addSubview(paywayLab)
    tipPaywayLab = paywayLab
    paywayLab.textColor = UIColor.font_lightWhiteColor
    paywayLab.font = UIFont.M_Font
    paywayLab.textAlignment = .center
    paywayLab.text = "使用支付宝转账"
    paywayLab.snp.makeConstraints { (make) in
      make.top.equalTo(moneyLab.snp.bottom).offset(8)
      make.left.right.equalToSuperview()
      make.height.equalTo(20)
    }
    let bankView = UIView.init(frame: .zero)
    self.addSubview(bankView)
    
    if chargeModel?.containBankMode == true {
      bankView.snp.makeConstraints { (make) in
        make.left.right.equalToSuperview()
        make.top.equalTo(paywayLab.snp.bottom).offset(22)
        make.height.equalTo(55)
      }
//      let nameDesLab = UILabel.init(frame: .zero)
//      bankView.addSubview(nameDesLab)
//      nameDesLab.text = "持卡人姓名"
//      nameDesLab.textColor = UIColor.view_white
//      nameDesLab.font = UIFont.M_Font
//      nameDesLab.snp.makeConstraints { (make) in
//        make.left.equalTo(20)
//        make.width.equalTo(80)
//        make.top.equalToSuperview()
//        make.height.equalTo(55)
//      }
//      let nameLab = UILabel.init(frame: .zero)
//      bankView.addSubview(nameLab)
//      realNameLabel = nameLab
//      nameLab.text = "王思聪"
//      nameLab.textAlignment = .right
//      nameLab.textColor = UIColor.view_white
//      nameLab.snp.makeConstraints { (make) in
//        make.right.equalToSuperview().offset(-20)
//        make.top.bottom.equalTo(nameDesLab)
//        make.left.equalTo(nameDesLab.snp.right).offset(15)
//      }
//      let nameLineView = UIView.init(frame: .zero)
//      bankView.addSubview(nameLineView)
//      nameLineView.backgroundColor = UIColor.view_lineColor
//      nameLineView.snp.makeConstraints { (make) in
//        make.left.equalTo(nameDesLab.snp.left)
//        make.right.equalTo(nameLab.snp.right)
//        make.bottom.equalTo(nameDesLab.snp.bottom)
//        make.height.equalTo(1)
//      }
      
      let bankDesLab = UILabel.init(frame: .zero)
      bankView.addSubview(bankDesLab)
      bankDesLab.textColor = UIColor.view_white
      bankDesLab.font = UIFont.M_Font
      bankDesLab.text = "收款银行"
      bankDesLab.snp.makeConstraints { (make) in
        make.left.equalTo(20)
        make.width.equalTo(80)
        make.top.equalToSuperview()
        make.height.equalTo(55)
      }

      let arrowImgView = UIImageView.init(frame: .zero)
      arrowImgView.image = UIImage.init(named: "arrow_right")
      bankView.addSubview(arrowImgView)
      arrowImgView.snp.makeConstraints { (make) in
        make.right.equalToSuperview().offset(-20)
        make.centerY.equalTo(bankDesLab.snp.centerY)
        make.width.equalTo(22)
        make.height.equalTo(22)
      }
      
      let bankModel = chargeModel?.bankList?[safe:selectIndex] as? BankListModel
      
      let bankNameLab = UILabel.init(frame: .zero)
      bankView.addSubview(bankNameLab)
      bankNamelabel = bankNameLab
      bankNameLab.text = bankModel?.bankName
      bankNameLab.textColor = UIColor.view_white
      bankNameLab.font = UIFont.M_Font
      let size = bankNameLab.sizeThatFits(CGSize.init(width: 100, height: 40))
      bankNameLab.snp.makeConstraints { (make) in
        make.right.equalTo(arrowImgView.snp.left).offset(-5)
        make.top.equalTo(bankDesLab.snp.top)
        make.height.equalTo(55)
        make.width.equalTo(size.width+5)
      }
      let bankImgView = UIImageView.init(frame: .zero)
      bankView.addSubview(bankImgView)
      bankImageView = bankImgView
      bankImgView.image = UIImage.init(named: "Logo")
      bankImgView.snp.makeConstraints { (make) in
        make.right.equalTo(bankNameLab.snp.left).offset(-5)
        make.centerY.equalTo(bankNameLab.snp.centerY)
        make.height.equalTo(22)
        make.width.equalTo(22)
      }

      let bankLineView = UIView.init(frame: .zero)
      bankView.addSubview(bankLineView)
      bankLineView.backgroundColor = UIColor.view_lineColor
      bankLineView.snp.makeConstraints { (make) in
        make.left.equalTo(bankDesLab.snp.left)
        make.right.equalToSuperview().offset(-20)
        make.height.equalTo(1)
        make.bottom.equalTo(bankView.snp.bottom)
      }
      
      let bankBtn = UIButton.init(frame: .zero)
      bankView.addSubview(bankBtn)
      bankBtn.snp.makeConstraints { (make) in
        make.left.right.equalTo(bankLineView)
        make.bottom.equalTo(bankLineView.snp.bottom)
        make.top.equalTo(bankDesLab.snp.top)
      }
      bankBtn.addTarget(self, action: #selector(selectBankAction), for: .touchUpInside)
      
      refreshBankInfo()
    }
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((self.newWidth-10*3)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("前往支付", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(10)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
    
    // 活动的背景的框框
    let activityBg = UIView.init(frame: .zero)
    activityBg.layer.cornerRadius = 5
    activityBg.layer.masksToBounds = true
    activityBg.layer.backgroundColor = UIColor.init(hexString: "0d0d01", alpha: 0.2).cgColor
    self.addSubview(activityBg)
    activityBg.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(0)
      make.right.equalToSuperview().offset(0)
      make.height.equalTo(91)
      make.bottom.equalTo(sureBtn.snp.top).offset(-23)
    }
    
    // 加送
    let addToSend = UILabel.init(frame: .zero)
    let sendStr = chargeModel?.send
    addToSend.text = "加送:" + sendStr!
    addToSend.textColor = UIColor.init("F9AB10")
    addToSend.font = UIFont.systemFont(ofSize: 16)
    activityBg.addSubview(addToSend)
    addToSend.backgroundColor = UIColor.clear
    addToSend.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(activityBg.snp.top).offset(22)
      make.height.equalTo(21)
    }
    
    // 实际到账
    let toTheAccount = UILabel.init(frame: .zero)
    let acountStr = chargeModel?.acount
    toTheAccount.text = "实际到账:" + acountStr!
    toTheAccount.textColor = UIColor.white
    toTheAccount.font = UIFont.systemFont(ofSize: 14)
    toTheAccount.backgroundColor = UIColor.clear
    activityBg.addSubview(toTheAccount)
    
    toTheAccount.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(addToSend.snp.bottom).offset(5)
      make.height.equalTo(19)
    }
    
    let amount:String = chargeModel?.amount ?? ""
    let DoubleAmount = Double(amount)
    let haveActivity:Bool = ManagerModel.instanse.activityShow
    if (selfPayType.isEqual("15" as String) == true || selfPayType.isEqual("16" as String) == true) && haveActivity == true && CGFloat(DoubleAmount ?? 0) >= 99.00{
      activityBg.isHidden = false
      activityBg.snp.updateConstraints { (make) in
        make.height.equalTo(91)
      }
    }else{
      activityBg.isHidden = true
      activityBg.snp.updateConstraints { (make) in
        make.height.equalTo(0)
      }
    }
    
    setAmountTipInfo()
  }
  
  func setAmountTipInfo(){
  
    let tipCode = chargeModel?.tipCode ?? .defaultPayCode
    switch tipCode {
    case .aliBQCode:
      tipPaywayLab?.text = "请使用支付宝转账"
      break
    case .aliScanCode:
      tipPaywayLab?.text = "请使用支付宝扫码"
      break
    case .aliWapCode:
      tipPaywayLab?.text = "请使用支付宝支付"
      break
    case .wxBQCode:
      tipPaywayLab?.text = "请使用微信转账"
      break
    case .wxScanCode:
      tipPaywayLab?.text = "请使用微信扫码"
      break
    case .wxWapCode:
      tipPaywayLab?.text = "请使用微信支付"
      break
    case .bkBQCode:
      tipPaywayLab?.text = "请使用银行卡转账"
      break
    case .otherQQScan:
      tipPaywayLab?.text = "请使用QQ扫码"
      break
    case .otherQQPay:
      tipPaywayLab?.text = "请使用QQ支付"
      break
    case .otherJdScan:
      tipPaywayLab?.text = "请使用京东扫码"
      break
    case .otherJdPay:
      tipPaywayLab?.text = "请使用京东支付"
      break
    case .otherRgBtc:
      amountLab?.text = "比特币" + (chargeModel?.amount ??  "")
      amountLab?.font = UIFont.PFM24_Font
      tipPaywayLab?.textColor = UIColor.font_purplishRedColor
      titleLab.text = "确认存款"
      tipPaywayLab?.text = "请使用比特币支付"
      break
    case .otherBtc:
      titleLab.text = "确认存款"
      tipPaywayLab?.text = "请使用比特币支付"
      break
    default:
      
      tipPaywayLab?.text =  "请使用" + (chargeModel?.tipName ?? "")
      let tipName = chargeModel?.tipName ?? ""
      
      if tipName.isEqual("网银转账" as String){
         tipPaywayLab?.text = "请使用银行卡转账"
      }
      if tipName.isEqual("银联在线存款" as String){
        tipPaywayLab?.text = "请使用银联支付"
      }
      if tipName.isEqual("银联扫码" as String){
        tipPaywayLab?.text = "请使用银联扫码支付"
      }
      if tipName.isEqual("网银在线存款" as String){
        tipPaywayLab?.text = "请使用网银支付"
      }
    }
  }
  
  func refreshBankInfo(){
    
    let isManualBank = chargeModel?.isManualBank ?? false
    if isManualBank {
      
    }else{
     
    }
    let bankModel = chargeModel?.bankList?[safe:selectIndex] as? BankListModel
    realNameLabel?.text = chargeModel?.realName ?? ""
    bankNamelabel?.text = bankModel?.bankName
    let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (bankModel?.bankIcon ?? "")
    bankImageView?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "Logo"))
  }
  
  @objc func selectBankAction(){
    
    let bankList = chargeModel?.bankList ?? []
    let selectBankTableView = SelectBankTableView.init(frame: .zero, dataArr: bankList , bankDataType: .BankType , defaultIndex:selectIndex )
    selectBankTableView.showView()
    selectBankTableView.callbackBlock = { [weak self] (indexPath: IndexPath) ->Void in
      print("selectBankTableView.callbackBlock------>indexPath \(indexPath)")
      self?.selectIndex = indexPath.row
      self?.refreshBankInfo()
    }
  }
  
  class func showPopView(chargeAlertModel:ChargeAlerModel, sureBlock:@escaping (_ sureAction:Int)->Void ) {
    sureChargeAlertView = SureChargeAlertView.init(frame: .zero, chargeAlerModel: chargeAlertModel)
    sureChargeAlertView?.callbackBlock = sureBlock
    sureChargeAlertView?.showView()
    
  }
  
  func showView(){
    MaskView.show(subView: self)

  }
  
  func hidenView(){
    MaskView.hiden()
  }
  
  @objc func cancelAction(){
    
    if callbackBlock != nil {
      callbackBlock?(-1)  //取消
    }
    hidenView()
  }
  
  @objc func sureAction(){
    
    if callbackBlock != nil {
      callbackBlock?(selectIndex)
    }
    hidenView()

  }
  
  
  
 @objc private func closeAction(){
     hidenView()
  }

}
