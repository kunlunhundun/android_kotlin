//
//  ChargeQueryOrderPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 13/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

public enum TapState:Int {
  case close = 0
  case cancel = 1
  case sure = 2
}


class ChargeQueryOrderPopView: UIView {

  
  fileprivate static var queryOrderPopView:ChargeQueryOrderPopView?
  
  var callbackBlock:((_ tapState:TapState)->(Void))?
  
  
  override init(frame: CGRect ) {
    super.init(frame: frame)
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-220, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 200)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  private func setupView(){
    self.backgroundColor = UIColor.view_popBlackColor
    self.layer.cornerRadius = 5.0
    self.clipsToBounds = true
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "存款确认中…"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("遇到问题？联系客服", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.right.equalToSuperview().offset(-10)
      make.top.equalTo(lineView).offset(20)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("我已支付，查询订单", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.right.equalToSuperview().offset(-10)
      make.height.equalTo(48)
      make.top.equalTo(cancelBtn.snp.bottom).offset(15)
    }
  }
  
  class func showPopView(tapBtnBlock:@escaping (_ tapState:TapState)->Void ) {
    queryOrderPopView = ChargeQueryOrderPopView.init(frame: .zero)
    queryOrderPopView?.callbackBlock = tapBtnBlock
    queryOrderPopView?.showView()
  }
  
  func showView(){
    MaskView.show(subView: self)
  }
  
  func hidenView(){
    MaskView.hiden()
  }
  
  @objc func cancelAction(){
    if callbackBlock != nil {
      callbackBlock?(.cancel)  //取消
    }
    hidenView()
  }
  
  @objc func sureAction(){
    
    if callbackBlock != nil {
      callbackBlock?(.sure)
    }
    hidenView()
    //MARK:查询下1888是否送完
    ManagerModel.instanse.getActivityInfo()
    
    
    
  }
  
  @objc private func closeAction(){
    hidenView()
  }
}
