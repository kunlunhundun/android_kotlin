//
//  NOBankCardInfoView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 22/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class NOBankCardInfoView: UIView {

  var callBackBlock:(()->Void)?
  
  convenience  init(frame: CGRect,supView:UIView) {
    self.init();
  
    self.backgroundColor = UIColor.init(colorValue: 0x272F36)
    setupView()
  }
  
  func setupView(){
    
    let imgView = UIImageView.init(frame: .zero)
    self.addSubview(imgView)
    imgView.image = UIImage.init(named: "BlankIcon")
    
    imgView.snp.makeConstraints { (make) in
      make.centerX.equalToSuperview()
      make.centerY.equalToSuperview().offset(-150)
      make.width.equalTo(189)
      make.height.equalTo(137)
    }
    let desLab = UILabel.init(color: UIColor.font_lightBlackWhiteColor, font: UIFont.PFML_Font)
    self.addSubview(desLab)
    desLab.textAlignment = .center
    desLab.text = "暂无银行卡使用，请更换存款方式"
    desLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(imgView.snp.bottom).offset(20)
    }
    let changeWayBtn = UIButton.init(frame: .zero)
    changeWayBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(changeWayBtn)
    changeWayBtn.addTarget(self, action: #selector(changeWayAction), for: .touchUpInside)
    changeWayBtn.layer.cornerRadius = 5.0
    changeWayBtn.setTitle("切换存款方式", for: .normal)
    changeWayBtn.titleLabel?.font = UIFont.PFML_Font
    changeWayBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalToSuperview().offset(10)
      make.height.equalTo(48)
      make.top.equalTo(desLab.snp.bottom).offset(50)
    }
  }
  
  @objc func  changeWayAction(){
    callBackBlock?()
  }
}
