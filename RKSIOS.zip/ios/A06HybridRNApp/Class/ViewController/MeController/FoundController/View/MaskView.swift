//
//  MaskView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/10.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class MaskView: UIView {

  public static var maskView:MaskView?
  
  var maskButton:UIButton!
  
   override init(frame: CGRect) {
    super.init(frame: frame)
    self.frame = UIScreen.main.bounds
    setupView()
    
  }
  
  func setupView(){
    
    let fullImage = UIImageTools.applyBlurFullScreenShots()
    let maskFullImgView = UIImageView.init(frame: UIScreen.main.bounds)
    maskFullImgView.image = fullImage
    self.addSubview(maskFullImgView)
    
    let transparentView = UIView.init(frame: UIScreen.main.bounds)
    transparentView.backgroundColor = UIColor.init(red: 255.0/255.0, green: 72.0/255.0, blue: 147.0/255.0, alpha: CGFloat(1))
    transparentView.alpha = 0.5
    maskFullImgView.addSubview(transparentView)
    self.addSubview(transparentView)
    maskButton = UIButton.init(frame: UIScreen.main.bounds)
    self.addSubview(maskButton)
    maskButton.addTarget(self, action: #selector(btnClickFun), for:.touchUpInside)
    
  }
  
  @objc func btnClickFun(){
    
    MaskView.hiden()
    print("btnClickFun-------->>>>>>>>>>")
  }
  
  func showView(subView:UIView){
    self.addSubview(subView)
    UIApplication.shared.delegate?.window??.addSubview(self)
  }
  
  func hidenView(){
    self.isHidden = true
    for subView in  self.subviews {
      subView.removeFromSuperview()
    }
    self.removeFromSuperview()
  }
  
  
  class func show(subView:UIView){
    
    if maskView != nil  {
       self.hiden()
    }
     maskView = MaskView.init()
     maskView?.isHidden = false
     maskView?.addSubview(subView)
    UIApplication.shared.delegate?.window??.addSubview(maskView!)
  }
  
  class func hiden() {
    maskView?.isHidden = true
    if maskView != nil {
      for subView in  maskView!.subviews {
        subView.removeFromSuperview()
      }
    }
   
    maskView?.removeFromSuperview()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  

}
