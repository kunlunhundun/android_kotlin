//
//  AlipayTimerView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/15.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class AlipayTimerView: UIView {
  
  
  var timeCount = 0
  var timer : Timer?
  convenience  init(frame: CGRect , timeStr:String) {
    self.init(frame: frame)
    
    setupView(timeStr: timeStr)
    initData(timeStr: timeStr)
  }
  
  func initData( timeStr:String){
    
    let timeArr = timeStr.components(separatedBy: ":")
    var minStr = ""
    var secondStr = ""
    if timeArr.count > 1 {
      minStr = timeArr[0]
    }
    if timeArr.count >= 2 {
      secondStr = timeArr[1]
    }
    let min = Int(minStr) ?? 0
    let second = Int(secondStr) ?? 0
    if  min >= 1 {
      timeCount = min * 60
    }
    if second > 0 {
      timeCount += second
    }
    if timeCount > 0 {
      startTimer()
    }
  }
  
  func setupView(timeStr:String){
    
    timeLabel.text = "订单过期 " + timeStr
    
    self.addSubview(timeLabel)
    self.addSubview(logoImage)
  
    logoImage.snp.makeConstraints { (make) in
      make.centerY.equalTo(self.snp.centerY)
      make.right.equalTo(self.snp.right)
      make.width.equalTo(20)
      make.height.equalTo(20)
    }
    timeLabel.snp.makeConstraints { (make) in
      make.centerY.equalTo(self.snp.centerY)
      make.left.equalToSuperview()
      make.right.equalTo(logoImage.snp.left).offset(-5)
      make.height.equalTo(20)
    }
    
  
  }
  
  
  func startTimer(){
    
    if timer == nil {
      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerEvent), userInfo: nil, repeats: true)
      timer?.fire()
      RunLoop.current.add(timer!, forMode: .commonModes)
    }
  }
  
  func destoryTimer(){
    if timer != nil {
      if timer!.isValid {
        timer?.invalidate()
        timer = nil
      }
    }
  }
  
  @objc func timerEvent(){
    timeCount -= 1
    if timeCount == 0 {
      destoryTimer()
    }
    let minutes = timeCount / 60
    let seconds = timeCount % 60
    if seconds < 10 {
      timeLabel.text = "\(minutes)" + ":0" + "\(seconds)"
    }else{
      timeLabel.text = "\(minutes)" + ":" + "\(seconds)"

    }
    
  }
  

  
  lazy var timeLabel : UILabel = {
    
    var timeLab = UILabel.init(frame: .zero)
    timeLab.textColor = UIColor.view_white
    timeLab.font = UIFont.M_Font
    timeLab.textAlignment = .right
    return timeLab
  }()
  
  lazy var logoImage : UIImageView = {
    var logoImg = UIImageView.init(frame: .zero)
    logoImg.image = UIImage.init(named: "icon_payment_clock")
    return logoImg
  }()
  
  
}
