//
//  BlankBlackListGuidView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 16/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class BlankBlackListGuidView: UIView {

  var contentLab:UILabel!
  
  convenience init(frame: CGRect,content:String?) {
    self.init(frame: frame)
    setupView()
    contentLab.text = content
  }
  
  func setupView(){
    
    let contentImgView = UIImageView.init(frame: .zero)
    self.addSubview(contentImgView)
    contentImgView.image = UIImage.init(named: "BlackListIcon")
    contentImgView.snp.makeConstraints { (make) in
      make.centerY.equalTo(self.snp.centerY).offset(-STATUS_NAV_BAR_Y-40)
      make.centerX.equalToSuperview()
      make.width.equalTo(71)
      make.height.equalTo(81)
    }
    
    contentLab = UILabel.init(color: UIColor.font_lightBlackWhiteColor, font: UIFont.L_Font)
    self.addSubview(contentLab)
    contentLab.numberOfLines = 0
    contentLab.snp.makeConstraints { (make) in
      make.top.equalTo(contentImgView.snp.bottom).offset(20)
      make.width.equalTo(192)
      make.centerX.equalToSuperview()
      make.height.equalTo(50)
    }
    contentLab.textAlignment = .center
    contentLab.text = "当前无可用存款方式，请联系客服或稍后重试"
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("返回首页", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-100)
      make.width.equalTo((SCREEN_WIDTH-10*4)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("联系客服", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(20)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
  }
  
  @objc func cancelAction(){
    self.nearNav()?.popToRootViewController(animated: true)
  }
  
  @objc func sureAction(){
    let customerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: false)
    self.nearNav()?.pushViewController(customerOnlineVC, animated: true)
  }
}
