//
//  ChargeTableViewCell.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/7.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

public enum CellMode: Int {
  case headImgMode = 0
  case oneTitleMode = 1
  case titleAndDetailMode = 2
  case inputContentMode = 3
  case manualInputContentMode = 4
  case selectedBankMode = 5
  case pointCardInputAndUpArrowMode = 6
  case inputAndUpArrowMode = 7
  case inputAndRightArrow = 8
  case transactionBankName
  case transactionWashCode
}

class ChargeTableViewCell: UITableViewCell,UITextFieldDelegate {

  var max:String = ""
  var cellHeight:CGFloat = 60
  var textFieldEditingBlock:((_ isEndEdit:Bool)->Void)?
  
   /*headImgMode */
  var hd_headImgView:UIImageView?
  var hd_contentLab:UILabel?
  
  /*oneTitleMode */
  var ot_contentLab:UILabel?
  
  /*titleAndDetailMode */
  var td_detailLab:UILabel?
  var td_lineView:UIView?
  var td_desLab:UILabel?
  var td_detailBtn:UIButton?
  
   /*inputContentMode */
  var ic_desLab:UILabel?
  var ic_textField:UITextField?
  var ic_lineView:UIView?
  var ic_errorTipLab:UILabel?
  
  /*selectedBankMode */
  var sb_desLab:UILabel?
  var sb_bankLab:UILabel?
  var sb_bankIcon:UIImageView?
  
  //inputAndUpArrowMode
  var iua_desLab:UILabel?
  var iua_textField:UITextField?
  var iua_arrowBtn:UIButton?
  
  //inputAndRightArrow
  var ira_desLab:UILabel?
  var ira_textField:UITextField?
  var ira_lineview:UIView?
  var markImage:UIImageView = UIImageView()
  var cellmodel:Int = 0

  var selectNameBtnBlock:((_ selectIndex:Int)->Void)?
  
  public convenience init(style: UITableViewCellStyle, reuseIdentifier: String? , cellMode: CellMode) {
    
    self.init(style: style, reuseIdentifier: reuseIdentifier)
    
    if cellMode == CellMode.headImgMode {
      setupHeadImgCellView()
    }
    else if cellMode == CellMode.oneTitleMode {
      setupOneTitleView()
    }
    else if cellMode == CellMode.inputContentMode {
      setupInputContentView()
    }else if cellMode == CellMode.manualInputContentMode {
      setupManualInputContentView()
    }else if cellMode == CellMode.titleAndDetailMode{
      setupTitleAndDetailMode()
    }else if cellMode == CellMode.selectedBankMode {
      setupSelectedBankModeView()
    }else if cellMode == CellMode.inputAndUpArrowMode {
      setupInputAndUpArrowContentView()
    }else if cellMode == CellMode.pointCardInputAndUpArrowMode {
      setupPointCardInputAndUpArrowContentView()
    }
    else if cellMode == CellMode.inputAndRightArrow {
      setupInputAndRightArrowContentView()
    }
  }
  
  func setupHeadImgCellView(){
    
    let headImgView = UIImageView.init(frame: .zero)
    contentView.addSubview(headImgView)
    hd_headImgView = headImgView
    headImgView.image = UIImage.init(named: "logo")
    headImgView.snp.makeConstraints { (make) in
      make.left.equalTo(self).offset(View_Margin)
      make.centerY.equalTo(self.snp.centerY)
      make.size.equalTo(CGSize.init(width: 40, height: 40))
    }
    
    let contentLab = UILabel.init(frame: .zero)
    contentView.addSubview(contentLab)
    hd_contentLab = contentLab
    contentLab.text = "其他存款"
    contentLab.textColor = UIColor.view_white
    contentLab.font = UIFont.M_Font
    contentLab.snp.makeConstraints { (make) in
      make.left.equalTo(headImgView.snp.right).offset(15)
      make.centerY.equalTo(headImgView.snp.centerY)
    }
  
    let detail:NSString = "切换存款类型"
    let detailW = detail.getWidthWithMaxHeight(16, in: UIFont.M_Font)
    let accessBtn = ActivityAllButton()
    accessBtn.setTitle("切换存款类型", for: .normal)
    accessBtn.setImage(UIImage.init(named: "arrow_right"), for: .normal)
    accessBtn.isUserInteractionEnabled = false
    contentView.addSubview(accessBtn)
    accessBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(0-View_Margin)
      make.centerY.equalTo(contentView.snp.centerY)
      make.width.equalTo(detailW+32)
      make.height.equalTo(30)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalTo(contentView).offset(View_Margin)
      make.height.equalTo(1)
      make.bottom.equalTo(contentView.snp.bottom)
    }
  }
  
  func setupOneTitleView(){
    
    let contentLab = UILabel.init(frame: .zero)
    contentView.addSubview(contentLab)
    ot_contentLab = contentLab
    contentLab.text = "支付宝转银行卡"
    contentLab.textColor = UIColor.view_white
    contentLab.font = UIFont.M_Font
    contentLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    // 1888活动
    let activityMark = UIImageView.init(frame: .zero)
    contentView.addSubview(activityMark)
    activityMark.image = UIImage(named: "activity1888")
    markImage = activityMark
    markImage.isHidden = true
    activityMark.snp.makeConstraints { (make) in
      make.left.equalTo(contentLab.snp.right).offset(5)
      make.height.equalTo(20)
      make.width.equalTo(68)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let allowImgView = UIImageView.init(frame: .zero)
    contentView.addSubview(allowImgView)
    allowImgView.image = UIImage.init(named: "arrow_right")
    allowImgView.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    td_lineView = lineView
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.bottom.equalTo(contentView.snp.bottom)
    }
  }
  
  func setupInputContentView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    ic_desLab = desLab
    desLab.text = "存款金额"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.height.equalTo(40)
      make.top.equalTo(0)
    }
    
    let inputTextField = BaseTextfiled.init(frame: .zero)
    contentView.addSubview(inputTextField)
    ic_textField = inputTextField
    inputTextField.placeholder = "请输入金额20-100万之间的整数"
    inputTextField.textColor = UIColor.view_white
    inputTextField.delegate = self
    inputTextField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    inputTextField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    inputTextField.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin)
      make.height.equalTo(30)
      make.top.equalTo(5)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.top.equalTo(contentView.snp.top).offset(39)
    }
    ic_lineView = lineView
    
    ic_errorTipLab = UILabel.init(color: UIColor.font_errorRedColor, font: UIFont.M_Font)
    contentView.addSubview(ic_errorTipLab!)
    ic_errorTipLab!.isHidden = true
    ic_errorTipLab!.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalTo(inputTextField.snp.right)
      make.top.equalTo(lineView.snp.bottom)
      make.height.equalTo(20)
    }
  }
  
  func setupManualInputContentView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    ic_desLab = desLab
    desLab.text = "存款金额"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.height.equalTo(60)
      make.top.equalTo(0)
    }
    
    let inputTextField = BaseTextfiled.init(frame: .zero)
    contentView.addSubview(inputTextField)
    ic_textField = inputTextField
    inputTextField.placeholder = "请输入金额20-100万之间的整数"
    inputTextField.textColor = UIColor.view_white
    inputTextField.delegate = self
    inputTextField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    inputTextField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    inputTextField.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin)
      make.height.equalTo(30)
      make.top.equalToSuperview().offset(15)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.top.equalTo(contentView.snp.top).offset(59)
    }
    ic_lineView = lineView
    
    ic_errorTipLab = UILabel.init(color: UIColor.init(hexInt: 0xE14040), font: UIFont.M_Font)
    contentView.addSubview(ic_errorTipLab!)
    ic_errorTipLab!.isHidden = true
    ic_errorTipLab!.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalTo(inputTextField.snp.right)
      make.top.equalTo(lineView.snp.bottom)
      make.height.equalTo(20)
    }
  }
  
  func hidenErrorMsg(){
    ic_errorTipLab?.isHidden = true
    ic_lineView?.backgroundColor = UIColor.view_lineColor
    ic_textField?.text = ""
    if ic_textField?.isFirstResponder == true {
      ic_lineView?.backgroundColor = UIColor.view_white
    }
  }
  
  func hidenErrorMsgWithContentText(){
    ic_errorTipLab?.isHidden = true
    ic_lineView?.backgroundColor = UIColor.view_white
  }
  
  func showErrorMsg(msg:String){
    ic_errorTipLab?.isHidden = false
    ic_lineView?.backgroundColor = UIColor.line_redColor
    ic_errorTipLab?.text = msg
    
  }
  
  func textFieldDidBeginEditing(_ textField: UITextField) {
    
    self.textFieldEditingBlock?(false)
   
  }
  
  func textFieldDidEndEditing(_ textField: UITextField) {
    self.textFieldEditingBlock?(true)
  }
  
  
  // MARK:控制金额的输入位数
  func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    
    if self.ic_desLab?.text == "存款金额" {
      guard let text = textField.text else{
        return true
      }
      let textLength = text.characters.count + string.characters.count - range.length
      return textLength <= self.max.count
    }else{
      return true
    }
  }
  
  func setupTitleAndDetailMode(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    td_desLab = desLab
    desLab.text = "类型"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.height.equalTo(20)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let detailLab = UILabel.init(frame: .zero)
    contentView.addSubview(detailLab)
    td_detailLab = detailLab
    detailLab.text = "ABCEP18022016201818"
    detailLab.textColor = UIColor.view_white
    detailLab.font = UIFont.M_Font
    detailLab.textAlignment = .right
    detailLab.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin)
      make.height.equalTo(20)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    let  detailBtn = UIButton.init(frame: .zero)
    detailLab.addSubview(detailBtn)
    td_detailBtn = detailBtn
    detailBtn.snp.makeConstraints { (make) in
      make.left.right.top.bottom.equalToSuperview()
    }
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    td_lineView = lineView
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.left)
      make.right.equalTo(detailLab.snp.right)
      make.height.equalTo(1)
      make.bottom.equalTo(contentView.snp.bottom)
    }
  }
  
  func setupSelectedBankModeView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    sb_desLab = desLab
    desLab.text = "支付银行"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(70)
      make.height.equalTo(20)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let bankImgView = UIImageView.init(frame: .zero)
    contentView.addSubview(bankImgView)
    sb_bankIcon = bankImgView
    bankImgView.image = UIImage.init(named: "logo")
    bankImgView.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(20)
      make.centerY.equalTo(self.snp.centerY)
      make.size.equalTo(CGSize.init(width: 22.5, height: 22.5))
    }
    
    let allowImgView = UIImageView.init(frame: .zero)
    contentView.addSubview(allowImgView)
    allowImgView.image = UIImage.init(named: "arrow_right")
    allowImgView.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.size.equalTo(CGSize.init(width: 22, height: 22))
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let bankNameLab = UILabel.init(frame: .zero)
    contentView.addSubview(bankNameLab)
    sb_bankLab = bankNameLab
    bankNameLab.text = ""
    bankNameLab.textColor = UIColor.view_white
    bankNameLab.font = UIFont.M_Font
    bankNameLab.snp.makeConstraints { (make) in
      make.left.equalTo(bankImgView.snp.right).offset(15)
      make.centerY.equalTo(bankImgView.snp.centerY)
      make.right.equalTo(allowImgView.snp.left).offset(-5)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.bottom.equalTo(contentView.snp.bottom)
    }
  }
  
 
  
  func setupInputAndUpArrowContentView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    iua_desLab = desLab
    desLab.text = "存款方式"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.height.equalTo(20)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let inputTextField = BaseTextfiled.init(frame: .zero)
    contentView.addSubview(inputTextField)
    iua_textField = inputTextField
    inputTextField.placeholder = "请选择存款方式"
    inputTextField.textColor = UIColor.view_white
    inputTextField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    inputTextField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    inputTextField.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin-30)
      make.height.equalTo(30)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    inputTextField.isEnabled = false

    let arrowImgBtn = UIButton.init(frame: .zero)
    contentView.addSubview(arrowImgBtn)
    iua_arrowBtn = arrowImgBtn
    arrowImgBtn.setImage(UIImage.init(named: "arrow_down"), for: .normal)
    arrowImgBtn.setImage(UIImage.init(named: "arrow_up"), for: .selected)
    arrowImgBtn.contentHorizontalAlignment = .right
    arrowImgBtn.isUserInteractionEnabled = false
    arrowImgBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.size.equalTo(CGSize.init(width: 30, height: 30))
      make.centerY.equalTo(contentView.snp.centerY)
    }
 
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.bottom.equalTo(contentView.snp.bottom)
    }
  }
  
  func setupPointCardInputAndUpArrowContentView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    iua_desLab = desLab
    desLab.text = "存款方式"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.top.equalToSuperview().offset(25)
      make.height.equalTo(30)
    }
    
    let inputTextField = UITextField.init(frame: .zero)
    contentView.addSubview(inputTextField)
    iua_textField = inputTextField
    inputTextField.placeholder = "请选择存款方式"
    inputTextField.textColor = UIColor.view_white
    inputTextField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    inputTextField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    inputTextField.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin-30)
      make.height.equalTo(30)
      make.top.equalToSuperview().offset(20+5)
    }
    inputTextField.isEnabled = false
    
    let arrowImgBtn = UIButton.init(frame: .zero)
    contentView.addSubview(arrowImgBtn)
    iua_arrowBtn = arrowImgBtn
    arrowImgBtn.setImage(UIImage.init(named: "arrow_down"), for: .normal)
    arrowImgBtn.setImage(UIImage.init(named: "arrow_up"), for: .selected)
    arrowImgBtn.contentHorizontalAlignment = .right
    arrowImgBtn.isUserInteractionEnabled = false
    arrowImgBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.size.equalTo(CGSize.init(width: 30, height: 30))
      make.top.equalToSuperview().offset(20+5)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.top.equalToSuperview().offset(59)
    }
    
    ic_errorTipLab = UILabel.init(color: UIColor.init(hexInt: 0xE14040), font: UIFont.M_Font)
    contentView.addSubview(ic_errorTipLab!)
    ic_errorTipLab?.text = "请选择点卡类型"
    ic_errorTipLab!.isHidden = true
    ic_errorTipLab!.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalTo(inputTextField.snp.right)
      make.top.equalTo(lineView.snp.bottom)
      make.height.equalTo(20)
    }
    
  }
  
  func setupInputAndRightArrowContentView(){
    
    let desLab = UILabel.init(frame: .zero)
    contentView.addSubview(desLab)
    ira_desLab = desLab
    desLab.text = "存款金额"
    desLab.textColor = UIColor.view_white
    desLab.font = UIFont.M_Font
    desLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(75)
      make.height.equalTo(20)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let inputTextField = UITextField.init(frame: .zero)
    contentView.addSubview(inputTextField)
    ira_textField = inputTextField
    inputTextField.placeholder = ""
    inputTextField.textColor = UIColor.view_white
    inputTextField.setValue(UIFont.systemFont(ofSize: 15), forKeyPath: "_placeholderLabel.font")
    inputTextField.setValue(UIColor.init(colorValue: 0x888888), forKeyPath: "_placeholderLabel.textColor")
    inputTextField.snp.makeConstraints { (make) in
      make.left.equalTo(desLab.snp.right).offset(15)
      make.right.equalToSuperview().offset(-View_Margin-30)
      make.height.equalTo(30)
      make.centerY.equalTo(contentView.snp.centerY)
    }
    ira_textField?.isEnabled = false

    let allowImgView = UIImageView.init(frame: .zero)
    contentView.addSubview(allowImgView)
    allowImgView.image = UIImage.init(named: "arrow_right")
    allowImgView.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.size.equalTo(CGSize.init(width: 22, height: 22))
      make.centerY.equalTo(contentView.snp.centerY)
    }
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    ira_lineview = lineView
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.equalTo(contentView.snp.left).offset(View_Margin)
      make.right.equalTo(contentView.snp.right)
      make.height.equalTo(1)
      make.top.equalToSuperview().offset(59)
    }
    
    ic_errorTipLab = UILabel.init(color: UIColor.init(hexInt: 0xE14040), font: UIFont.M_Font)
    contentView.addSubview(ic_errorTipLab!)
    ic_errorTipLab?.text = ""
    ic_errorTipLab!.isHidden = true
    ic_errorTipLab!.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalTo(inputTextField.snp.right)
      make.top.equalTo(lineView.snp.bottom)
      make.height.equalTo(20)
    }
    
  }
  
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
