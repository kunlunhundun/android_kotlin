//
//  AliWxOrderGuidPopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 04/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class AliWxOrderGuidPopView: UIView {

  public static var aliWxOrderGuidView:AliWxOrderGuidPopView?
  var isAlipay:Bool = false
  var backView:UIView!
  var lineView:UIView!
  
  convenience init(isAliPay:Bool) {
    self.init()
    self.frame = UIScreen.main.bounds
    self.backgroundColor = UIColor.init(red: 0.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: CGFloat(0.5))

    isAlipay = isAliPay
    setupView()
  }
  
  func setupView(){
    
    backView = UIView.init(frame: .zero)
    self.addSubview(backView)
    backView.backgroundColor = UIColor.init(hexInt: 0x1F2337)
    backView.layer.cornerRadius = 8.0
    backView.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.right.equalToSuperview().offset(-10)
      make.height.equalTo(502)
      make.centerY.equalTo(self.snp.centerY)
    //  make.top.equalToSuperview().offset(STATUS_NAV_BAR_Y+20)
    //  make.bottom.equalToSuperview().offset(-STATUS_NAV_BAR_Y)
    }
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "如何使用支付宝转账"
    titleLab.textAlignment = .center
    backView.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    backView.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(180)
      make.height.equalTo(40)
      make.centerX.equalTo(backView.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(backView).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    lineView = UIView.init(frame: .zero)
    backView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(backView).offset(40)
    }
    
    if isAlipay{
      titleLab.text = "如何使用支付宝转账"
      setupAliView()
    }else{
      titleLab.text = "如何使用微信转账"
      setupWechatView()
    }
   
    
  }
  
   fileprivate func setupWechatView(){
    
    //点击微信右上角的“+”，选择“收付款”并拉到最下面，选择“转账到银行卡”即可。
    let wechatTipLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    wechatTipLab.text = "点击微信右上角的“+”，选择“收付款”并拉到最下面，选择“转账到银行卡”即可。"
    wechatTipLab.numberOfLines = 0
    backView.addSubview(wechatTipLab)
    wechatTipLab.snp.makeConstraints { (make) in
      make.width.equalTo(273)
      make.top.equalTo(lineView.snp.bottom).offset(30)
      make.height.equalTo(50)
      make.centerX.equalTo(backView.snp.centerX)

    }
    NSString.changeUILablePartColor(wechatTipLab, changeOneString: "收付款", changeTwoString: "转账到银行卡", andAllColor: UIColor.white, andMark: UIColor.font_purplishRedColor, andMark: UIFont.M_Font)
    
    let contentImgView = UIImageView.init(frame: .zero)
    backView.addSubview(contentImgView)
    contentImgView.image = UIImage.init(named: "WechatGuid")
    contentImgView.snp.makeConstraints { (make) in
      make.width.equalTo(273)
      make.height.equalTo(238)
      make.centerX.equalTo(backView.snp.centerX)
      make.centerY.equalTo(backView.snp.centerY)
    }

    let knowBtn = UIButton.init(frame: .zero)
    knowBtn.backgroundColor = UIColor.btn_rightRed
    knowBtn.layer.cornerRadius = 5.0
    knowBtn.setTitle("我知道了", for: .normal)
    knowBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    knowBtn.setTitleColor(UIColor.white, for: .normal)
    knowBtn.titleLabel?.font = UIFont.PFML_Font
    backView.addSubview(knowBtn)
    knowBtn.snp.makeConstraints { (make) in
      make.width.equalTo(273)
      make.bottom.equalTo(backView.snp.bottom).offset(-10)
      make.height.equalTo(48)
      make.centerX.equalTo(backView.snp.centerX)
    }
    
  }
  
  
  fileprivate func setupAliView(){
    
    let contentImgView = UIImageView.init(frame: .zero)
    backView.addSubview(contentImgView)
    contentImgView.image = UIImage.init(named: "AlipayGuid")
    contentImgView.snp.makeConstraints { (make) in
      make.width.equalTo(273)
      make.height.equalTo(372)
      make.centerX.equalTo(backView.snp.centerX)
      make.top.equalTo(lineView.snp.bottom).offset(10)
    }
    
    let knowBtn = UIButton.init(frame: .zero)
    knowBtn.backgroundColor = UIColor.btn_rightRed
    knowBtn.layer.cornerRadius = 5.0
    knowBtn.setTitle("我知道了", for: .normal)
    knowBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    knowBtn.setTitleColor(UIColor.white, for: .normal)
    knowBtn.titleLabel?.font = UIFont.PFML_Font
    backView.addSubview(knowBtn)
    knowBtn.snp.makeConstraints { (make) in
      make.width.equalTo(273)
      make.bottom.equalTo(backView.snp.bottom).offset(-10)
      make.height.equalTo(48)
      make.centerX.equalTo(backView.snp.centerX)
    }
    
  }
  
  @objc func closeAction(){
    
   self.hidenView()
    print("btnClickFun-------->>>>>>>>>>")
  }
  
 fileprivate func showView(){
    
    UIApplication.shared.delegate?.window??.addSubview(self)
  }
  
 fileprivate  func hidenView(){
    for subView in  self.subviews {
      subView.removeFromSuperview()
    }
    self.removeFromSuperview()
  }
  
  
  class func show(isAliPay:Bool){
    
    aliWxOrderGuidView = AliWxOrderGuidPopView.init(isAliPay: isAliPay)
    aliWxOrderGuidView?.showView()
  }
  

}
