//
//  TransaTableViewCell.swift
//  A06HybridRNApp
//
//  Created by kunlun on 09/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class TransaTableViewCell: UITableViewCell {

  var drawToImgView:UIImageView!
  var bankNameLab:UILabel!
  var detailLab:UILabel?
  var arrowImgBtn:UIButton?
  var mWashTableview:WashCodeTableView?
  
  public convenience init(style: UITableViewCellStyle, reuseIdentifier: String? , cellMode: CellMode) {
    
    self.init(style: style, reuseIdentifier: reuseIdentifier)
    if cellMode == .transactionBankName {
      setupBankView()
    }else if cellMode == .transactionWashCode {
      setupWashCodeView()
    }
  }
  
  func setupBankView(){
    
    let drawToTipLabel = UILabel.init(color: .white,font: fontpfr15)
    drawToTipLabel.text = "提现到"
    contentView.addSubview(drawToTipLabel)
    drawToTipLabel.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(View_Margin)
      make.centerY.equalTo(contentView)
    }
    bankNameLab = UILabel.init(color: .white,font: fontpfr14)
    contentView.addSubview(bankNameLab)
    bankNameLab.text = ""
    bankNameLab.snp.makeConstraints { (make) in
      make.right.equalTo(contentView.snp.right).offset(-15)
      make.top.bottom.equalTo(contentView)
    }
    drawToImgView = UIImageView.init()
    drawToImgView.image = UIImage.init(named: "logo")
    contentView.addSubview(drawToImgView)
    drawToImgView.snp.makeConstraints { (make) in
      make.centerY.equalTo(contentView)
      make.right.equalTo(bankNameLab.snp.left).offset(-5)
      make.width.height.equalTo(24)
    }
   
    let lineView = UIView.init()
    lineView.backgroundColor = UIColor.line_lightBlack
    contentView.addSubview(lineView)
    
    lineView.snp.makeConstraints { (make) in
      make.bottom.equalToSuperview()
      make.height.equalTo(1)
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
    }
    
  }
  
  func reloadDataList(dataList:[String]) {
    
    mWashTableview?.reloadDataList(dataList: [""])
  }
  
  func setupWashCodeView(){
    
    let washDesLabel = UILabel.init(color: .white,font: fontpfr15)
    washDesLabel.text = "洗码厅"
    contentView.addSubview(washDesLabel)
    washDesLabel.snp.makeConstraints { (make) in
      make.left.equalTo(contentView).offset(View_Margin)
      make.top.equalToSuperview().offset(15)
      make.height.equalTo(20)
    }
    
     detailLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
    contentView.addSubview(detailLab!)
    detailLab!.textAlignment = .right
    detailLab!.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-15)
      make.width.equalTo(60)
      make.top.equalToSuperview().offset(15)
      make.height.equalTo(20)
    }
    
    /*arrowImgBtn = UIButton.init(frame: .zero)
    contentView.addSubview(arrowImgBtn!)
    arrowImgBtn!.setImage(UIImage.init(named: "arrow_down"), for: .normal)
    arrowImgBtn!.setImage(UIImage.init(named: "arrow_up"), for: .selected)
    arrowImgBtn!.contentHorizontalAlignment = .right
    arrowImgBtn!.isUserInteractionEnabled = false
    arrowImgBtn!.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.size.equalTo(CGSize.init(width: 30, height: 30))
      make.top.equalTo(10)
    }
    
     mWashTableview =  WashCodeTableView.init(frame: .zero)
    contentView.addSubview(mWashTableview!)
    mWashTableview!.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalToSuperview().offset(50)
      make.height.equalTo(0)
    } */
    
    let lineView = UIView.init(frame: .zero)
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.bottom.equalToSuperview()
      make.height.equalTo(1)
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
    }
    
  }
  
  
}

class WashCodeTableView:UIView,UITableViewDelegate,UITableViewDataSource{
  
  var dataArr:[String]?
  var tableView:UITableView!
  
   override init(frame: CGRect) {
    super.init(frame: frame)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func reloadDataList(dataList:[String]) {
    
    dataArr = dataList
    tableView.reloadData()
  }
  
  func setupView(){
    
    self.backgroundColor = UIColor.clear
    tableView = UITableView.init(frame: .zero, style: .plain)
    self.addSubview(tableView)
    self.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
    }
    tableView.delegate = self
    tableView.dataSource = self
    tableView.separatorStyle = .none
    tableView.backgroundColor = UIColor.clear
    
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return dataArr?.count ?? 0
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "TransaWashCodeViewCell") as? TransaWashCodeViewCell
    if cell == nil {
      cell = TransaWashCodeViewCell.init(style: .default, reuseIdentifier: "TransaWashCodeViewCell")
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    return cell!
    
  }
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 30 
  }
  
}

class TransaWashCodeViewCell:UITableViewCell{
  
  var gameNameLab:UILabel!
  var amountLab:UILabel!
  var stateLab:UILabel!
  
  override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  func setupView(){
    
    gameNameLab = UILabel.init(color: UIColor.font_littleWhiteColor, font: UIFont.M_Font)
    contentView.addSubview(gameNameLab)
    gameNameLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.width.equalTo(100)
      make.top.bottom.equalToSuperview()
    }
    amountLab = UILabel.init(color: UIColor.font_littleWhiteColor, font: UIFont.M_Font)
    amountLab.textAlignment = .right
    contentView.addSubview(amountLab)
    amountLab.snp.makeConstraints { (make) in
      make.right.equalTo(contentView).offset(-90)
      make.left.equalTo(gameNameLab.snp.right).offset(20)
      make.top.bottom.equalToSuperview()
    }
    
    stateLab = UILabel.init(color: UIColor.view_blueColor, font: UIFont.M_Font) //font_brightRedColor
    contentView.addSubview(stateLab)
    stateLab.textAlignment = .right
    stateLab.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.bottom.equalToSuperview()
      make.width.equalTo(50)
    }
  
  }
  
  
  
}


