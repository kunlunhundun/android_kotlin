//
//  ChargeBankPayView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 28/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class ChargeBankPayView: UIView,UITableViewDataSource,UITableViewDelegate {
  
  var backHomePage:((_ str:String)->(Void))?

  var delegate:DidSelectedPaywaysDelegate?
  var paykindArr:[PayKindModel]?
  var viewModel:ChargeViewModel?
  var curTypeModel:PayTypeModel?
  
  var amountTableViewCell:ChargeTableViewCell?
  var nameTableViewCell:ChargeTableViewCell?
  var noBankCardInfoView:NOBankCardInfoView?
  var amountText = ""
  var orderAmount = ""
  var amountTextFiled:UITextField?
  var nameTextFiled:UITextField?
  var isFix:Bool = false
  var isBQRealName:Bool = false
  var depositorArr:[String] = []
  var selfAddToSend:UILabel = UILabel()
  var selfToTheAccount:UILabel = UILabel()
  var selfCompleteLabel:UILabel = UILabel()
  var toSendStr:String = ""
  var toTheAccountStr:String = ""
  var selfActivityBg:UIView = UIView()

  var selectIndexNetOnlineBank = 0
  var selecetIndexNetPCBank = 0
  
  var subwaysLastIndex = 0
  let disposeBag = DisposeBag()
  
  var realNameCollectionView : ChargeCollectionViewCell = ChargeCollectionViewCell.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 80),isRealName:true)
  
   init(frame: CGRect,isfomeActivity:Bool) {
    super.init(frame: frame)
    setupView()
    
    // MAKE:如果是活动界面过来额要弹出支付方式
    if isfomeActivity {
      let time: TimeInterval = 0.5
      DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
        self.isComeFromActivity()
      }
    }
  }
  
  // 如果是活动过来的弹出支付方式
  func isComeFromActivity(){
    let paywaysMainPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.mainPaywaysMode)
    paywaysMainPopView.showView()
    if paykindArr?.count ?? 0 > 0 {
      paywaysMainPopView.paykindSubjectArr.value = paykindArr!
      
      let count = paywaysMainPopView.paykindSubjectArr.value.count
      paywaysMainPopView.tableView?.snp.updateConstraints({ (make) in
        make.height.equalTo(count * 60)
      })
    }
    paywaysMainPopView.callbackBlock = { [weak self] (indexPath) in
      let kindNameArr = self?.paykindArr
      var bankK = -1
      for  i in 0..<(kindNameArr?.count ?? 0 ) {
        let kindModel = kindNameArr?[i]
        if kindModel?.payKindCode?.contains("BANKPAY") ?? false {
          bankK = i
          break
        }
      }
      if indexPath.row == bankK {
        return
      }
      self?.amountText = ""
      self?.amountTextFiled?.text = ""
      self?.nameTextFiled?.text = ""
      self?.isBQRealName = false
      self?.noBankCardInfoView?.isHidden = true
      self?.delegate?.selectedPaysIndex!(indexPath.row)
    }
    
    // 查看支持App
    paywaysMainPopView.linkCallbackBlock = {
      let activityVC = ActivityWebViewController.init()
      self.nearNav()?.pushViewController(activityVC, animated: true)
    }
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  var tableView : UITableView?
  var collectionAmountView : ChargeCollectionViewCell = ChargeCollectionViewCell.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 95),isRealName:false)
  
  func setupView(){
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.separatorStyle = .none
    self.addSubview(tableView!)
    tableView?.snp.makeConstraints({ (make) in
      make.left.right.bottom.equalTo(self)
      make.top.equalToSuperview().offset(0) // STATUS_NAV_BAR_Y
    })
    tableView?.backgroundColor = UIColor.clear
    
    let footView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 145 + 54))
    
    // 活动的背景的框框
    let activityBg = UIView.init(frame: .zero)
    activityBg.layer.cornerRadius = 5
    activityBg.layer.masksToBounds = true
    activityBg.layer.backgroundColor = UIColor.init(R: 42, G: 45, B: 50, A: 1).cgColor
    footView.addSubview(activityBg)
    selfActivityBg = activityBg
    activityBg.snp.makeConstraints { (make) in
      make.left.equalTo(footView).offset(15)
      make.right.equalTo(footView).offset(-15)
      make.top.equalTo(footView).offset(15)
      make.height.equalTo(91)
    }
    
    // 加送
    let addToSend = UILabel.init(frame: .zero)
    addToSend.text = "加送："
    addToSend.textColor = UIColor.init(R: 249, G: 171, B: 16, A: 1)
    addToSend.font = UIFont.systemFont(ofSize: 16)
    activityBg.addSubview(addToSend)
    addToSend.backgroundColor = UIColor.clear
    selfAddToSend = addToSend
    addToSend.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(activityBg.snp.top).offset(22)
      make.height.equalTo(21)
    }
    
    // 实际到账
    let toTheAccount = UILabel.init(frame: .zero)
    toTheAccount.text = "实际到账："
    toTheAccount.textColor = .white
    toTheAccount.font = UIFont.systemFont(ofSize: 14)
    activityBg.addSubview(toTheAccount)
    toTheAccount.backgroundColor = UIColor.clear
    selfToTheAccount = toTheAccount
    toTheAccount.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(addToSend.snp.bottom).offset(5)
      make.height.equalTo(19)
    }
    
    // activity已经完成
    let completeLabel = UILabel.init(frame: .zero)
    completeLabel.text = "您今日的1888元已领取完毕,明日可继续领取"
    completeLabel.textColor = .white
    completeLabel.font = UIFont.systemFont(ofSize: 14)
    completeLabel.textAlignment = .center
    activityBg.addSubview(completeLabel)
    completeLabel.backgroundColor = UIColor.clear
    selfCompleteLabel = completeLabel
    completeLabel.snp.makeConstraints { (make) in
      make.left.equalTo(0)
      make.top.equalTo(0)
      make.bottom.equalTo(0)
      make.right.equalTo(0)
    }
    
    // 下一步的按钮
    let nextBtn = UIButton.init(frame: .zero);
    footView.addSubview(nextBtn)
    nextBtn.snp.makeConstraints { (make) in
      make.left.equalTo(footView).offset(View_Margin)
      make.right.equalTo(footView).offset(0-View_Margin)
      make.top.equalTo(activityBg.snp.bottom).offset(36)
      make.height.equalTo(54)
    }
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.setTitle("下一步", for: .normal)
    nextBtn.layer.cornerRadius = 5.0
    nextBtn.setTitleColor(UIColor.view_white, for: .normal)
    nextBtn.titleLabel?.font = UIFont.PFML_Font
    nextBtn.addTarget(self, action: #selector(nextAction), for: .touchUpInside)
    tableView?.tableFooterView = footView
    
    collectionAmountView.seletedAmountSubject.subscribe(onNext: {[weak self] (amount:String) in
      self?.amountTableViewCell?.hidenErrorMsg()
      self?.amountTextFiled?.text = amount
      self?.amountText = amount
  
      // 送的金额和实际到账
      let double = Double(amount)
      
      var float = CGFloat(double ?? 0) * 0.005
      float = CGFloat(NSString.roundFloat(Float(float)))
      
      if float > 1888 {
         float = 1888
      }
      let send = String(format: "%.2f",float)
      self?.selfAddToSend.text = "加送:" + send
      self?.toSendStr = send
      
      var floatCou = CGFloat(double ?? 0) + float
      floatCou = CGFloat(NSString.roundFloat(Float(floatCou)))
      
      let count = String(format: "%.2f",floatCou)
      self?.selfToTheAccount.text = "实际到账:" + count
      self?.toTheAccountStr = count
      
      let pypeType = self?.curTypeModel?.payType
      if NSInteger(amount) ?? 0 >= 99 && (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true){
        self?.footerActionViewssShow()
      }else{
        self!.footerActionViewsHiden()
      }
      
    }).disposed(by:collectionAmountView.disposeBag)
    
    realNameCollectionView.seletedAmountSubject.subscribe(onNext: {[weak self] (realName:String) in
      self?.nameTableViewCell?.hidenErrorMsg()
      self?.nameTextFiled?.text = realName
    }).disposed(by:realNameCollectionView.disposeBag)
  }
  
  // 加送活动显示
  func footerActionViewssShow(){
    self.selfActivityBg.isHidden = false
    self.selfActivityBg.snp.updateConstraints{ (make) in
      make.height.equalTo(91)
    }
  }

  // 加送活动不显示
  func footerActionViewsHiden(){
    self.selfActivityBg.isHidden = true
    self.selfActivityBg.snp.updateConstraints{ (make) in
      make.height.equalTo(0)
    }
  }

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
  if curTypeModel == nil  {
     checkCurPayTypeModel()
  }
  let payType = curTypeModel?.payType ?? ""
  if payType == PaySubCode.manualBank.rawValue  || payType == PaySubCode.bqBankPay.rawValue   {
    return 5 + (isBQRealName ? 1 : 0)

  }else if payType == PaySubCode.unionpayScan.rawValue {
    
    let fix:Bool = self.isFix
    return fix == false ? 4 : 3
  
  }else if payType == PaySubCode.netBankOnline.rawValue {
    let fix:Bool = self.isFix
    let bankCount:Int = self.viewModel?.payBKPayNetOnlineModel?.bankList?.count ?? 0
    var count:Int = 3
    if bankCount > 0 {
      count = count + 1
    }
    if fix == false {
      count = count + 1
    }
    return count
    
  }else if payType == PaySubCode.netBankMOB.rawValue {
    
    let fix:Bool = self.isFix
    return fix == false ? 4 : 3
  }
  let bankCount:Int = self.viewModel?.payBKPayNetPCModel?.bankList?.count ??  0
  return bankCount > 0 ? 5 : 4
}
  
func numberOfSections(in tableView: UITableView) -> Int {
  return 1
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
  
  let payType = curTypeModel?.payType ?? ""
  
  if  indexPath.row == 0 {
    var cell = tableView.dequeueReusableCell(withIdentifier: "indentifierHeadImgCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "indentifierHeadImgCell", cellMode: CellMode.headImgMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (viewModel?.curKindModel?.payKindIcon ?? "")
    cell?.hd_headImgView?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
    cell?.hd_contentLab?.text = viewModel?.curKindModel?.payKindName
    return cell!
  }
  else if indexPath.row == 1 {
    var cell = tableView.dequeueReusableCell(withIdentifier: "indentifierOneTitleCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "indentifierOneTitleCell", cellMode: CellMode.oneTitleMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    let payTypeName = curTypeModel?.payTypeName ?? ""
    cell?.ot_contentLab?.text = payTypeName
    
    let haveActivity:Bool = ManagerModel.instanse.activityShow
    let pypeType = curTypeModel?.payType
    if (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) && haveActivity == true {
      
      cell?.markImage.isHidden = false
      footerActionViewssShow()
      selfCompleteLabel.isHidden = true
      selfToTheAccount.isHidden = false
      selfAddToSend.isHidden = false
    }
    else if (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) && haveActivity == false {
      cell?.markImage.isHidden = false
      footerActionViewssShow()
      selfCompleteLabel.isHidden = false
      selfToTheAccount.isHidden = true
      selfAddToSend.isHidden = true
    }
    else{
      cell?.markImage.isHidden = true
      footerActionViewsHiden()
    }
    return cell!
  }
  else if indexPath.row == 2 {
    var cell = tableView.dequeueReusableCell(withIdentifier: "ChargeCollectionViewCell")
    if cell == nil {
       cell = UITableViewCell.init(style: .default, reuseIdentifier: "ChargeCollectionViewCell")
       cell?.selectionStyle = .none
       cell?.backgroundColor = UIColor.clear
       cell?.contentView.addSubview(collectionAmountView)
    }
    collectionAmountView.errorTipLab.isHidden = true
    return cell!
  }
    
  else if indexPath.row == 3 {
    
    // MARK:网银在线存款
    let fix:Bool = self.isFix
    let bankCount:Int = self.viewModel?.payBKPayNetOnlineModel?.bankList?.count ?? 0
    
    if payType == PaySubCode.netBankOnline.rawValue && bankCount > 0 && fix == true{
      
      var cell = tableView.dequeueReusableCell(withIdentifier: "netSelectedBankModeIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "netSelectedBankModeIndentifierInputContentCell", cellMode: CellMode.selectedBankMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      let bankModel = self.viewModel?.payBKPayNetOnlineModel?.bankList?[safe:selectIndexNetOnlineBank]
      cell?.sb_bankLab?.text = bankModel?.bankName
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (bankModel?.bankIcon ?? "")
      cell?.sb_bankIcon?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
      return cell!
    }
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "AmountIndentifierInputContentCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "AmountIndentifierInputContentCell", cellMode: CellMode.inputContentMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
      amountTableViewCell = cell
      amountTextFiled = cell?.ic_textField
      amountTextFiled?.keyboardType = .numberPad
      
      cell?.ic_textField?.rx.text.orEmpty.changed.subscribe(onNext: {  text in
        
        // 老代码限制了总的长度
        if (text.count > 10) {
          let preText = text.prefix(10)
          cell?.ic_textField?.text = String(preText)
          return
        }
      
        // 送的金额和实际到账
        let double = Double(text)
        var float = CGFloat(double ?? 0) * 0.005
        float = CGFloat(NSString.roundFloat(Float(float)))
        if float > 1888 {
           float = 1888
        }
        let send = String(format: "%.2f",float)
        self.selfAddToSend.text = "加送:" + send
        self.toSendStr = send
        
        var floatCou = CGFloat(double ?? 0) + float
        floatCou = CGFloat(NSString.roundFloat(Float(floatCou)))
        let count = String(format: "%.2f",floatCou)
        self.selfToTheAccount.text = "实际到账:" + count
        self.toTheAccountStr = count
        
        let pypeType = self.curTypeModel?.payType
        if (NSInteger(text) ?? 0 >= 99) && (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) {
          self.footerActionViewssShow()
        }else{
          self.footerActionViewsHiden()
        }
        
        // 八快速选择的取消掉
        if text.count > 0 {
          self.collectionAmountView.cancelSelectedIndexHighlight()
        }
        
      }).disposed(by: disposeBag)
      cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
        if self == nil{
          return
        }
        if !isEndEdit  {
          cell?.ic_lineView?.backgroundColor = UIColor.view_white
          cell?.ic_errorTipLab?.isHidden = true
        }else{
          cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
          self?.collectionAmountView.cancelSelectedIndexHighlight()

          let contentText = cell?.ic_textField?.text ?? ""
          if contentText.count < 1 {
            cell?.ic_errorTipLab?.text = "存款金额不能为空"
            cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
            cell?.ic_errorTipLab?.isHidden = false
          }else{
            let codeName = "BANKPAY"
            let subTypeName = self?.curTypeModel?.payType ?? ""
            let errorMsg = self?.viewModel?.showErrorAmountMsg(inputAmount: contentText, payTypeName: codeName, subTypeName: subTypeName)
            if errorMsg?.count ?? 0 > 1 {
              cell?.ic_errorTipLab?.text = errorMsg
              cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
              cell?.ic_errorTipLab?.isHidden = false
              
            }else{
              cell?.ic_errorTipLab?.text = ""
              cell?.ic_errorTipLab?.isHidden = true
            }
          }
        }
      }
    }

    cell?.ic_errorTipLab?.isHidden = true
    cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
    amountTextFiled?.text = ""
    if amountTextFiled != nil {
      let result:(String,String) = viewModel?.checkAmountBeyound(amountTextField: amountTextFiled!, payTypeName: "BANKPAY", subTypeName: payType) ?? ("","")
      let maxAmount:String = result.1
      cell?.max = maxAmount 
    }
    return cell!
  }
  
  if  payType == PaySubCode.manualBank.rawValue || payType == PaySubCode.bqBankPay.rawValue   {
    
    if isBQRealName {
      if indexPath.row == 4 {
        var cell = tableView.dequeueReusableCell(withIdentifier: "BQRealNameIndentifierInputContentCell")
        if cell == nil {
          cell = UITableViewCell.init(style: .default, reuseIdentifier: "BQRealNameIndentifierInputContentCell")
          cell?.selectionStyle = .none
          cell?.backgroundColor = UIColor.clear
          cell?.addSubview(realNameCollectionView)
        }
        let depositorList =  payType == PaySubCode.bqBankPay.rawValue ? self.viewModel?.payBQBankLimitAmount?.depositorList :
          self.viewModel?.payManualBankLimitAmount?.depositorList
        depositorArr.removeAll()
        for i in 0..<(depositorList?.count ?? 0)  {
          let depositorModel = depositorList?[safe:i]
          depositorArr.append(depositorModel?.depositor ?? "")
        }
        if depositorArr.count > 0 {
           realNameCollectionView.realoadData(amountArr: depositorArr, isShowTitle: false,payType:payType)
        }
        return cell!
      }
    }
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "NameIndentifierInputContentCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "NameIndentifierInputContentCell", cellMode: CellMode.inputContentMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
      nameTableViewCell = cell
      nameTextFiled = cell?.ic_textField

      ChargeViewModel.checkChineseName(nameTextFieldCell: cell!, tableView: nil , disposeBag: disposeBag)

      cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
        if self == nil{
          return
        }
        if !isEndEdit {
          
          cell?.ic_lineView?.backgroundColor = UIColor.view_white
          cell?.ic_errorTipLab?.isHidden = true
          
        }else{
          cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
          let contentText = cell?.ic_textField?.text ?? ""
          if contentText.count < 1 {
            cell?.ic_lineView?.backgroundColor = UIColor.line_redColor
            cell?.ic_errorTipLab?.text = "存款人姓名不能为空"
            cell?.ic_errorTipLab?.isHidden = false
          }else if contentText.count < 2 {
            cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
          }else if contentText.count > 21 {
            cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
          }else{
            let lastStr = String(contentText.last!)
            let isLastChinese = RegularExp.isChinese(lastStr)
            if isLastChinese == false {
              cell?.showErrorMsg(msg: "存款人姓名最后一位不能为特殊字符")
            }
            
            let firstChart = contentText.first
            if firstChart == "*" {
              return
            }
            let content =  contentText.replacingOccurrences(of: "·", with: "")
            if !RegularExp.isChinese(content){
              cell?.showErrorMsg(msg: "请输入真实有效的存款人姓名")
            }
          }
        }
      }
    }
    
    if curTypeModel?.payType == PaySubCode.bqBankPay.rawValue {
      cell?.ic_desLab?.text = "银行卡姓名"
    }else if payType == PaySubCode.manualBank.rawValue {
      cell?.ic_desLab?.text = "持卡人姓名"
    }
    nameTextFiled?.placeholder = "请输入银行卡绑定的姓名"
    cell?.ic_errorTipLab?.isHidden = true
    cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
    nameTextFiled?.text = ""
    return cell!
  }
  
  // MARK:网银在线存款
  if payType == PaySubCode.netBankOnline.rawValue {

    var cell = tableView.dequeueReusableCell(withIdentifier: "netSelectedBankModeIndentifierInputContentCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "netSelectedBankModeIndentifierInputContentCell", cellMode: CellMode.selectedBankMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    let bankModel = self.viewModel?.payBKPayNetOnlineModel?.bankList?[safe:selectIndexNetOnlineBank]
    cell?.sb_bankLab?.text = bankModel?.bankName
    let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (bankModel?.bankIcon ?? "")
    cell?.sb_bankIcon?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
    return cell!
  }
  

  var cell = tableView.dequeueReusableCell(withIdentifier: "netpcSelectedBankModeIndentifierInputContentCell") as? ChargeTableViewCell
  if cell == nil {
    cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "netpcSelectedBankModeIndentifierInputContentCell", cellMode: CellMode.selectedBankMode)
    cell?.selectionStyle = .none
    cell?.backgroundColor = UIColor.clear
  }
  let bankModel = self.viewModel?.payBKPayNetPCModel?.bankList?[safe:selecetIndexNetPCBank]
  cell?.sb_bankLab?.text = bankModel?.bankName
  let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (bankModel?.bankIcon ?? "")
  cell?.sb_bankIcon?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
  return cell!
}


func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
  if indexPath.row == 2 {
    return collectionAmountView.colletionHeight
  }
  if isBQRealName {
    if indexPath.row == 4 {
       return 80
    }
  }
  let payType = curTypeModel?.payType ?? ""

  if payType == PaySubCode.netBankOnline.rawValue {
    if indexPath.row == 4 {
      return 40
    }
  }
  if payType == PaySubCode.netBankPC.rawValue{
    if indexPath.row == 4 {
      return 40
    }
  }
  return 60
}
 
func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
  
  if indexPath.row == 0 {
    let paywaysMainPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.mainPaywaysMode)
    paywaysMainPopView.showView()
     
    if paykindArr?.count ?? 0 > 0 {
      paywaysMainPopView.paykindSubjectArr.value = paykindArr!
      
      let count = paywaysMainPopView.paykindSubjectArr.value.count
      paywaysMainPopView.tableView?.snp.updateConstraints({ (make) in
        make.height.equalTo(count * 60)
      })
    }
    paywaysMainPopView.callbackBlock = { [weak self] (indexPath) in
      let kindNameArr = self?.paykindArr
      var bankK = -1
      for  i in 0..<(kindNameArr?.count ?? 0 ) {
        let kindModel = kindNameArr?[i]
        if kindModel?.payKindCode?.contains("BANKPAY") ?? false {
          bankK = i
          break
        }
      }
      if indexPath.row == bankK {
        return
      }
      self?.amountText = ""
      self?.amountTextFiled?.text = ""
      self?.nameTextFiled?.text = ""
      self?.isBQRealName = false
      self?.noBankCardInfoView?.isHidden = true
      self?.delegate?.selectedPaysIndex!(indexPath.row)
    }
    
    // 查看支持App
    paywaysMainPopView.linkCallbackBlock = {
      let activityVC = ActivityWebViewController.init()
      self.nearNav()?.pushViewController(activityVC, animated: true)
    }
  }
  if indexPath.row == 1 {
    let payWaysSubPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.subPaywaysMode)
    
    payWaysSubPopView.showView()
    
    let  kindModel = self.viewModel?.curKindModel
    if kindModel?.payTypeList?.count ?? 0 > 0 {
      payWaysSubPopView.paySubTypeSubjectArr.value = (kindModel?.payTypeList)!
    }
    payWaysSubPopView.callbackBlock = { [weak self] (indexPath) in
//      if indexPath.row == self?.subwaysLastIndex { // 和H5和安卓保持一致
//        return
//      }
      self?.subwaysLastIndex = indexPath.row
      self?.amountTextFiled?.text = ""
      self?.amountText = ""
      self?.nameTextFiled?.text = ""
      self?.isBQRealName = false
      self?.noBankCardInfoView?.isHidden = true
      self?.payWaysSubChange(indexPath: indexPath.row)
    }
    
    // MARK:查看app
    payWaysSubPopView.linkCallbackBlock = {
      let activityVC = ActivityWebViewController.init()
      self.nearNav()?.pushViewController(activityVC, animated: true)
    }
  }
  
  
  if indexPath.row == 4 {
    
    let payType = curTypeModel?.payType ?? ""
    var defaultIndex = 0
    var bankList:[BankListModel]? = nil
    if payType == PaySubCode.netBankOnline.rawValue  {
       bankList = self.viewModel?.payBKPayNetOnlineModel?.bankList
       defaultIndex = self.selectIndexNetOnlineBank
    }else if payType == PaySubCode.netBankPC.rawValue {
       bankList = self.viewModel?.payBKPayNetPCModel?.bankList
       defaultIndex = self.selecetIndexNetPCBank
    }else{
      return 
    }
    let selectBankTableView = SelectBankTableView.init(frame: .zero, dataArr: bankList ?? [] , bankDataType: .BankType , defaultIndex:defaultIndex )
    selectBankTableView.showView()
    selectBankTableView.callbackBlock = { [weak self] (indexPath: IndexPath) ->Void in
      
       print("selectBankTableView.callbackBlock------>indexPath \(indexPath)")
      
       if payType == PaySubCode.netBankOnline.rawValue {
        self?.selectIndexNetOnlineBank = indexPath.row
       }else{
        self?.selecetIndexNetPCBank = indexPath.row
       }
      
      // self?.tableView?.reloadData() 此处如果刷新整个tableView会把金额一起刷新掉
      let indexPath: IndexPath = IndexPath.init(row: 4, section: 0)
      self?.tableView?.reloadRows(at: [indexPath], with: .fade)
    }
  }
  

  // MARK:网银在线存款输入框没有的时候
  let pypeType = curTypeModel?.payType
  if pypeType == PaySubCode.netBankOnline.rawValue {
    
    let fix:Bool = self.isFix
    let bankCount:Int = self.viewModel?.payBKPayNetOnlineModel?.bankList?.count ?? 0
    if  bankCount > 0 && fix == true{
      if indexPath.row == 3 {
        
        let payType = curTypeModel?.payType ?? ""
        var defaultIndex = 0
        var bankList:[BankListModel]? = nil
        if payType == PaySubCode.netBankOnline.rawValue  {
          bankList = self.viewModel?.payBKPayNetOnlineModel?.bankList
          defaultIndex = self.selectIndexNetOnlineBank
        }else if payType == PaySubCode.netBankPC.rawValue {
          bankList = self.viewModel?.payBKPayNetPCModel?.bankList
          defaultIndex = self.selecetIndexNetPCBank
        }else{
          return
        }
        let selectBankTableView = SelectBankTableView.init(frame: .zero, dataArr: bankList ?? [] , bankDataType: .BankType , defaultIndex:defaultIndex )
        selectBankTableView.showView()
        selectBankTableView.callbackBlock = { [weak self] (indexPath: IndexPath) ->Void in
          if payType == PaySubCode.netBankOnline.rawValue {
            self?.selectIndexNetOnlineBank = indexPath.row
          }else{
            self?.selecetIndexNetPCBank = indexPath.row
          }
          let indexPath: IndexPath = IndexPath.init(row: 3, section: 0)
          self?.tableView?.reloadRows(at: [indexPath], with: .fade)
        }
      
      }
    }
  }
}

  func resignAllFirstResponder() {
    amountTextFiled?.resignFirstResponder()
    nameTextFiled?.resignFirstResponder()
  }

@objc func nextAction(){
  
  resignAllFirstResponder()
  var amount = amountTextFiled?.text ?? ""
  let payType = curTypeModel?.payType ?? ""
  var payId = ""
  var realName = nameTextFiled?.text ?? ""
  amount = amount.count > 0 ? amount : amountText
  orderAmount = amount

  if amount.count < 1 {
    if self.isFix == true {
      collectionAmountView.errorTipLab.isHidden = false
    }else{
      amountTableViewCell?.ic_errorTipLab?.isHidden = false
      amountTableViewCell?.ic_errorTipLab?.text = "存款金额不能为空"
      amountTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
    }
    return
  }
  if amountTableViewCell?.ic_errorTipLab?.isHidden == false {
    return
  }
  if payType == PaySubCode.bqBankPay.rawValue || payType == PaySubCode.manualBank.rawValue {
    if realName.count < 1 {
      nameTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
      nameTableViewCell?.ic_errorTipLab?.text = "存款人姓名不能为空"
      nameTableViewCell?.ic_errorTipLab?.isHidden = false
      return
    }else if (nameTableViewCell?.ic_errorTipLab?.isHidden == false) {
      return
    }
    
  }
  if  payType == PaySubCode.unionpayScan.rawValue || payType == PaySubCode.netBankOnline.rawValue || payType == PaySubCode.netBankPC.rawValue || payType == PaySubCode.netBankMOB.rawValue {
    payId = ""
    var bankNo = ""
    if payType == PaySubCode.unionpayScan.rawValue {
       payId = viewModel?.payBKPayScanModel?.payid ?? ""
    }else if payType == PaySubCode.netBankOnline.rawValue {
      payId = viewModel?.payBKPayNetOnlineModel?.payid ?? ""
      let bankModel = viewModel?.payBKPayNetOnlineModel?.bankList?[safe:selectIndexNetOnlineBank]
      bankNo = bankModel?.bankNo ?? ""
    }else if payType == PaySubCode.netBankPC.rawValue {
      payId = viewModel?.payBKPayNetPCModel?.payid ?? ""
      let bankModel = viewModel?.payBKPayNetPCModel?.bankList?[safe:selecetIndexNetPCBank]
      bankNo = bankModel?.bankNo ?? ""
    }else if payType == PaySubCode.netBankMOB.rawValue {
      payId = viewModel?.payBKPayNetMOBModel?.payid ?? ""
      let bankModel = viewModel?.payBKPayNetMOBModel?.bankList?[safe:selecetIndexNetPCBank]
      bankNo = bankModel?.bankNo ?? ""
    }
    
    let alertModel = ChargeAlerModel.init()
    alertModel.containBankMode = false
    alertModel.amount = amount
    alertModel.realName = realName
    alertModel.tipName = curTypeModel?.payTypeName ?? ""
    alertModel.send = self.toSendStr
    alertModel.acount = self.toTheAccountStr
    alertModel.paytype = payType
    
    SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: {[weak self] (selectIndex) in
      if selectIndex == -1 {
        
      }else{
      
        self?.viewModel?.requestCreateOnlineOrder(amount: amount, payid: payId, payType:payType, bankNo:bankNo, finishHandleBlock: { (onlineOrderModel) in
          
          self?.jumpToOrderWebViewCtr(onlineOrderModel: onlineOrderModel)
          
        }, failureHandleBlok: { (error) in
          ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
        })
     
      }
    })
  }else if payType == PaySubCode.manualBank.rawValue {
    
    var depositorType = "0"
    var findId = ""
    if isBQRealName  {
      let depositorList = viewModel?.payManualBankLimitAmount?.depositorList
      for i in 0..<(depositorList?.count ?? 0)  {
        let depositorModel = depositorList?[safe:i]
        if realName.contains(depositorModel?.depositor ?? "test")   {
          findId = depositorModel?.id ?? ""
          break
        }
      }
      if findId.count > 1 {
        realName = findId
        depositorType = "1"
      }
    }
    
    viewModel?.requestQueryManualBankList(name: realName, depositorType: depositorType ,finishHandleBlock: {[weak self] (payManualBankListModel) in
      
      if (payManualBankListModel.bankCards?.count ?? 0 ) < 1 {
        guard let weakSelf = self else {
          return
        }
        if self?.noBankCardInfoView == nil {
          self?.noBankCardInfoView = NOBankCardInfoView.init(frame: .zero, supView: weakSelf)
          self?.addSubview(weakSelf.noBankCardInfoView!)
          self?.noBankCardInfoView?.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(120)
          }
        }
        self?.noBankCardInfoView?.callBackBlock = {
          if self == nil || self?.tableView == nil {
            return
          }
          self?.tableView?.delegate?.tableView!(self!.tableView!, didSelectRowAt:IndexPath.init(row: 0, section: 0))
        }
        //ProgressTopPopView.showPopView(content: "没有银行卡", popStyle: .errorMsgToast)
        
        return
      }
      let alertModel = ChargeAlerModel.init()
      alertModel.containBankMode = true
      alertModel.amount = amount
      alertModel.isManualBank = true
      alertModel.tipName = self?.curTypeModel?.payTypeName ?? ""
      alertModel.realName = self?.nameTextFiled?.text
      alertModel.bankList = payManualBankListModel.bankCards
    
      SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: { (selectIndex) in
        if selectIndex == -1 {
          
        }else{
          let bankModel = alertModel.bankList?[safe:selectIndex] as? BankListModel
          let orderModel = BQPaymentModel()
          orderModel.bankIcon = bankModel?.bankIcon
          orderModel.realName = alertModel.realName
          orderModel.payWayCode = .manualBankPay
          orderModel.accountName = bankModel?.accountName
          orderModel.accountNo = bankModel?.accountNo
          orderModel.amount = amount
          orderModel.bankBranchName = bankModel?.bankBranchName
          orderModel.bankCity = bankModel?.city
          orderModel.bankName = bankModel?.bankName
          orderModel.payLimitTime = "16:30"
          orderModel.bankCardId = bankModel?.bankCardId
          orderModel.province = bankModel?.province
          orderModel.depositorId = findId
          orderModel.depositorType = depositorType
          orderModel.createDate = ManagerModel.getNowDateFormatStr()

          let alipayVC = AlipayWeChatOrderViewController.init(model: orderModel)
          self?.nearNav()?.pushViewController(alipayVC, animated: true)
          
          self?.collectionAmountView.selectIndex = -1
          self?.collectionAmountView.collectionView.reloadData()
          self?.amountTextFiled?.text  = ""
          self?.nameTextFiled?.text = ""
        }
      })
      
    }, failureHandleBlok: { (error) in
      
      // 网络不稳定,请稍后再试
      let message = error.kl_tips ?? ""
      ProgressTopPopView.showPopView(content: "网络不稳定,请稍后再试", popStyle: .errorMsgToast)
      if message.isEqual("网络不稳定,请稍后再试" as String){
        let time: TimeInterval = 1.5
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
          self.backHomePage?("")
        }
      }
    })
  }
  else if  payType == PaySubCode.bqBankPay.rawValue {
    
    var depositorType = "0"
    var findId = ""
    if isBQRealName  {
      let depositorList = viewModel?.payBQBankLimitAmount?.depositorList
      for i in 0..<(depositorList?.count ?? 0)  {
        let depositorModel = depositorList?[safe:i]
        if realName.contains(depositorModel?.depositor ?? "test")   {
          findId = depositorModel?.id ?? ""
          break
        }
      }
      if findId.count > 1 {
        realName = findId
        depositorType = "1"
      }
    }
    
    viewModel?.requestBQBankList(bqPayType:PaySubCode.bqBankPay.rawValue , realName: realName, depositorType:depositorType,  finishHandleBlock: { [weak self]  (payBankListModel) in
      
      if (payBankListModel.bankList?.count ?? 0 ) < 1 {
        
        guard let weakSelf = self else {
          return
        }
        if weakSelf.noBankCardInfoView == nil {
          weakSelf.noBankCardInfoView = NOBankCardInfoView.init(frame: .zero, supView: weakSelf)
          weakSelf.addSubview(weakSelf.noBankCardInfoView!)
          
          weakSelf.noBankCardInfoView?.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(120)
          }
        }
        weakSelf.noBankCardInfoView?.isHidden = false
        weakSelf.noBankCardInfoView?.callBackBlock = {
          if weakSelf.tableView == nil {
            return
          }
          weakSelf.tableView?.delegate?.tableView!(self!.tableView!, didSelectRowAt:IndexPath.init(row: 0, section: 0))
        }
        //ProgressTopPopView.showPopView(content: "没有银行卡", popStyle: .errorMsgToast)
        return
      }
        let alertModel = ChargeAlerModel.init()
        alertModel.containBankMode = true
        alertModel.amount = amount
        alertModel.tipName = self?.curTypeModel?.payTypeName ?? ""
        alertModel.realName = self?.nameTextFiled?.text
        alertModel.bankList = self?.viewModel?.payBQBankListModel?.bankList
        SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: { (selectIndex) in
          if selectIndex == -1 {
            
          }else{
            let bankModel = alertModel.bankList?[safe:selectIndex] as? BankListModel
            let bankCode = bankModel?.bankCode ?? ""
            var param = ManagerModel.configLoginNameParamDic()
            param["depositor"] = realName
            param["depositorType"] = depositorType
            param["amount"] = amount
            param["bankCode"] = bankCode
            param["payType"] = PaySubCode.bqBankPay.rawValue

            self?.viewModel?.requestBQPayment(param: param, finishHandleBlock: { (paymentOrderModel) in
              paymentOrderModel?.bankIcon = bankModel?.bankIcon
              paymentOrderModel?.realName = self?.nameTextFiled?.text
              paymentOrderModel?.payWayCode = .bankBQPay
              paymentOrderModel?.title = self?.curTypeModel?.payTypeName
              paymentOrderModel?.transaType = .deposit
              paymentOrderModel?.createDate = ManagerModel.getNowDateFormatStr()
              let alipayVC = AlipayWeChatOrderViewController.init(model: paymentOrderModel)
              self?.nearNav()?.pushViewController(alipayVC, animated: true)
              
              self?.collectionAmountView.selectIndex = -1
              self?.collectionAmountView.collectionView.reloadData()
              self?.amountTextFiled?.text  = ""
              self?.nameTextFiled?.text = ""
              
            },failureHandleBlock: { (error) in
              ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
            })
          }
        })
      
    }, failureHandleBlok: { [weak self] (error) in
      if error.kl_code?.contains("801111") == true {

        guard let weakSelf = self else {
          return
        }
        if weakSelf.noBankCardInfoView == nil {
          weakSelf.noBankCardInfoView = NOBankCardInfoView.init(frame: .zero, supView: weakSelf)
          weakSelf.addSubview(weakSelf.noBankCardInfoView!)
          
          weakSelf.noBankCardInfoView?.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(120)
          }
        }
        weakSelf.noBankCardInfoView?.isHidden = false
        weakSelf.noBankCardInfoView?.callBackBlock = {
          if weakSelf.tableView == nil {
            return
          }
          weakSelf.tableView?.delegate?.tableView!(self!.tableView!, didSelectRowAt:IndexPath.init(row: 0, section: 0))
        }
        //ProgressTopPopView.showPopView(content: "没有银行卡", popStyle: .errorMsgToast)
        return
      }
      
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      let message = error.kl_tips ?? ""
      if message.isEqual("网络不稳定,请稍后再试" as String){
        let time: TimeInterval = 1.5
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
          self?.backHomePage?("")
        }
      }
    })
  }
}
  

  
  func checkCurPayTypeModel(){
    
    if curTypeModel != nil  {
      return
    }
    let payTypeModel = self.viewModel?.curKindModel?.payTypeList?[safe:0]
    curTypeModel = payTypeModel
  }
  
  func payWaysSubChange(indexPath:Int){
    
    let kindCode = self.viewModel?.curKindModel?.payKindCode ?? ""
    let payTypeModel = self.viewModel?.curKindModel?.payTypeList?[safe:indexPath]
    let payType = payTypeModel?.payType ?? ""
    let payTypeName = payTypeModel?.payTypeName ?? ""
    curTypeModel = payTypeModel
    
    viewModel?.collectionAmountView = collectionAmountView
    
    if payType == PaySubCode.bqBankPay.rawValue || payType == PaySubCode.manualBank.rawValue {
      
      viewModel?.requestQueryBQAmountList(payType: payType, finishHanleBlock: { [weak self] (isSuccess) in
        if isSuccess{
          if payType == PaySubCode.manualBank.rawValue {
            self?.isFix = self?.viewModel?.payManualBankLimitAmount?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payManualBankLimitAmount?.amounts, isFix: self?.isFix,payType:payType)
            self?.isBQRealName = (self?.viewModel?.payManualBankLimitAmount?.depositorList?.count ??  0 ) > 0 ? true : false
            self?.tableView?.reloadData()
          }else{
            self?.isFix = self?.viewModel?.payBQBankLimitAmount?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBQBankLimitAmount?.amounts, isFix: self?.isFix,payType:payType)
            self?.isBQRealName = (self?.viewModel?.payBQBankLimitAmount?.depositorList?.count ??  0 ) > 0 ? true : false

            self?.tableView?.reloadData()
          }
        }
      })
      return
    }
    viewModel?.requestQueryOnlineBanksList(payType: payType, paykindCode:kindCode, subTypeName: payTypeName,finishHandleBlock: { [weak self] (isSuccess) in
      if isSuccess {
        if payType == PaySubCode.netBankOnline.rawValue {
          self?.isFix = self?.viewModel?.payBKPayNetOnlineModel?.amountType?.fix ?? false
          self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBKPayNetOnlineModel?.amountType?.amounts, isFix: self?.isFix,payType:payType)
        }else if payType == PaySubCode.netBankPC.rawValue {
          self?.isFix = self?.viewModel?.payBKPayNetPCModel?.amountType?.fix ?? false
          self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBKPayNetPCModel?.amountType?.amounts, isFix: self?.isFix,payType:payType)
        }else if payType == PaySubCode.unionpayScan.rawValue  {
          self?.isFix = self?.viewModel?.payBKPayScanModel?.amountType?.fix ?? false
          self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBKPayScanModel?.amountType?.amounts, isFix: self?.isFix,payType:payType)
        }else if payType == PaySubCode.netBankMOB.rawValue {
          self?.isFix = self?.viewModel?.payBKPayNetMOBModel?.amountType?.fix ?? false
          self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBKPayNetMOBModel?.amountType?.amounts, isFix: self?.isFix,payType:payType)
        }
        self?.tableView?.reloadData()
      }
    })
    tableView?.reloadData()
  }
  
  private func jumpToOrderWebViewCtr(onlineOrderModel:PayOnlineOrderModel){
    
    let orderWebVC = OrderWebViewController.init(url: onlineOrderModel.payUrl ?? "")
    self.nearNav()?.pushViewController(orderWebVC, animated: true)
    onlineOrderModel.amount = orderAmount
    onlineOrderModel.createDate = ManagerModel.getNowDateFormatStr()
    orderWebVC.dismissSubject.subscribe(onNext: { (newValue:Int) in
      
      self.collectionAmountView.selectIndex = -1
      self.collectionAmountView.collectionView.reloadData()
      self.amountTextFiled?.text  = ""
      self.nameTextFiled?.text = ""
      
      ChargeQueryOrderPopView.showPopView(tapBtnBlock: {[weak self] (tapState) in
        if tapState == TapState.sure {
          let transacDetailVC = TransactiontDetailViewController()
          onlineOrderModel.transaType = .deposit
          onlineOrderModel.title =  self?.curTypeModel?.payTypeName
          transacDetailVC.transacDetailModel = onlineOrderModel
          self?.nearNav()?.pushViewController(transacDetailVC, animated: true)
        }else if tapState == TapState.cancel {
          let customerOnlineVC = CustomerOnlineHtmlViewController()
          self?.nearNav()?.pushViewController(customerOnlineVC, animated: true)
        }
      })
    },onError: { (error) in
      print("\(error)")
    }).disposed(by: self.disposeBag)
  }
}
