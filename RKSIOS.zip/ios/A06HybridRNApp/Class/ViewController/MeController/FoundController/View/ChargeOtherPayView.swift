//
//  ChargeOtherPayView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 11/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ChargeOtherPayView: UIView,UITableViewDataSource,UITableViewDelegate {
  
  var delegate:DidSelectedPaywaysDelegate?
  var paykindArr:[PayKindModel]?
  var viewModel:ChargeViewModel?
  var curTypeModel:PayTypeModel?
  var kindModel:PayKindModel?
  
  var amountTableViewCell:ChargeTableViewCell?
  var pointCardNumberTableViewCell:ChargeTableViewCell?
  var pointCardTypeTableViewCell:ChargeTableViewCell?
  var pointCardPwdTableViewCell:ChargeTableViewCell?
  var rgBtcTableViewCell:ChargeTableViewCell?
  
  var amountText = ""
  var orderAmount = ""
  var amountTextFiled:UITextField?
  var pointCardNumField:UITextField?
  var pointCardPwdField:UITextField?
  var manualBtcField:UITextField?
  
  var normalFooterView:UIView?
  var btcFooterView:BtcFooterView?
  var pointCardFooterView:UIView?
  
  var subwaysLastIndex = 0
  let disposeBag = DisposeBag()
  var isFix:Bool = false
  var isSelectPointCard:Int = -1  //-1

  var tableView : UITableView?
  var selfActivityBg:UIView = UIView()
  var selfAddToSend:UILabel = UILabel()
  var selfToTheAccount:UILabel = UILabel()
  var selfQqsaoma:UILabel = UILabel()
  var selfCompleteLabel:UILabel = UILabel()
  
  var toSendStr:String = ""
  var toTheAccountStr:String = ""
  
  var collectionAmountView : ChargeCollectionViewCell = ChargeCollectionViewCell.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 0),isRealName:false)
  
  init(frame: CGRect, isfomeActivity:Bool) {
    super.init(frame: frame)
    setupView()
    
    // MAKE:如果是活动界面过来额要弹出支付方式
    if isfomeActivity {
      let time: TimeInterval = 0.5
      DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
        self.isComeFromActivity()
      }
    }
  }
  
  func isComeFromActivity(){
    let paywaysMainPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.mainPaywaysMode)
    paywaysMainPopView.showView()
    if paykindArr?.count ?? 0 > 0 {
      paywaysMainPopView.paykindSubjectArr.value = paykindArr!
    }
    paywaysMainPopView.callbackBlock = { [weak self] (indexPath) in
      let kindNameArr = self?.paykindArr
      var otherK = -1
      for  i in 0..<(kindNameArr?.count ?? 0 ) {
        let kindModel = kindNameArr?[i]
        if kindModel?.payKindCode?.contains("OKPAY") ?? false {
          otherK = i
          break
        }
      }
      if indexPath.row == otherK {
        return
      }
      self?.amountText = ""
      self?.amountTextFiled?.text = ""
      self?.isSelectPointCard = -1
      self?.pointCardTypeTableViewCell?.iua_textField?.text = ""
      self?.pointCardNumberTableViewCell?.hidenErrorMsg()
      self?.pointCardNumberTableViewCell?.hidenErrorMsg()
      self?.pointCardPwdTableViewCell?.hidenErrorMsg()
      self?.rgBtcTableViewCell?.hidenErrorMsg()
      self?.amountTableViewCell?.hidenErrorMsg()
      self?.collectionAmountView.errorTipLab.isHidden = true
      self?.pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = true
      self?.delegate?.selectedPaysIndex!(indexPath.row)
    }
    
    // MARK:查看app
    paywaysMainPopView.linkCallbackBlock = {
      let activityVC = ActivityWebViewController.init()
      self.nearNav()?.pushViewController(activityVC, animated: true)
    }
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.separatorStyle = .none
    self.addSubview(tableView!)
    tableView?.snp.makeConstraints({ (make) in
      make.left.right.bottom.equalTo(self)
      make.top.equalToSuperview().offset(0)  //STATUS_NAV_BAR_Y
    })
    tableView?.backgroundColor = UIColor.clear
    
    let footView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 145 + 54))
    normalFooterView = footView
    
    // 活动的背景的框框
    let activityBg = UIView.init(frame: .zero)
    activityBg.layer.cornerRadius = 5
    activityBg.layer.masksToBounds = true
    activityBg.layer.backgroundColor = UIColor.init(R: 42, G: 45, B: 50, A: 1).cgColor
    footView.addSubview(activityBg)
    selfActivityBg = activityBg
    activityBg.snp.makeConstraints { (make) in
      make.left.equalTo(footView).offset(15)
      make.right.equalTo(footView).offset(-15)
      make.top.equalTo(footView).offset(15)
      make.height.equalTo(91)
    }
    
    // 加送
    let addToSend = UILabel.init(frame: .zero)
    addToSend.text = "加送："
    addToSend.textColor = UIColor.init(R: 249, G: 171, B: 16, A: 1)
    addToSend.font = UIFont.systemFont(ofSize: 16)
    activityBg.addSubview(addToSend)
    addToSend.backgroundColor = UIColor.clear
    selfAddToSend = addToSend
    addToSend.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(activityBg.snp.top).offset(22)
      make.height.equalTo(21)
    }
    
    // 实际到账
    let toTheAccount = UILabel.init(frame: .zero)
    toTheAccount.text = "实际到账："
    toTheAccount.textColor = .white
    toTheAccount.font = UIFont.systemFont(ofSize: 14)
    activityBg.addSubview(toTheAccount)
    toTheAccount.backgroundColor = UIColor.clear
    selfToTheAccount = toTheAccount
    toTheAccount.snp.makeConstraints { (make) in
      make.centerX.equalTo(activityBg.snp.centerX)
      make.top.equalTo(addToSend.snp.bottom).offset(5)
      make.height.equalTo(19)
    }
    
    // QQ扫码提示
    let qqsaoma = UILabel.init(frame: .zero)
    qqsaoma.text = "近期扫码支付系统不稳定，如遇问题，请重试几次,或改用其他存款方式"
    qqsaoma.textColor = UIColor.init(R: 247, G:247 , B: 247, A: 0.3)
    qqsaoma.numberOfLines = 2
    qqsaoma.font = UIFont.systemFont(ofSize: 14)
    activityBg.addSubview(qqsaoma)
    qqsaoma.backgroundColor = UIColor.clear
    selfQqsaoma = qqsaoma
    qqsaoma.snp.makeConstraints { (make) in
      make.top.equalTo(0)
      make.left.equalTo(0)
      make.right.equalTo(0)
    }
    
    // activity已经完成
    let completeLabel = UILabel.init(frame: .zero)
    completeLabel.text = "您今日的1888元已领取完毕,明日可继续领取"
    completeLabel.textColor = .white
    completeLabel.font = UIFont.systemFont(ofSize: 14)
    completeLabel.textAlignment = .center
    activityBg.addSubview(completeLabel)
    completeLabel.backgroundColor = UIColor.clear
    selfCompleteLabel = completeLabel
    completeLabel.snp.makeConstraints { (make) in
      make.left.equalTo(0)
      make.top.equalTo(0)
      make.bottom.equalTo(0)
      make.right.equalTo(0)
    }
    
    let nextBtn = UIButton.init(frame: .zero);
    footView.addSubview(nextBtn)
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.setTitle("下一步", for: .normal)
    nextBtn.layer.cornerRadius = 5.0
    nextBtn.setTitleColor(UIColor.view_white, for: .normal)
    nextBtn.titleLabel?.font = UIFont.PFML_Font
    nextBtn.addTarget(self, action: #selector(nextAction), for: .touchUpInside)
    nextBtn.snp.makeConstraints { (make) in
      make.left.equalTo(footView).offset(View_Margin)
      make.right.equalTo(footView).offset(0-View_Margin)
      make.top.equalTo(activityBg.snp.bottom).offset(36)
      make.height.equalTo(54)
    }
   
    btcFooterView = BtcFooterView()
    btcFooterView?.nextBtn.addTarget(self, action: #selector(nextAction), for: .touchUpInside)
    tableView?.tableFooterView = footView
    
    collectionAmountView.seletedAmountSubject.subscribe(onNext: {[weak self] (amount:String) in
      self?.amountTableViewCell?.hidenErrorMsg()
      self?.amountTextFiled?.text = amount
      self?.collectionAmountView.errorTipLab.isHidden = true
      let payType = self?.curTypeModel?.payType ?? ""
      if payType == PaySubCode.pointCard.rawValue {
        
       let pointCardListMode =  self?.viewModel?.payPointCardListModel?.pointCardList?[safe:(self?.isSelectPointCard ?? 0)]
        let fee = pointCardListMode?.fee
        if fee == nil || self?.btcFooterView?.toastLab == nil{
          return
        }
        let totalAmount = amount + "元"
        let feeAmountValue = Double(amount.toIntValue()*fee!.toIntValue())/100.0
        let feeAmount = String(format: "%.2f", feeAmountValue) + "元"
        let realAmountValue = amount.toDoubleValue() -  feeAmountValue
        let realAmount =  String(format: "%.2f", realAmountValue) + "元"
        self?.amountText = String(format: "%.2f", realAmountValue)
        self?.btcFooterView?.toastLab.text = "点卡面值:" + totalAmount +   " 手续费:" +  feeAmount +   " 实际到账:" + realAmount
        NSString.changeUILablePartColor(self?.btcFooterView?.toastLab!, changeOneString: totalAmount, changeTwoString: feeAmount, changeThreeString: realAmount, andAllColor: UIColor.white, andMark: UIColor.font_purplishRedColor, andMark: UIFont.M_Font)
      }
      
      // 送的金额和实际到账
      let double = Double(amount)
      var float = CGFloat(double ?? 0) * 0.005
      float = CGFloat(NSString.roundFloat(Float(float)))
      if float > 1888 {
         float = 1888
      }
      let send = String(format: "%.2f",float)
      self?.selfAddToSend.text = "加送:" + send
      self?.toSendStr = send
      
      var floatCou = CGFloat(double ?? 0) + float
      floatCou = CGFloat(NSString.roundFloat(Float(floatCou)))
      let count = String(format: "%.2f",floatCou)
      self?.selfToTheAccount.text = "实际到账:" + count
      self?.toTheAccountStr = count
      
      let pypeType = self?.curTypeModel?.payType
      if NSInteger(amount) ?? 0 >= 99 && (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true){
        self?.footerActionViewssShow()
      }else{
        
        if pypeType?.isEqual("7" as String) == true{
          self?.footerActionViewssShow()
          self?.selfAddToSend.isHidden = true
          self?.selfToTheAccount.isHidden = true
          self?.selfQqsaoma.isHidden = false
          self?.selfCompleteLabel.isHidden = true
          self?.selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
          
        }else{
          self?.footerActionViewsHiden()
          self?.selfAddToSend.isHidden = false
          self?.selfToTheAccount.isHidden = false
          self?.selfQqsaoma.isHidden = true
          self?.selfCompleteLabel.isHidden = true
          self?.selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
        }
      }
      
    }).disposed(by:collectionAmountView.disposeBag)
  }
  
  // 加送活动显示
  func footerActionViewssShow(){
    self.selfActivityBg.isHidden = false
    self.selfActivityBg.snp.updateConstraints{ (make) in
      make.height.equalTo(91)
    }
  }
  
  // 加送活动不显示
  func footerActionViewsHiden(){
    self.selfActivityBg.isHidden = true
    self.selfActivityBg.snp.updateConstraints{ (make) in
      make.height.equalTo(0)
    }
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if curTypeModel == nil  {
      checkCurPayTypeModel()
    }
    let payType = curTypeModel?.payType ?? ""
    if payType == PaySubCode.pointCard.rawValue  {
      return 5 + ( (isSelectPointCard == -1) ? 0 : 1)
    }
    if payType == PaySubCode.QQWap.rawValue || payType == PaySubCode.QQScan.rawValue
      || payType == PaySubCode.jdWap.rawValue || payType == PaySubCode.jdScan.rawValue || payType == PaySubCode.btcpay.rawValue {
      return 4 - (isFix ? 1 : 0)
    }
    if payType == PaySubCode.manualBtc.rawValue {
      return 3
    }
    return 4
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    if  indexPath.row == 0 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "indentifierHeadImgCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "indentifierHeadImgCell", cellMode: CellMode.headImgMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (viewModel?.curKindModel?.payKindIcon ?? "")
      cell?.hd_headImgView?.sd_setImage(with: URL.init(string: cdnImgUrl), placeholderImage: UIImage.init(named: "logo"))
      cell?.hd_contentLab?.text = viewModel?.curKindModel?.payKindName

      return cell!
    }
    else if indexPath.row == 1 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "indentifierOneTitleCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "indentifierOneTitleCell", cellMode: CellMode.oneTitleMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      cell?.ot_contentLab?.text = curTypeModel?.payTypeName ?? ""
      
      let haveActivity:Bool = ManagerModel.instanse.activityShow
      let pypeType = curTypeModel?.payType
      if (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) && haveActivity == true {
        cell?.markImage.isHidden = false
        footerActionViewssShow()
        selfAddToSend.isHidden = false
        selfToTheAccount.isHidden = false
        selfQqsaoma.isHidden = true
        selfCompleteLabel.isHidden = true
        selfActivityBg.layer.backgroundColor = UIColor.init(R: 42, G: 45, B: 50, A: 1).cgColor
      }
      else if (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) && haveActivity == false {
        cell?.markImage.isHidden = false
        footerActionViewssShow()
        selfAddToSend.isHidden = true
        selfToTheAccount.isHidden = true
        selfQqsaoma.isHidden = true
        selfCompleteLabel.isHidden = false
        selfActivityBg.layer.backgroundColor = UIColor.init(R: 42, G: 45, B: 50, A: 1).cgColor
      }
      else{
        
        if pypeType?.isEqual("7" as String) == true{
          cell?.markImage.isHidden = true
          footerActionViewssShow()
          selfAddToSend.isHidden = true
          selfToTheAccount.isHidden = true
          selfQqsaoma.isHidden = false
          selfCompleteLabel.isHidden = true
          selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
          
        }else{
          cell?.markImage.isHidden = true
          footerActionViewsHiden()
          selfAddToSend.isHidden = false
          selfToTheAccount.isHidden = false
          selfQqsaoma.isHidden = true
          selfCompleteLabel.isHidden = true
          selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
        }
      }
      
      return cell!
    }
    let payType = curTypeModel?.payType ?? ""
    if payType == PaySubCode.manualBtc.rawValue {
      
      var cell = tableView.dequeueReusableCell(withIdentifier: "rgBtcIndentifierInputContentCell") as? ChargeTableViewCell
      if cell == nil {
        cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "rgBtcIndentifierInputContentCell", cellMode: CellMode.manualInputContentMode)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      
        manualBtcField = cell?.ic_textField
        manualBtcField?.keyboardType = UIKeyboardType.decimalPad
        rgBtcTableViewCell = cell
        
        cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
          if self == nil{
            return
          }
          if !isEndEdit  {
            cell?.ic_lineView?.backgroundColor = UIColor.view_white
            cell?.ic_errorTipLab?.isHidden = true
          }else{
            cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
            let contentText = cell?.ic_textField?.text ?? ""
            if contentText.count < 1 {
              cell?.showErrorMsg(msg: "比特币不能为空")
            }else{
               let textFloat = contentText.toDoubleValue()
              if (textFloat < 0.01){
                cell?.showErrorMsg(msg: "请输入0.01-30个比特币数量")
              }
            }
          }
        }
        manualBtcField?.rx.text.orEmpty.changed.subscribe(onNext: {[weak self]   text in
          
          if (text.first == ".") { //防止输入前面小数点
            self?.manualBtcField?.text = ""
            return
          }
          if (text.contains(".") == true) { //防止输入位数过长
           if (text.first == "0") {
            if (text.count > 4) {
              let preText = text.prefix(4)
              self?.manualBtcField?.text = String(preText)
              return
            }
           }else{
              if (text.count > 5) {
                let preText = text.prefix(5)
                self?.manualBtcField?.text = String(preText)
                return
              }
            }
          }
          if(text.count > 1 ) { ////防止输入00
            let preText = text.prefix(2)
            if (preText == "00") {
              self?.manualBtcField?.text = "0"
              return
            }
          }
          if(text.first == "0"){ //防止输入01
            if (text.count > 1) {
              let preText = text.prefix(2)
              if(preText != "0."){
                self?.manualBtcField?.text = "0."
                return
              }
            }
          }
          var textFloat = text.toDoubleValue()
          if textFloat > 30.0 {
            self?.manualBtcField?.text = "30"
            textFloat = 30.0
          }
          if self?.btcFooterView?.toastLab == nil || text.count < 1 {
              return
            }
            let btcResultAmount = (Double(text) ?? 0 ) * (Double( self?.viewModel?.payQueryBtcRateModel?.btcRate ?? "0" ) ?? 0 )
            let decBtcAmount =  String.init(format: "%.2f元", btcResultAmount)
            self?.btcFooterView?.toastLab.text =  "= " + "\(decBtcAmount)"  + "  人民币(RMB)"
            NSString.changeUILablePartColor(self!.btcFooterView!.toastLab, change: decBtcAmount, andAllColor: UIColor.white, andMark: UIColor.font_purplishRedColor, andMark: UIFont.M_Font)
            
          }).disposed(by: disposeBag)
        
      }
      cell?.ic_desLab?.text = "比特币"
      cell?.ic_textField?.placeholder = "请输入0.01-30个比特币数量"
      return cell!
    }
    
    if payType == PaySubCode.pointCard.rawValue {
      if indexPath.row == 2 {
        var cell = tableView.dequeueReusableCell(withIdentifier: "SelectTypeIndentifierInputContentCell") as? ChargeTableViewCell
        if cell == nil {
          cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "SelectTypeIndentifierInputContentCell", cellMode: CellMode.pointCardInputAndUpArrowMode)
          cell?.selectionStyle = .none
          cell?.backgroundColor = UIColor.clear
          pointCardTypeTableViewCell = cell
        }
        if isSelectPointCard == -1 {
          cell?.iua_textField?.placeholder = "请选择类型"
        }else{
          let cardListModel = viewModel?.payPointCardListModel?.pointCardList?[safe:isSelectPointCard]
          cell?.iua_textField?.text = cardListModel?.name
        }
        cell?.iua_desLab?.text = "点卡类型"
        cell?.iua_textField?.placeholder = "请选择类型"
        return cell!
      }
      
      if isSelectPointCard != -1  && indexPath.row == 3{
        var cell = tableView.dequeueReusableCell(withIdentifier: "ChargeCollectionViewCell")
        if cell == nil {
          cell = UITableViewCell.init(style: .default, reuseIdentifier: "ChargeCollectionViewCell")
          cell?.selectionStyle = .none
          cell?.backgroundColor = UIColor.clear
          cell?.addSubview(collectionAmountView)
        }
        return cell!
      }
     else if isSelectPointCard == -1 && indexPath.row == 3 || isSelectPointCard != -1 && indexPath.row == 4{
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "CardNumIndentifierInputContentCell") as? ChargeTableViewCell
        if cell == nil {
          cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "CardNumIndentifierInputContentCell", cellMode: CellMode.inputContentMode)
          cell?.selectionStyle = .none
          cell?.backgroundColor = UIColor.clear
          cell?.ic_desLab?.text = "点卡卡号"
          cell?.ic_textField?.placeholder = "输入卡号"
          pointCardNumberTableViewCell = cell
          pointCardNumField = cell?.ic_textField
          cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
            if self == nil{
              return
            }
            if !isEndEdit  {
              cell?.ic_lineView?.backgroundColor = UIColor.view_white
              cell?.ic_errorTipLab?.isHidden = true
            }else{
              cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
              
              let contentText = cell?.ic_textField?.text ?? ""
              if contentText.count < 1 {
                cell?.showErrorMsg(msg: "点卡卡号不能为空")
              }else{
                if contentText.count < 6 {
                  cell?.showErrorMsg(msg: "请输入正确的点卡卡号")
                }else if contentText.count > 45 {
                  cell?.showErrorMsg(msg: "请输入正确的点卡卡号,不能大于45位")
                }else if (!RegularExp.isValidateDigitEn(contentText))   {
                  cell?.showErrorMsg(msg: "请输入正确的点卡卡号,只能输入数字和字母")
                }else{
                  cell?.ic_errorTipLab?.isHidden = true
                }
              }
            }
          }
          
        }
       
        return cell!
        
      }else if isSelectPointCard == -1 && indexPath.row == 4 || isSelectPointCard != -1 && indexPath.row == 5{
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "PwdIndentifierInputContentCell") as? ChargeTableViewCell
        if cell == nil {
          cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "PwdIndentifierInputContentCell", cellMode: CellMode.inputContentMode)
          cell?.selectionStyle = .none
          cell?.backgroundColor = UIColor.clear
          cell?.ic_desLab?.text = "点卡密码"
          cell?.ic_textField?.placeholder = "输入密码"
          cell?.ic_textField?.isSecureTextEntry = true
          pointCardPwdField = cell?.ic_textField
          pointCardPwdTableViewCell = cell
          cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
            if self == nil{
              return
            }
            if !isEndEdit  {
              cell?.ic_lineView?.backgroundColor = UIColor.view_white
              cell?.ic_errorTipLab?.isHidden = true
            }else{
              cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
  
              let contentText = cell?.ic_textField?.text ?? ""
              if contentText.count < 1 {
                cell?.showErrorMsg(msg: "点卡密码不能为空")
              }else{
                if contentText.count < 2 {
                  cell?.showErrorMsg(msg: "请输入正确密码")
                }else{
                  cell?.ic_errorTipLab?.isHidden = true
                }
              }
            }
          }
        }
        return cell!
      }
  }
  if indexPath.row == 2 {
      var cell = tableView.dequeueReusableCell(withIdentifier: "ChargeCollectionViewCell")
      if cell == nil {
        cell = UITableViewCell.init(style: .default, reuseIdentifier: "ChargeCollectionViewCell")
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
        cell?.addSubview(collectionAmountView)
      }
      return cell!
    }
      
    var cell = tableView.dequeueReusableCell(withIdentifier: "AmountIndentifierInputContentCell") as? ChargeTableViewCell
    if cell == nil {
      cell = ChargeTableViewCell.init(style: .default, reuseIdentifier: "AmountIndentifierInputContentCell", cellMode: CellMode.inputContentMode)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
      
      amountTableViewCell = cell
      amountTextFiled = cell?.ic_textField
      amountTextFiled?.keyboardType = .numberPad
      cell?.ic_textField?.rx.text.orEmpty.changed.subscribe(onNext: {  text in
        
        if (text.count > 10) {
          let preText = text.prefix(10)
          cell?.ic_textField?.text = String(preText)
          return
        }
        
        // 送的金额和实际到账
        let double = Double(text)
        var float = CGFloat(double ?? 0) * 0.005
        float = CGFloat(NSString.roundFloat(Float(float)))
        if float > 1888 {
           float = 1888
        }
        let send = String(format: "%.2f",float)
        self.selfAddToSend.text = "加送:" + send
        self.toSendStr = send
        
        var floatCou = CGFloat(double ?? 0) + float
        floatCou = CGFloat(NSString.roundFloat(Float(floatCou)))
        let count = String(format: "%.2f",floatCou)
        self.selfToTheAccount.text = "实际到账:" + count
        self.toTheAccountStr = count
        
        let pypeType = self.curTypeModel?.payType
        if NSInteger(text) ?? 0 >= 99 && (pypeType?.isEqual("15" as String) == true || pypeType?.isEqual("16" as String) == true) {
          self.footerActionViewssShow()
        }else{
          
          if pypeType?.isEqual("7" as String) == true{
          
            self.footerActionViewssShow()
            self.selfAddToSend.isHidden = true
            self.selfToTheAccount.isHidden = true
            self.selfQqsaoma.isHidden = false
            self.selfCompleteLabel.isHidden = true
            self.selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
            
          }else{
            
            self.footerActionViewsHiden()
            self.selfAddToSend.isHidden = false
            self.selfToTheAccount.isHidden = false
            self.selfQqsaoma.isHidden = true
            self.selfCompleteLabel.isHidden = true
            self.selfActivityBg.layer.backgroundColor = UIColor.clear.cgColor
          }
        }
        
        // 八快速选择的取消掉
        if text.count > 0 {
          self.collectionAmountView.cancelSelectedIndexHighlight()
        }
        
      }).disposed(by: disposeBag)
      cell?.textFieldEditingBlock = { [weak self ] (isEndEdit) in
        if self == nil{
          return
        }
        if !isEndEdit  {
          cell?.ic_lineView?.backgroundColor = UIColor.view_white
          cell?.ic_errorTipLab?.isHidden = true
        }else{
          cell?.ic_lineView?.backgroundColor = UIColor.view_lineColor
          self?.collectionAmountView.cancelSelectedIndexHighlight()

          let contentText = cell?.ic_textField?.text ?? ""
          if contentText.count < 1 {
            cell?.showErrorMsg(msg: "存款金额不能为空")

          }else{
            let codeName = "OKPAY"
            let subTypeName = self?.curTypeModel?.payType ?? ""
            let errorMsg = self?.viewModel?.showErrorAmountMsg(inputAmount: contentText, payTypeName: codeName, subTypeName: subTypeName)
            if errorMsg?.count ?? 0 > 1 {
              cell?.showErrorMsg(msg: errorMsg!)
            }else{
              cell?.ic_errorTipLab?.isHidden = true
            }
          }
        }
      }
    }
  
    amountTextFiled?.text = ""
    if amountTextFiled != nil {
      let result:(String,String) = viewModel?.checkAmountBeyound(amountTextField: amountTextFiled!, payTypeName: "OKPAY", subTypeName: payType) ?? ("","")
      let maxAmount:String = result.1
      cell?.max = maxAmount
    }
    
    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
    let payType = curTypeModel?.payType ?? ""
    if payType == PaySubCode.pointCard.rawValue {
      
      if isSelectPointCard == -1 {
        if indexPath.row == 2 {
          return 80
        }
        
      }else {
        if indexPath.row == 2 {
          return 60
        }
        if indexPath.row == 3 {
          return collectionAmountView.colletionHeight
        }
      }
      return 60
    }
    if payType == PaySubCode.manualBtc.rawValue {
      if indexPath.row == 2 {
        return 80
      }
    }
    
    if indexPath.row == 2 {
      return collectionAmountView.colletionHeight
    }
    return 60
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    if indexPath.row == 0 {
      let paywaysMainPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.mainPaywaysMode)
      paywaysMainPopView.showView()
      if paykindArr?.count ?? 0 > 0 {
        paywaysMainPopView.paykindSubjectArr.value = paykindArr!
      }
      paywaysMainPopView.callbackBlock = { [weak self] (indexPath) in
        let kindNameArr = self?.paykindArr
        var otherK = -1
        for  i in 0..<(kindNameArr?.count ?? 0 ) {
          let kindModel = kindNameArr?[i]
          if kindModel?.payKindCode?.contains("OKPAY") ?? false {
            otherK = i
            break
          }
        }
        if indexPath.row == otherK {
          return
        }
        self?.amountText = ""
        self?.amountTextFiled?.text = ""
        self?.isSelectPointCard = -1
        self?.pointCardTypeTableViewCell?.iua_textField?.text = ""
        self?.pointCardNumberTableViewCell?.hidenErrorMsg()
        self?.pointCardNumberTableViewCell?.hidenErrorMsg()
        self?.pointCardPwdTableViewCell?.hidenErrorMsg()
        self?.rgBtcTableViewCell?.hidenErrorMsg()
        self?.amountTableViewCell?.hidenErrorMsg()
        self?.collectionAmountView.errorTipLab.isHidden = true
        self?.pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = true
        self?.delegate?.selectedPaysIndex!(indexPath.row)
      }
      
      // MARK:查看app
      paywaysMainPopView.linkCallbackBlock = {
        let activityVC = ActivityWebViewController.init()
        self.nearNav()?.pushViewController(activityVC, animated: true)
      }
    }
    if indexPath.row == 1 {
      let payWaysSubPopView = ChargePaywayPopView.init(frame: .zero, payways: PaywaysMode.subPaywaysMode)
      payWaysSubPopView.showView()
      
      kindModel = self.viewModel?.curKindModel
      if kindModel?.payTypeList?.count ?? 0 > 0 {
        payWaysSubPopView.paySubTypeSubjectArr.value = (kindModel?.payTypeList)!
      }
      payWaysSubPopView.callbackBlock = { [weak self] (indexPath) in
        if indexPath.row == self?.subwaysLastIndex {
          return
        }
        self?.subwaysLastIndex = indexPath.row
        self?.amountText = ""
        self?.amountTextFiled?.text = ""
        self?.isSelectPointCard = -1
        self?.pointCardTypeTableViewCell?.iua_textField?.text = ""
        self?.pointCardNumberTableViewCell?.hidenErrorMsg()
        self?.pointCardNumberTableViewCell?.hidenErrorMsg()
        self?.pointCardPwdTableViewCell?.hidenErrorMsg()
        self?.rgBtcTableViewCell?.hidenErrorMsg()
        self?.amountTableViewCell?.hidenErrorMsg()
        self?.collectionAmountView.errorTipLab.isHidden = true
        self?.pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = true
        self?.payWaysSubChange(indexPath: indexPath.row)
      }
      
      // MARK:查看app
      payWaysSubPopView.linkCallbackBlock = {
        let activityVC = ActivityWebViewController.init()
        self.nearNav()?.pushViewController(activityVC, animated: true)
      }
    }
    let payType = curTypeModel?.payType ?? ""

    if indexPath.row == 2 && payType == PaySubCode.pointCard.rawValue {
    
        let selectCard = (isSelectPointCard == -1 ? 0 : isSelectPointCard)
        let pointCardList = viewModel?.payPointCardListModel?.pointCardList ?? []
        let selectBankTableView = SelectBankTableView.init(frame: .zero, dataArr: pointCardList , bankDataType: .PointCardType,defaultIndex:selectCard )
        selectBankTableView.showView()
        selectBankTableView.callbackBlock = { [weak self] (indexPath: IndexPath) ->Void in
          print("selectBankTableView.callbackBlock------>indexPath \(indexPath)")
          if self?.isSelectPointCard == indexPath.row {
            return
          }
          self?.isSelectPointCard = indexPath.row
          self?.amountText = ""
          self?.amountTextFiled?.text = ""
          self?.btcFooterView?.toastLab.text = "点卡面值:0元    手续费:0元    实际到账:0元"
          self?.btcFooterView?.tipLimitAmountLab.isHidden = true
          self?.pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = true
          self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payPointCardListModel?.pointCardList?[safe:indexPath.row]?.amountList, isFix:true, payType:payType)
          self?.tableView?.reloadData()
        }
    }
  }
  
  func resignAllFirstResponder() {
    amountTextFiled?.resignFirstResponder()
    manualBtcField?.resignFirstResponder()
    pointCardNumField?.resignFirstResponder()
    pointCardPwdField?.resignFirstResponder()
  }

  @objc func nextAction(){
    
    resignAllFirstResponder()
    let payType = curTypeModel?.payType ?? ""
    var amount = amountTextFiled?.text ?? ""
    
    amount = amount.count > 0 ? amount : amountText
     if payType == PaySubCode.manualBtc.rawValue {
      amount = manualBtcField?.text ?? ""
    }
    orderAmount = amount
    if amount.count < 1{
      if payType == PaySubCode.pointCard.rawValue {
        if isSelectPointCard == -1 {
          pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = false
          return
        }else{
          collectionAmountView.errorTipLab.isHidden = false
        }
      }
      if self.isFix == true {
        collectionAmountView.errorTipLab.isHidden = false
      }else{
        amountTableViewCell?.ic_errorTipLab?.isHidden = false
        amountTableViewCell?.ic_errorTipLab?.text = "存款金额不能为空"
        amountTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
      }
      return
    }
    if amountTableViewCell?.ic_errorTipLab?.isHidden == false {
      return
    }
    
     if payType == PaySubCode.pointCard.rawValue {
      if isSelectPointCard == -1 {
        pointCardTypeTableViewCell?.ic_errorTipLab?.isHidden = false
        return
      }
      let pointCardNum = pointCardNumField?.text ?? ""
      let pointCardPwd = pointCardPwdField?.text ?? ""
      
      if amount.count < 1{
        collectionAmountView.errorTipLab.isHidden = false
        return
      }else if pointCardNum.count < 1 {
        
        pointCardNumberTableViewCell?.ic_errorTipLab?.text = "点卡卡号不能为空"
        pointCardNumberTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
        pointCardNumberTableViewCell?.ic_errorTipLab?.isHidden = false
        return
      }else if pointCardNumberTableViewCell?.ic_errorTipLab?.isHidden == false {
        return
      }
      else if pointCardPwd.count < 1 {
        pointCardPwdTableViewCell?.ic_errorTipLab?.text = "点卡密码不能为空"
        pointCardPwdTableViewCell?.ic_lineView?.backgroundColor = UIColor.line_redColor
        pointCardPwdTableViewCell?.ic_errorTipLab?.isHidden = false
        return
      }
      let pointCardListModel = viewModel?.payPointCardListModel?.pointCardList?[safe:isSelectPointCard]
      let cardCode = pointCardListModel?.cardCode ?? ""
      let payId = viewModel?.payPointCardListModel?.payid ?? ""
      var param = ManagerModel.configLoginNameParamDic()
      param["amount"] = amountText
      param["cardNo"] = pointCardNumField?.text
      param["cardPwd"] = pointCardPwdField?.text
      param["cardCode"] = cardCode
      param["payid"] = payId
      
      viewModel?.requestPointCardPayment(param: param, finishHandleBlock: { [weak self] (paymentOrderModel) in
        if paymentOrderModel.nextType == "1" {
          
          paymentOrderModel.isPointCard = true
          self?.jumpToOrderWebViewCtr(onlineOrderModel: paymentOrderModel)
          
        }else{
          
          paymentOrderModel.isPointCard = true
          paymentOrderModel.payUrl = paymentOrderModel.xurl
          paymentOrderModel.postParam = paymentOrderModel.xparam
          self?.jumpToOrderWebViewCtr(onlineOrderModel: paymentOrderModel)
          //self?.nearNav()?.pushViewController(TransactiontDetailViewController.init(billNo:paymentOrderModel.billNo,isPointCard:true), animated: true)
        }
        
      }, failureHandleBlock: { (error) in
         ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      })
    }
     else if payType == PaySubCode.QQWap.rawValue || payType == PaySubCode.QQScan.rawValue
      || payType == PaySubCode.jdWap.rawValue || payType == PaySubCode.jdScan.rawValue  {
      var payId = ""
      let bankNo = ""
      var tipCode = OrderCode.otherQQScan
      let amount = amountTextFiled?.text ?? ""
      if payType == PaySubCode.jdScan.rawValue {
        payId = viewModel?.payJdScanModel?.payid ?? ""
        tipCode = .otherJdScan
      }else if payType == PaySubCode.jdWap.rawValue {
        payId = viewModel?.payJdChargeModel?.payid ?? ""
        tipCode = .otherJdPay
      }else if payType == PaySubCode.QQScan.rawValue {
        payId = viewModel?.payQQScanModel?.payid ?? ""
        tipCode = .otherQQScan

      }else if payType == PaySubCode.QQWap.rawValue {
        payId = viewModel?.payQQChargeModel?.payid ?? ""
        tipCode = .otherQQPay
      }
      
      let alertModel = ChargeAlerModel.init()
      alertModel.containBankMode = false
      alertModel.amount = amount
      alertModel.tipCode = tipCode
      alertModel.send = self.toSendStr
      alertModel.acount = self.toTheAccountStr
      alertModel.paytype = payType
      
      SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: {[weak self] (selectIndex) in
        if selectIndex == -1 {
          
        }else{
          
          self?.viewModel?.requestCreateOnlineOrder(amount: amount, payid: payId,payType:payType, bankNo:bankNo, finishHandleBlock: { (onlineOrderModel) in
            self?.jumpToOrderWebViewCtr(onlineOrderModel: onlineOrderModel)
          }, failureHandleBlok: { (error) in
            ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)

          })
          
        }
      })
    }
     else if payType == PaySubCode.btcpay.rawValue {
      let payId = viewModel?.payBTCListModel?.payid ?? ""
      let amount = amountTextFiled?.text ?? ""
      
      let tipCode = OrderCode.otherBtc
      let alertModel = ChargeAlerModel.init()
      alertModel.containBankMode = false
      alertModel.amount = amount
      alertModel.tipCode = tipCode
      
      SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: {[weak self] (selectIndex) in
        if selectIndex == -1 {
          
        }else{
          
          self?.viewModel?.requestCreateOnlineOrder(amount: amount, payid: payId, payType:payType, bankNo:"", finishHandleBlock: {[weak self]  (onlineOrderModel) in
          
              self?.jumpToOrderWebViewCtr(onlineOrderModel: onlineOrderModel)
            }, failureHandleBlok: {   (error) in
              ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
          })
        
        }
      })
    }
      
     else if payType == PaySubCode.manualBtc.rawValue {
      let tipCode = OrderCode.otherRgBtc
      let amount = manualBtcField?.text ?? ""
      if amount.count < 1 {
        rgBtcTableViewCell?.showErrorMsg(msg: "比特币不能为空")
        return
      }
      if viewModel?.payQueryBtcRateModel?.btcRate == nil {
        ProgressTopPopView.showPopView(content: "获取比特币的汇率失败", popStyle: .errorMsgToast)
        return
      }
      let btcResultAmount = (Double(amount) ?? 10 ) * (Double( viewModel?.payQueryBtcRateModel?.btcRate ?? "10" ) ?? 10 )
      let decBtcAmount =  String.init(format: "%.2f元", btcResultAmount)
      let alertModel = ChargeAlerModel.init()
      alertModel.containBankMode = false
      alertModel.amount = amount
      alertModel.tipCode = tipCode
      alertModel.tipName = "人民币 " + decBtcAmount
      SureChargeAlertView.showPopView(chargeAlertModel: alertModel, sureBlock: {[weak self] (selectIndex) in
        if selectIndex == -1 {
          
        }else{
          self?.viewModel?.payQueryBtcRateModel?.inputAmount = amount
          self?.viewModel?.payQueryBtcRateModel?.rmbAmount = "人民币 " + decBtcAmount
          let manualBtcOrderVC = ManualBtcOrderViewController.init(btcRateModel: self?.viewModel?.payQueryBtcRateModel);
          self?.nearNav()?.pushViewController(manualBtcOrderVC, animated: true)
        }
      })
    }
  }
  
  
  func checkCurPayTypeModel(){
    
    if curTypeModel != nil  {
      return
    }
    let payTypeModel = self.viewModel?.curKindModel?.payTypeList?[safe:0]
    curTypeModel = payTypeModel
  }
  
  
  func payWaysSubChange(indexPath:Int){
    
    self.tableView?.tableFooterView = normalFooterView

    let kindCode = self.viewModel?.curKindModel?.payKindCode ?? ""
    let payTypeModel = self.viewModel?.curKindModel?.payTypeList?[safe:indexPath]
    let payType = payTypeModel?.payType ?? ""
    let payTypeName = payTypeModel?.payTypeName ?? ""
    curTypeModel = payTypeModel
    viewModel?.collectionAmountView = collectionAmountView
    if payType == PaySubCode.pointCard.rawValue  {
        viewModel?.requestQueryPointCardList(finishHandleBlock: { [weak self] (pointCardModel) in
        self?.btcFooterView?.toastLab.text = "点卡面值:0元    手续费:0元    实际到账:0元"
        self?.btcFooterView?.tipLimitAmountLab.isHidden = true
        self?.tableView?.tableFooterView = self?.btcFooterView
        self?.tableView?.reloadData()
      }, failureHandleBlok: { (error) in
        ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      })

    }
    else if payType == PaySubCode.QQWap.rawValue || payType == PaySubCode.QQScan.rawValue
      || payType == PaySubCode.jdWap.rawValue || payType == PaySubCode.jdScan.rawValue || payType == PaySubCode.btcpay.rawValue {
      viewModel?.requestQueryOnlineBanksList(payType: payType, paykindCode: kindCode, subTypeName: payTypeName, finishHandleBlock: {[weak self]  (isSuccess) in
        if isSuccess {
          if payType == PaySubCode.jdScan.rawValue {
            self?.isFix = self?.viewModel?.payJdScanModel?.amountType?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payJdScanModel?.amountType?.amounts, isFix: self?.isFix, payType:payType)
          }else if payType == PaySubCode.jdWap.rawValue {
            self?.isFix = self?.viewModel?.payJdChargeModel?.amountType?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payJdChargeModel?.amountType?.amounts, isFix: self?.isFix, payType:payType)
          }
          else if payType == PaySubCode.QQScan.rawValue {
            self?.isFix = self?.viewModel?.payQQScanModel?.amountType?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payQQScanModel?.amountType?.amounts, isFix: self?.isFix, payType:payType)
          }else if payType == PaySubCode.QQWap.rawValue {
            self?.isFix = self?.viewModel?.payQQChargeModel?.amountType?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payQQChargeModel?.amountType?.amounts, isFix: self?.isFix, payType:payType)
          }else if payType == PaySubCode.btcpay.rawValue {
            self?.isFix = self?.viewModel?.payBTCListModel?.amountType?.fix ?? false
            self?.viewModel?.showDepositAmounts(amountArr: self?.viewModel?.payBTCListModel?.amountType?.amounts, isFix: self?.isFix, payType:payType)
          }
          self?.tableView?.reloadData()
          
        }
      })
    }else if payType == PaySubCode.manualBtc.rawValue  {
      
      viewModel?.requestQueryBtcRateAndAddress(finishHandleBlock: { (queryBtcRateModel) in
        
      }, failureHandleBlok: { (error) in
        ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      })
      
      btcFooterView?.toastLab.text = "=     人民币(RMB)"
      btcFooterView?.tipLimitAmountLab.isHidden = false
      self.tableView?.tableFooterView = btcFooterView
    }
  
    self.tableView?.reloadData()
  }
  
  
  private func jumpToOrderWebViewCtr(onlineOrderModel:PayOnlineOrderModel){
    
    let orderWebVC = OrderWebViewController.init(url: onlineOrderModel.payUrl ?? "",postParam:onlineOrderModel.postParam)
    self.nearNav()?.pushViewController(orderWebVC, animated: true)
    
    onlineOrderModel.amount =  onlineOrderModel.amount ?? orderAmount
    onlineOrderModel.createDate = ManagerModel.getNowDateFormatStr()
    orderWebVC.dismissSubject.subscribe(onNext: {[weak self ] (newValue:Int) in
      ChargeQueryOrderPopView.showPopView(tapBtnBlock: { (tapState) in
        
        self?.collectionAmountView.selectIndex = -1
        self?.collectionAmountView.collectionView.reloadData()
        
        if tapState == TapState.sure {
          let transacDetailVC = TransactiontDetailViewController()
          onlineOrderModel.transaType = .deposit
          onlineOrderModel.title =  self?.curTypeModel?.payTypeName
          transacDetailVC.transacDetailModel = onlineOrderModel
          self?.nearNav()?.pushViewController(transacDetailVC, animated: true)
        }else if tapState == TapState.cancel {
          let customerOnlineVC = CustomerOnlineHtmlViewController()
          self?.nearNav()?.pushViewController(customerOnlineVC, animated: true)
        }
      })
    },onError: { (error) in
      print("\(error)")
    }).disposed(by: self.disposeBag)
  }
}

class BtcFooterView: UIView {
  
  var toastLab:UILabel!
  var tipLimitAmountLab:UILabel!
  var nextBtn:UIButton!
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    self.frame = CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 200)
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func setupView(){
    let  btcToastView = UIView.init(frame: CGRect.init(x: 15, y: 10, width: SCREEN_WIDTH-30, height: 50))
    self.addSubview(btcToastView)
    btcToastView.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
    btcToastView.layer.cornerRadius = 6
    btcToastView.layer.borderColor = UIColor.init(colorValue: 0x515C5F).cgColor
    btcToastView.layer.borderWidth = 1.0
    toastLab = UILabel.init(frame: btcToastView.bounds)
    btcToastView.addSubview(toastLab)
    toastLab.textColor = UIColor.white
    toastLab.font = UIFont.M_Font
    toastLab.textAlignment = .center
    toastLab.text = "=     人民币(RMB)"
    tipLimitAmountLab = UILabel.init(frame: CGRect.init(x: 0, y: btcToastView.newBottom+15, width: SCREEN_WIDTH, height: 20))
    self.addSubview(tipLimitAmountLab)
    tipLimitAmountLab.text = "单笔存款限0.01-30个比特币"
    tipLimitAmountLab.textColor = UIColor.font_lightBlackWhiteColor
    tipLimitAmountLab.font = UIFont.M_Font
    tipLimitAmountLab.textAlignment = .center
    nextBtn = UIButton.init(frame: .zero)
    self.addSubview(nextBtn)
    nextBtn.backgroundColor = UIColor.btn_rightRed
    nextBtn.setTitle("下一步", for: .normal)
    nextBtn.layer.cornerRadius = 5.0
    nextBtn.setTitleColor(UIColor.view_white, for: .normal)
    nextBtn.titleLabel?.font = UIFont.PFML_Font
    nextBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(0-View_Margin)
      make.bottom.equalToSuperview().offset(-20)
      make.height.equalTo(54)
    }
  }
}
