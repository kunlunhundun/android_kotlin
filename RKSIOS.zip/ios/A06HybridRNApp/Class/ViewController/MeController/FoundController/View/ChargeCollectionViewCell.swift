//
//  ChargeCollectionViewCell.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/9.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ChargeCollectionViewCell: UIView,UICollectionViewDelegate,UICollectionViewDataSource {

  var collectionView:UICollectionView!
  var titleLab:UILabel!
  var errorTipLab:UILabel!
  var colletionHeight:CGFloat = 95

  let disposeBag = DisposeBag()
  var seletedAmountSubject = PublishSubject<String>()

  var selectIndex = -1
  var isRealNameCollect:Bool = false
  var dataArr:[Any] =  ["50","100","500"]
  
  convenience init(frame: CGRect,isRealName:Bool = false) {
     self.init(frame: frame)
     isRealNameCollect = isRealName
     setupColloctionCellView()
  }
  
  func setupColloctionCellView(){
    
    titleLab = UILabel.init(frame: .zero)
    titleLab.text = "选择充值面值"
    titleLab.font = UIFont.M_Font
    titleLab.textColor = UIColor.view_white
    self.addSubview(titleLab)
    titleLab.snp.makeConstraints { (make) in
      make.right.top.equalTo(self)
      make.left.equalTo(self).offset(View_Margin)
      make.height.equalTo(0)
    }
    
    let collectBottomMargn:CGFloat =  isRealNameCollect ? 0.0 : 15.0
    let collectMarginW:CGFloat =  15.0
    
    let bottomNum = NSNumber.init(value: Int(collectBottomMargn))
    let layout:EqualSpaceFlowLayout! = EqualSpaceFlowLayout.init(wthType: AlignType.withLeft, itemSpace: nil, leftRightSpace: nil, topBottomSpace: bottomNum)
    layout.minimumInteritemSpacing = collectMarginW
    layout.minimumLineSpacing = 15;
    // layout.sectionInset = UIEdgeInsetsMake(collectMarginW, collectMarginW, collectMarginW, collectMarginW)
    layout.sectionInset = UIEdgeInsetsMake(collectBottomMargn, 15, 15, collectBottomMargn);

    collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: layout)
    self.addSubview(collectionView)
    collectionView.snp.makeConstraints { (make) in
      make.top.equalTo(titleLab.snp.bottom)
      make.left.right.equalTo(self)
      make.bottom.equalToSuperview().offset( (isRealNameCollect ? 0 : -20))
    }
    
    errorTipLab = UILabel.init(color: UIColor.font_errorRedColor, font: UIFont.M_Font)
    self.addSubview(errorTipLab!)
    errorTipLab.text = "请选择充值金额"
    errorTipLab!.isHidden = true
    errorTipLab!.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalTo(self.snp.right)
      make.bottom.equalTo(self.snp.bottom)
      make.height.equalTo(15)
    }
    
    collectionView.delegate = self
    collectionView.dataSource = self
    collectionView.isScrollEnabled = false
    collectionView.backgroundColor = UIColor.clear
    collectionView.register(ContentCollectionViewCell.self, forCellWithReuseIdentifier: "ContentCollectionViewCell")
  }
  
  func cancelSelectedIndexHighlight(){
    selectIndex = -1
    collectionView.reloadData()
  }
  
  func realoadData(amountArr:[Any]?, isShowTitle:Bool, payType:String){
    if isShowTitle {
      self.titleLab.snp.remakeConstraints { (make) in
        make.top.equalTo(self).offset(10)
        make.left.equalTo(View_Margin)
        make.height.equalTo(25)
      }
    }else{
      self.titleLab.snp.remakeConstraints({ (make) in
        make.height.equalTo(0)
        make.right.left.top.equalTo(self)
      })
    }
    dataArr = amountArr ?? []
    
    // 判断出第一个大于99的然后选中他
    let haveActivity:Bool = ManagerModel.instanse.activityShow
    if dataArr.count > 0 {
      if (payType.isEqual("15" as String) == true || payType.isEqual("16" as String) == true) && haveActivity == true{
        for (index,value) in dataArr.enumerated() {
          
          // NSNumber
          if (value is NSNumber) {
              let str = value as! NSNumber
              if NSInteger(truncating: str) >= 99 {
                selectIndex = index
                let time: TimeInterval = 0.3
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
                  let content = self.dataArr[safe:self.selectIndex]
                  let contentStr = "\(content ?? "" )"
                  self.seletedAmountSubject.onNext(contentStr)
                  self.collectionView.reloadData()
                }
                break
              }
          }
          
        
          // String
          if (value is String) {
            let str = value as! String
            if NSInteger(str) ?? 0 >= 99 {
              selectIndex = index
              let time: TimeInterval = 0.3
              DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
                let content = self.dataArr[safe:self.selectIndex]
                let contentStr = "\(content ?? "" )"
                self.seletedAmountSubject.onNext(contentStr)
                self.collectionView.reloadData()
              }
              break
            }
          }
          

        }
      }else{
        selectIndex = -1
        self.collectionView.reloadData()
      }
    }
    
    let collectBottomMargn:CGFloat = isRealNameCollect ? 0.0 : 15.0

    self.layoutIfNeeded()
    let height =  self.collectionView.contentSize.height
    let allHeight = (isShowTitle ? 30  : 0) + height + collectBottomMargn
    
    self.colletionHeight = allHeight
    
    self.frame = CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: allHeight)
   
    collectionView.snp.makeConstraints { (make) in
      make.top.equalTo(titleLab.snp.bottom)
      make.left.right.bottom.equalTo(self)
    }
     print("showDepositAmounts-------->\(height)")
  }

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    if isRealNameCollect {
      return dataArr.count > 2 ? 2 : dataArr.count
    }
    return dataArr.count
  }
  
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
    let collectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ContentCollectionViewCell", for: indexPath) as!  ContentCollectionViewCell
  
    let content = dataArr[safe:indexPath.row]
    let contentStr = "\(content ?? "" )"
    collectCell.contentLab.text = contentStr
    
    collectCell.contentLab.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
    if indexPath.row == selectIndex {
      collectCell.contentLab.backgroundColor = UIColor.view_yellowColor
    }
    return collectCell
  }
  
   func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
    let width:CGFloat = 57;
    return CGSize.init(width: width, height: width)
  }
 
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    errorTipLab.isHidden = true
    let content = dataArr[safe:indexPath.row]
    let contentStr = "\(content ?? "" )"
    seletedAmountSubject.onNext(contentStr)
    selectIndex = indexPath.row
    collectionView.reloadData()
  }
}

class ContentCollectionViewCell: UICollectionViewCell {
  
  public var contentLab : UILabel!
  
  override init(frame: CGRect) {
    super.init(frame: frame);
    
    contentLab = UILabel.init(frame: .zero)
    contentView.addSubview(contentLab)
    contentLab.text = "100"
    contentView.addSubview(contentLab)
    contentLab.textColor = UIColor.view_white
    contentLab.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
    contentLab.font = UIFont.M_Font
    contentLab.clipsToBounds = true
    contentLab.textAlignment = .center
    contentLab.layer.cornerRadius = 5.0
    contentLab.snp.makeConstraints { (make) in
      make.edges.equalTo(self)
    }
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}




