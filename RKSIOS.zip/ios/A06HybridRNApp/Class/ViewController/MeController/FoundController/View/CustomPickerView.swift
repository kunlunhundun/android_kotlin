//
//  CustomPickerView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 02/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

let kScale  = UIScreen.main.bounds.size.width / 375
let hScale = UIScreen.main.bounds.size.height / 667

public enum PickerViewType:Int {
  case dateType = 0
  case oneTitle = 1
}


// 顶部菜单view
fileprivate class PickerViewTopMenuView: UIView {
  
  
  let cancelButton = UIButton()
  let sureButton = UIButton()
  let bottomLineView = UIView()
  override init(frame: CGRect) {
    super.init(frame: frame)
    
    initUIProperty()
    initLayoutSubview()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  
  private func initUIProperty()  {
    
    cancelButton.setTitle("取消", for: .normal)
    cancelButton.setTitleColor(UIColor.init(colorValue: 0x333333), for: .normal)
    cancelButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 15)
    self.addSubview(cancelButton)
    
    sureButton.setTitle("确定", for: .normal)
    sureButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 15)
    sureButton.setTitleColor(UIColor.init(colorValue: 0x333333), for: .normal)
    self.addSubview(sureButton)
    
    bottomLineView.backgroundColor = UIColor.init(colorValue: 0xDADADA)
    self.addSubview(bottomLineView)
    
  }
  
  private func initLayoutSubview(){
    
    cancelButton.snp.makeConstraints { (make) in
      make.top.bottom.equalToSuperview()
      make.left.equalToSuperview()
      make.width.equalTo(60)
    }
    
    sureButton.snp.makeConstraints { (make) in
      make.top.bottom.equalToSuperview()
      make.right.equalToSuperview()
      make.width.equalTo(60)
    }
    
    bottomLineView.snp.makeConstraints { (make) in
      make.bottom.equalToSuperview()
      make.right.left.equalToSuperview()
      make.height.equalTo(0.5)
    }
  }
  
}


class CustomPickerView: UIView,UIPickerViewDelegate,UIPickerViewDataSource {

  public static var customPickerView:CustomPickerView?

  var backgroundView:UIView!
  var pickerViewType:PickerViewType!
  var datePickerView:UIDatePicker?
  var pickerView:UIPickerView?
  var dataArr:[String]?
  var selectedIndex:Int = -1
  var selectedHandleBlock:((_ selectIndex:Int?,_ selectedDate:Date?)->Void)?
  var customMaskView:UIView?
  
  fileprivate var topMenuView:PickerViewTopMenuView!

  convenience init(frame: CGRect, pickerType:PickerViewType) {
    self.init(frame: frame)
    
    self.frame = CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT)
    self.backgroundColor = UIColor.clear
    
    customMaskView = UIView.init(frame: UIScreen.main.bounds)
    self.addSubview(customMaskView!)
    
    backgroundView = UIView.init(frame: CGRect.init(x: 0, y: SCREEN_HEIGHT, width: SCREEN_WIDTH, height: 260*hScale))
    backgroundView.backgroundColor = UIColor.view_white
    self.addSubview(backgroundView)
    topMenuView = PickerViewTopMenuView()
    backgroundView.addSubview(topMenuView)
    topMenuView.snp.makeConstraints { (make) in
      make.left.right.top.equalToSuperview()
      make.height.equalTo(45)
    }
    topMenuView.sureButton.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    topMenuView.cancelButton.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)

    pickerViewType = pickerType
    if (pickerType == .dateType){
      datePickerView = UIDatePicker()
      datePickerView?.backgroundColor = UIColor.view_white
      backgroundView.addSubview(datePickerView!)
      datePickerView?.snp.makeConstraints({ (make) in
        make.top.equalTo(topMenuView.snp.bottom)
        make.bottom.equalTo(backgroundView.snp.bottom)
        make.left.right.equalToSuperview()
      })
      let formatter = ManagerModel.configDateFormatter()
      
      formatter.dateFormat = "yyyy年MM月dd日00分"
      datePickerView?.minimumDate = formatter.date(from: "1900年01月01日00分")
      datePickerView?.locale =  Locale.init(identifier: "zh")
      datePickerView?.datePickerMode = UIDatePickerMode.dateAndTime
      let curDateStr = formatter.string(from: Date.init())
      let curDate = formatter.date(from: curDateStr) ?? Date.init()
      datePickerView?.setDate(curDate, animated: true)
      
    }else{
      
      pickerView = UIPickerView.init()
      pickerView?.backgroundColor = UIColor.view_white
      pickerView?.selectRow(2, inComponent: 0, animated: true)
      backgroundView.addSubview(pickerView!)
      pickerView?.snp.makeConstraints({ (make) in
        make.top.equalTo(topMenuView.snp.bottom)
        make.bottom.equalTo(backgroundView.snp.bottom)
        make.left.right.equalToSuperview()
      })
      pickerView?.delegate = self
      pickerView?.dataSource = self
    }
    
  }
  
  
  @objc func sureAction(){
    
    var selectIndex = -1
    var date:Date?
    if pickerViewType == .dateType {
      date = datePickerView?.date
      
    }else if pickerViewType == .oneTitle {
      selectIndex = pickerView?.selectedRow(inComponent: 0) ?? -1
    }
    selectedHandleBlock?(selectIndex,date)
    hideAnimation()
  }
  
  @objc func cancelAction(){
    
    selectedHandleBlock?(-1,nil)
    hideAnimation()
  }
  
  func showAnimation(){
    UIApplication.shared.delegate?.window??.addSubview(self)
    UIView.animate(withDuration: 0.5) {
      self.customMaskView?.addSubview(self.backgroundView)
      var frame = self.backgroundView.frame
      frame.origin.y = SCREEN_HEIGHT-260*hScale
      self.backgroundView.frame = frame
    }
  }
  
  func hideAnimation(){

    UIView.animate(withDuration: 0.5, animations: {
      var frame = self.backgroundView.frame
      frame.origin.y = SCREEN_HEIGHT
      self.backgroundView.frame = frame
    }) { (finished) in
      self.backgroundView.removeFromSuperview()
      self.removeFromSuperview()
    }
  }
  
  class func showView(pickerType:PickerViewType, pickerDataArr:[String], sureHandleBlock:@escaping(_ selectIndex:Int?,_ selectedDate:Date?)->Void ){
    
    customPickerView = CustomPickerView(frame: .zero, pickerType: pickerType)
    if pickerType == .oneTitle {
      customPickerView?.dataArr = pickerDataArr
      customPickerView?.pickerView?.reloadAllComponents()
    }
    customPickerView?.selectedHandleBlock = sureHandleBlock
    customPickerView?.showAnimation()
    
  }
  
  //设置选择框的总列数,继承于UIPickViewDataSource协议
  func numberOfComponents(in pickerView: UIPickerView) -> Int {
    if pickerViewType == .dateType {
      return 1
    }
    return 1
  }
  //设置选择框的总行数,继承于UIPickViewDataSource协议
  func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    //总行数设置为数据源的总长度
  
    return dataArr?.count ?? 0
  }
  
  func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
    
    for  singleLine in pickerView.subviews {
      if singleLine.frame.size.height < 2 {
        singleLine.backgroundColor = UIColor.line_lightBlack
      }
    }
    let label = UILabel.init()
    label.textAlignment = .center
    label.font = UIFont.XL_Font
    label.text = self.pickerView(pickerView, titleForRow: row, forComponent: component)
    return label
    
  }
  //设置选项框各选项的内容,继承于UIPickViewDelegate协议
  func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
  
    let title = dataArr?[safe:row]
    return title ?? ""
  }
  
  //选择控件的事件选择
  func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
    
//    if(component == 0){
//      pickerView.reloadComponent(1)
//      pickerView.selectRow(0, inComponent: 1, animated: true)
//    }
    
  }
  //设置每行选项的高度
  func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
    
    return 45.0
    
  }
 

  
  

}
