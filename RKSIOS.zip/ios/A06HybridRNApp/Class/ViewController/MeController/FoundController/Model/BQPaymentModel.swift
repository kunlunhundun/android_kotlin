//
//  BQPaymentModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 28/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON


public enum OrderPayWays:Int {
   case alipay = 0
   case wxpay = 1
   case bankBQPay = 2
   case manualBankPay = 3
}

class BQPaymentModel: TransactionDetailModel {

  var accountName:String?
 // var accountNo:String?
 // var amount:String?
  var bankBranchName:String?
  var bankCity:String?
  var bankCode:String?
//  var bankName:String?
 // var billNo:String?
  var postscript:String?
  var payLimitTime:String?

  
  
  var realName:String?
  var bankIcon:String?
  var payWayCode:OrderPayWays?
  var depositorType:String?
  var depositorId:String?
  
  var bankCardId:String?
  var province:String?

  /*
  var bankCode:String?
  var bankName:String?
  var bankIcon:String?
  var bankNo:String?
  
  //手工银行的
  var accountName:String?
  var accountNo:String?
  var bankBranchName:String?
  var bankCardId:String?
  var city:String?
  var province:String? */
  
  
  required init() {
    
  }
  
}
