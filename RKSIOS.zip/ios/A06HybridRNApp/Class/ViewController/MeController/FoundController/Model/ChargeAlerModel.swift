//
//  ChargeAlerModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/12.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

public enum OrderCode:Int {
  case aliBQCode = 0
  case aliScanCode = 1
  case aliWapCode = 2
  case wxBQCode = 3
  case wxScanCode = 4
  case wxWapCode = 5
  case bkBQCode = 6
  case bkRGCode = 7
  case bkNetOnlineCode = 8
  case bkNetKJCode = 9
  case otherQQScan = 10
  case otherQQPay = 11
  case otherJdScan = 12
  case otherJdPay = 13
  case otherRgBtc = 14
  case otherBtc = 15
  case defaultPayCode
}

class ChargeAlerModel: HandyJSON {

  var containBankMode:Bool = false
  var bankList:[AnyObject]?
  var isManualBank:Bool = false
  var realName:String?
  var amount:String?
  var tipCode:OrderCode = .defaultPayCode
  var tipName:String = ""
  var send:String = ""
  var acount:String = ""
  var paytype:String = ""

  required init() {}
}
