//
//  PointCardPaymentModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 12/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class TransactionDetailModel: HandyJSON {

  var accountNo:String?
  var amount:String?
  var bankName:String?
  var rate:String?
  var beginDate:String?
  var betAmount:String?
  var createDate:String?
  var endDate:String?
  var auditDate:String?
  var updateDate:String?
  var flag:String?
  var flagDesc:String?
  var intergral:String?
  var intergralCash:String?
  var itemIcon:String?
  var loginName:String?
  var platformId:String?
  var platformName:String?
  var referenceId:String?
  var requestId:String?
  var billNo:String?
  var remindFlag:String?
  var title:String?
  var titleName:String?
  var typeName:String?
  var type:String?
  var typeIntegral:String?
  var transCode:String?
  var transaType:FundRecordType?
  
  required init() {
    
  }
}
