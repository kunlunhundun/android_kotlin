//
//  PayWaysModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON



class PayWaysModel: HandyJSON {

  var payList:[PayKindModel]?
  var blackFlag:String?
  var bindBankCard:String?
  var bindMobile:String?

  required init() {
  }
}


class PayKindModel: HandyJSON {
  
  var payKind:String?
  var payKindName:String?
  var payKindIcon:String?
  var payKindCode:String?
  var payTypeList:[PayTypeModel]?
  
  required init() {
  }
}

class PayTypeModel: HandyJSON {
  
  var payType:String?
  var payTypeIcon:String?
  var payTypeName:String?

  required init() {
  }
}


class DomainListModel:HandyJSON {
  
  var domainList:[String]?
  
  required init() {
    
  }
}

