//
//  QueryBtcRateModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 14/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class QueryBtcRateModel: HandyJSON {
  
  
  var accountId:String?
  var amount:String?
  var btcAddress:String?
  var btcAmount:String?
  var btcCurrency:String?
  var btcRate:String?
  var btcUuid:String?
  var currency:String?
  var payid:String?
  
  
  var inputAmount:String?
  var rmbAmount:String?
  
  required init() {
    
  }

}
