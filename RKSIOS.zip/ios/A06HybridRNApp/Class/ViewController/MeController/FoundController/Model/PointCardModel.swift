//
//  PointCardModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 12/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class PointCardListModel: HandyJSON {
  
  var amountList:[Int]?
  var cardCode:String?
  var fee:String?
  var id:String?
  var name:String?
  
  required init() {
    
  }
  
}


class PointCardModel: HandyJSON {
  
  var cardNum:String?
  var channelCode:String?
  var payid:String?
  var pointCardList:[PointCardListModel]?
  
  
  required init() {
    
  }
  

}
