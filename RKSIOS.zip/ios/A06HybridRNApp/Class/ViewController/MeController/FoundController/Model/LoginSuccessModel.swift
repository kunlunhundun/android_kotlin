//
//  LoginSuccessModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/16.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class LoginSuccessModel:HandyJSON  {

  var password: String?
  var token: String?
  var loginName: String?
  var mobileNo: String?
  var customerId: String?
  var starLevel: String?
  var realName: String?
  var customerType: String?
  var avatar: String?
  var starLevelName: String?
  var webToken: String?
  

  var registDate:String? // 注册日期
  var verifyCode:String? // 预留信息
  var bankCardNum:Int?  // 银行卡张数
  var emailBind:Int? // 是否绑定邮箱
  var cashCredit:String?  // 本地现金额度
  var gender:String? // 性别
  var mobileNoBind:Int? // 是否绑定手机号
  var btcNum:Int?      // 比特币卡
  var address:String? //地址
  var gameCredit:Float? // 本地游戏额度
  var birthday:String?
  

  required init() { }
  
}


class LetterMsgModel:HandyJSON  {
  
  var body:String?
  
//  var data: [Any]?
//  var pageNo: String?
//  var pageSize: String?
//  var totalPage: String?
//  var totalRow: String?
 
  
  required init() { }
  
}
