//
//  PayOnlineOrderModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 27/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class PayOnlineOrderModel:TransactionDetailModel  {

//  var amount:String?
  var billDate:String?
  var paycode:String?
  var url:String?
  var payUrl:String?
  var name:String?
  
  //pointcard
  var xparam:String?
  var xurl:String?
  
  var domainList:[String]?
  
  var nextType:String?
  var postParam:String?
  var isPointCard:Bool?  //是否是点卡支付
  

  
  

  required init() {
    
  }
  
}
