//
//  PayBankListModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class PayBankListModel: HandyJSON {

  var bankList:[BankListModel]?
  var maxAmount:String?
  var minAmount:String?
  var payid:String?
  var amountType:AmountTypeModel?
  var optDepositAmounts:[Any]?
  
  
  var fix:Bool?
  var amounts:[Any]?
  var depositorList:[DepositorListModel]?
  var bankCards:[BankListModel]?
  
  var errorCode:String?
  var qrcodeName:String?
  var qrcodeType:String?
  var payType:String?

  

  required init() {
    
  }
  
}

class AmountTypeModel:HandyJSON{
  
  var fix:Bool?
  var amounts:[AnyObject]?
  
  required init() {
    
  }
}


class BankListModel:HandyJSON{
  
  var bankCode:String?
  var bankName:String?
  var bankIcon:String?
  var bankNo:String?
  
  //手工银行的
  var accountName:String?
  var accountNo:String?
  var bankBranchName:String?
  var bankCardId:String?
  var city:String?
  var province:String?
  
  
  required init() {
    
  }
}


class DepositorListModel:HandyJSON{
  
  var depositor:String?
  var id:String?
  
  required init() {
    
  }
  
}
