//
//  ChargeViewModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift
import Alamofire


public enum PaySubCode:String {

  case manualBank    = "0"   //手工存款
  case netBankOnline = "1"   //网银在线
  case pointCard     = "2"   //点卡支付
  case bqAliPay      = "92"
  case bqWxPay       = "91"
  case bqBankPay     = "90"
  case alipayScan    = "5"   //支付宝扫码
  case wxpayScan     = "6"   //微信扫码
  case QQScan        = "7"   //QQ 扫码
  case wxpayWap      = "8"   //微信wap
  case alipayWap     = "9"   //支付宝wap
  case QQWap         = "11"
  case unionpayScan  = "15"  //银联扫码
  case jdScan        = "16"  //京东扫码
  case jdWap         = "17"  //京东wap
  case netBankPC     = "18"  //网银快捷pc
  case netBankMOB    = "19"  //网银快捷MOB
  case btcpay        = "20"  //比特币
  case unionpayWap   = "21"  //银联wap
  case manualBtc     = "98"  //手工比特币
  // case BQPay = "3"        //bq支付
}

class ChargeViewModel: NSObject {

  var payAlipayWapBankListModel:PayBankListModel?       //阿里扫码
  var payBQAliBankListModel:PayBankListModel?           //阿里BQ
  var payAlipayScanModel:PayBankListModel?              //阿里扫码
  var payWXpayWapBankListModel:PayBankListModel?        //微信wap
  var payWXpayScanModel:PayBankListModel?               //微信扫码
  var payBQWXBankListModel:PayBankListModel?            //微信BQ
  var payBKPayScanModel:PayBankListModel?               //银联扫码
  var payBKPayNetOnlineModel:PayBankListModel?          //网银在线支付
  var payBKPayNetPCModel:PayBankListModel?              //网银快捷支付pc
  var payBKPayNetMOBModel:PayBankListModel?             //网银快捷支付MOB
  var payManualBanksModel:PayBankListModel?             //手工存款
  var payBQBankListModel:PayBankListModel?              //银行卡BQ存款
  var payPointCardListModel:PointCardModel?             //点卡列表
  var payQQScanModel:PayBankListModel?                  //qq扫码
  var payQQChargeModel:PayBankListModel?                //qq支付
  var payJdScanModel:PayBankListModel?                  //京东扫码
  var payJdChargeModel:PayBankListModel?                //京东支付
  var payBTCListModel:PayBankListModel?                 //比特币支付
  var payQueryBtcRateModel:QueryBtcRateModel?           //比特币查询汇率和地址
  
  var payBQAliLimitAmount:PayBankListModel?
  var payBQWxLimitAmount:PayBankListModel?
  var payBQBankLimitAmount:PayBankListModel?

  var payManualBankLimitAmount:PayBankListModel?
  var collectionAmountView:ChargeCollectionViewCell?
  
  var registeResult: Observable<AnyObject>?
  let queryPayWaysSubject = PublishSubject<PayWaysModel>()
  var curKindModel:PayKindModel?
  
  var chargeView:UIView?
  
  override init() {
    super.init()
  }
  
  func initData(){
    
  }
  
  func kindNameTypeNameMapDesignName(payWaysModel:PayWaysModel){
    
    guard let payKindList = payWaysModel.payList else {
      return
    }
    for kindModel in payKindList {
       let payKindCode = kindModel.payKindCode ?? ""
      if  payKindCode.contains("ALIPAY")  {
        kindModel.payKindName = "支付宝存款"
        guard let payTypeList =  kindModel.payTypeList else {
          break
        }
        for typeModel in payTypeList {
          let payType = typeModel.payType
          if payType == PaySubCode.alipayWap.rawValue {
            typeModel.payTypeName = "支付宝支付"
          }else if payType == PaySubCode.alipayScan.rawValue {
            typeModel.payTypeName = "支付宝扫码"
          }else {
            typeModel.payTypeName = "支付宝转银行卡"
          }
        }
      }else if payKindCode.contains("WXAPY"){
        kindModel.payKindName = "微信存款"
        guard let payTypeList =  kindModel.payTypeList else {
          break
        }
        for typeModel in payTypeList {
          let payType = typeModel.payType
          if payType == PaySubCode.wxpayWap.rawValue {
            typeModel.payTypeName = "微信支付"
          }else if payType == PaySubCode.wxpayScan.rawValue {
            typeModel.payTypeName = "微信扫码"
          }else {
            typeModel.payTypeName = "微信转银行卡"
          }
        }
      }else if payKindCode.contains("BANKPAY"){
        kindModel.payKindName = "银行卡存款"
        guard let payTypeList =  kindModel.payTypeList else {
          break
        }
        for typeModel in payTypeList {
          let payType = typeModel.payType
        }
        
      }else if payKindCode.contains("OKPAY"){
        kindModel.payKindName = "其他存款"
      }
    }
  }
  
  
  func queryPayWaysV3(){
    
    let param = ManagerModel.configLoginNameParamDic()
    APITool.request(.queryPayWaysV3, parameters: param, successHandle: { [weak self] (payWaysModel : PayWaysModel) in
      //self?.kindNameTypeNameMapDesignName(payWaysModel: payWaysModel)
      self?.queryPayWaysSubject.onNext(payWaysModel)
      print("payWaysModel---->\(payWaysModel)")
    }) { [weak self] (apiError) in
      let error = apiError ?? APIError()
      self?.queryPayWaysSubject.onError(error)
    }
  }
  

  func requestQueryOnlineBanksList(payType:String , paykindCode:String, subTypeName:String, realName:String = "", finishHandleBlock:@escaping (_ isSuccess:Bool )->()) {
    
    LoadingView.showLoadingViewWith(to: chargeView)
    
    if paykindCode.contains("ALIPAY"){
      if payType == PaySubCode.alipayWap.rawValue {
        if payAlipayWapBankListModel != nil {
          LoadingView.hideLoadingView(for: self.chargeView)
          finishHandleBlock(true)
          return
        }
      }
      else if payType == PaySubCode.alipayScan.rawValue {
        if payAlipayScanModel != nil {
          LoadingView.hideLoadingView(for: self.chargeView)
          finishHandleBlock(true)
        }
      }
    }else if paykindCode.contains("WXAPY"){
      if payType == PaySubCode.wxpayWap.rawValue{
        if payWXpayWapBankListModel != nil {
          LoadingView.hideLoadingView(for: self.chargeView)

          finishHandleBlock(true)
          return
        }
      }
      else if payType == PaySubCode.wxpayScan.rawValue {
        if payWXpayScanModel != nil {
          LoadingView.hideLoadingView(for: self.chargeView)

          finishHandleBlock(true)
        }
      }
    }else if paykindCode.contains("BANKPAY"){
      if payType == PaySubCode.unionpayScan.rawValue {
        if  payBKPayScanModel != nil {
          LoadingView.hideLoadingView(for: self.chargeView)
           finishHandleBlock(true)
        }
      }
   }
    var param = ManagerModel.configLoginNameParamDic()
    param["payType"] = payType
    param["depositor"] = realName

    APITool.request(.queryOnlineBanks, parameters: param, successHandle: { [weak self] (paybankListModel : PayBankListModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)

      if paykindCode.contains("ALIPAY"){
        if payType == PaySubCode.alipayWap.rawValue {
          self?.payAlipayWapBankListModel = paybankListModel
        }else{
          self?.payAlipayScanModel = paybankListModel
        }
      }else if paykindCode.contains("WXAPY"){
          if payType == PaySubCode.wxpayWap.rawValue  {
              self?.payWXpayWapBankListModel = paybankListModel
            }
          else if payType == PaySubCode.wxpayScan.rawValue{
            self?.payWXpayScanModel = paybankListModel
          }
        }
      else if paykindCode.contains("BANKPAY"){
        if payType == PaySubCode.netBankOnline.rawValue {
          self?.payBKPayNetOnlineModel = paybankListModel
        }else if payType == PaySubCode.netBankPC.rawValue {
          self?.payBKPayNetPCModel = paybankListModel
        }else if payType == PaySubCode.unionpayScan.rawValue {
          self?.payBKPayScanModel = paybankListModel
        }else if payType == PaySubCode.netBankMOB.rawValue {
          self?.payBKPayNetMOBModel = paybankListModel
        }
      }
      else if (paykindCode.contains("OKPAY")){
        if payType == PaySubCode.jdScan.rawValue {
          self?.payJdScanModel = paybankListModel
        }else if payType == PaySubCode.jdWap.rawValue {
          self?.payJdChargeModel = paybankListModel
        }
        else if payType == PaySubCode.QQScan.rawValue {
          self?.payQQScanModel = paybankListModel
        }else if payType == PaySubCode.QQWap.rawValue{
          self?.payQQChargeModel = paybankListModel
        }else if payType == PaySubCode.btcpay.rawValue {
          self?.payBTCListModel = paybankListModel
        }
      }
      
      finishHandleBlock(true)
      print("paybankListModel---->\(paybankListModel)")
    }) { [weak self] (apiError) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      print("queryOnlineBanks error \n")
      finishHandleBlock(false)
    }
  }
 

  func requestBQBankList(bqPayType:String = "0" , realName:String = "" , depositorType:String =  "0", finishHandleBlock:@escaping (_ payBankListModel:PayBankListModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()) {
  
    var param = ManagerModel.configLoginNameParamDic()
    param["payType"] = bqPayType
    param["depositor"] = realName
    param["depositorType"] = depositorType

    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.queryBQBanks, parameters: param, successHandle: { [weak self] (paybankListModel : PayBankListModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      if bqPayType == PaySubCode.bqBankPay.rawValue {
        self?.payBQBankListModel = paybankListModel
      }else if bqPayType == PaySubCode.bqWxPay.rawValue {
        self?.payBQWXBankListModel = paybankListModel
      }else if bqPayType == PaySubCode.bqAliPay.rawValue {
        self?.payBQAliBankListModel = paybankListModel
      }
      finishHandleBlock(paybankListModel)
      
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestQueryManualBankList(name:String, depositorType:String,  finishHandleBlock:@escaping (_ payBankListModel:PayBankListModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    var param = ManagerModel.configLoginNameParamDic()
    param["payType"] = "0"
    param["depositor"] = name
    param["depositorType"] = depositorType

    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.queryManualBank, parameters: param, successHandle: {  (payBankListModel : PayBankListModel) in
      LoadingView.hideLoadingView(for: self.chargeView)
      finishHandleBlock(payBankListModel)
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestQueryBtcRateAndAddress(finishHandleBlock:@escaping (_ queryBtcRateModel:QueryBtcRateModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()) {
    var param = ManagerModel.configLoginNameParamDic()
    param["btcAmount"] = "1"
    LoadingView.showLoadingViewWith(to: self.chargeView)

    APITool.request(.queryBtcRateAndAddress, parameters: param, successHandle: { [weak self]  (queryBtcRateModel : QueryBtcRateModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      self?.payQueryBtcRateModel = queryBtcRateModel
      finishHandleBlock(queryBtcRateModel)
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestQueryPointCardList( finishHandleBlock:@escaping (_ pointCardModel:PointCardModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->() ) {
    let param = ManagerModel.configLoginNameParamDic()
    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.queryPointCardList, parameters: param, successHandle: { [weak self]  (pointCardModel : PointCardModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      self?.payPointCardListModel = pointCardModel
      finishHandleBlock(pointCardModel)
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestPointCardPayment(param:[String:Any], finishHandleBlock:@escaping(_ pamentModel:PayOnlineOrderModel)->(),failureHandleBlock:@escaping(_ error:APIError)->()){
    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.pointCardPayment, parameters: param, successHandle: { [weak self] (onlineOrderModel : PayOnlineOrderModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      finishHandleBlock(onlineOrderModel)
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlock(error)
    }
  }
  
  func requestCreateOnlineOrder(amount:String ,payid:String, payType:String , bankNo:String = "", finishHandleBlock:@escaping (_ onlineOrderModel:PayOnlineOrderModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->() ){
    var param = ManagerModel.configLoginNameParamDic()
    param["amount"] = amount
    param["bankNo"] = bankNo
    param["payid"] = payid
    param["payType"] = payType

    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.createOnlineOrder, parameters: param, successHandle: { [weak self] (onlineOrderModel : PayOnlineOrderModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      
      var domainUrl = ""
      for paymentUrl in onlineOrderModel.domainList ?? [""] {
        if  ManagerModel.instanse.chargeDomainListModel.contains(paymentUrl) == true {
          domainUrl = paymentUrl
          break ;
        }
      }
      if domainUrl.count > 1 {
        
      }
      finishHandleBlock(onlineOrderModel)
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  func requestBQPayment(param:[String:Any], finishHandleBlock:@escaping (_ paymentOrderModel:BQPaymentModel? )->(), failureHandleBlock:@escaping (_ error:APIError)->() ) {
    LoadingView.showLoadingViewWith(to: self.chargeView)
    APITool.request(.BQPayment, parameters: param, successHandle: { [weak self]  (paymentModel : BQPaymentModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      finishHandleBlock(paymentModel)
      
    }) { [weak self] (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: self?.chargeView)
      let error = apiError ?? APIError()
      failureHandleBlock(error)
    }
  }
  
 class func requestQueryDomainList() {
  
    let param = ManagerModel.configBasicParamDic()
    if ManagerModel.instanse.chargeDomainListModel.count > 1 {
      return
    }
    APITool.request(.queryDomainList, parameters: param, successHandle: {   (domainListModel:DomainListModel) in
      checkDomain(domainList: domainListModel.domainList)
    }) {  (apiError) in
      print("queryOnlineBanks error \n")
      let error = apiError ?? APIError()
     
    }
  }
  fileprivate class func checkDomain(domainList:[String]?){
    
    guard let domainListModel = domainList  else {
      return
    }
    for  domainUrl in domainListModel {
      validateChargeDomain(domainUrl: domainUrl)
    }
  }
 fileprivate class func validateChargeDomain(domainUrl:String){
    
    let  headers: HTTPHeaders = ["pid":config_pid]
    let manager = Alamofire.SessionManager.default
    manager.session.configuration.timeoutIntervalForRequest = 20
  

    Alamofire.request(domainUrl, method: .get, parameters: nil, encoding: URLEncoding.default, headers: headers).responseData { response in

        if let data = response.result.value, let utf8Text = String(data: data, encoding: .utf8) {
          if ManagerModel.instanse.chargeDomainListModel.contains(domainUrl) == false {
            ManagerModel.instanse.chargeDomainListModel.append(domainUrl)
            print("domainUrl------------>\(domainUrl)")
          }
        }
      }
    
  }
}
