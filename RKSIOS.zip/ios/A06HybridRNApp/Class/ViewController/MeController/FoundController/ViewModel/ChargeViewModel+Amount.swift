//
//  ChargeViewModel+Amount.swift
//  A06HybridRNApp
//
//  Created by kunlun on 01/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

extension ChargeViewModel {
  
  func requestQueryBQAmountList(payType:String,finishHanleBlock:@escaping(_ isSuccess:Bool)->()){
    
    var param = ManagerModel.configLoginNameParamDic()
    param["payType"] = payType
    LoadingView.showLoadingViewWith(to: chargeView)

    APITool.request(.queryAmountList, parameters: param, successHandle: { [weak self] (payBQLimitAmount : PayBankListModel) in
      LoadingView.hideLoadingView(for: self?.chargeView)

      if payType == PaySubCode.manualBank.rawValue {
        self?.payManualBankLimitAmount = payBQLimitAmount
      }else if payType == PaySubCode.bqAliPay.rawValue {
        self?.payBQAliLimitAmount = payBQLimitAmount
      }else if payType == PaySubCode.bqWxPay.rawValue {
        self?.payBQWxLimitAmount = payBQLimitAmount
      }else if payType == PaySubCode.bqBankPay.rawValue {
        self?.payBQBankLimitAmount = payBQLimitAmount
      }
      finishHanleBlock(true)
    }) {[weak self]  (apiError) in
      LoadingView.hideLoadingView(for: self?.chargeView)
      finishHanleBlock(false)
    }
  }
  
  func showDepositAmounts(amountArr:[Any]?, isFix:Bool?,payType:String){
    
    if (amountArr?.count ?? 0) == 0 {
      self.collectionAmountView?.realoadData(amountArr: ["100","500"], isShowTitle: false, payType:payType)

    }else{
      self.collectionAmountView?.realoadData(amountArr: amountArr, isShowTitle: false, payType:payType)
    }
  }
  
  func checkAmountBeyound(amountTextField:UITextField,payTypeName:String,subTypeName:String,isShowWarn:Bool = false) -> (minAmount:String,maxAmount:String) {
    
    var minAmount:String = ""
    var maxAmount:String = ""
    let result =  minAndMaxAmount(payTypeName: payTypeName, subTypeName: subTypeName)
    minAmount = result.minAmount
    maxAmount = result.maxAmount
    let textPlace = "请输入金额" + (minAmount  )
    amountTextField.placeholder =  textPlace + "~"  + (maxAmount ) + "之间的整数"
    return (minAmount ?? "",maxAmount ?? "")
  }
  
  func minAndMaxAmount(payTypeName:String,subTypeName:String) -> (minAmount:String,maxAmount:String){
  
    var minAmount:String?
    var maxAmount:String?
    
    if payTypeName.contains("ALIPAY") {
      if subTypeName == PaySubCode.alipayWap.rawValue {
        minAmount = payAlipayWapBankListModel?.minAmount
        maxAmount = payAlipayWapBankListModel?.maxAmount
      }else if subTypeName == PaySubCode.bqAliPay.rawValue {
        minAmount = payBQAliLimitAmount?.minAmount
        maxAmount = payBQAliLimitAmount?.maxAmount
      }else if subTypeName == PaySubCode.alipayScan.rawValue {
        minAmount = payAlipayScanModel?.minAmount
        maxAmount = payAlipayScanModel?.maxAmount
      }
    }else if payTypeName.contains("WXAPY"){
      if subTypeName == PaySubCode.wxpayWap.rawValue {
        minAmount = payWXpayWapBankListModel?.minAmount
        maxAmount = payWXpayWapBankListModel?.maxAmount
      }else if subTypeName == PaySubCode.bqWxPay.rawValue {
        minAmount = payBQWxLimitAmount?.minAmount
        maxAmount = payBQWxLimitAmount?.maxAmount
      }else if subTypeName == PaySubCode.wxpayScan.rawValue {
        minAmount = payWXpayScanModel?.minAmount
        maxAmount = payWXpayScanModel?.maxAmount
      }
    }else if payTypeName.contains("BANKPAY"){
      if subTypeName == PaySubCode.bqBankPay.rawValue {
        minAmount = payBQBankLimitAmount?.minAmount
        maxAmount = payBQBankLimitAmount?.maxAmount
      }else if subTypeName == PaySubCode.manualBank.rawValue {
        payManualBankLimitAmount?.minAmount = "50"
        payManualBankLimitAmount?.maxAmount = "1000000"
        minAmount = payManualBankLimitAmount?.minAmount
        maxAmount = payManualBankLimitAmount?.maxAmount
      }else if subTypeName == PaySubCode.netBankOnline.rawValue {
        minAmount = payBKPayNetOnlineModel?.minAmount
        maxAmount = payBKPayNetOnlineModel?.maxAmount
      }else if subTypeName == PaySubCode.netBankPC.rawValue {
        minAmount = payBKPayNetPCModel?.minAmount
        maxAmount = payBKPayNetPCModel?.maxAmount
      }else if subTypeName == PaySubCode.unionpayScan.rawValue {
        minAmount = payBKPayScanModel?.minAmount
        maxAmount = payBKPayScanModel?.maxAmount
      }else if subTypeName == PaySubCode.netBankMOB.rawValue {
        minAmount = payBKPayNetMOBModel?.minAmount
        maxAmount = payBKPayNetMOBModel?.maxAmount
      }
      
      
    }else if payTypeName.contains("OKPAY"){
      
      if subTypeName == PaySubCode.jdScan.rawValue {
        minAmount = payJdScanModel?.minAmount
        maxAmount = payJdScanModel?.maxAmount
      }else if subTypeName == PaySubCode.jdWap.rawValue {
        minAmount = payJdChargeModel?.minAmount
        maxAmount = payJdChargeModel?.maxAmount
      }else if subTypeName == PaySubCode.QQScan.rawValue {
        minAmount = payQQScanModel?.minAmount
        maxAmount = payQQScanModel?.maxAmount
      }else if subTypeName == PaySubCode.QQWap.rawValue {
        minAmount = payQQChargeModel?.minAmount
        maxAmount = payQQChargeModel?.maxAmount
      }else if subTypeName == PaySubCode.btcpay.rawValue {
        minAmount = payBTCListModel?.minAmount
        maxAmount = payBTCListModel?.maxAmount
      }
    }
    
    return (minAmount ?? "",maxAmount ?? "")
    
  }
  
  
  func showErrorAmountMsg(inputAmount:String, payTypeName:String,subTypeName:String) -> (String){
    
    var minAmount:String = ""
    var maxAmount:String = ""
    let result =  minAndMaxAmount(payTypeName: payTypeName, subTypeName: subTypeName)
    minAmount = result.minAmount
    maxAmount = result.maxAmount
    if minAmount.toIntValue() == 0 && maxAmount.toIntValue() == 0 {
      return ""
    }
    if inputAmount.toIntValue() >= minAmount.toIntValue() && inputAmount.toIntValue() <= maxAmount.toIntValue() {
      return ""
    }else if inputAmount.toIntValue() < minAmount.toIntValue() {
      return "存款金额不能小于" + minAmount + "元"
    }else if inputAmount.toIntValue() > maxAmount.toIntValue(){
      return "存款金额不能大于" + maxAmount + "元"
    }
     return ""
  }
  
 
  
  class func checkChineseName(nameTextFieldCell:ChargeTableViewCell, tableView:CaseyTableView?, disposeBag:DisposeBag) {
    
    if nameTextFieldCell.ic_textField == nil{
      return
    }
    let nameTextField = nameTextFieldCell.ic_textField
    
    nameTextField!.rx.text.orEmpty.changed
      .subscribe(onNext: { text in
       
        let lastText = text.last
        if lastText == nil || text.count > 21  {
          return
        }
        if text.count > 1 {
          let firstText = text.first
          if firstText == "*" {
            return
          }
        }
        if self.checkSpecialCharacter(text: lastText!) {
          if text.count == 1 {  //第一字符不能为为特殊字符
            nameTextField!.text = "" // + "·"
            nameTextFieldCell.hidenErrorMsg()
            if tableView != nil {
              nameTextFieldCell.cellHeight = 60
              tableView?.reloadData()
            }
          }
          else{
            let prefixText = text.prefix(text.count-1)
            nameTextField?.text = prefixText  + "·"
            let index = text.index(text.endIndex, offsetBy: -2)
            let lastStr = text[index..<text.endIndex]
            let last2Charater = lastStr.first
            if last2Charater == nil {
              return
            }
            if self.checkSpecialCharacter(text: last2Charater!) {
              
              nameTextField?.text = prefixText + ""
              nameTextFieldCell.showErrorMsg(msg: "不能连续包含两个特殊字符")
              if tableView != nil {
                nameTextFieldCell.cellHeight = 80
                tableView?.reloadData()
              }
            }else{
              nameTextFieldCell.hidenErrorMsgWithContentText()
              if tableView != nil {
                nameTextFieldCell.cellHeight = 60
                tableView?.reloadData()
              }
            }
          }
        }else{
          nameTextFieldCell.hidenErrorMsgWithContentText()
          if tableView != nil {
            nameTextFieldCell.cellHeight = 60
            tableView?.reloadData()
          }
        }
        
        
      })
      .disposed(by: disposeBag)
    
  }
  
  class func  checkSpecialCharacter(text:Character) -> Bool {
    if text == "," || text == "，" || text == "." || text == "。"
      || text == "*" || text == "、" || text == "·"  {
      return true
    }else{
      return false
    }
  }
  
  
  
  

}
