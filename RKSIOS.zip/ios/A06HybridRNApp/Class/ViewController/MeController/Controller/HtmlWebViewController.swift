//
//  HtmlWebViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 24/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import Foundation
import WebKit
import XCGLogger


class HtmlWebViewController: UIViewController,WKUIDelegate,WKNavigationDelegate,WKScriptMessageHandler {
  
  var webView:WKWebView!
  var webUrl:String?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    setUpWKwebView()
  }

    func setUpWKwebView() {
      
      let webConfiguration = WKWebViewConfiguration()
      webConfiguration.preferences = WKPreferences()
      webConfiguration.preferences.javaScriptEnabled = true
      webConfiguration.preferences.javaScriptCanOpenWindowsAutomatically = true
      webConfiguration.processPool = WKProcessPool()
      webConfiguration.userContentController = WKUserContentController()
      webView = WKWebView(frame: view.bounds, configuration: webConfiguration)
      webView.uiDelegate = self
      webView.navigationDelegate = self
      let myURL = URL(string: "http://m.hwx22.com/loginGame.php?gameID=bib&gameType=PT&username=AGA03FKUNLUN9&password=OTkzMmNiZDk=")
      
     // let requestUrl = webUrl ?? "http://m.hwx22.com/loginGame.php?gameID=bib&gameType=PT&username=AGA03FKUNLUN9&password=OTkzMmNiZDk="
      let myRequest = URLRequest(url: myURL! )  //URL.init(string: requestUrl)!
      webView.load(myRequest)
      view.addSubview(webView)
    }
    
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
      XCGLogger.debug("\(message)")
  }
  
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    
    XCGLogger.debug("didFinish")
  }
  func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
    XCGLogger.debug("didFailProvisionalNavigation")
  }
  func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
    XCGLogger.debug("didFail navigation")
  }
  func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    XCGLogger.debug("didStartProvisionalNavigation")
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    
    decisionHandler(WKNavigationActionPolicy.allow)
    
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
    decisionHandler(WKNavigationResponsePolicy.allow)
    
  }
  
  func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
    
  }
  
  func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
    
    XCGLogger.debug("\(message)")
    
  }
  
  func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
  
    XCGLogger.debug("\(message)")
  }
}
