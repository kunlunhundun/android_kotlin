//
//  WithDrawViewController.swift
//  A06HybridRNApp
//
//  Created by zaky on 26/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class WithDrawViewController: UIViewController {

  
  var withDataDrawModel:WithDrawModel?
  var bankCardListModel:BankCardBtcModel?
  var lastSelectIndex:Int = 0
  var queryBtcRateModel:QueryBtcRateModel?
  var confirmBtcRateModel:QueryBtcRateModel?

  var withDrawView:WithDrawView!
  var withDrawViewModel:WithDrawViewModel!
  var disposeBag = DisposeBag()
  var isFirstLoad:Bool = true
  let _navRightButton:UIButton = UIButton()
  var completionQuKuan:((_ property:String?)->(Void))!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "取款"
        let isBindPhone = isNeedBindPhone()
        if isBindPhone == false {
           needBindBankCard()
        }
    }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    let isBindMobiel = !(ManagerModel.shareInstanse().personInfoModel?.mobileNoBind == 0)
    let isBindCard = !( ManagerModel.shareInstanse().personInfoModel?.bankCardNum == 0 && ManagerModel.shareInstanse().personInfoModel?.btcNum == 0)
    let finishBind = (isBindMobiel && isBindCard)
    if !isFirstLoad && !finishBind{
      let isBindPhone = isNeedBindPhone()
      if isBindPhone == false {
        needBindBankCard()
      }
    }
    isFirstLoad = false
    
    _navRightButton.frame = CGRect.init(x: 0, y: 0, width: 60, height: 44)
    _navRightButton.setTitleColor(.white, for: .normal)
    _navRightButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 16)
    _navRightButton.setTitle("在线客服", for: .normal)
    _navRightButton.addTarget(self, action: #selector(self.eidtStatusEvent(_:)), for: .touchUpInside)
    self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(customView: _navRightButton)
  }
  
  //MARK: 跳望在线客服
  @objc private func eidtStatusEvent(_ sender:UIButton?) {
    let customerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: false)
    self.nearNav()?.pushViewController(customerOnlineVC, animated: true)
  }
  
  func isNeedBindPhone() -> Bool {
  
    self.requestData()
    if ManagerModel.shareInstanse().personInfoModel?.mobileNoBind == 0 {
    
      ProgressTopPopView.showPopViewCallBack(content: "您还未绑定手机号,请绑定后再操作", popStyle: .oneTitleConfirm, confirmTitle:"去绑定" ,callBackBlock: { [weak self] (isConfirm) in
        if isConfirm {
          let bindPhoneVC = BindPhoneViewController()
          self?.nearNav()?.pushViewController(bindPhoneVC, animated: true)
          bindPhoneVC.finishBindCallBackBlock = {
            //self?.needBindBankCard()
          }
        }else{
          self?.nearNav()?.popViewController(animated: true)
        }
      })
      return true
    }
    return false
  }
  
  func needBindBankCard(){
   
    if ManagerModel.shareInstanse().personInfoModel?.bankCardNum == 0 && ManagerModel.shareInstanse().personInfoModel?.btcNum == 0 {
      
      ProgressTopPopView.showPopViewCallBack(content: "您还未绑定银行卡,请绑定后再操作", popStyle: .oneTitleConfirm, confirmTitle: "去绑定") {[weak self] (isConfrim) in
        if isConfrim {
          let addBankVC = AddBankCardViewController()
          self?.nearNav()?.pushViewController(addBankVC, animated: true)
          addBankVC.finishCallBack = { [weak self] in
            self?.requestData()
          }
        }else{
          self?.nearNav()?.popViewController(animated: true)
        }
      }
      return
    }
  }
  
  func requestData(){
    
    withDrawViewModel = WithDrawViewModel()
    let group = DispatchGroup();
    let queue  = DispatchQueue.global()
    queue.async(group:group){
      group.enter()
      self.withDrawViewModel.requestGetBalance(finishHandleBlock: { [weak self] (withDrawModel) in
        self?.withDataDrawModel = withDrawModel
        print("----->requestGetBalance")
        group.leave()
      }) {  (error) in
        ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
        group.leave()
      }
    }
    queue.async(group:group){
      
      group.enter()
      self.withDrawViewModel.rquestQueryBankAndBit(finishHandleBlock: {[weak self] (bankCardListModel) in
        self?.bankCardListModel = bankCardListModel
        
        print("----->rquestQueryBankAndBit")
        group.leave()
        
      }) { (error) in
        ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
        group.leave()
      }
    }
    
    LoadingView.showLoadingViewWith(to: self.view)
    group.notify(queue: DispatchQueue.main, execute: { [weak self] in
      LoadingView.hideLoadingView(for: self?.view)
      print("----->setupView")
      self?.setupView()
    })
    
  }
  
  func refreshTotalAmount(){
    
    LoadingView.showLoadingViewWith(to: self.view)
    self.withDrawViewModel.requestGetBalance(finishHandleBlock: { [weak self] (withDrawModel) in
      self?.withDataDrawModel = withDrawModel
      self?.withDrawView.setDataDrawModel(dataDrawModel: withDrawModel)
      LoadingView.hideLoadingView(for: self?.view)
      print("----->requestGetBalance")
      self?.completionQuKuan?(withDrawModel.balance)
      self?.navigationController?.popViewController(animated: true)
    }) {[weak self]  (error) in
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      LoadingView.hideLoadingView(for: self?.view)
    }
  }
  

  func setupView(){
    
    withDrawView = WithDrawView.init(frame: self.view.bounds)
    self.view.addSubview(withDrawView)
    withDrawView.snp.makeConstraints { (make) in
      make.left.right.bottom.top.equalTo(self.view)
    }
    
    withDrawView.refreshBtn.rx.tap.asObservable().subscribe(onNext: {
      LoadingView.showLoadingViewWith(to: self.view)
      self.withDrawViewModel.requestGetBalance(finishHandleBlock: { [weak self] (withDrawModel) in
        self?.withDataDrawModel = withDrawModel
        self?.withDrawView.setDataDrawModel(dataDrawModel: withDrawModel)
        LoadingView.hideLoadingView(for: self?.view)
      }) { [weak self] (error) in
        LoadingView.hideLoadingView(for: self?.view)
        ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
      }
    }).disposed(by: self.disposeBag)
    
    withDrawView.drawBackBtn.rx.tap.asObservable().subscribe(onNext: {
      
      guard let accounts = self.bankCardListModel?.accounts else {
        return
      }
      if accounts.count < 1 {
        return
      }
      SelectBankTableView.showPopView(dataArr: accounts, bankDataType: .withDrawCardType, selectIndex:self.lastSelectIndex  ,sureBlock: { [weak self] (indexPath) in
        self?.lastSelectIndex = indexPath.row
        let infoCardModel = self?.bankCardListModel?.accounts?[safe:indexPath.row]
        if infoCardModel?.accountType == "BTC" {
          self?.swichBtcDrawView()
        }
        self?.withDrawView.selectIndexBank(drawBankModel: infoCardModel)
      })
      
    }).disposed(by: self.disposeBag)
    
    withDrawView.setDataDrawModel(dataDrawModel: self.withDataDrawModel)

    guard  (self.bankCardListModel?.accounts?.count ?? 0 ) > 0 else {
      return
    }
    let cardModel = self.bankCardListModel?.accounts?[safe:0]
    withDrawView.selectIndexBank(drawBankModel: cardModel)
    if cardModel?.accountType == "BTC" {
      swichBtcDrawView()
    }
    
    withDrawView.confirmBtn.rx.tap.asObservable().subscribe(onNext: { [weak self] in
      
      self?.endFisrtResponder()
      let selectIndex =  self?.lastSelectIndex ?? 0
      let cardModel = self?.bankCardListModel?.accounts?[safe:selectIndex]
      if cardModel?.accountType == "BTC" {
        self?.makesureBtcRateAmount()
      }else{
        self?.withdrawFromBankAndBtc()
      }
    }).disposed(by: self.disposeBag)
  }
  
  func endFisrtResponder(){
    withDrawView.amountField.resignFirstResponder()
    withDrawView.pswField.resignFirstResponder()
  }
  
  func swichBtcDrawView(){
    
    withDrawViewModel?.rquestWithDrawQueryBtcRate(amount: "10000", finishHandleBlock: { [weak self] (btcRateModel) in
      self?.queryBtcRateModel = btcRateModel
      self?.withDrawView.refreshBitRateView(btcRateModel: btcRateModel)
    }) {  (error) in
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
  
  func makesureBtcRateAmount(){
    
    let amount = withDrawView.amountField.text ?? ""
    LoadingView.showLoadingViewWith(to: self.view)
    withDrawViewModel?.rquestWithDrawQueryBtcRate(amount: amount, finishHandleBlock: { [weak self] (btcRateModel) in
      self?.confirmBtcRateModel = btcRateModel
      LoadingView.hideLoadingView(for: self?.view)

      WithDrawBtcSureAlertView.showPopView(btcRateModel: btcRateModel, sureBlock: { [weak self] (sureIndex) in
        if  sureIndex == 0 {
          self?.withdrawFromBankAndBtc()
        }
      })
      
    }) {[weak self]  (error) in
      LoadingView.hideLoadingView(for: self?.view)
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
  
  func withdrawFromBankAndBtc(){
    
    let amount = withDrawView.amountField.text ?? ""
    let pwdText = withDrawView.pswField.text ?? ""
    let isShow = withDrawView.amountTipLab.isHidden
    let psisShow = withDrawView.pswErrorTipLab.isHidden
    
    if isShow != true {
       return
    }
    if psisShow != true {
      return
    }
    if amount.count < 1 {
      withDrawView.showAmountTextFieldErrorTip()
      return
    }
    if pwdText.count < 1  {
      withDrawView.showPswTextFieldErrorTip()
      return
    }
    
    let selectIndex =  lastSelectIndex
    let cardModel = bankCardListModel?.accounts?[safe:selectIndex]
  
    let accountId = cardModel?.accountId ?? ""
    var btcAmount = ""
    var btcRate = ""
    var btcUuid = ""
    if cardModel?.accountType == "BTC" {
      btcAmount = confirmBtcRateModel?.btcAmount ?? ""
      btcRate = confirmBtcRateModel?.btcRate ?? ""
      btcUuid = confirmBtcRateModel?.btcUuid ?? ""
    }
    var param = ManagerModel.configLoginNameParamDic()
    param["amount"] = amount
    param["password"] = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: pwdText)
    param["accountId"] = accountId
    param["btcAmount"] = btcAmount
    param["btcRate"] = btcRate
    param["btcUuid"] = btcUuid
    
    LoadingView.showLoadingViewWith(to: self.view)
    withDrawViewModel.rquestCreateRequest(param: param, finishHandleBlock: { [weak self]  (createRequestModel) in
      LoadingView.hideLoadingView(for: self?.view)

      ProgressTopPopView.showPopView(content: "您的取款将在10分钟后到账", popStyle: .successMsgToast)
      self?.refreshTotalAmount()
      ReactInteraction.shareInstance().refreshData()
      
    }) { [weak self] (error) in
     
      LoadingView.hideLoadingView(for: self?.view)
      if error.kl_code?.contains("WS_304817") ?? false{
        ProgressTopPopView.showPopView(content: "你尚有处理中的申请" , popStyle: .errorMsgToast)
        return ;
      }
      if error.kl_code?.contains("WS_304820") ?? false{
        ProgressTopPopView.showPopView(content: "取款银行卡不存在" , popStyle: .errorMsgToast)
        return ;
      }
      if (error.kl_code?.contains("WS_304848") ?? false) || (error.kl_code?.contains("WS_304847") ?? false) {
        ProgressTopPopView.showPopView(content: "当前卡号不可用，请选择其他存款方式" , popStyle: .errorMsgToast)
        return ;
      }
    
      if error.kl_code?.contains("GW_800411") ?? false{
        ProgressTopPopView.showPopView(content:  "错误次数超过最大错误次数，请重新登录后再试", popStyle: .errorMsgToast)
        let walltime = DispatchWallTime.now() + 2
        DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
          ReactInteraction.shareInstance()?.logOut()
          self?.navigationController?.popToRootViewController(animated: true)
        }
        return
      }
      ProgressTopPopView.showPopView(content: error.kl_tips ?? "", popStyle: .errorMsgToast)
    }
  }
}
