//
//  MeViewController.swift
//  A06KSEntireGame
//
//  Created by kunlun on 2018/11/2.
//  Copyright © 2018年 kunlun. All rights reserved.
//

import UIKit
import HandyJSON

class MeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.navigationItem.leftBarButtonItem = nil
      
        let contentBtn = UIButton(frame: CGRect(x: 20, y: 60, width: 200, height: 200))
        contentBtn.setTitle("A06项目", for: .normal)
        contentBtn.setTitleColor(UIColor.red, for: .normal)
        self.view.addSubview(contentBtn)
      
      
      let queue = DispatchQueue(label: "requestHandler")
      let group = DispatchGroup()
      weak var weakSelf =  self
      queue.async(group: group) {
        let sema = DispatchSemaphore(value: 0)
      
        let paramDic = ManagerModel.configBasicParamDic()
        
        APITool.request(.welcome, parameters: paramDic, successHandle: { (welcomeModel : WelcomeModel) in
          
          sema.signal()
          ManagerModel.instanse.key0 = welcomeModel.key0 ?? ""
          ManagerModel.instanse.publicKey = welcomeModel.publicKey ?? ""
        
          let info = welcomeModel.info ?? ""
          let baseInfo =  BaseJsonTool.base64Decoding(encodedString: info)
          let infoModel:InfoModel? =  InfoModel.deserialize(from: baseInfo)
          ManagerModel.instanse.infoModel = infoModel
          
          print("infoModel---->\(infoModel?.toJSONString() ?? "")")
          print("pubkey---->\(ManagerModel.instanse.publicKey )")
          
        }) { (aprError) in
           sema.signal()
        }
        
        //异步调用返回前，就会一直阻塞在这
        sema.wait()
        }
      
      group.notify(queue: DispatchQueue.main, execute: {[weak self] in
        
      //  self?.requestRegistUserName();
        self?.requestLoginUserName()
        
      })
      
      
    /*  queue.async(group: group) {
        let sema = DispatchSemaphore(value: 0)
        
        var paramDic = ManagerModel.configBasicParamDic()
        paramDic["loginName"] = "ckunlun69"
        let password = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: "test1234")
        paramDic["password"] = password
        
        APITool.request(.loginUserName, parameters: paramDic, successHandle: { (loginSucModel : LoginSuccessModel) in
          sema.signal()
          ManagerModel.instanse.loginSuccessModel = loginSucModel
          ManagerModel.configLoginNameParamDic()
          print("loginSucModel---->\(loginSucModel)")
          
        }) { (aprError) in
          sema.signal()
        }
        
        sema.wait()
        } */
     

      contentBtn.addTarget(self, action: #selector(jump), for: .touchUpInside)
      //  requestWelcome()
      
        // Do any additional setup after loading the view.
    }
  
  @objc func jump(){
    
    print("kdklddkldldsllksdjkdkdjslkkdekjdjk")
  }
  
  
  func requestWelcome() {
    
    let paramDic = ManagerModel.configBasicParamDic()
    
    APITool.request(.welcome, parameters: paramDic, successHandle: { (welcomeModel : WelcomeModel) in
      
      print("welcomeModel---->\(welcomeModel)")
      ManagerModel.instanse.key0 = welcomeModel.key0 ?? ""
      ManagerModel.instanse.publicKey = welcomeModel.publicKey ?? ""
      print("key0---->\(ManagerModel.instanse.key0 )")
      print("pubkey---->\(ManagerModel.instanse.publicKey )")

    }) { (aprError) in
      
    }
    
  }
  
  func requestHome() {
    
    let paramDic = ManagerModel.configLoginNameParamDic()
    
    APITool.request(.welcome, parameters: paramDic, successHandle: { (welcomeModel : WelcomeModel) in
      
      print("welcomeModel---->\(welcomeModel)")
      ManagerModel.instanse.key0 = welcomeModel.key0 ?? ""
      ManagerModel.instanse.publicKey = welcomeModel.publicKey ?? ""
      print("key0---->\(ManagerModel.instanse.key0 )")
      print("pubkey---->\(ManagerModel.instanse.publicKey )")
      
    }) { (aprError) in
      
    }
    
  }
  
  
  func requestRegistUserName(){
    
    
    var paramDic = ManagerModel.configBasicParamDic()
    paramDic["loginName"] = "ckunlun9"//cward70  ckunlun6
    let password = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: "admin12345") //
    paramDic["password"] = password
    
    APITool.request(.registUserName, parameters: paramDic, successHandle: { (loginSucModel : LoginSuccessModel) in
      
      ManagerModel.instanse.loginSuccessModel = loginSucModel
      
      print("loginSucModel---->\(loginSucModel)")
      
    }) { (aprError) in
      
    }
    
  }
  
  func requestLoginUserName(){
    
    var paramDic = ManagerModel.configBasicParamDic()
    paramDic["loginName"] = "cingt8"  //ckunlun6 8  cward70 ckunlun9
    let password = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: "tt123456") //admin12345 test1234
    paramDic["password"] = password

    APITool.request(.loginUserName, parameters: paramDic, successHandle: { (loginSucModel : LoginSuccessModel) in
      
      ManagerModel.instanse.loginSuccessModel = loginSucModel
      
      print("loginSucModel---->\(loginSucModel)")
      
    }) { (aprError) in
      
    }
  }
  
  
  
  

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
