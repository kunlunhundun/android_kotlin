//
//  PersonInfoCardModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON
class PersonInfoCardModel: HandyJSON , Codable{

  
  var accountId:String? // 账户编号
  var accountName:String? // 姓名
  var accountNo:String? // 账号 /比特币地址
  var accountType:String? // 账号类型： 借记卡，信用卡， 存折，BTC
  var backgroundColor:String? // 银行背景图
  var bankBranchName:String? // 开户支行名称银行
  var bankIcon:String? // 银行ICon
  var bankName:String? // 银行名称
  var city:String? //  开户城市
  var flag:String? // 账号状态
  var loginName:String? //
  var province:String? // 银行开户省份
  
  
  required init() {
    
  }
  
  
  func netBitCardDeleteParam() -> [String:String] {
    
    var param = ["btcName":"比特币钱包"]
    param["btcUrl"] = self.accountNo ?? ""
    param["accountId"] = self.accountId ?? ""
    return param
  }
  
  func netBankCardDeleteParam() -> [String:String] {
    
    
    var param = [String:String]()
    param["accountName"] = self.accountName ?? ""
    param["accountNo"] = self.accountNo ?? ""
    param["accountType"] = self.accountType ?? ""
    param["bankBranchName"] = self.bankBranchName ?? ""
    param["bankName"] = self.bankName ?? ""
    param["city"] = self.city ?? ""
    param["accountId"] = self.accountId ?? ""
    return param
  }
  
}
