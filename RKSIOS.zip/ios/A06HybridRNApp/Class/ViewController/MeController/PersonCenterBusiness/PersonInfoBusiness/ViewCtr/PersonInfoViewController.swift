//
//  PersonInfoViewController.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonInfoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

  
  
    var personInfoModel:PersonInfoModel?
  
    let modelNet = PersonInfoModelNet()
    private var _tableView : UITableView?
    private var _cardInfoHeaderView = PersonCardInfoHeaderView()
    private let _readNameCell  = PersonInfoStatusBriefCell()
    private let _phoneNumCell  = PersonInfoStatusBriefCell()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "个人信息"
        initUIProperty()
        initLayoutSubview()
        netLoadData(false)
    }
  
    override func viewWillAppearFlushView(_ status: Int) {
        super.viewWillAppearFlushView(status)
        netLoadData(true)
    }
  
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      // 刷新状态（本地更新personInfoModel数据）
      if (personInfoModel?.birthday?.count ?? 0) > 0 {
        _readNameCell.statusLabel.text = "已完善"
        _readNameCell.statusLabel.textColor = UIColor.init(colorValue: 0x44D9B5)
        _readNameCell.subTitle = personInfoModel?.realName
      }else{
        _readNameCell.statusLabel.text = "未完善"
        _readNameCell.statusLabel.textColor = UIColor.init(colorValue: 0xFFFFFF)
        _readNameCell.subTitle = nil
      }
      
      if (personInfoModel?.mobileNoBind ?? 0) > 0  {
        _phoneNumCell.statusLabel.text = "更换"
        _phoneNumCell.statusLabel.textColor = UIColor.init(colorValue: 0xFA2663)
        _phoneNumCell.subTitle = personInfoModel?.mobileNo
      }else{
        _phoneNumCell.statusLabel.text = "未绑定"
        _phoneNumCell.statusLabel.textColor = UIColor.init(colorValue: 0xFFFFFF)
        _phoneNumCell.subTitle = nil
      }
    }
  
    private func initUIProperty()    {
      
        _readNameCell.topLineView.isHidden = false
        _readNameCell.titleLabel.text = "实名认证"
      
        _phoneNumCell.topLineView.isHidden = true
        _phoneNumCell.titleLabel.text = "手机号绑定"
      
        _cardInfoHeaderView.x = 0
        _cardInfoHeaderView.y = 0
        _cardInfoHeaderView.width = SCREEN_WIDTH
        _cardInfoHeaderView.heigth = 277
        
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView?.register(PersonInfoStatusBriefCell.classForCoder(), forCellReuseIdentifier: "PersonInfoStatusBriefCell")
        _tableView!.tableHeaderView = _cardInfoHeaderView
        self.view.addSubview(_tableView!)
      
        weak var weakSelf = self
        _tableView?.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            weakSelf?.netLoadData(false)
        })
    }
  
    private func initLayoutSubview()    {
        _tableView?.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
  
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 74
    }
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
          return _readNameCell
        }else{
          return _phoneNumCell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if  indexPath.row == 0 {
            let viewCtr = RealNameVertifyViewController()
            viewCtr.personInfoModel = self.personInfoModel
            self.navigationController?.pushViewController(viewCtr, animated: true)
        }
        if indexPath.row == 1 {
            let viewCtr = BindPhoneViewController()
            viewCtr.personInfoModel = self.personInfoModel
            self.navigationController?.pushViewController(viewCtr, animated: true)
        }
    }
  

  // MARK: NetWork
  func netLoadData(_ passiveAnimation:Bool)  {
    
    if passiveAnimation {
      _tableView!.setContentOffset(CGPoint.init(x: 0, y: -_tableView!.mj_header.heigth), animated: true)
    }else {
      LoadingView.showLoadingViewWith(to: self.view)
    }
    
    modelNet.netPersonInfoWithCard { (result, errorDesc)in
      self._tableView?.mj_header.endRefreshing()
      self._cardInfoHeaderView.dataModel = self.modelNet
      if passiveAnimation {
        self._tableView!.setContentOffset(CGPoint.zero, animated: true)
      }else{
        LoadingView.hideLoadingView(for: self.view)
      }
    }
  }
}
