//
//  PersonCardMenuView.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonCardListView: UIView, UIScrollViewDelegate {
  
    var dataModel:[PersonInfoCardModel]? {
      didSet{
        flushDataView()
      }
    }
  
    let _menuScrollView = UIScrollView()
    
    let _cardViewStartTag = 112
    let _cardPageWidth:CGFloat = 275.0 // 255.0 + 10*2, 其内容区width 255.0； 10是左右的空白区
    let _cardPageHeight:CGFloat = 150.0
    
    fileprivate override init(frame: CGRect) {
        super.init(frame: frame)
        initUIProperty()
        initLayoutSubview()
    }
  
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initUIProperty()  {
        
        _menuScrollView.delegate = self
        _menuScrollView.isPagingEnabled = true
        _menuScrollView.clipsToBounds = false
        _menuScrollView.showsHorizontalScrollIndicator = false
        self.addSubview(_menuScrollView)
    
        _menuScrollView.contentSize = CGSize.init(width: _cardPageWidth, height: _cardPageHeight)
        self.scrollViewDidScroll(_menuScrollView)
    }
  
    private let _maxCountOfCard = 3
    private let cardColorArr = [(UIColor.init(colorValue: 0xF82363), UIColor.init(colorValue: 0x8F4EF7)),
                                (UIColor.init(colorValue: 0x36DFDC), UIColor.init(colorValue: 0x3E8BDB)),
                                  (UIColor.init(colorValue: 0x6A94F7), UIColor.init(colorValue: 0x813EDB))]

    private func flushDataView(){
      
      
      
      _menuScrollView.removeAllSubView()
      
      let cardCount = dataModel?.count ?? 0
      if cardCount > 0 {
        for index in 0...cardCount-1 {
          
          let cardInfoView = MyCardInfoView()
          
          cardInfoView.tag = _cardViewStartTag + index
          cardInfoView.x = CGFloat(index)*_cardPageWidth
          cardInfoView.y = 0
          cardInfoView.width = _cardPageWidth
          cardInfoView.heigth = _cardPageHeight
          cardInfoView.dataModel = dataModel![index]
          
          if index < cardColorArr.count {
            let (startColor, endColor) = cardColorArr[index]
            cardInfoView.setGradientColor(startColor: startColor, endColor: endColor)
          }
          _menuScrollView.addSubview(cardInfoView)
        }
      }
      
      // 最多3张卡,3张卡就不能显示添加银行卡的View
      if cardCount < _maxCountOfCard {
        
        let cardInfoView = MyCardInfoView()
        cardInfoView.tag = _cardViewStartTag + cardCount
        _menuScrollView.addSubview(cardInfoView)
        
        cardInfoView.x = CGFloat(cardCount)*_cardPageWidth
        cardInfoView.y = 0
        cardInfoView.width = _cardPageWidth
        cardInfoView.heigth = _cardPageHeight
        cardInfoView.dataModel = nil
        _menuScrollView.contentSize = CGSize.init(width: _cardPageWidth*CGFloat(cardCount+1), height: _cardPageHeight)
      }else {
        _menuScrollView.contentSize = CGSize.init(width: _cardPageWidth*CGFloat(cardCount), height: _cardPageHeight)
      }
      
      let index = Int(_menuScrollView.contentOffset.x/_cardPageWidth)
      UIView.animate(withDuration: 0.2) {
        self.showHighlightCard(index)
      }
    }
  
    private func initLayoutSubview()  {
        _menuScrollView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.width.equalTo(_cardPageWidth)
            make.top.equalToSuperview().offset(26)
            make.height.equalTo(_cardPageHeight)
        }
    }
  
    //MARK: 修改系统事件响应
  
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        if !self.isHidden &&  self.frame.contains(point) && !_menuScrollView.frame.contains(point){
            return _menuScrollView
        }
        return super.hitTest(point, with: event)
    }
    
  
    // MARK: scrollview delegate
    
    let _vGap:CGFloat = 15.0
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        
        var index = Int(_menuScrollView.contentOffset.x/_cardPageWidth)
        if Int(_menuScrollView.contentOffset.x)%Int(_cardPageWidth) > Int(_cardPageWidth)/2 {
            index = index + 1
            
        }
        if (index + _cardViewStartTag) == _currentHighlightCardView?.tag {
            return
        }
    
        
        UIView.animate(withDuration: 0.2) {
            
            self.showHighlightCard(index)
        }
        
    }
    
    var _currentHighlightCardView:MyCardInfoView?
    
    private func showHighlightCard(_ index: Int)  {
        
        if  let currentCardView = _menuScrollView.viewWithTag(index+_cardViewStartTag) as? MyCardInfoView{
            currentCardView.y = 0
            currentCardView.hightlight = true
            _currentHighlightCardView = currentCardView
        }
        
        if  let preCardView = _menuScrollView.viewWithTag(index+_cardViewStartTag-1) as? MyCardInfoView {
            preCardView.y = _vGap
            preCardView.hightlight = false
        }
      
        if let backCardView = _menuScrollView.viewWithTag(index+_cardViewStartTag+1) as? MyCardInfoView {
            backCardView.y = _vGap
            backCardView.hightlight = false
        }
        
    }
    
}
