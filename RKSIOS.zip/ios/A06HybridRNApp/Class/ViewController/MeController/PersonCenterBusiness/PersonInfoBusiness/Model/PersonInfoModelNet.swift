//
//  PersonInfoModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class PersonInfoModelNet: NSObject,Codable {
  
  
  var cardAccountArr = [PersonInfoCardModel]() // 银行卡
  var cardBitAccountArr = [PersonInfoCardModel]() // 比特币
  
  var btcRate:Int?
  
  func netPersonInfoWithCard(_ completion:@escaping NetFinish)  {
    
    
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bankAndBitQuery.rawValue, parameters: nil) { (result, error, isCache) in
      
      
      if let dateResult = result {
        
        self.cardAccountArr.removeAll()
        self.cardBitAccountArr.removeAll()
        if let accountsArry = dateResult["accounts"] as? [[String:Any]] {
          
          for cardInfo in accountsArry {
            
           
            if let cardModel =  PersonInfoCardModel.deserialize(from: NSDictionary(dictionary: cardInfo)) {
              
              if cardModel.accountType?.elementsEqual("BTC") ?? false{
                self.cardBitAccountArr.append(cardModel)
              }else{
                self.cardAccountArr.append(cardModel)
              }
              
            }
            
          }
          
        }
        completion(nil, nil)
        
      }else{
        
        
          completion(nil, error?.errorDesc)
        
      }
      
      
    }
    
  }
  
  
  // 删除银行卡/比特币信息
  func netBankCardDelete(_ param:[String:Any] , _ completion:@escaping NetFinish)  {
    
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bankCardDelete.rawValue, parameters: param) { (result, error, isCache) in
      
      
      if let dateResult = result {
        
        completion(dateResult, nil)
        
      }else{
        
        
        completion(nil, error?.errorDesc)
        
      }
      
      
    }
  }
  
  
}
