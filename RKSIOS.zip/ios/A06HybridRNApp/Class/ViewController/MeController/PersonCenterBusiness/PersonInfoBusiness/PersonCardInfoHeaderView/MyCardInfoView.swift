//
//  myCardInfoView.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class MyCardInfoView: UIView {

    var dataModel:PersonInfoCardModel? {
      
      didSet{
          flushDataView()
      }
      
    }
    
    private let _contentView = UIView()
    private let _bankLogImageView = UIImageView() // 银行log 图片
    private let _bankNameLabel = UILabel()// 银行名称
    private let _bankCardNumberLabel = UILabel() // 银行卡号
    private let _bankCardOfPersonNameLabel = UILabel() // 名字
    private let _deleteButton = UIButton() // 删除按钮
  
    private let _addBankCardButton = UIButton() // 添加银行卡button
  
  
    var hightlight: Bool {
        
        get{ return false}
        set{
            if  newValue {
                self.alpha = 1
            }else {
                self.alpha = 0.3
            }
        }
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUIProperty()
        initLayoutSubview()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    var startColor:UIColor = UIColor.init(colorValue: 0xF82363)
    var endColor:UIColor = UIColor.init(colorValue: 0x8F4EF7)
  
    override func layoutSubviews() {
      
      super.layoutSubviews()
      _contentView.gradient(withVertical: false, startGdColor: startColor, endGdColor: endColor)
    }
  
    private func initUIProperty()  {
      
        
        _contentView.layer.cornerRadius = 8
        _contentView.clipsToBounds = true
        self.addSubview(_contentView)
      
        _bankLogImageView.image = UIImage.init(named: "其他存款.png")
        self.addSubview(_bankLogImageView)
      
        _bankNameLabel.text = "招商银行"
        _bankNameLabel.textColor = .white
        _bankNameLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        self.addSubview(_bankNameLabel)
      
        _bankCardNumberLabel.text = "2234   0000   9816   4584"
        _bankCardNumberLabel.textColor = .white
        _bankCardNumberLabel.font = UIFont.PingFangSCRegular(ofSize: 18)
        self.addSubview(_bankCardNumberLabel)
      
        _bankCardOfPersonNameLabel.text = "DU LANTE"
        _bankCardOfPersonNameLabel.textColor = .white
        _bankCardOfPersonNameLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        self.addSubview(_bankCardOfPersonNameLabel)
        
      
        _deleteButton.setImage(UIImage.init(named: "删除-2.png"), for: .normal)
        _deleteButton.addTarget(self, action: #selector(deleteBankCardEvent(_:)), for: .touchUpInside)
        self.addSubview(_deleteButton)
        
        _addBankCardButton.setTitle("+添加银行卡", for: .normal)
        _addBankCardButton.setTitleColor(.white, for: .normal)
        _addBankCardButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        _addBankCardButton.addTarget(self, action: #selector(addBankCardEvent(_:)), for: .touchUpInside)
        _addBankCardButton.backgroundColor = UIColor.init(colorValue: 0x2B3034)
        _addBankCardButton.isHidden = true
        _addBankCardButton.layer.cornerRadius = _contentView.layer.cornerRadius
        self.addSubview(_addBankCardButton)
    }
  
    private func flushDataView(){
      
      if dataModel == nil {
          _addBankCardButton.isHidden = false
      }else {
          _addBankCardButton.isHidden = true
      }

      _bankNameLabel.text = dataModel?.bankName
      _bankCardOfPersonNameLabel.text = dataModel?.accountName
      _bankCardNumberLabel.text = dataModel?.accountNo
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (dataModel?.bankIcon ?? "")
      _bankLogImageView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: ""))

    }
    func setGradientColor(startColor:UIColor, endColor:UIColor) {
      
      self.startColor = startColor
      self.endColor = endColor
    }
  
    private func initLayoutSubview()  {
        
        _contentView.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.top.bottom.equalToSuperview()
        }
        
        
        _bankLogImageView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(18+10)
            make.top.equalToSuperview().offset(18)
            make.width.height.equalTo(27)
            
        }
        
        _bankNameLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(53+10)
            make.width.equalTo(150)
            make.centerY.equalTo(_bankLogImageView.snp.centerY)
            make.height.equalTo(21)
            
        }
        
        _bankCardNumberLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(18+10)
            make.right.equalToSuperview().offset(-13-10)
            make.top.equalToSuperview().offset(65)
            make.height.equalTo(25)
        }
        
        
        _bankCardOfPersonNameLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(18+10)
            make.width.equalTo(150)
            make.bottom.equalToSuperview().offset(-18)
            make.height.equalTo(21)
            
        }
        
        
        _deleteButton.snp.makeConstraints { (make) in
            
            make.right.equalToSuperview().offset(-10)
            make.centerY.equalTo(_bankCardOfPersonNameLabel.snp.centerY)
            make.width.height.equalTo(45)
        }
        
        _addBankCardButton.snp.makeConstraints { (make) in

            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.top.bottom.equalToSuperview()
        }
 
    }
    
    //MARK: 添加删除 button 事件
    @objc private func addBankCardEvent(_ sender:UIButton) {
        
        self.nearNav()?.pushViewController(AddBankCardViewController(), animated: true)
    }
    
    
  @objc private func deleteBankCardEvent(_ sender:UIButton) {
    
    if let viewCtr =  self.nearViewController() as? PersonInfoViewController {
      let cardCount =  viewCtr.modelNet.cardBitAccountArr.count + viewCtr.modelNet.cardAccountArr.count
      if cardCount == 1 {
        ProgressTopPopView.showPopView(content: "至少保留一张取款卡", popStyle: .errorMsgToast)
        return
      }
    }
    ProgressTopPopView.showPopViewCallBack(content: "您是否删除银行卡!", popStyle: .oneTitleConfirm, confirmTitle: "确定") { [weak self] (isConfirm) in
      if isConfirm {
         self?.netDeleteBitCard()
      }

    }
    
    print("deleteBankCardEvent")
  }
  
  
  func netDeleteBitCard()  {
    
    LoadingView.showLoadingViewWith(to: self.nearViewController()?.view)

    PersonInfoModelNet().netBankCardDelete(dataModel!.netBankCardDeleteParam()) { [weak self] (result, error) -> (Void) in
      
      LoadingView.hideLoadingView(for: self?.nearViewController()?.view)

      if error == nil {
        
        ProgressTopPopView.showPopView(content: "删除成功", popStyle: .successMsgToast)

        if let viewCtr =  self?.nearViewController() as? PersonInfoViewController{
            viewCtr.netLoadData(true)
        }
        
      }else {
        ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
      
      }
      
    }
    
  }
}
