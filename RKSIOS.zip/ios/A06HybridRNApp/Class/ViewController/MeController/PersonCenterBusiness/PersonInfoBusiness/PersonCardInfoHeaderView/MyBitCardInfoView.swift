//
//  BitCardInfoView.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class MyBitCardInfoView: UIView {

    
  
    var dataModel:PersonInfoCardModel? {
      
      didSet{
        flushDataView()
      }
      
    }
    private let _contentView = UIView()
    private let _logImageView = UIImageView() // 币 log 图片
    private let _btcNameLabel = UILabel()// 名称
    private let _btcNumberLabel = UILabel() // 卡号
    private let _personNameLabel = UILabel() // 名字
    private let _deleteButton = UIButton() // 删除按钮
    private let _addBTCButton = UIButton() // 添加银行卡button
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initUIProperty()
        initLayoutSubview()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initUIProperty()  {
        
        self.backgroundColor = UIColor.init(colorValue: 0xFFF63A)
        self.layer.cornerRadius = 8
        
        self.addSubview(_contentView)
        
        _logImageView.image = UIImage.init(named: "比特币icon.png")
        _contentView.addSubview(_logImageView)
        
        _btcNameLabel.text = "BTC"
        _btcNameLabel.textColor = UIColor.init(colorValue: 0x333333)
        _btcNameLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _btcNameLabel.textAlignment = .right
        _contentView.addSubview(_btcNameLabel)
        
        _btcNumberLabel.text = "**** **** **** HOTSS"
        _btcNumberLabel.textColor = UIColor.init(colorValue: 0x333333)
        _btcNumberLabel.font = UIFont.PingFangSCRegular(ofSize: 18)
        _contentView.addSubview(_btcNumberLabel)
        
        _personNameLabel.text = "DU LANTE"
        _personNameLabel.textColor = UIColor.init(colorValue: 0x555555)
        _personNameLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        _contentView.addSubview(_personNameLabel)
      
        _deleteButton.setImage(UIImage.init(named: "删除-黑.png"), for: .normal)
        _deleteButton.addTarget(self, action: #selector(deleteBankCardEvent(_:)), for: .touchUpInside)
        _contentView.addSubview(_deleteButton)
      
        _addBTCButton.setTitle("+添加比特币卡", for: .normal)
        _addBTCButton.setTitleColor(.white, for: .normal)
        _addBTCButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        _addBTCButton.addTarget(self, action: #selector(addBankCardEvent(_:)), for: .touchUpInside)
        _addBTCButton.backgroundColor = UIColor.init(colorValue: 0x2B3034)
        _addBTCButton.isHidden = true
        self.addSubview(_addBTCButton)
    }
  
    private func flushDataView(){
      
      if dataModel == nil {
        _addBTCButton.isHidden = false
      }else{
        _addBTCButton.isHidden = true
      }
  
      _personNameLabel.text = dataModel?.accountName
      _btcNumberLabel.text = dataModel?.accountNo
    }
  
    private func initLayoutSubview()  {
        
        _contentView.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.top.bottom.equalToSuperview()
            
        }
        
        
        _logImageView.snp.makeConstraints { (make) in
            
            make.left.top.equalToSuperview().offset(15)
            make.width.equalTo(30)
            make.height.equalTo(44)
            
        }
        
        _btcNameLabel.snp.makeConstraints { (make) in
            
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(15)
            make.width.equalTo(50)
            make.height.equalTo(22)
        }
        
        _btcNumberLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-48)
            make.top.equalToSuperview().offset(69)
            make.height.equalTo(25)
        }
        
        
        _personNameLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(15)
            make.width.equalTo(150)
            make.bottom.equalToSuperview().offset(-26)
            make.height.equalTo(21)
            
        }
        
        
        _deleteButton.snp.makeConstraints { (make) in
            
            make.right.equalToSuperview()
            make.centerY.equalTo(_personNameLabel.snp.centerY)
            make.width.height.equalTo(45)
        }
        
        _addBTCButton.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.top.bottom.equalToSuperview()
            
        }
    }
  
  
    //MARK: 添加删除 button 事件
    @objc private func addBankCardEvent(_ sender:UIButton) {
      
      if (ManagerModel.instanse.personInfoModel?.realName?.count ?? 0) < 1  {
        
        //您没有绑定真实姓名，请先前往绑定实名认证。
        
        ProgressTopPopView.showPopViewCallBack(content: "您尚未完成个人资料认证请认证后再操作。", popStyle: .oneTitleConfirm, confirmTitle: "去认证")
        { [weak self] (isConfirm) in
          if isConfirm {
            let realNameVC = RealNameVertifyViewController()
            realNameVC.personInfoModel = ManagerModel.instanse.personInfoModel
            self?.nearNav()?.pushViewController(realNameVC, animated: true)
            realNameVC.callBackBlock = {
              self?.nearNav()?.pushViewController(AddBitCardViewController(), animated: true)
            }
          }
        }
        
      }else{
        self.nearNav()?.pushViewController(AddBitCardViewController(), animated: true)
      }
    }
    
    
    @objc private func deleteBankCardEvent(_ sender:UIButton) {
      
      if let viewCtr =  self.nearViewController() as? PersonInfoViewController {
        let cardCount =  viewCtr.modelNet.cardBitAccountArr.count + viewCtr.modelNet.cardAccountArr.count
        if cardCount == 1 {
          ProgressTopPopView.showPopView(content: "至少保留一张取款卡", popStyle: .errorMsgToast)
          return
        }
      } 
      ProgressTopPopView.showPopViewCallBack(content: "您是否删除比特币卡!", popStyle: .oneTitleConfirm, confirmTitle: "确定") { [weak self] (isConfirm) in
        if isConfirm {
          self?.netDeleteBitCard()
        }
      }
      
    }
  
  
  func netDeleteBitCard()  {
    
    
     LoadingView.showLoadingViewWith(to: self.nearViewController()?.view)
      PersonInfoModelNet().netBankCardDelete(dataModel!.netBitCardDeleteParam()) { [weak self ] (result, error) -> (Void) in
        LoadingView.hideLoadingView(for: self?.nearViewController()?.view)
        if error == nil {
          
          ProgressTopPopView.showPopView(content: "删除成功", popStyle: .successMsgToast)

          self?._addBTCButton.isHidden = false
          if let viewCtr =  self?.nearViewController() as? PersonInfoViewController{
            viewCtr.netLoadData(true)
          }
          
        }else {
          ProgressTopPopView.showPopView(content: error! , popStyle: .errorMsgToast)
        }
      }
    
  }
}
