//
//  PersonInfoStatusBriefCell.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonInfoStatusBriefCell: UITableViewCell {

    let titleLabel = UILabel()
    var subTitle:String? {
    
      didSet{
          subTitleLabel.text = subTitle
          self.setNeedsLayout()
      }
    }
  
    private let subTitleLabel = UILabel()
  
    let statusLabel = UILabel()
    let topLineView = UIView()
    private let _bottomLineView = UIView()
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        
        initUIProperty()
        initLayoutSubview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    override func layoutSubviews() {
      super.layoutSubviews()
      if subTitle != nil && subTitle!.count > 1 {
        
        titleLabel.x = 18
        titleLabel.y =  (self.heigth - (21*2 + 3))/2
        titleLabel.width = 120
        titleLabel.heigth = 21
        
        subTitleLabel.x = 18
        subTitleLabel.y = titleLabel.bottom + 3
        subTitleLabel.width = 120
        subTitleLabel.heigth = 21

      }else {
      
          titleLabel.x = 18
          titleLabel.y = 0
          titleLabel.width = 120
          titleLabel.heigth = self.heigth
      }
    }
  
    private func initUIProperty()  {
        
        self.backgroundColor = .clear
        self.selectionStyle = .none
      
        titleLabel.textColor = .white
        titleLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        self.contentView.addSubview(titleLabel)
      
        subTitleLabel.textColor = UIColor.init(hex: 0x888888)
        subTitleLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        subTitleLabel.backgroundColor = .clear
        self.contentView.addSubview(subTitleLabel)
      
        statusLabel.textColor = .white
        statusLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        statusLabel.textAlignment = .right
        self.contentView.addSubview(statusLabel)
        
        topLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        self.contentView.addSubview(topLineView)
        
        _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        self.contentView.addSubview(_bottomLineView)
        
    }
    
    private func initLayoutSubview()  {
        
        
        statusLabel.snp.makeConstraints { (make) in
            
            make.right.equalToSuperview().offset(-15)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(120)
        }
        
        topLineView.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(1)
        }
        
        _bottomLineView.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
}
