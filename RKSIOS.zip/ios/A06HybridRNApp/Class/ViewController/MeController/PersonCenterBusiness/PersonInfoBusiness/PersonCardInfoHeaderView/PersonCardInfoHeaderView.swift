//
//  PersonInfoTableViewHeaderView.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonCardInfoHeaderView: UIView {

  
    var dataModel:PersonInfoModelNet? {
      
      didSet{
        flushDataView()
      }
    }
  
    private let _myBankCardButton = UIButton()
    private let _myBitBCardButton = UIButton()
    private let _menuRedLineView = UIView()
    private let _gapLineView = UIView()

    private let _personCardMenuView = PersonCardListView() // 银行卡
    private let _myBitCardInfoView = MyBitCardInfoView() // 比特币卡
    

    fileprivate override init(frame: CGRect) {
        super.init(frame: frame)
        initUIProperty()
        initLayoutSubview()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    override func layoutSubviews() {
      
      super.layoutSubviews()
      
      if _menuRedLineView.gradientLayer == nil {
        _menuRedLineView.centerX = _myBankCardButton.centerX
        _menuRedLineView.bottom = _myBankCardButton.bottom
        _menuRedLineView.width = 100
        _menuRedLineView.heigth = 3
        _menuRedLineView.gradientInBottom(withVertical: false, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
      }
    }

    private func flushDataView(){
      
      // 银行卡卡信息更新
      _personCardMenuView.dataModel = dataModel?.cardAccountArr
      
      // 比特币卡信息更新
      if (dataModel?.cardBitAccountArr.count ?? 0) > 0 {
          _myBitCardInfoView.dataModel = dataModel?.cardBitAccountArr.first
          _myBitBCardButton.setTitle(String.init("我的比特币卡(1/1)"), for: .normal)
      }else{
          _myBitCardInfoView.dataModel = nil
          _myBitBCardButton.setTitle(String.init("我的比特币卡(0/1)"), for: .normal)
      }
      
      if (dataModel?.cardAccountArr.count ?? 0) > 0 {
          _myBankCardButton.setTitle(String.init(format: "我的银行卡(%d/3)", dataModel!.cardAccountArr.count) , for:  .normal)
      }else{
          _myBankCardButton.setTitle("我的银行卡(0/3)", for:  .normal)
      }
    }

    @objc func menuButtonEvent(_ sender:UIButton) {
        _menuRedLineView.cleanFrameStatus()
        UIView.animate(withDuration: 0.2) {
            self._menuRedLineView.centerX = sender.centerX
        }
        _myBitBCardButton.isSelected = false
        _myBankCardButton.isSelected = false
        sender.isSelected = true
      
        if  sender.tag == 0 {
            _personCardMenuView.isHidden = false
            _myBitCardInfoView.isHidden = true
            _myBitBCardButton.titleLabel?.font = UIFont.PingFangSCLight(ofSize: 16)
            _myBankCardButton.titleLabel?.font = UIFont.PingFangSCMedium(ofSize: 16)
        }else {
            _personCardMenuView.isHidden = true
            _myBitCardInfoView.isHidden = false
            _myBitBCardButton.titleLabel?.font = UIFont.PingFangSCMedium(ofSize: 16)
            _myBankCardButton.titleLabel?.font = UIFont.PingFangSCLight(ofSize: 16)
        }
    }
}


extension PersonCardInfoHeaderView {
  // initUI
  private func initUIProperty()  {
    _myBankCardButton.setTitle("我的银行卡(0/3)", for: .normal)
    _myBankCardButton.setTitleColor(.white, for: .selected)
    _myBankCardButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
    _myBankCardButton.addTarget(self, action: #selector(menuButtonEvent(_:)), for: .touchUpInside)
    _myBankCardButton.tag = 0
    _myBankCardButton.titleLabel?.font = UIFont.PingFangSCMedium(ofSize: 16)
    _myBankCardButton.contentHorizontalAlignment = .center
    _myBankCardButton.isSelected = true
    self.addSubview(_myBankCardButton)
    
    _myBitBCardButton.setTitle("我的比特币卡(0/1)", for: .normal)
    _myBitBCardButton.setTitleColor(.white, for: .selected)
    _myBitBCardButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
    _myBitBCardButton.addTarget(self, action: #selector(menuButtonEvent(_:)), for: .touchUpInside)
    _myBitBCardButton.tag = 1
    _myBitBCardButton.titleLabel?.font = UIFont.PingFangSCLight(ofSize: 16)
    _myBitBCardButton.contentHorizontalAlignment = .center
    self.addSubview(_myBitBCardButton)
    
    _gapLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
    
    self.addSubview(_gapLineView)
    self.addSubview(_menuRedLineView)
    self.addSubview(_personCardMenuView)
    
    _myBitCardInfoView.isHidden = true
    _myBitCardInfoView.clipsToBounds = true
    self.addSubview(_myBitCardInfoView)
  }
  // LayoutUI
  private func initLayoutSubview()  {
    _myBankCardButton.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(5)
      make.top.equalToSuperview()
      make.height.equalTo(44)
    }
    _myBitBCardButton.snp.makeConstraints { (make) in
      make.left.equalTo(_myBankCardButton.snp.right).offset(10)
      make.top.equalToSuperview()
      make.height.equalTo(44)
    }
    _gapLineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(_myBankCardButton.snp.bottom)
      make.height.equalTo(1)
    }
    _personCardMenuView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalToSuperview().offset(44)
      make.bottom.equalToSuperview()
    }
    _myBitCardInfoView.snp.makeConstraints { (make) in
      make.centerX.equalToSuperview()
      make.width.equalTo(275)
      make.top.equalTo(_personCardMenuView.snp.top).offset(27)
      make.height.equalTo(150)
    }
  }
}
