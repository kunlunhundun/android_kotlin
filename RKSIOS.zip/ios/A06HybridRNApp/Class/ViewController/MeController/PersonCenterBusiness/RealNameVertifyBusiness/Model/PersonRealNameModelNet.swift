//
//  PersonRealNameModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class PersonRealNameModelNet: NSObject {
  // 实名认证
  func netRealName(_ param:[String:Any] , _ completion:@escaping NetFinish)  {
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.realName.rawValue, parameters: param) { (result, error, isCache) in
      completion(nil, error?.errorDesc)
    }
  }
}
