//
//  PersonBottomMenuButton.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class BottomMenuButton: UIButton {

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setTitleColor(.white, for: .normal)
        self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        self.contentHorizontalAlignment = .left

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        let startX = (self.width - 50)/2
        
        self.imageView?.x = startX
        self.imageView?.centerY = self.heigth/2
        self.imageView?.width = 20
        self.imageView?.heigth = 20
       
        
        self.titleLabel?.x = self.imageView!.right + 5
        self.titleLabel?.centerY = self.heigth/2
        self.titleLabel?.width = 30
        self.titleLabel?.heigth = 20
    
      
      if self.messageCountLabel.superview == nil {
        
          if self.messageCountLabel.text == nil {
            self.messageCountLabel.isHidden = true
          }
        
          self.messageCountLabel.centerY = self.imageView!.y + 1
          self.messageCountLabel.centerX = self.imageView!.right
          self.addSubview(self.messageCountLabel)
      }
    }
  
  func messageCount(count:String) {
  
      self.messageCountLabel.text = count
      if Int(count) == 0 {
        self.messageCountLabel.isHidden = true
      }else{
        self.messageCountLabel.isHidden = false
        if Int(count)! > 99 {
          self.messageCountLabel.text = "..."
        }
      }
  }
  
  fileprivate lazy var messageCountLabel: UILabel = {
    
    let label = UILabel()
    label.x = 0
    label.y = 0
    label.width = 15
    label.heigth = 15
    
    label.layer.cornerRadius = label.width/2
    label.backgroundColor = UIColor.init(hex: 0xF43E5A)
    label.textAlignment = .center
    label.clipsToBounds = true
    label.textColor = .white
    label.font = UIFont.SFProDisplayRegular(ofSize: 10)
    
    return label
    
  }()
}
