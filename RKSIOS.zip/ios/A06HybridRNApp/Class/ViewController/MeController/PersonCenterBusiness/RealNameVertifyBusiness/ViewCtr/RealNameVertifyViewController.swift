//
//  RealNameVertifyViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class RealNameVertifyViewController: UIViewController, CaseyTableViewDelegate, BankInfoEditCelllDelegate{
  
    var personInfoModel:PersonInfoModel?
    let _implyDescLabel = UILabel()
    let _commitButton = UIButton()
    var callBackBlock:(()->Void)?
  
    private let _readNameCell = BankInfoEditCell(.ContentRealNameVerify)
    private let _birthdayDateCell = BankInfoEditCell()
    private let _sexCell = BankInfoEditCell()
    
    private var _tableView : CaseyTableView?
 
    var currentEditingTextFiled: UITextField?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "实名认证"
        initUIProperty()
        initLayoutSubview()
    }
  
    override func viewDidLayoutSubviews() {
      super.viewDidLayoutSubviews()
      if _commitButton.gradientLayer == nil {
        
        if (self.personInfoModel?.birthday?.count ?? 0) > 0 { // 已经实名了
          _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0x2C2E38), endGdColor: UIColor.init(colorValue: 0x2C2E38))
          _commitButton.setTitleColor(UIColor.init(hex: 0x888888), for: .normal)
          _commitButton.isHidden = true
        }else{
          _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
          _commitButton.setTitleColor(.white, for: .normal)
          _commitButton.isHidden = false
        }
      }
    }
  
    private func initUIProperty()    {
        
        _readNameCell.contentTextField.isEnabled = true
        _readNameCell.cellStyle(.baseStyle)
        _readNameCell.titleLabel.text = "真实姓名"
        _readNameCell.contentTextField.placeholder = "请输入姓名"
        _readNameCell.contentTextField.isEnabled = false
        _readNameCell.delegate = self
      
        _birthdayDateCell.titleLabel.text = "出生日期"
        _birthdayDateCell.contentTextField.placeholder = "请选择出生日期"
        _birthdayDateCell.contentTextField.isEnabled = false
        _birthdayDateCell.cellStyle(.arrowRightStyle)
    
        _sexCell.titleLabel.text = "性别"
        _sexCell.contentTextField.placeholder = "请选择性别"
        _sexCell.contentTextField.isEnabled = false
        _sexCell.cellStyle(.arrowRightStyle)
      
        if (self.personInfoModel?.birthday?.count ?? 0) > 0 {
          
          _readNameCell.contentTextField.text = self.personInfoModel?.realName!
          _birthdayDateCell.contentTextField.text = self.personInfoModel?.birthday ?? "******"
          
          if self.personInfoModel?.gender == "M"{
            _sexCell.contentTextField.text = "男"
          }else{
            _sexCell.contentTextField.text = "女"
          }
          
          _birthdayDateCell.cellStyle(.baseStyle)
          _sexCell.cellStyle(.baseStyle)
          
        }else {
          
          if self.personInfoModel?.gender == "M"{
            _sexCell.contentTextField.text = "男"
          }else{
            _sexCell.contentTextField.text = "女"
          }
          
          if (self.personInfoModel?.realName?.count ?? 0) > 0 {
             _readNameCell.contentTextField.text = self.personInfoModel?.realName!
             _readNameCell.contentTextField.isEnabled = false
          }else{
            _readNameCell.contentTextField.isEnabled = true
          }
        }
      
        _implyDescLabel.backgroundColor = UIColor.init(colorValue: 0x262B2E)
        _implyDescLabel.text = "修改个人资料请联系客服"
        _implyDescLabel.textAlignment = .center
        _implyDescLabel.textColor = UIColor.init(colorValue: 0xDABF94)
        _implyDescLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        self.view.addSubview(_implyDescLabel)
        
        _tableView = CaseyTableView()
        _tableView?.cyDelegate = self
        self.view.addSubview(_tableView!)
      
        _commitButton.backgroundColor = UIColor.init(colorValue: 0x2C2E38)
        _commitButton.setTitle("提交认证", for: .normal)
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        _commitButton.layer.cornerRadius = 8
        _commitButton.addTarget(self, action: #selector(commitEvent(_:)), for: .touchUpInside)
        _commitButton.clipsToBounds = true
        self.view.addSubview(_commitButton)
    }
    
    private func initLayoutSubview()    {
        _implyDescLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(30)
        }
        _tableView?.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(30)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        _commitButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(64*3+80)
            make.height.equalTo(54)
        }
    }
  
    // 信息未提示信息
    func checkInfoIsValid() -> String? {
      
      if (self.personInfoModel?.realName?.count ?? 0) > 0 {
        
      }else{
        if let errorImply =  _readNameCell.checkContentInfo() {
          _tableView?.reloadData()
          return errorImply
        }
      }
      if _birthdayDateCell.contentTextField.text?.count == 0 {
          ProgressTopPopView.showPopView(content: _birthdayDateCell.contentTextField.placeholder ?? "" , popStyle: .errorMsgToast)
          return _birthdayDateCell.contentTextField.placeholder
      }
      if _sexCell.contentTextField.text?.count == 0 {
          ProgressTopPopView.showPopView(content: _sexCell.contentTextField.placeholder ?? "" , popStyle: .errorMsgToast)
          return _sexCell.contentTextField.placeholder
      }
      return nil
    }
  
  
    //MARK: 提交事件
    @objc func commitEvent(_ sender:UIButton){
        if (self.personInfoModel?.birthday?.count ?? 0) > 0 { // 已经实名了
          return
        }
        if let _ = checkInfoIsValid() {
            return
        }
        netReadName()
    }
    
    //MARK: tableview delegate
    func tableView(_ tableView: CaseyTableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: CaseyTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
          return _readNameCell.cellHeight
        }else {
          return 64
        }
    }
    
    func tableView(_ tableView: CaseyTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            return _readNameCell
        }else if indexPath.row == 1 {
            return _birthdayDateCell
        }else {
            return _sexCell
        }
    }
    
    func tableView(_ tableView: CaseyTableView, didSelectRowAt indexPath: IndexPath) {
        
        _readNameCell.contentTextField.resignFirstResponder()
      
        if (self.personInfoModel?.birthday?.count ?? 0) > 0 { // 已经实名了
            return
        }
      
        if indexPath.row == 1 { // 出生日期
            
            
            let datePickerView =  CaseyDatePicker()
            datePickerView.showDatePicker(true) { (reslut) -> (Void) in
              
              
              var dateStr = reslut.first
              
              for index in 1...reslut.count-1 {
                
                dateStr?.append(String.init(format: "-%02d", Int(reslut[index])!))
                
              }
              
              self._birthdayDateCell.contentTextField.text =  dateStr
              
            }
            
            
        }else if indexPath.row == 2 { // 性别
            
        
            let datePickerView =  CaseyDatePicker()
            datePickerView.dataArr = [["男", "女"]]
            datePickerView.showDatePicker(true) { (reslut) -> (Void) in
                
                self._sexCell.contentTextField.text = reslut.first
              
            }
        }else{
            
        }
    }
  
  
  
    //MARK: network
    func netReadName()  {
      
      var cardInfo = [String:String]()
      cardInfo["birth"] =  _birthdayDateCell.contentTextField.text
      
      if (self.personInfoModel?.realName?.count ?? 0) > 0 {
        cardInfo["realName"] = ""
      }else{
        cardInfo["realName"] = _readNameCell.contentTextField.text
      }
      
      if _readNameCell.contentTextField.text == "男" {
        cardInfo["gender"] = "M"
      }else {
        cardInfo["gender"] = "F"
      }
      
      LoadingView.showLoadingViewWith(to: self.view)
      PersonRealNameModelNet().netRealName(cardInfo) { [weak self] (result, errorDesc) -> (Void) in
        
        LoadingView.hideLoadingView(for: self?.view)
        if errorDesc != nil {
          ProgressTopPopView.showPopView(content: errorDesc! , popStyle: .errorMsgToast)
        }else {
          
          if let _ = self?.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
            // PersonInfoViewController界面直接本地更新(结合viewWillAppear)，不进行网络请求。个人信息界面没有直接提供刷新手机号，实名状态的接口
            if let realNameStr = cardInfo["realName"] as NSString? {
              
              if realNameStr.length == 2 {
                  self?.personInfoModel?.realName = "*" + realNameStr.substring(from: realNameStr.length - 1)
              }else if realNameStr.length == 3 {
                  self?.personInfoModel?.realName = "**" + realNameStr.substring(from: realNameStr.length - 1)
              }else {
                if realNameStr.length > 1 {
                  self?.personInfoModel?.realName = "***" + realNameStr.substring(from: realNameStr.length - 1)
                }
              }
            }
            self?.personInfoModel?.gender = cardInfo["gender"]
            self?.personInfoModel?.birthday = cardInfo["birth"]
          }
          
          if let targetViewCtr = self?.navigationController?.searchNearViewController(targerClass: PersonCenterViewController.classForCoder()) {
            targetViewCtr.isFlushView = .FlushByNoShowLoading
          }
          ProgressTopPopView.showPopView(content: "实名认证成功", popStyle: .successMsgToast)
          self?.callBackBlock?()
          self?.navigationController?.popViewController(animated: true)
        }
      }
    }
}
