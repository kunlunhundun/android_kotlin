//
//  KLTabBarViewCtroller.swift
//  A06KSEntireGame
//
//  Created by kunlun on 2018/11/2.
//  Copyright © 2018年 kunlun. All rights reserved.
//

import Foundation
import UIKit


class MainTabBarViewCtroller: UITabBarController {
  
    var pageHomeViewNav:BaseNavigationController!
    var messageButton:BottomMenuButton?
  
  
    override func viewDidLoad() {
      
      let homeRNVC = ManagerModel.instanse.homePageVC ?? HomeRNViewController()
       ManagerModel.instanse.homePageVC = homeRNVC
      
       pageHomeViewNav = BaseNavigationController.init(rootViewController: homeRNVC)
      
      let messageViewNav = BaseNavigationController.init(rootViewController: CustomerServeViewController())
      
      let customerViewNav = BaseNavigationController.init(rootViewController: CustomerServeViewController())
      let personCenterVC = PersonCenterViewController()
      let settingViewNav =  BaseNavigationController.init(rootViewController: personCenterVC)
      
      self.viewControllers = [pageHomeViewNav, messageViewNav, customerViewNav, settingViewNav]
      messageButton = _bottomMenuView.viewWithTag(1) as? BottomMenuButton
    }

  override func viewDidAppear(_ animated: Bool) {
      super.viewDidAppear(animated)
  
      if _bottomMenuView.superview == nil {
        
        for view in self.tabBar.subviews {
          view.isHidden = true
        }
      
        _bottomMenuView.x = 0
        _bottomMenuView.y = 0
        _bottomMenuView.width = self.tabBar.width
        _bottomMenuView.heigth = self.tabBar.heigth
        _bottomMenuView.isUserInteractionEnabled = true
        self.tabBar.addSubview(_bottomMenuView)
      }
  }
  
  func showHidenTabbar(isHiden:Bool){
    self.tabBar.isHidden = isHiden
    _bottomMenuView.isHidden = isHiden
  }
  
  private let _bottomMenuView:UIView = {
    
    let menuArr = [("首页", "首页.png"),("消息", "消息.png"),("客服", "客服.png"),("更多", "tab_more.png")]
    let buttonWidth = SCREEN_WIDTH/CGFloat(menuArr.count)
    
    let menuView = UIView()
    menuView.backgroundColor = UIColor.init(colorValue: 0x141723)
    
    for index in 0...menuArr.count-1 {
      
      let (title, imageName) = menuArr[index]
      
      let menuButton = BottomMenuButton()
      menuButton.setTitle(title, for: .normal)
      menuButton.setImage(UIImage.init(named: imageName), for: .normal)
      menuButton.tag = index
      menuButton.addTarget(self, action: #selector(menuButtonEvent(_:)), for: .touchUpInside)
      menuView.addSubview(menuButton)
      
      menuButton.snp.makeConstraints { (make) in
        make.top.equalToSuperview()
        make.bottom.equalToSuperview()
        make.left.equalTo(CGFloat(index)*buttonWidth)
        make.width.equalTo(buttonWidth)
      }
    }
    return menuView
  }()
  
  @objc func menuButtonEvent(_ sender:UIButton) {
    
    if sender.tag == 1 {
      
      if ManagerModel.instanse.loginSuccessModel == nil {
        //ProgressTopPopView.showPopView(content: "请先登录", popStyle: .errorMsgToast)
        ReactInteraction.shareInstance()?.login()
        return
      }
      
      if pageHomeViewNav.viewControllers.count > 1 {
        ManagerModel.jumpRNPage(pageName: RNPageMessage, needBack: false,isNewVC: true)
      }else{
        ManagerModel.jumpRNPage(pageName: RNPageMessage, needBack: true)
      }
      return
    }
    if sender.tag == 2 {
      CustomerServePopView.showPopView()
      return;
    }
    if sender.tag == 3 {
      SetBottomPopView.showPopView()
      return
    }
    if sender.tag == 0 {
      
      if pageHomeViewNav.viewControllers.count > 1 {
        ManagerModel.jumpRNPage(pageName: RNPageHome, needBack: true)
        self.pageHomeViewNav?.popToRootViewController(animated: true)
      
//        ManagerModel.jumpRNPage(pageName: RNPageHome, needBack: false,isNewVC: true)
//        DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+1) {
//          ManagerModel.shareInstanse().showHidenTabbar(true)
//        }
        
      }else{
        ManagerModel.jumpRNPage(pageName: RNPageHome, needBack: true)
      }
    }
    self.selectedIndex = sender.tag
  }
}
