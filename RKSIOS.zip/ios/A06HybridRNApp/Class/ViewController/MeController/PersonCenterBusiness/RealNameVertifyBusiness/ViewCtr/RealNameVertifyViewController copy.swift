//
//  RealNameVertifyViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class RealNameVertifyViewController: UIViewController, UITableViewDelegate, UITableViewDataSource , BankInfoEditCelllDelegate{
    
    var personInfoModel:PersonInfoModel?
    let _implyDescLabel = UILabel()
    let _commitButton = UIButton()
  
    private let _readNameCell = BankInfoEditCell()
    private let _birthdayDateCell = BankInfoEditCell()
    private let _sexCell = BankInfoEditCell()
    
    private var _tableView : UITableView?
 
    var currentEditingTextFiled: UITextField? {
      
      didSet{
        checkCommitButtonStatus()
      }
    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "实名认证"
        initUIProperty()
        initLayoutSubview()
        
    }
    
    private func initUIProperty()    {
        
        _readNameCell.contentTextField.isEnabled = true
        _readNameCell.cellStyle(.baseStyle)
        _readNameCell.titleLabel.text = "真实姓名"
        _readNameCell.contentTextField.placeholder = "请输入姓名"
        _readNameCell.delegate = self
      
        _birthdayDateCell.titleLabel.text = "出生日期"
        _birthdayDateCell.contentTextField.placeholder = "请选择出生日期"
        _birthdayDateCell.contentTextField.isEnabled = false
        _birthdayDateCell.cellStyle(.arrowDownStyle)
    
        _sexCell.titleLabel.text = "性别"
        _sexCell.contentTextField.placeholder = "请选择性别"
        _sexCell.contentTextField.isEnabled = false
        _sexCell.cellStyle(.arrowDownStyle)
        
        
        _implyDescLabel.backgroundColor = UIColor.init(colorValue: 0x262B2E)
        _implyDescLabel.text = "修改个人资料请联系客服"
        _implyDescLabel.textAlignment = .center
        _implyDescLabel.textColor = UIColor.init(colorValue: 0xDABF94)
        _implyDescLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        self.view.addSubview(_implyDescLabel)
        
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView!.register(BankInfoEditCell.classForCoder(), forCellReuseIdentifier: "BankInfoEditCell")
        self.view.addSubview(_tableView!)
      
        
        _commitButton.backgroundColor = UIColor.init(colorValue: 0x2C2E38)
        _commitButton.setTitle("提交认证", for: .normal)
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        _commitButton.layer.cornerRadius = 8
        _commitButton.addTarget(self, action: #selector(commitEvent(_:)), for: .touchUpInside)
        _commitButton.clipsToBounds = true
        self.view.addSubview(_commitButton)
        
    }
    
    private func initLayoutSubview()    {
        
        
        _implyDescLabel.snp.makeConstraints { (make) in
            
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(30)
        }
        
        _tableView?.snp.makeConstraints { (make) in
            
            make.top.equalToSuperview().offset(30)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        _commitButton.snp.makeConstraints { (make) in
            
            
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.bottom.equalToSuperview().offset(-53)
            make.height.equalTo(54)
        }
    }
    
    // MARK: 检查内容
  
    func checkCommitButtonStatus()  {
      
      if let _ = implyInfoStr() {
        
        _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0x2C2E38), endGdColor: UIColor.init(colorValue: 0x2C2E38))
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        
      }else {
        
        _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
        _commitButton.setTitleColor(.white, for: .normal)
      }
      
    }
  
    // 信息未提示信息
    func implyInfoStr() -> String? {
      
      if _readNameCell.contentTextField.text?.count == 0 {
        
        return _readNameCell.contentTextField.placeholder
      }
      if _birthdayDateCell.contentTextField.text?.count == 0 {
        
        return _birthdayDateCell.contentTextField.placeholder
      }
      if _sexCell.contentTextField.text?.count == 0 {
        
        return _sexCell.contentTextField.placeholder
      }
      return nil
    }
  
    //MARK: 提交事件
    @objc func commitEvent(_ sender:UIButton){
      
        if let implyInfo = implyInfoStr() {
          
          print(implyInfo)
          return
        }
        netReadName()
      
    }
    
    //MARK: tableview delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 3
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
      
        if indexPath.row == 0 {
          return _readNameCell.cellHeight
        }else {
          return 64
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            return _readNameCell
        }else if indexPath.row == 1 {
            return _birthdayDateCell
        }else {
            return _sexCell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        _readNameCell.contentTextField.resignFirstResponder()
        
        if indexPath.row == 1 { // 出生日期
            
            
            let datePickerView =  CaseyDatePicker()
            datePickerView.showDatePicker(true) { (reslut) -> (Void) in
              
              
              var dateStr = reslut.first
              
              for index in 1...reslut.count-1 {
                
                dateStr?.append(String.init(format: "-%02d", Int(reslut[index])!))
                
              }
              
              self._birthdayDateCell.contentTextField.text =  dateStr
              self.checkCommitButtonStatus()
            }
            
            
        }else if indexPath.row == 2 { // 性别
            
        
            let datePickerView =  CaseyDatePicker()
            datePickerView.dataArr = [["男", "女"]]
            datePickerView.showDatePicker(true) { (reslut) -> (Void) in
                
                self._sexCell.contentTextField.text = reslut.first
                self.checkCommitButtonStatus()
            }
            
            
        }else{
            
        }
        
        
    }
  
  
  
    //MARK: network
    func netReadName()  {
      
      var cardInfo = [String:String]()
      cardInfo["birth"] =  _birthdayDateCell.contentTextField.text
      cardInfo["realName"] = _readNameCell.contentTextField.text
      if _readNameCell.contentTextField.text == "男" {
        cardInfo["gender"] = "M"
      }else {
        cardInfo["gender"] = "F"
      }
      
      LoadingView.showLoadingViewWith(to: self.view)
      PersonRealNameModelNet().netRealName(cardInfo) { (result, errorDesc) -> (Void) in
        
        
        if errorDesc != nil {
          
          CaseyImplyAlertView.shareInstance().showFinishErrorImply(errorDesc!)
          
        }else {
          
          if let _ = self.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
            // PersonInfoViewController界面直接本地更新(结合viewWillAppear)，不进行网络请求。个人信息界面没有直接提供刷新手机号，实名状态的接口
            self.personInfoModel?.realName = cardInfo["realName"]
          }
          if let targetViewCtr = self.navigationController?.searchNearViewController(targerClass: PersonCenterViewController.classForCoder()) {
            
            targetViewCtr.isFlushView = .FlushByNoShowLoading
          }
          
          CaseyImplyAlertView.shareInstance().showFinishImply("实名认证成功")
          self.navigationController?.popViewController(animated: true)
        }
        
      }
      
      LoadingView.hideLoadingView(for: self.view)
      
      
    }

}

