//
//  KLNavigationController.swift
//  A06KSEntireGame
//
//  Created by kunlun on 2018/11/2.
//  Copyright © 2018年 kunlun. All rights reserved.
//

import UIKit

class BaseNavigationController: UINavigationController, UINavigationControllerDelegate, UIGestureRecognizerDelegate {
  

    override func viewDidLoad() {
        
      super.viewDidLoad()
    
      // self.view.backgroundColor = UIColor.black
      let backBarView = UIView.init(frame: CGRect.init(origin: CGPoint.zero, size: CGSize.init(width: SCREEN_WIDTH, height: STATUS_NAV_BAR_Y)))
      backBarView.gradient(withVertical: true, startGdColor: UIColor.init(colorValue: 0x29323A), endGdColor: UIColor.init(colorValue: 0x272F36))
      let shotImage = UIImageTools.screenshotsView(backBarView)
      
      self.navigationBar.setBackgroundImage(shotImage, for: .any, barMetrics: .default)
      self.navigationBar.shadowImage = UIImage()
      
      self.navigationBar.barTintColor = UIColor.white
      self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white, NSAttributedString.Key.font:UIFont.PingFangSCMedium(ofSize: 18)]
      self.navigationBar.tintColor = UIColor.white
    }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
  }

  func preferredStatusBarStyle() -> UIStatusBarStyle {
      return  .lightContent
  }
  
  func prefersStatusBarHidden() -> Bool {
    return  false
  }
  
  //MARK: 重写跳转
  override func pushViewController(_ viewController: UIViewController, animated: Bool) {
    
    if self.viewControllers.count>0 {
      if viewController.isKind(of: PersonCenterViewController.classForCoder()) {
        
      }else{
        viewController.hidesBottomBarWhenPushed = true //跳转之后隐藏
      }
    }
    super.pushViewController(viewController, animated: true)
    self.hidesBottomBarWhenPushed = true
  }
  
  
  override func popViewController(animated: Bool) -> UIViewController? {
//    if  self.viewControllers.count == 2 {
//      self.hidesBottomBarWhenPushed = false
//    }
    return super.popViewController(animated: animated)
  }
  
  
  
  //MARK: UINavigationControllerDelegate
  
  func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
    
    if self.interactivePopGestureRecognizer != nil{
      
      self.interactivePopGestureRecognizer?.delegate = self
      self.interactivePopGestureRecognizer?.isEnabled = true
      
    }
    
    
    if self.viewControllers.count == 1{
      
      self.interactivePopGestureRecognizer?.isEnabled = false
      self.interactivePopGestureRecognizer?.delegate = nil
      
    }
    
  }
  
  //MARK: 获取导航栏底部黑色线
  func findHairlineImageViewUnder(_ view:UIView) -> UIImageView? {
    
    if view.isKind(of: UIImageView.classForCoder()) && view.bounds.size.height <= 1.0 {
        return view as? UIImageView
    }
    
    for subView in view.subviews {
      
      if let imageView = self.findHairlineImageViewUnder(subView){
        return imageView
      }
    }
    return nil
  }
}


extension UINavigationController {
  
  func popToViewControllerOfClassName(classType:AnyClass, animated:Bool) {
    
    let viewCtrArr = self.viewControllers
    for viewCtr in viewCtrArr {
    
      if classType == viewCtr.classForCoder {
          self.popToViewController(viewCtr, animated: animated)
      }
    }
  }
  
  func searchNearViewController(targerClass:AnyClass) -> UIViewController?{
    let viewCtrArr = self.viewControllers
    for viewCtr in viewCtrArr {

      if targerClass == viewCtr.classForCoder {
            return viewCtr
      }
    }
    return nil
  }
  
}
