//
//  BaseViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/8.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

  var backBtn:UIButton! = nil
  var rightBtn:UIButton! = nil
    override func viewDidLoad() {
        super.viewDidLoad()

  
      self.view.gradient(withVertical: true, startGdColor: UIColor.init(colorValue: 0x272F36), endGdColor: UIColor.init(colorValue: 0x0D0F12))
      
      if let count = self.navigationController?.viewControllers.count {
        if count > 1 {
          setupLeftBackBtn()
        }
      }
      
    }
  

  func setupLeftBackBtn(){
    
    backBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 44))
    backBtn.contentHorizontalAlignment = .left
    backBtn.addTarget(self, action: #selector(backAction), for: .touchUpInside)
    backBtn.setImage(UIImage.init(named: "navBackArrow"), for: .normal)
    
    let barBtnView = UIView.init(frame: backBtn.bounds)
    barBtnView.addSubview(backBtn)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.leftBarButtonItem  = barButtonItem
    
  }
  
  func setupRightBtn(){
    
    rightBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 70, height: 44))
    rightBtn.contentHorizontalAlignment = .right
    rightBtn.setTitle("在线客服", for: .normal)
    rightBtn.addTarget(self, action: #selector(rightAction), for: .touchUpInside)
    rightBtn.isHidden = true
    let barBtnView = UIView.init(frame: rightBtn.bounds)
    barBtnView.addSubview(rightBtn)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.leftBarButtonItem  = barButtonItem
    
  }
  
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
  }
  
  @objc func rightAction() {
    
    let customerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: false)
    self.navigationController?.pushViewController(customerOnlineVC, animated: true)
  }
  
  @objc func backAction(){
    
    self.navigationController?.popViewController(animated: true)
    
  }
  
  deinit {
    print("deinit-->\(self.classForCoder)")
  }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
