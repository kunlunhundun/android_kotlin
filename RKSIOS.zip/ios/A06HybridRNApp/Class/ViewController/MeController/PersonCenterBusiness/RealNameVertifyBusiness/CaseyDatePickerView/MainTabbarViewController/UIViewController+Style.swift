//
//  UIViewController+Style.swift
//  A06HybridRNApp
//
//  Created by Casey on 19/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit


enum ViewFlushFlag:Int {
  case NoFlush = 0 // 不刷新
  case FlushByNoShowLoading = 1 // 刷新不显示loading view 即使用下拉刷新风格
  case FlushByShowLoading = 2 // 刷新显示 loading View

}


/*
 界面刷新机制
 */
@objc protocol flushViewProtocol {
  
     @objc func viewWillAppearFlushView(_ status:Int)
  
}


extension UIViewController: flushViewProtocol {
  
  
   public static func initializeOfSwift() {
    
      exchangeMethod()
    
  }
  
  
/*  static func swizzleViewWillAppear() {
    if self != UIViewController.self {
      return
    }
    let _: () = {
      let originalSelector = #selector(UIViewController.delete(_:))
      let swizzledSelector = #selector(UIViewController.newDeinit)
      let originalMethod = class_getInstanceMethod(self, originalSelector)
      let swizzledMethod = class_getInstanceMethod(self, swizzledSelector)
      method_exchangeImplementations(originalMethod!, swizzledMethod!);
    }()
  }
  
  @objc fileprivate func newViewWillAppear (_ animated: Bool){
    
  }
  @objc fileprivate func newDeinit() {
    
    print("deinit-->\(self.classForCoder)")
  } */
  
  
  var isFlushView:ViewFlushFlag {
    
    get {
      
      let key:UnsafePointer<String>! = UnsafePointer.init(bitPattern: "_isFlushView".hashValue)
      
      if let number =  objc_getAssociatedObject(self, key) as? NSNumber {
        
        
          return ViewFlushFlag.init(rawValue: number.intValue) ?? .NoFlush
        
      }else {
        
          return .NoFlush
      }
      
    }set{
      
        let key:UnsafePointer<String>! = UnsafePointer.init(bitPattern: "_isFlushView".hashValue)
        let number = NSNumber.init(value: newValue.rawValue)
        objc_setAssociatedObject(self, key, number, .OBJC_ASSOCIATION_RETAIN)
    }
    
  }
  
  
  static func exchangeMethod()  {
    
    if let methodOrigin = class_getInstanceMethod(self, #selector(viewDidLoad)) {
      
      
      if let methodTarget = class_getInstanceMethod(self.classForCoder(), #selector(viewDidLoadOfStyle)){
      
          method_exchangeImplementations(methodOrigin, methodTarget)
        
      }
    }
    
    if let methodOrigin = class_getInstanceMethod(self.classForCoder(), #selector(viewWillAppear(_:))) {
     
      
      if let methodTarget = class_getInstanceMethod(self.classForCoder(), #selector(viewWillAppearOfStyle)){
        
        method_exchangeImplementations(methodOrigin, methodTarget)
        
      }
    }

    
  }
  
  
  @objc fileprivate  func viewDidLoadOfStyle() {
    
    
      if self.isKind(of: UINavigationController.classForCoder()) {
        
        self.viewDidLoadOfStyle()
        return
      }
    
    
    if self.classForCoder == UIAlertController.classForCoder() {
      return
    }
    
      self.view.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0x272F36), endGdColor: UIColor.init(colorValue: 0x0D0F12))
    
      let backBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 44))
      backBtn.contentHorizontalAlignment = .left
      backBtn.addTarget(self, action: #selector(navBackAction), for: .touchUpInside)
      backBtn.setImage(UIImage.init(named: "navBackArrow"), for: .normal)
    
      let barBtnView = UIView.init(frame: backBtn.bounds)
      barBtnView.addSubview(backBtn)
      let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
      self.navigationItem.leftBarButtonItem  = barButtonItem

      self.viewDidLoadOfStyle()
    
  }
  
  
   @objc fileprivate func viewWillAppearOfStyle(_ animated: Bool) {
    
    if self.isFlushView != .NoFlush {
      
        viewWillAppearFlushView(self.isFlushView.rawValue)
        self.isFlushView = .NoFlush
    }
    
    if !(self.isKind(of: PersonCenterViewController.classForCoder()) || self.isKind(of: HomeRNViewController.classForCoder()) ){
      ManagerModel.instanse.showHidenTabbar(false)
    }
    
    self.viewWillAppearOfStyle(animated)
    
  }
  

  @objc func navBackAction(){
      
      self.navigationController?.popViewController(animated: true)
      
  }
  
  func viewWillAppearFlushView(_ status: Int) {
    
   

      
  }
  

  
}
