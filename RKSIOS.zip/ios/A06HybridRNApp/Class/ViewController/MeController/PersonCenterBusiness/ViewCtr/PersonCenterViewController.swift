//
//  PersonCenterViewController.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit


class PersonCenterViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var isFromHomePage:Bool = false
    private let modelNet = PersonCenterModelNet()
    private let _scrollView = UIScrollView()
    private var _tableView : UITableView?
    private let _personInfoTableHeadView = PersonCenterTableViewHeaderView() //  个人信息View
    private var sectionCount = 0
  
    var versionView:UIView = UIView()
  
  
    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.navigationItem.title = "个人中心"
        self.navigationItem.leftBarButtonItem = nil
    
        if isFromHomePage {
          self.setLeftNavBtn()
        }
        initUIProperty()
        initLayoutSubview()
        
        netLoadData(false)
        ManagerModel.shareInstanse().showHidenTabbar(true)
      
        setversionview()
      
      
    }
    override func viewWillAppearFlushView(_ status: Int) {
      super.viewWillAppearFlushView(status)
      netLoadData(true)
    }
    override func viewWillAppear(_ animated: Bool) {
      
    }
    override func viewDidAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      ManagerModel.shareInstanse().showHidenTabbar(true)
    }
    private func setversionview() {
      versionView.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 26)
      versionView.backgroundColor = .clear
      let label = UILabel()
      label.font = UIFont.systemFont(ofSize: 13)
      label.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 13)
      label.backgroundColor = .clear
      label.textColor = UIColor.init(colorValue: 0x24282C)
      let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
      label.textAlignment = .center
      label.text = "版本号:" + currentVersion
      versionView.addSubview(label)
      _tableView?.tableFooterView = versionView
    }
}

// MARK: 私有方法
extension PersonCenterViewController {
  func setLeftNavBtn(){
    let backBtn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 44))
    backBtn.contentHorizontalAlignment = .left
    backBtn.addTarget(self, action: #selector(leftNavBackAction), for: .touchUpInside)
    backBtn.setImage(UIImage.init(named: "navBackArrow"), for: .normal)
    
    let barBtnView = UIView.init(frame: backBtn.bounds)
    barBtnView.addSubview(backBtn)
    let barButtonItem = UIBarButtonItem.init(customView: barBtnView)
    self.navigationItem.leftBarButtonItem  = barButtonItem
  }
  
  @objc func leftNavBackAction(){
    ManagerModel.jumpRNPage(pageName: RNPageHome, needBack: false)
    DispatchQueue.main.asyncAfter(wallDeadline: DispatchWallTime.now()+0.2) {
      self.navigationController?.popViewController(animated: true)
    }
  }
}

// MARK: setUI
extension PersonCenterViewController {
  
  private func initUIProperty() {
    _personInfoTableHeadView.x = 0
    _personInfoTableHeadView.y = 0
    _personInfoTableHeadView.width = SCREEN_WIDTH
    _personInfoTableHeadView.heigth = 199
    _tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
    _tableView?.estimatedRowHeight = 0
    _tableView!.delegate = self
    _tableView!.dataSource = self
    _tableView!.backgroundColor = .clear
    _tableView!.separatorStyle = .none
    _tableView!.tableHeaderView = _personInfoTableHeadView
    self.view.addSubview(_tableView!)
    weak var weakSelf = self
    _tableView?.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
      weakSelf?.netLoadData(false)
    })
  }
  
  private func initLayoutSubview() {
    _tableView?.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.left.right.equalToSuperview()
      make.bottom.equalToSuperview()
    }
  }
}

// MARK: tableview的代理方法
extension PersonCenterViewController {
  
  func numberOfSections(in tableView: UITableView) -> Int {
    if modelNet.discountActivityCount > 0{
      sectionCount = 3
    }else{
      sectionCount = 2
    }
    return sectionCount
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if section == 1 && modelNet.discountActivityCount > 0 {
      return (modelNet.discountActivityCount > 2) ? 2 : modelNet.discountActivityCount
    }else if section == 0 {
      return 1
    }else{
      return 2
    }
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if indexPath.section == 0 {
      return PersonAssetCell.cellHeight
    } else{
      if modelNet.discountActivityCount > 0 {
        return ActivityBreifCell.cellHeight
      }else{
        return ReportBriefCell.cellHeight
      }
    }
  }
  
  func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    if section == 1 {
      return PersonCenterSectionHeadView.height
    } else if section == 2{
      return PersonCenterSectionHeadView.heightOfReport
    }
    return 0.1
  }
  
  func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
    return 0.1
  }
  
  func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    if section == 0 {
      let view = UIView()
      view.backgroundColor = .clear
      return view
    }else  {
      if modelNet.discountActivityCount > 0 {
        let  headView = PersonCenterSectionHeadView()
        headView.style = section-1
        return headView
      }else {
        let  headView = PersonCenterSectionHeadView()
        headView.style = section
        return headView
      }
    }
  }
  

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    if indexPath.section == 0 {
      var cell = _tableView?.dequeueReusableCell(withIdentifier: "PersonAssetCell") as? PersonAssetCell
      if cell == nil {
        cell = PersonAssetCell.init(style: .default, reuseIdentifier: "PersonAssetCell")
      }
      cell?.style = indexPath.row
      cell?.dataModel = modelNet.assetInfoModel
      return cell!
      
    }else if indexPath.section == 1{
      
      if modelNet.discountActivityCount > 0 {
        
        var cell = _tableView?.dequeueReusableCell(withIdentifier: "ActivityBreifCell") as? ActivityBreifCell
        if cell == nil {
          cell = ActivityBreifCell.init(style: .default, reuseIdentifier: "ActivityBreifCell")
        }
        cell?.dataModel = modelNet.discountActivityModel?.tA06MyPromoList?[indexPath.row]
        return cell!
        
      }
      else{
        var cell = _tableView?.dequeueReusableCell(withIdentifier: "ReportBriefCell") as? ReportBriefCell
        if cell == nil {
          cell = ReportBriefCell.init(style: .default, reuseIdentifier: "ReportBriefCell")
        }
        cell?.testStyle = indexPath.row
        if indexPath.row == 0 {
          
          cell?.dataModel = modelNet.fundRecordModel?.depositRecord
      
        }else {
          
          cell?.dataModel = modelNet.fundRecordModel?.drawalRecord
          if cell?.dataModel?.flag == 1 {
             cell?._payStatusLabel.text = "支付中"
          }
        }
        return cell!
      }
    }
      
    else {
      var cell = _tableView?.dequeueReusableCell(withIdentifier: "ReportBriefCell") as? ReportBriefCell
      if cell == nil {
        cell = ReportBriefCell.init(style: .default, reuseIdentifier: "ReportBriefCell")
      }
      cell?.testStyle = indexPath.row
      if indexPath.row == 0 {
        cell?.dataModel = modelNet.fundRecordModel?.depositRecord  //
      }else {
        cell?.dataModel = modelNet.fundRecordModel?.drawalRecord // 取款记录
      }
      return cell!
    }
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    // 报表的跳转
    if indexPath.section == sectionCount-1 {
      
      var model:FundRecordInfoModel? = nil
      
      if indexPath.row == 0 {
        if let m = modelNet.fundRecordModel?.depositRecord  {
          model = m // 取款记录
        }
      }else {
        if let m = modelNet.fundRecordModel?.drawalRecord {
          model = m // 取款记录
        }
      }
      
      if model == nil {
        ProgressTopPopView.showPopView(content: "无记录", popStyle: .errorMsgToast)
        return
      }
      let transaDetailModel = TransactionDetailModel()
      transaDetailModel.amount =  model?.amount
      transaDetailModel.rate = model?.rate
      transaDetailModel.createDate = model?.createDate
      transaDetailModel.flag =  "\(model?.flag ?? 0 )"
      transaDetailModel.flagDesc = model?.flagDesc
      transaDetailModel.itemIcon = model?.itemIcon
      transaDetailModel.referenceId = model?.requestId
      transaDetailModel.remindFlag =  "\(model?.remindFlag ?? 0)"
      transaDetailModel.title = model?.title
      transaDetailModel.accountNo = model?.accountNo
      transaDetailModel.bankName = model?.bankName
      transaDetailModel.transaType =  indexPath.row == 0 ? .deposit : .drawal
      transaDetailModel.transCode = model?.transCode
      
      let transaDetailVC = TransactiontDetailViewController.init(billNo: model?.requestId, isPersonCenter: true, isFromReport: true)
      transaDetailVC.transacDetailModel = transaDetailModel
      self.nearNav()?.pushViewController(transaDetailVC, animated: true)
    }
    
    // TODO:福利活动的跳转
    if modelNet.discountActivityCount > 0{ // 有福利活动
      if indexPath.section == sectionCount-2  {
        if indexPath.row == 0 {
          let model = modelNet.discountActivityModel?.tA06MyPromoList?[0]
         // let promoCode = model?.linkUrl
          let jsonStr = model?.toJSONString() ?? ""
          ReactInteraction.shareInstance()?.go(toPromo: jsonStr)
          
          let messageVC = RNViewController()
          let walltime = DispatchWallTime.now() + 0.3
          DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
            messageVC.view.addSubview(ManagerModel.shareInstanse().homePageVC?.view ?? UIView())
            let currentVC = ManagerModel.instanse.getTopViewController()
            currentVC.navigationController?.pushViewController(messageVC, animated: true)
          }
        
        }else{
          let model = modelNet.discountActivityModel?.tA06MyPromoList?[1];
        //  let promoCode = model?.linkUrl
          let jsonStr = model?.toJSONString() ?? ""
          ReactInteraction.shareInstance()?.go(toPromo: jsonStr)
       //   ReactInteraction.shareInstance().go(toPromo: promoCode)
          let messageVC = RNViewController()
          let walltime = DispatchWallTime.now() + 0.3
          DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
            messageVC.view.addSubview(ManagerModel.shareInstanse().homePageVC?.view ?? UIView())
            let currentVC = ManagerModel.instanse.getTopViewController()
            currentVC.navigationController?.pushViewController(messageVC, animated: true)
          }
        }
      }
    }
  }
  
  
  
  

}

// MARK: 网络请求
extension PersonCenterViewController {
  
  func netLoadData(_ passiveAnimation:Bool)  {
    
    if passiveAnimation {
      _tableView!.setContentOffset(CGPoint.init(x: 0, y: -_tableView!.mj_header.heigth), animated: true)
    }else{
      LoadingView.showLoadingViewWith(to: self.view)
    }
    
    modelNet.netPersonCenterAllNet { (result, errorDesc)in
      
      self._personInfoTableHeadView.dataModel = self.modelNet.personInfoModel
      self._tableView?.mj_header.endRefreshing()
      self._tableView?.reloadData()
      
      if passiveAnimation {
        self._tableView!.setContentOffset(CGPoint.zero, animated: true)
      }else{
        LoadingView.hideLoadingView(for: self.view)
      }
      if self.modelNet.netFail {
        //LoadingView.hideLoadingView(for: self.view)
        // ProgressTopPopView.showPopView(content: "信息获取失败" , popStyle: .errorMsgToast)
      }
    }
    
    modelNet.netPersonCenterFundRecordNet { (result, errorDesc)in
      
      self._personInfoTableHeadView.dataModel = self.modelNet.personInfoModel
      self._tableView?.mj_header.endRefreshing()
      self._tableView?.reloadData()
      
      if passiveAnimation {
        self._tableView!.setContentOffset(CGPoint.zero, animated: true)
      }else{
        LoadingView.hideLoadingView(for: self.view)
      }
      if self.modelNet.netFail {
        //LoadingView.hideLoadingView(for: self.view)
        //ProgressTopPopView.showPopView(content: "信息获取失败" , popStyle: .errorMsgToast)
      }
    }
  }
}


