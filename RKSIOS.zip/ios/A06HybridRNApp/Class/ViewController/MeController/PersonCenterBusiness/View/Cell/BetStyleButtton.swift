//
//  BetStyleButtton.swift
//  A06HybridRNApp
//
//  Created by kunlun on 20/02/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class BetStyleButtton : UIButton {
  
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    
    self.setTitleColor(.white, for: .normal)
    self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 13)
    self.titleLabel?.textAlignment = .left
    self.layer.cornerRadius = 5
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  
  override func layoutSubviews() {
    
    super.layoutSubviews()
    
    self.imageView?.center.y = self.heigth/2
    self.imageView?.x = self.width/2 - 18 - 5
    self.imageView?.width = 18
    self.imageView?.heigth = 18
    
    self.titleLabel?.x = self.imageView!.right + 5
    self.titleLabel?.center.y = self.heigth/2
    self.titleLabel?.width = self.width - self.imageView!.right-5
    self.titleLabel?.heigth = 18
    
  }
  
}
