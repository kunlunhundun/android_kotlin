//
//  PersonInfoMenuView.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonCenterTableViewHeaderView: UIView {

  
    private let _backGroundView = UIView()
    private let _nameLabel = UILabel()          // 名字
    private let _gradeImageView = UIImageView() // VIP 登记图片
    private let _gradeDescLabel = UILabel()     // VIP
    private let _rightArrowButton = UIButton()  // 箭头
    private let _backButton = UIButton()        // 箭头
  
    private let _nameVerifyButton = PersonInfoMenuButton() // 实名认证
    private let _iphoneBindButton = PersonInfoMenuButton() // 手机号绑定
    private let _bankBindButton = PersonInfoMenuButton()   // 银行卡绑定
  
    var dataModel:PersonInfoModel?  {
      didSet{
        flushDataView()
      }
    }
  
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUIProperty()
        initLayoutSubview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    override func layoutSubviews() {
        super.layoutSubviews()
        if (_backGroundView.gradientLayer == nil) {
            _backGroundView.gradientInBottom(withVertical: false, startGdColor: UIColor.init(hex: 0xEB5D4D), endGdColor: UIColor.init(hex: 0xFB2464))
        }
    }
  
    func initUIProperty()  {
    
        _backGroundView.layer.cornerRadius = 8
        _backGroundView.clipsToBounds = true
        self.addSubview(_backGroundView)
        
        _nameLabel.text = ""
        _nameLabel.font = UIFont.SegoeUISemibold(ofSize: 24)
        _nameLabel.textColor = .white
        _nameLabel.textAlignment = .left
        _backGroundView.addSubview(_nameLabel)
      
        _gradeImageView.image = nil
        _backGroundView.addSubview(_gradeImageView)
      
        _gradeDescLabel.text = ""
        _gradeDescLabel.textColor = .white
        _gradeDescLabel.textAlignment = .left
        _gradeDescLabel.font = UIFont.SegoeUI(ofSize: 15)
        _backGroundView.addSubview(_gradeDescLabel)
      
        _rightArrowButton.setImage(UIImage.init(named: "箭头右.png"), for: .normal)
        _rightArrowButton.addTarget(self, action: #selector(arrowRightEvent(_:)), for: .touchUpInside)
        _backGroundView.addSubview(_rightArrowButton)

        _nameVerifyButton.setTitle("实名认证", for: .normal)
        _nameVerifyButton.setTitleColor(.white, for: .selected)
        _nameVerifyButton.setTitleColor(.white, for: .normal)
        _nameVerifyButton.setImage(UIImage.init(named: "实名-验证 copy.png"), for: .normal)
        _nameVerifyButton.setImage(UIImage.init(named: "实名-验证.png"), for: .selected)
        //_nameVerifyButton.addTarget(self, action: #selector(nameVerifyEvent(_:)), for: .touchUpInside)
        _backGroundView.addSubview(_nameVerifyButton)


        _iphoneBindButton.setTitle("手机号绑定", for: .normal)
        _iphoneBindButton.setTitleColor(.white, for: .selected)
        _iphoneBindButton.setTitleColor(.white, for: .normal)
        _iphoneBindButton.setImage(UIImage.init(named: "手机-验证 copy.png"), for: .normal)
        _iphoneBindButton.setImage(UIImage.init(named: "手机-验证.png"), for: .selected)
        //_iphoneBindButton.addTarget(self, action: #selector(iphoneBindEvent(_:)), for: .touchUpInside)
        _backGroundView.addSubview(_iphoneBindButton)

        _bankBindButton.setTitle("银行卡绑定", for: .normal)
        _bankBindButton.setTitleColor(.white, for: .selected)
        _bankBindButton.setTitleColor(.white, for: .normal)
        _bankBindButton.setImage(UIImage.init(named: "银行卡icon.png"), for: .normal)
        _bankBindButton.setImage(UIImage.init(named: "银行卡认证.png"), for: .selected)
        //_bankBindButton.addTarget(self, action: #selector(emailBindEvent(_:)), for: .touchUpInside)
        _backGroundView.addSubview(_bankBindButton)
      
        _backGroundView.addSubview(_backButton)
        _backButton.addTarget(self, action: #selector(arrowRightEvent(_:)), for: .touchUpInside)
      
        _nameVerifyButton.isSelected = true
        _iphoneBindButton.isSelected = true
        _bankBindButton.isSelected = true
    }
  
    private func flushDataView()  {
      
      _nameLabel.text = dataModel?.loginName
      _gradeDescLabel.text = dataModel?.starLevelName
      
      let path = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/VIP", ofType: "png")
      let image = UIImage.init(contentsOfFile: path ?? "")
      _gradeImageView.image = image
      
      if (dataModel?.birthday?.count ?? 0) > 0 {
        _nameVerifyButton.isSelected = true
      }else{
        _nameVerifyButton.isSelected = false
      }
      
      if (dataModel?.mobileNoBind ?? 0) > 0 {
        _iphoneBindButton.isSelected = true
      }else{
        _iphoneBindButton.isSelected = false
      }
      
      if (dataModel?.bankCardNum ?? 0) + (dataModel?.btcNum ?? 0) > 0 {
        _bankBindButton.isSelected = true
      }else{
        _bankBindButton.isSelected = false
      }
  }
    
    func initLayoutSubview()  {
      
        _backGroundView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.width.equalTo(SCREEN_WIDTH-30)
            make.top.equalToSuperview().offset(10)
            make.height.equalTo(179)
        }
        _backButton.snp.makeConstraints { (make) in
          make.edges.equalToSuperview()
        }
        _nameLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(28)
            make.width.equalTo(260)
            make.height.equalTo(32)
        }
        _gradeImageView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(80)
            make.width.equalTo(26)
            make.height.equalTo(21)
        }
        _gradeDescLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(56)
            make.centerY.equalTo(_gradeImageView.snp.centerY)
            make.width.equalTo(80)
            make.height.equalTo(20)
        }
        _rightArrowButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-2)
            make.centerY.equalTo(_gradeImageView.snp.centerY)
            make.width.equalTo(44)
            make.height.equalTo(50)
        }
        _nameVerifyButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.width.equalTo((SCREEN_WIDTH-35*2)/3)
            make.height.equalTo(20)
            make.bottom.equalToSuperview().offset(-25)
        }
        _iphoneBindButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.width.equalTo(_nameVerifyButton.snp.width)
            make.height.equalTo(17)
            make.bottom.equalToSuperview().offset(-25)
        }
        _bankBindButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.width.equalTo(_nameVerifyButton.snp.width)
            make.height.equalTo(17)
            make.bottom.equalToSuperview().offset(-25)
        }
    }
  
    @objc func arrowRightEvent(_ sender:UIButton) {
        let viewCtr = PersonInfoViewController()
        viewCtr.personInfoModel = dataModel
        self.nearNav()?.pushViewController(viewCtr, animated: true)
    }
  
    @objc func nameVerifyEvent(_ sender:UIButton) {
        let viewCtr = RealNameVertifyViewController()
        viewCtr.personInfoModel = self.dataModel
        self.nearNav()?.pushViewController(viewCtr, animated: true)
    }
    
    @objc func iphoneBindEvent(_ sender:UIButton) {
        let viewCtr = BindPhoneViewController()
        viewCtr.personInfoModel = self.dataModel
        self.nearNav()?.pushViewController(viewCtr, animated: true)
    }
    
    @objc func emailBindEvent(_ sender:UIButton) {
      if !sender.isSelected {
        let viewCtr = AddBankCardViewController()
        self.nearNav()?.pushViewController(viewCtr, animated: true)
      }
    }
}
