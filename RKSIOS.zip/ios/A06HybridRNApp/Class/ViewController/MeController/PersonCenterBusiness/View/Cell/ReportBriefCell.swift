//
//  ReportBriefCell.swift
//  PersonReport
//
//  Created by Casey on 13/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class ReportBriefCell: UITableViewCell {
  
    static let cellHeight:CGFloat = 78
    var dataModel:FundRecordInfoModel? {
      didSet{
        self.flushDataView()
      }
  }
  
    var testStyle:Int = 0 {
        willSet{
            if newValue == 1 {
                _noneDataLabel.isHidden = true
                _styleImageView.image = UIImage.init(named: "取款.png")
                _styleDescLabel.text = "取款"
            }else {
                _noneDataLabel.isHidden = false
                _styleImageView.image = UIImage.init(named: "存款.png")
                _styleDescLabel.text = "存款"
            }
        }
    }
    
    let _backGroundView = UIView()
    let _styleImageView = UIImageView() // 存款/取款 图片
    let _styleDescLabel = UILabel() // 存款/取款
    let _vGapLineView = UIView() // 分割线
    let _dateLable = UILabel() // 日期
    let _timeLabel = UILabel() // 时间
    let _moneyLabel = UILabel() // 金额
    let _payStyleLabel = UILabel() // 支付方式
    let _payStatusLabel = UILabel() // 状态
    let _noneDataLabel = UILabel() // 无记录状态
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        initUIProperty()
        initLayoutSubview()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initUIProperty()  {
        
        self.backgroundColor = .clear
        self.selectionStyle = .none
        
        _backGroundView.backgroundColor = UIColor.init(colorValue: 0x24282C)
        _backGroundView.layer.cornerRadius = 5
        self.contentView.addSubview(_backGroundView)
      
        _styleImageView.image = UIImage.init(named: "存款.png")
        _backGroundView.addSubview(_styleImageView)
        
        _styleDescLabel.text = "存款"
        _styleDescLabel.textColor = .white
        _styleDescLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _styleDescLabel.textAlignment = .center
        _backGroundView.addSubview(_styleDescLabel)
        
        _vGapLineView.backgroundColor = UIColor.init(colorValue: 0x28323B)
        _backGroundView.addSubview(_vGapLineView)
        
        _dateLable.text = "09-17"
        _dateLable.textColor = .white
        _dateLable.font = UIFont.PingFangSCRegular(ofSize: 14)
        _backGroundView.addSubview(_dateLable)
        
        _timeLabel.text = "13:17"
        _timeLabel.textColor = .white
        _timeLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _backGroundView.addSubview(_timeLabel)
        
        _moneyLabel.text = "100元"
        _moneyLabel.textColor = .white
        _moneyLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _backGroundView.addSubview(_moneyLabel)
        
        _payStyleLabel.text = "扫码支付"
        _payStyleLabel.textColor = UIColor.init(colorValue: 0x888888)
        _payStyleLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _backGroundView.addSubview(_payStyleLabel)
        
        _payStatusLabel.text = "未通过"
        _payStatusLabel.textColor = UIColor.init(colorValue: 0xFA2663)
        _payStatusLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _payStatusLabel.textAlignment = .right
        _backGroundView.addSubview(_payStatusLabel)
        
        _noneDataLabel.text = "无记录"
        _noneDataLabel.isHidden = false
        _noneDataLabel.backgroundColor = _backGroundView.backgroundColor
        _noneDataLabel.layer.cornerRadius = 5
        _noneDataLabel.layer.masksToBounds = true
        _noneDataLabel.textColor = UIColor.init(colorValue: 0x888888)
        _noneDataLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _noneDataLabel.textAlignment = .center
        _backGroundView.addSubview(_noneDataLabel)
    }
  
    private func flushDataView(){
      
      if let dataInfo = dataModel {
        
        _noneDataLabel.isHidden = true
        _dateLable.text = dataInfo.beginDateDesc
        _timeLabel.text = dataInfo.beginTimeDesc
        _moneyLabel.text = String.init(format: "%@元", dataInfo.amountDesc ?? "")
        
        _payStatusLabel.text = dataInfo.flagDesc
        
        if dataInfo.flag == 0 || dataInfo.flag == 1 { // 0等待处理 和 1处理中
          _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
        }else if dataInfo.flag == 2 { // 2成功
          _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
        }else{ // 3失败 和 4超时
          _payStatusLabel.textColor = UIColor.init(colorValue : 0x999999)
        }
        
        let transCode = dataModel?.transCode
        let title = dataModel?.title
        
        if transCode != nil {
          if transCode?.isEqual("1" as String) == true { _payStyleLabel.text = "人工存款" }
          if transCode?.isEqual("2" as String) == true { _payStyleLabel.text = "网银在线存款"  }
          if transCode?.isEqual("3" as String) == true {_payStyleLabel.text = "点卡存款"  }
          if transCode?.isEqual("4" as String) == true {_payStyleLabel.text = "微信扫码" }
          if transCode?.isEqual("5" as String) == true {_payStyleLabel.text = "支付宝扫码"  }
          if transCode?.isEqual("6" as String) == true {_payStyleLabel.text = "银行卡转账"  }
          if transCode?.isEqual("7" as String) == true {_payStyleLabel.text = "QQ扫码"  }
          if transCode?.isEqual("8" as String) == true {_payStyleLabel.text = "微信支付" }
          if transCode?.isEqual("9" as String) == true {_payStyleLabel.text = "支付宝支付" }
          if transCode?.isEqual("11" as String) == true {_payStyleLabel.text = "QQ钱包支付"  }
          if transCode?.isEqual("15" as String) == true {_payStyleLabel.text = "银联扫码"  }
          if transCode?.isEqual("16" as String) == true {_payStyleLabel.text = "京东扫码"  }
          if transCode?.isEqual("17" as String) == true {_payStyleLabel.text = "京东支付"  }
          if transCode?.isEqual("18" as String) == true {_payStyleLabel.text = "银联在线存款"  }
          if transCode?.isEqual("19" as String) == true {_payStyleLabel.text = "银联在线存款"  }
          if transCode?.isEqual("20" as String) == true {_payStyleLabel.text = "比特币支付"  }
          if transCode?.isEqual("22" as String) == true {_payStyleLabel.text = "微信转账"  }
          if transCode?.isEqual("26" as String) == true {_payStyleLabel.text = "支付宝转账"  }
        }else{
          _payStyleLabel.text = title
        }
        
        let str:String = dataInfo.flagDesc!
        if(str.isEqual("审核中" as String)){
          _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
        }
        if(str.isEqual("支付中" as String)){
          _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
        }
        if(str.isEqual("未通过" as String)){
          _payStatusLabel.textColor = UIColor.init(colorValue : 0x999999)
        }
        if(str.isEqual("成功" as String)){
          _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
        }
        if(str.isEqual("已派发" as String)){
          _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
        }
        
      } else {
        _noneDataLabel.isHidden = false
      }
    }
  
    private func initLayoutSubview()  {
      
        _backGroundView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(5)
            make.right.equalToSuperview().offset(-15)
            make.bottom.equalToSuperview().offset(-5)
        }
        _styleDescLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.bottom.equalToSuperview().offset(-11)
            make.width.equalTo(62)
            make.height.equalTo(21)
        }
        _styleImageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(_styleDescLabel.snp.centerX)
            make.bottom.equalTo(_styleDescLabel.snp.top).offset(-4)
            make.width.equalTo(21)
            make.height.equalTo(21)
        }
        _vGapLineView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(62)
            make.width.equalTo(1)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        _dateLable.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(79)
            make.centerY.equalTo(_styleImageView.snp.centerY)
            //make.width.equalTo(42)
            make.height.equalTo(20)
        }
        _timeLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(79)
            make.centerY.equalTo(_styleDescLabel.snp.centerY)
            make.width.equalTo(45)
            make.height.equalTo(20)
        }
        _moneyLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(136)
            make.centerY.equalTo(_styleImageView.snp.centerY)
            make.width.equalTo(100)
            make.height.equalTo(20)
        }
        _payStyleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(136)
            make.centerY.equalTo(_styleDescLabel.snp.centerY)
            make.width.equalTo(150)
            make.height.equalTo(20)
        }
        _payStatusLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-20)
            make.centerY.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(20)
        }
        _noneDataLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(64)
            make.right.equalToSuperview()
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}
