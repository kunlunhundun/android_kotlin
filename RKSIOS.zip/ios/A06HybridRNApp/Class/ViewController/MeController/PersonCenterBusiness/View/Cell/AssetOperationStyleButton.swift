//
//  AssetOperationStyleButton.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class AssetOperationStyleButton: UIButton {

   
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setTitleColor(.white, for: .normal)
        self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 13)
        self.titleLabel?.textAlignment = .center
        self.layer.cornerRadius = 5
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        self.imageView?.centerX = self.width/2
        self.imageView?.y = 9
        self.imageView?.width = 18
        self.imageView?.heigth = 18
        
        
        self.titleLabel?.x = 0
        self.titleLabel?.y = self.imageView!.bottom + 4
        self.titleLabel?.width = self.width
        self.titleLabel?.heigth = 18
        
        
    }

}
