//
//  PersonInfoMenuButton.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonInfoMenuButton: UIButton {

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setTitleColor(.white, for: .normal)
        if UIScreen.main.bounds.width == 320 {
            self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 12)
        }
        else{
            self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    override func layoutSubviews() {
       
        super.layoutSubviews()
        
        self.imageView?.contentMode = .scaleAspectFit
      
        self.imageView?.x = 0
        self.imageView?.centerY = self.heigth/2
        self.imageView?.width = self.heigth
        self.imageView?.heigth = self.heigth
      
      
        self.titleLabel?.x = self.imageView!.right + 2
        self.titleLabel?.centerY = self.heigth/2
        self.titleLabel?.width = self.width - self.titleLabel!.x
        self.titleLabel?.heigth = self.heigth
        
        
//        self.imageView?.snp.makeConstraints({ (make) in
//            make.left.equalToSuperview()
//            make.centerY.equalToSuperview()
//            make.width.height.equalTo(self.snp.height)
//        })
//
//        self.titleLabel?.snp.makeConstraints({ (make) in
//            make.left.equalTo(self.imageView!.snp.right).offset(5)
//            make.right.equalToSuperview()
//            make.top.equalToSuperview()
//            make.height.equalToSuperview()
//        })
    }
    
    
}
