//
//  PersonAssetCell.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonAssetCell: UITableViewCell {

    var dataModel:AssertInfoModel? {
      
      didSet{
        
        self.flushDataView()
        
      }
      
    }
  
  
    static let cellHeight:CGFloat = 78 + 10 + 60
  

    private  let _allAssetTitleLabel = UILabel() // 总资产（标题）
    private  let _moneyLogImageView = UIImageView()
    private  let _allMoneyValueLabel = UILabel() // 总资产值
    private  let _depositStyleButton = BetStyleButtton() // 存款
    private  let _drawalStyleButton = BetStyleButtton()// 取款
    private  let _washCodeStyleButton = BetStyleButtton()// 取款

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        initUIProperty()
        initLayoutSubview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    private func initUIProperty()  {
        
        self.backgroundColor = .clear
        self.selectionStyle = .none
        
        _allAssetTitleLabel.text = "总资产"
        _allAssetTitleLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _allAssetTitleLabel.textColor = .white
        self.addSubview(_allAssetTitleLabel)
        
        
        self.addSubview(_moneyLogImageView)
        
        
        _allMoneyValueLabel.text = "12412.12"
        _allMoneyValueLabel.font = UIFont.boldSystemFont(ofSize: 24)
        _allMoneyValueLabel.textColor = .white
        self.addSubview(_allMoneyValueLabel)
      
      
        
        _depositStyleButton.setTitle("存款", for: .normal)
        _depositStyleButton.setImage(UIImage.init(named: "存款.png"), for: .normal)
        _depositStyleButton.backgroundColor = UIColor.init(colorValue: 0xFB7A24)
        _depositStyleButton.addTarget(self, action: #selector(depositEvent(_:)), for: .touchUpInside)
        self.addSubview(_depositStyleButton)
        
        
        _drawalStyleButton.setTitle("取款", for: .normal)
        _drawalStyleButton.setImage(UIImage.init(named: "取款.png"), for: .normal)
        _drawalStyleButton.backgroundColor = UIColor.init(colorValue: 0x262B2E)
        self.addSubview(_drawalStyleButton)
        _drawalStyleButton.addTarget(self, action: #selector(drawalEvent), for: .touchUpInside)
      
      _washCodeStyleButton.setTitle("洗码", for: .normal)
      _washCodeStyleButton.backgroundColor = UIColor.init(colorValue: 0x262B2E)
      _washCodeStyleButton.setImage(UIImage.init(named: "洗码.png"), for: .normal)
      self.addSubview(_washCodeStyleButton)
      _washCodeStyleButton.addTarget(self, action: #selector(washCodeEvent), for: .touchUpInside)
      
      let path = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/MRB", ofType: "png")
      let image = UIImage.init(contentsOfFile: path ?? "")
      _moneyLogImageView.image = image
    }
    
    private func flushDataView(){
      
      if  self.style == 0{ // 总资产
        
        let amountStr = dataModel?.balance ?? ManagerModel.shareInstanse().totalAmount
        _allMoneyValueLabel.text = amountStr

       // let amount = amountStr.toDoubleValue()
       // _allMoneyValueLabel.text = String.init(format: "%.2f", amount)
      }else{ // 洗码
        _allMoneyValueLabel.text = dataModel?.withdrawBal
      }
    }
  
  
    private func initLayoutSubview()  {
        
        _allAssetTitleLabel.snp.makeConstraints { (make) in
            
            
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(20)
            make.width.equalTo(100)
            make.height.equalTo(22)
        }
        
        _allMoneyValueLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(50)
            make.top.equalTo(_allAssetTitleLabel.snp.bottom).offset(7)
            make.width.equalTo(200)
            make.height.equalTo(33)
        }
      
        _moneyLogImageView.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(15)
            make.centerY.equalTo(_allMoneyValueLabel.snp.centerY)
            make.width.equalTo(20)
            make.height.equalTo(20)
        }
        
    
      var btnWidth = Int(SCREEN_WIDTH) - View_Margin*2 - 10*2
      btnWidth = btnWidth/3
        _depositStyleButton.snp.makeConstraints { (make) in
            make.top.equalTo(_allMoneyValueLabel.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(View_Margin)
            make.width.equalTo(btnWidth)
            make.height.equalTo(57)
        }
      
        _washCodeStyleButton.snp.makeConstraints  { (make) in
          make.top.equalTo(_depositStyleButton.snp.top)
          make.left.equalTo(_depositStyleButton.snp.right).offset(10)
          make.width.equalTo(btnWidth)
          make.height.equalTo(57)
        }
      
        _drawalStyleButton.snp.makeConstraints  { (make) in
          make.top.equalTo(_depositStyleButton.snp.top)
          make.right.equalToSuperview().offset(-View_Margin)
          make.width.equalTo(btnWidth)
          make.height.equalTo(57)
        }
    }
  
    // 0 是总资产：存取款； 1 是洗码
    private var _style: Int = 0
    var style: Int {
        
        get{
            
            return _style
            
        }set{
            _style = newValue
          
        }
    }

  
    //MARK: button 事件
  
    @objc func depositEvent(_ sender:UIButton) {
    
        let ChargeVC = ChargeViewController()
        self.nearNav()?.pushViewController(ChargeVC, animated: true)
    }
  
    @objc func drawalEvent(_ sender:UIButton) {
      
      if _style == 0{
          // 取款
        let withDrawVC = WithDrawViewController()
        self.nearNav()?.pushViewController(withDrawVC, animated: false)
        withDrawVC.completionQuKuan = {(banlence)in
          self._allMoneyValueLabel.text = banlence
        }
      }
    }
  @objc func washCodeEvent(){
    
    WashCodeAlertView.showPopView { (index) in
  
    }
  }
}
