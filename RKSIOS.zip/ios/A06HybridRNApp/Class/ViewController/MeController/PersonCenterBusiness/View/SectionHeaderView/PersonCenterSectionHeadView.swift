//
//  AcitivtySectionHeadView.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class PersonCenterSectionHeadView: UIView {

    
    static let height:CGFloat = 58
    static let heightOfReport:CGFloat = 58-5
    
    private let _sectionTitleLabel = UILabel()
    private let _allActivityButton = ActivityAllButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initUIProperty()
        initLayoutSubview()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initUIProperty()  {
        
        _sectionTitleLabel.text = "福利活动"
        _sectionTitleLabel.textColor = .white
        _sectionTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        self.addSubview(_sectionTitleLabel)
        
        _allActivityButton.setTitle("全部活动", for: .normal)
        _allActivityButton.setImage(UIImage.init(named: "箭头右.png"), for: .normal)
        _allActivityButton.addTarget(self, action: #selector(allActivityEvent(_:)), for: .touchUpInside)
        self.addSubview(_allActivityButton)
        
    }
    
    private func initLayoutSubview()  {
        
        _sectionTitleLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(15)
            make.width.equalTo(100)
            make.height.equalTo(32)
            make.bottom.equalToSuperview()
        }
        
        _allActivityButton.snp.makeConstraints { (make) in
            
            make.right.equalToSuperview().offset(-15)
            make.width.equalTo(90)
            make.height.equalTo(32)
            make.bottom.equalToSuperview()
        }
        
        
    }
  
    
    
    // 0 福利活动；1报表
    var style: Int = 0 {
        
        willSet{
            
            if newValue == 0 {
                
                _sectionTitleLabel.text = "福利活动"
                _allActivityButton.setTitle("全部活动", for: .normal)
                
            }else {
                
                _sectionTitleLabel.text = "报表"
                _allActivityButton.setTitle("详细", for: .normal)
            }
            
        }
        
        didSet{
            
            
        }
        
        
    }
    
    
    @objc func allActivityEvent(_ sender:UIButton) {
        
        if style == 0 {
          print("福利活动")
          ManagerModel.jumpRNPage(pageName: RNPagePromo, needBack: false,isNewVC:true)
        
        }else{
            let personReportVC = PersonReportInfoViewController()
            self.nearNav()?.pushViewController(personReportVC, animated: true)
        }
        
    }
}
