//
//  ActivityAllButton.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class ActivityAllButton: UIButton {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.setTitleColor(.white, for: .normal)
        self.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        self.contentHorizontalAlignment = .right
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        
        self.imageView?.right = self.width
        self.imageView?.centerY = self.heigth/2
        self.imageView?.width = 22
        self.imageView?.heigth = 22
        
        self.titleLabel?.left = 0
        self.titleLabel?.right = self.imageView!.left
        self.titleLabel?.centerY = self.heigth/2
       // self.titleLabel?.width = self.width - 16
        self.titleLabel?.heigth = 20
        
        
        
    }

}
