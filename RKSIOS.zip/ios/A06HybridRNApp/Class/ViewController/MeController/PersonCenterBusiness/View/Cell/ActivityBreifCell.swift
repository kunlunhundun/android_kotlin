//
//  ActivityBreifCell.swift
//  PersonReport
//
//  Created by Casey on 12/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class ActivityBreifCell: UITableViewCell {

    static let cellHeight:CGFloat = 78
    let _backGroundView = UIView()
    let _newImageView = UIImageView()
    let _activityTitleLabel = UILabel()
    let _activityDateLabel = UILabel()
    let _activityGiftImageView = UIImageView()
  
    var dataModel:ActivityInfoModel? {
      didSet{
          self.flushDataView()
        }
    }
  
    required init?(coder aDecoder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
      super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initUIProperty()
        initLayoutSubview()
    }
}

// 刷新数据
extension ActivityBreifCell {
  private func flushDataView(){
    _activityTitleLabel.text = dataModel?.title
    _activityDateLabel.text = dataModel?.dateDesc  // promo
    if dataModel?.promoFlag == 1 {
      _activityDateLabel.text = "长期活动"
    }
    
    let path = Bundle.main.path(forResource: "Bundle/assets/src/images/Main/promo", ofType: "png")
    let image = UIImage.init(contentsOfFile: path ?? "")
    _activityGiftImageView.image = image
  }
}

// UI布局
extension ActivityBreifCell {
  
  private func initUIProperty()  {
    
    self.backgroundColor = .clear
    self.selectionStyle = .none
    
    _backGroundView.backgroundColor = UIColor.init(colorValue: 0x24282C)
    _backGroundView.layer.cornerRadius = 5
    self.contentView.addSubview(_backGroundView)
    
    _newImageView.image = UIImage.init(named: "tag-new.png")
    _backGroundView.addSubview(_newImageView)
    
    _activityTitleLabel.textColor = .white
    _activityTitleLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
    _activityTitleLabel.text = "中秋博饼大抽奖活动-中秋大团圆"
    _backGroundView.addSubview(_activityTitleLabel)
    
    _activityDateLabel.text = "2018/9/24-2018/9/30"
    _activityDateLabel.textColor = UIColor.init(colorValue: 0x888888)
    _activityDateLabel.font = UIFont.PingFangSCRegular(ofSize: 12)
    _backGroundView.addSubview(_activityDateLabel)
    
    _backGroundView.addSubview(_activityGiftImageView)
  }
  
  private func initLayoutSubview()  {
    _backGroundView.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.top.equalToSuperview().offset(5)
      make.right.equalToSuperview().offset(-15)
      make.bottom.equalToSuperview().offset(-5)
    }
    _newImageView.snp.makeConstraints { (make) in
      make.left.equalToSuperview()
      make.top.equalToSuperview()
      make.width.equalTo(20)
      make.height.equalTo(20)
    }
    _activityGiftImageView.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-18)
      make.centerY.equalToSuperview()
      make.width.equalTo(32)
      make.height.equalTo(32)
    }
    _activityTitleLabel.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalTo(_activityGiftImageView.snp.left).offset(-5)
      make.top.equalToSuperview().offset(13)
      make.height.equalTo(22)
    }
    _activityDateLabel.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-52)
      make.bottom.equalToSuperview().offset(-11)
      make.height.equalTo(17)
    }
  }
}
