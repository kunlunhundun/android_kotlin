//
//  AssertInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class AssertInfoModel: NSObject, HandyJSON {
  
  var localBalance:String? // 本地额度
  var withdrawBal:String? // 洗码金额
  var yebInterest:String? //
  var yebAmount:String? //
  var balance:String? //
  var platformTotalBalance:String? //
  var minWithdrawAmount:String? //
  var platformBalances:[platformBalancesModel]?
  
  required override init() {
    
    super.init()
    
  }
  
}


class platformBalancesModel:NSObject, HandyJSON {
  
  
  
  var balance:String?
  var platformCode:String?
  var platformName:String?
  
  required override init() {
    
    super.init()
    
  }
  
  
  
}
