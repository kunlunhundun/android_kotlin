//
//  PersonCenterModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 19/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

/*
 
 资金记录综合查询 /credit/query
 优惠活动接口
 会员信息 "/_glaxy_a06_/customer/getByLoginName"
 */


class PersonCenterModelNet: NSObject {
  
  
  var personInfoModel:PersonInfoModel? = PersonInfoModel()// 个人信息
  var discountActivityModel: DiscountActivityModel? = DiscountActivityModel()// 活动信息
  var fundRecordModel:FundRecordModel? = FundRecordModel()// 报表信息
  var assetInfoModel:AssertInfoModel? = AssertInfoModel()// 资产信息
  
  var netFail:Bool {
    
    get {
      
      if personInfoModel?.customerId == nil || assetInfoModel?.balance == nil {
        return true
      }
      return false
    }
    
  }
  
  
  var discountActivityCount:Int { // 福利活动数量
    
    get{
      
      return (self.discountActivityModel?.tA06MyPromoList?.count ?? 0)
      
    }set{
      
    }
    
  }
  
  

  
  
  // 个人中心所有的网络请求
  func netPersonCenterAllNet(_ completion:@escaping NetFinish) {
    
    let accountInfoReq = accountInfoRequest()
    let discountActivityReq =  discountActivityRequest()
    let assetInfoReq = assetInfoRequest()
    let netArr = [accountInfoReq, discountActivityReq, assetInfoReq]
    
    //let netArr = [assetInfoReq]
    CaseyNetwork().requestMultiTask(tasks: netArr) {
      
        completion(nil, nil)
      
    }

  }
  
  func netPersonCenterFundRecordNet(_ completion:@escaping NetFinish) {
    
    let fundRecordDepositReq = fundRecordDepositRequest()
    let fundRecordDrawalReq = fundRecordDrawalRequest()
    let netArr = [fundRecordDepositReq, fundRecordDrawalReq]
    
    CaseyNetwork().requestMultiTask(tasks: netArr) {
      
      
      completion(nil, nil)

    }
  }

   // 账号信息
  public func accountInfoRequest() ->  CaseyNetReqestInfo {
    
    var paraDic = ["inclAddress":"1"] // 住址
    paraDic["inclbankAccount"] = "1" // 绑定银行卡张数
    paraDic["inclBtcAccount"] = "1" // 比特币张数
    paraDic["inclCredit"] = "1"  //  是否本地额度
    paraDic["inclEmailBind"] = "1" // 是否包含邮件绑定状态
    paraDic["inclMobileNoBind"] = "1" // 是否哦包含手机绑定状态
    paraDic["inclMobileNo"] = "1" // 是否哦包含手机号
    paraDic["inclRealName"] = "1" //  是否返回真实姓名
    paraDic["inclVerifyCode"] = "1" // 是否包含验证码
    
    
    let netRequest = CaseyNetwork.requestInfoJsonPOST(ServiceRootPath + PersonCenterNetPath.accountInfo.rawValue, parameters: paraDic) { [weak self] (result, error, isCahce) in
      if  let dataResult = result {
        let infoModel = PersonInfoModel.deserialize(from: dataResult)
        self?.personInfoModel =  infoModel
        ManagerModel.shareInstanse().personInfoModel = infoModel
      }
      else {
      
      }
    }
    return netRequest
  }
  
  
  //  优惠活动
  private func discountActivityRequest() ->  CaseyNetReqestInfo{
    let netRequest =  CaseyNetwork.requestInfoJsonPOST(ServiceRootPath + PersonCenterNetPath.discountActivity.rawValue, parameters: nil) { (result, error, isCahce) in
      if  let dataResult = result {
        self.discountActivityModel =  DiscountActivityModel.deserialize(from: dataResult)
      }else{
        
      }
    }
    return netRequest
  }
  
  // 存款
  private func fundRecordDepositRequest() ->  CaseyNetReqestInfo {
    
      var paraDic = ["beginDate":"2012-01-01 00:00:00"]
      paraDic["endDate"] =  CaseyDateModel.currentDateOfString()
      paraDic["lastDays"] = "15" // 最近几天， 如果存在开始结束时间，则优先处理该参数
      paraDic["pageNo"] = "1"
      paraDic["pageSize"] = "1"
      paraDic["target"] = "LOCAL" // 转账动作： AP转至棋牌。LOCAL转至主账号
      paraDic["type"] = "1"  // 1 充值， 2 体现， 3 洗码， 4 优惠， 5 账变， 6积分， 7 电游投注记录 8棋牌转账
      paraDic["inclVerifyCode"] = "1"
    
      let netRequest = CaseyNetwork.requestInfoJsonPOST(ServiceRootPath + PersonCenterNetPath.fundRecordDeposit.rawValue, parameters: paraDic) { (result, error, isCahce) in
      
      
        if  let dataResult = result {
          
          if let recordInfoArr = dataResult["data"] as? [[String:Any]] {
    
            if let recordInfo = recordInfoArr.first {
              
              self.fundRecordModel?.depositRecord = FundRecordInfoModel.deserialize(from: recordInfo)
            }
          }
          
          
        }else{
          
          
        }
  }
  
  return netRequest
  
  }

  
  // 取款
  private func fundRecordDrawalRequest() ->  CaseyNetReqestInfo {
    
    
    var paraDic = ["beginDate":"2012-01-01 00:00:00"]
    paraDic["endDate"] = CaseyDateModel.currentDateOfString()
    paraDic["lastDays"] = "15"
    paraDic["pageNo"] = "1"
    paraDic["pageSize"] = "1"
    paraDic["target"] = "LOCAL" // 转账动作： AP转至棋牌。LOCAL转至主账号
    paraDic["type"] = "2"  // 1 充值， 2 提现， 3 洗码， 4 优惠， 5 账变， 6积分， 7 电游投注记录 8棋牌转账
    paraDic["inclVerifyCode"] = "1"
    
    let netRequest = CaseyNetwork.requestInfoJsonPOST(ServiceRootPath + PersonCenterNetPath.fundRecordWithdraw.rawValue, parameters: paraDic) { (result, error, isCahce) in
      
      
      if  let dataResult = result {
        
     
          if let recordInfoArr = dataResult["data"] as? [[String:Any]] {
            
            if let recordInfo = recordInfoArr.first {
              
                self.fundRecordModel?.drawalRecord = FundRecordInfoModel.deserialize(from: recordInfo)
              
            }
          
        }
        
      }else{
        
        
      }
      
    }
    
    return netRequest
    
  }
  
  
  
  // 总资产
  private func assetInfoRequest() ->  CaseyNetReqestInfo {
    
    
    let paraDic = ["flag":"1"]

    
    let netRequest = CaseyNetwork.requestInfoJsonPOST(ServiceRootPath + PersonCenterNetPath.assetInfo.rawValue, parameters: paraDic) { (result, error, isCahce) in
      
      
      if  let dataResult = result {
       
        self.assetInfoModel = AssertInfoModel.deserialize(from: dataResult)
      
        ManagerModel.instanse.totalAmount =   self.assetInfoModel?.balance ?? ""
      }else{
        
        
      }
      
    }
    
    return netRequest
    
  }
  
}





