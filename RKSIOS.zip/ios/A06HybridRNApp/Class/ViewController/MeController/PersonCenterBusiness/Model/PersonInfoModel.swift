//
//  PersonInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 19/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON


class PersonInfoModel:HandyJSON {

  
  var customerId:String?    // 会员编号
  var starLevel:Int?        // VIP等级
  var starLevelName:String? // VIP等级描述
  var registDate:String?    // 注册日期
  var loginName:String?     // 登陆名
  var verifyCode:String?    // 预留信息
  var bankCardNum:Int?      // 银行卡张数
  var emailBind:Int?        // 是否绑定邮箱
  var cashCredit:String?    // 本地现金额度
  var realName:String?      // 真实名称
  var gender:String?        // 性别
  var mobileNoBind:Int?     // 是否绑定手机号
  var mobileNo:String?      // 手机号
  var btcNum:Int?           // 比特币卡
  var address:String?       // 地址
  var customerType:Int?     // 会员类型： 0 试玩， 1 真钱
  var gameCredit:Float?     // 本地游戏额度
  var birthday:String?
  
  required init() {
     
  }
  
  
}
