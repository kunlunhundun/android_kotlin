//
//  DiscountActivityModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class DiscountActivityModel:NSObject, HandyJSON,  Codable {
  var tA06MyPromoList:Array<ActivityInfoModel>?
  required override init() {
      super.init()
  }
}


class ActivityInfoModel:NSObject, HandyJSON, Codable {
  
  var abstractText:String? //
  var beginDate:String? // 开始时间
  var configId:Int? //
  var endDate:String? // 结束时间
  var imgTip:String? //
  var imgUrl:String? // 图片url
  var isTop:Int? //
  var linkUrl:String? // 链接url
  var promoCode:String? //
  var promoFlag:Int? //
  var promoKind:Int? //
  var title:String? // 
  
  required override init() {
    super.init()
  }
  
  private var _dateDesc:String?
  var dateDesc:String?{
    
    get{
      
      if _dateDesc == nil {
        
        let beginDateArr = beginDate?.components(separatedBy: " ")
        let endDateArr = endDate?.components(separatedBy: " ")
        
        if (beginDateArr?.count ?? 0) > 1 && (endDateArr?.count ?? 0) > 1 {
          
          var bDateStr = beginDateArr!.first
          var eDateStr = endDateArr!.first
          
          bDateStr = bDateStr?.replacingOccurrences(of: "-", with: "/")
          eDateStr = eDateStr?.replacingOccurrences(of: "-", with: "/")
          
          return bDateStr! + "-" + eDateStr!
          
        }
        
        
      }
      return _dateDesc
      
    }
  }
  
}
