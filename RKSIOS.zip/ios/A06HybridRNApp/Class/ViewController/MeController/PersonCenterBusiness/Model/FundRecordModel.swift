//
//  FundRecordModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class FundRecordModel: NSObject, Codable {
  
  
  var depositRecord:FundRecordInfoModel? // 存款记录
  var drawalRecord:FundRecordInfoModel? // 取款记录条数

}



