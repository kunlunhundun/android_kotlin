//
//  BindPhoneModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class BindPhoneModelNet: NSObject {
  
  var messageId:String?
  
  // 1.没有电话号码绑定手机发送
  func bindSendSmsCode(_ phoneNum:String , _ completion:@escaping NetFinish)  {
    var param = ["mobileNo": phoneNum];
    param["use"] = "3" // 1 注册， 2 登录， 3 绑定 4 找回密码 5 手机修改 9 常规验证
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.sendSmsCode.rawValue, parameters: param) { (result, error, isCache) in
      if let dateResult = result {
        self.messageId = dateResult["messageId"] as? String
      }
      completion(result, error?.errorDesc)
    }
  }
  
  // 2.绑定手机号 （注：不需要传手机号，验证码netSendSmsCode接口会返回一个messageId，传这个messageId数据）
  func netBindPhone(_ smsCode:String , _ completion:@escaping NetFinish)  {
      var  param = ["smsCode": smsCode]
      param["messageId"] = messageId ?? ""
    
      CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bindPhone.rawValue, parameters: param) { (result, error, isCache) in
        if(error?.errorCode.isEqual("GW_800205" as String) == true){
          completion(result, "短信验证吗不正确")
        }else{
          completion(result, error?.errorDesc)
        }
      }
  }
  
  // 3.注册的时候填写了手机号码然后来绑定
  func SendSmsCodeByloginNameToBind(_ loginName:String ,  _ completion:@escaping NetFinish)  {
    var param = ["loginName": loginName];
    param["use"] = "3"
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.sendSmsCodeByLoginName.rawValue, parameters: param) { (result, error, isCache) in
      if let dateResult = result {
        self.messageId = dateResult["messageId"] as? String
      }
      completion(result, error?.errorDesc)
    }
  }
}


extension BindPhoneModelNet {
  
  // 1.第一次验证码解绑
  func SendSmsCodeByloginName(_ loginName:String ,  _ completion:@escaping NetFinish)  {
    var param = ["loginName": loginName];
    param["use"] = "6"
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.sendSmsCodeByLoginName.rawValue, parameters: param) { (result, error, isCache) in
      if let dateResult = result {
        self.messageId = dateResult["messageId"] as? String
      }
      completion(result, error?.errorDesc)
    }
  }
  // 2.更换手机的时候验证短信验证码
  func VerifySmsCode(_ code:String , loginName:String,  _ completion:@escaping NetFinish)  {
    var param = ["loginName": loginName]
    param["use"] = "6"
    param["smsCode"] = code
    param["messageId"] = messageId ?? ""
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.verifySmsCode.rawValue, parameters: param) { (result, error, isCache) in
      completion(result, error?.errorDesc)
    }
  }
  // 3.发送重新绑定的验证码
  func SendSmsCode(_ phoneNum:String , loginName:String,  _ completion:@escaping NetFinish)  {
    var param = ["mobileNo": phoneNum];
    param["loginName"] = loginName
    param["use"] = "5"
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.sendSmsCode.rawValue, parameters: param) { (result, error, isCache) in
      if let dateResult = result {
        self.messageId = dateResult["messageId"] as? String
      }
      completion(result, error?.errorDesc)
    }
  }
  // 4.重新绑定
  func reBindMobileNo(_ smsCode:String , loginName:String,  _ completion:@escaping NetFinish)  {
    var param = ["smsCode": smsCode];
    param["loginName"] = loginName
    param["messageId"] = messageId ?? ""
    param["use"] = "5"
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.changeBindPhone.rawValue, parameters: param) { (result, error, isCache) in
      if error?.errorCode.isEqual("GW_800516" as String) ?? true {
        completion(result, "不能与原手机号一致")
      }else{
        completion(result, error?.errorDesc)
      }
    }
  }
}
