//
//  BindPhoneViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

enum BindPhonePage:Int{
  case fromHomePage = 0
  case fromPersonPage = 1
}

class BindPhoneViewController: UIViewController,  CaseyTableViewDelegate, UITextFieldDelegate {
  
    var personInfoModel:PersonInfoModel?
    private let  _netModel = BindPhoneModelNet()
    private let _implyDescLabel = UILabel()
    private let _commitButton = UIButton()
    private let _phoneNumCell = BankInfoEditCell(.ContentPhone)
    private let _messageCodeCell = BankInfoEditCell(.ContentSmsCode)
    private var _tableView : CaseyTableView?
    private var _titleArr:[(title:String, placehold:String, value:String)] = [("手机号","请输入您的手机号", ""),("验证码","请输入短信中的验证码", "")]
    private var state:Int = 0

  var fromViewPage:BindPhonePage?
  var finishBindCallBackBlock:(( )->Void)?
  convenience init(fromViewPage:BindPhonePage){
    self.init()
    self.fromViewPage = fromViewPage
    self.state = 0
  }

  override func viewDidLoad() {
        super.viewDidLoad()
    
        if personInfoModel?.mobileNoBind == 1 {
          self.title = "验证手机"
        }else{
          self.title = "绑定手机"
        }
        initUIProperty()
        initLayoutSubview()
    }
  
  override func viewDidLayoutSubviews() {
      super.viewDidLayoutSubviews()
      if  _commitButton.gradientLayer == nil {
        _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
        _commitButton.setTitleColor(.white, for: .normal)
      }
  }
  
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        _messageCodeCell.invalidateTimer()
    }
  
    private func initUIProperty() {
        
        _phoneNumCell.titleLabel.text = "手机号"
        _phoneNumCell.contentTextField.placeholder = "请输入您的手机号"
  
        _messageCodeCell.titleLabel.text = "验证码"
        _messageCodeCell.contentTextField.placeholder = "请输入短信验证码"
        _messageCodeCell.cellStyle(.smsCodeStyle)
        weak var weakSelf = self
        _messageCodeCell.sendCodeEventCheckInfoBlock = {
            weakSelf?._phoneNumCell.contentTextField.resignFirstResponder()
            weakSelf?.netSendSmsCode()
        }
      
        _implyDescLabel.backgroundColor = UIColor.init(colorValue: 0x262B2E)
      
        if personInfoModel?.mobileNoBind == 1 {
           _implyDescLabel.text = "为了您的账户资金安全，请验证手机"
        }else{
           _implyDescLabel.text = "为了您的账户资金安全，请绑定手机"
        }
      
        _implyDescLabel.textAlignment = .center
        _implyDescLabel.textColor = UIColor.init(colorValue: 0xDABF94)
        _implyDescLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        self.view.addSubview(_implyDescLabel)
      
        _tableView = CaseyTableView()
        _tableView!.cyDelegate = self
        self.view.addSubview(_tableView!)
        _tableView?.tapGestureRec?.isEnabled = false
        _commitButton.backgroundColor = UIColor.init(colorValue: 0x2C2E38)
        _commitButton.setTitle(title, for: .normal)
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        _commitButton.layer.cornerRadius = 8
        _commitButton.clipsToBounds = true
        _commitButton.addTarget(self, action: #selector(commitEvent(_:)), for: .touchUpInside)
        self.view.addSubview(_commitButton)
    }

    // 检查手机号
    func checkPhoneValid() -> String? {
        if personInfoModel?.mobileNoBind == 1 {
           return nil
        }else{
          if self._phoneNumCell.contentTextField.text?.count == 0 {
            return "请输入手机号"
          }
          // 判断电话话吗是否是注册的时候带来的
          let numberStr = self._phoneNumCell.contentTextField.text!
          if(numberStr.contains("****")){
            return nil
          }else{
            if RegularExp.isValidateMobile(self._phoneNumCell.contentTextField.text!) == false {
              return "手机号有误"
            }
          }
        }
        return nil
    }
  
    // 信息未提示信息
    func checkInfoIsValid() -> String? {
      
      if (personInfoModel?.mobileNoBind ?? 0) == 0  {
        if let errorImply =  _phoneNumCell.checkContentInfo() {
          _tableView?.reloadData()
          return errorImply
        }
      }
      
      if let errorImply =  _messageCodeCell.checkContentInfo() {
        _tableView?.reloadData()
        return errorImply
      }
      return nil
    }
}


// MARK: 按钮的响应事件
extension BindPhoneViewController {
  
  @objc func commitEvent(_ sender:UIButton){
    
    let phoneNum = _phoneNumCell.contentTextField.text!
    let str = sender.title(for: .normal)!
    
    if str.isEqual("绑定手机" as String) {
      if (personInfoModel?.mobileNoBind ?? 0) == 0  {
        
        if phoneNum.contains("****") == true {
          if self._phoneNumCell.contentTextField.text?.count == 0 {
            ProgressTopPopView.showPopView(content: "请输入手机号" , popStyle: .errorMsgToast)
            return
          }
          netBindPhone()
        }else{
          if let _ = checkInfoIsValid() {
            return
          }
          netBindPhone()
        }
      }
        
      else{
        if let _ = checkInfoIsValid() {
          return
        }
        netChangeBindPhoneNum()
      }
    }
    
    if str.isEqual("验证手机" as String) {
      if (personInfoModel?.mobileNoBind ?? 0) > 0  {
        if let _ = checkInfoIsValid() {
          return
        }
        //短信验证码
        let code = _messageCodeCell.contentTextField.text!
        let name = personInfoModel?.loginName ?? ""
        
          _netModel.VerifySmsCode(code, loginName: name) { (result, error) -> (Void) in
          if error != nil {
            ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
          }else {
            self.title = "绑定手机"
            self._implyDescLabel.text = "为了您的账户资金安全，请绑定手机"
            self._commitButton.setTitle(self.title, for: .normal)
            self._phoneNumCell.contentTextField.isEnabled = true
            self._phoneNumCell.contentTextField.text = ""
            self._messageCodeCell.contentTextField.text = ""
            self._messageCodeCell._timerCount = 0
            self._messageCodeCell.timeCountEvent()
            ProgressTopPopView.showPopView(content: "验证成功", popStyle: .successMsgToast)
            self.state = 3
          }
            
        }
      }
    }
  }
}


// MARK: 设置UI
extension BindPhoneViewController {

  private func initLayoutSubview()    {
    _implyDescLabel.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.left.right.equalToSuperview()
      make.height.equalTo(30)
    }
    _tableView?.snp.makeConstraints { (make) in
      make.top.equalToSuperview().offset(30)
      make.left.right.equalToSuperview()
      make.bottom.equalToSuperview()
    }
    _commitButton.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.top.equalToSuperview().offset(208)
      make.height.equalTo(54)
    }
  }
}

// MARK:tableView的代理方法
extension BindPhoneViewController {
  func tableView(_ tableView: CaseyTableView, numberOfRowsInSection section: Int) -> Int {
    return 2
  }
  func tableView(_ tableView: CaseyTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    if indexPath.row == 0 {
      _commitButton.snp.updateConstraints { (make) in
        make.top.equalToSuperview().offset(_phoneNumCell.cellHeight*2 + 80)
      }
      return _phoneNumCell.cellHeight
    }else {
      _commitButton.snp.updateConstraints { (make) in
        make.top.equalToSuperview().offset(_phoneNumCell.cellHeight*2 + 80)
      }
      return _messageCodeCell.cellHeight
    }
  }
  
  func tableView(_ tableView: CaseyTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    if indexPath.row == 0 {
      
      // 注册不要电话号码的时候
      if personInfoModel?.mobileNoBind == 1 {
        _phoneNumCell.contentTextField.text = personInfoModel?.mobileNo
        _phoneNumCell.contentTextField.isEnabled = false
        _phoneNumCell.contentTextField.textColor = UIColor.init(colorValue: 0x858586)
        _phoneNumCell.titleLabel.textColor = UIColor.init(colorValue: 0x858586)
      }
      // 注册有电话号吗的时候
      if personInfoModel?.mobileNoBind == 0 && personInfoModel?.mobileNo != "" && personInfoModel?.mobileNo != nil{
        _phoneNumCell.contentTextField.text = personInfoModel?.mobileNo
        _phoneNumCell.contentTextField.isEnabled = false
        _phoneNumCell.contentTextField.textColor = UIColor.init(colorValue: 0x858586)
        _phoneNumCell.titleLabel.textColor = UIColor.init(colorValue: 0x858586)
      }
      
      return _phoneNumCell
    }else {
      return _messageCodeCell
    }
  }
  func tableView(_ tableView: CaseyTableView, didSelectRowAt indexPath: IndexPath) {
    
  }
}

// MARK:发送验证码
extension BindPhoneViewController {
  
  func netSendSmsCode()  {
    
    if let errorImply = checkPhoneValid() {
      ProgressTopPopView.showPopView(content: errorImply , popStyle: .errorMsgToast)
      return
    }
    
    let number = self._phoneNumCell.contentTextField.text
    
    if (personInfoModel?.mobileNoBind ?? 0) > 0 {
    
      if self.state == 3 {
        
        let old = personInfoModel?.mobileNo ?? ""
        let new = _phoneNumCell.contentTextField.text!
        if old.isEqual(new as String) {
          ProgressTopPopView.showPopView(content: "不能与原手机号一致", popStyle: .successMsgToast)
          return
        }
      
        let phoneNum = _phoneNumCell.contentTextField.text!
        let phoneNumSecret = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: phoneNum)
        let loginName = personInfoModel?.loginName! ?? ""
        
        if self._phoneNumCell.contentTextField.text?.count == 0 {
          ProgressTopPopView.showPopView(content: "请输入手机号" , popStyle: .errorMsgToast)
          return
        }
        if RegularExp.isValidateMobile(self._phoneNumCell.contentTextField.text!) == false {
          ProgressTopPopView.showPopView(content: "手机号有误" , popStyle: .errorMsgToast)
          return
        }
        
        _messageCodeCell.startTimerByExtern()
        LoadingView.showLoadingViewWith(to: self.view)
        _netModel.SendSmsCode(phoneNumSecret, loginName: loginName) { (result, error) -> (Void) in
          LoadingView.hideLoadingView(for: self.view)

          if error == nil {
              ProgressTopPopView.showPopView(content: "发送成功", popStyle: .successMsgToast)
          }else{
              ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
          }
        }
        
      }else{
        
        let loginnName = personInfoModel?.loginName! ?? ""
        
         LoadingView.showLoadingViewWith(to: self.view)
        _messageCodeCell.startTimerByExtern()
        _netModel.SendSmsCodeByloginName(loginnName) { (result, error) -> (Void) in
          LoadingView.hideLoadingView(for: self.view)
          if error != nil {
            ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
          }else{
            ProgressTopPopView.showPopView(content: "发送成功", popStyle: .successMsgToast)
          }
        }
      }
    }
      
    // 注册的时候填写了手机号
    else if (personInfoModel?.mobileNoBind ?? 0) <= 0 && number?.contains("*****") ?? true {
      if self._phoneNumCell.contentTextField.text?.count == 0 {
        ProgressTopPopView.showPopView(content: "请输入手机号" , popStyle: .errorMsgToast)
        return
      }
      let phone = _phoneNumCell.contentTextField.text!
      let iphoneS = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: phone)
      _messageCodeCell.startTimerByExtern()
      LoadingView.showLoadingViewWith(to: self.view)
      _netModel.SendSmsCodeByloginNameToBind(iphoneS) { (result, error) -> (Void) in
        LoadingView.hideLoadingView(for: self.view)
        if error != nil {
          ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
        }else {
          ProgressTopPopView.showPopView(content: "发送成功", popStyle: .successMsgToast)
        }
      }
    }
    
    

    else{
      
      if self._phoneNumCell.contentTextField.text?.count == 0 {
        ProgressTopPopView.showPopView(content: "请输入手机号" , popStyle: .errorMsgToast)
        return
      }
      if RegularExp.isValidateMobile(self._phoneNumCell.contentTextField.text!) == false {
        ProgressTopPopView.showPopView(content: "手机号有误" , popStyle: .errorMsgToast)
        return
      }
      let phone = _phoneNumCell.contentTextField.text!
      let iphoneS = ManagerModel.encrypPswOrPhoneNumWith(passWordOrPhoneNum: phone)
      _messageCodeCell.startTimerByExtern()
       LoadingView.showLoadingViewWith(to: self.view)
      _netModel.bindSendSmsCode(iphoneS) { (result, error) -> (Void) in
        LoadingView.hideLoadingView(for: self.view)
        if error != nil {
          ProgressTopPopView.showPopView(content: error ?? "" , popStyle: .errorMsgToast)
        }else {
          ProgressTopPopView.showPopView(content: "发送成功", popStyle: .successMsgToast)
        }
      }
    }
    
    
    
  }
}


// MARK: 绑定手机号
extension BindPhoneViewController {

  func netBindPhone()  {
    
    LoadingView.showLoadingViewWith(to: self.view)
    let phoneNumber = _phoneNumCell.contentTextField.text! as NSString
    
    _netModel.netBindPhone(_messageCodeCell.contentTextField.text!) { [weak self] (result, errorDesc) -> (Void) in
      LoadingView.hideLoadingView(for: self?.view)
      
      if errorDesc != nil {
        ProgressTopPopView.showPopView(content: errorDesc ?? "绑定失败", popStyle: .errorMsgToast)
      }
      
      else {
        ProgressTopPopView.showPopView(content: "手机号绑定成功", popStyle: .successMsgToast)
        ManagerModel.instanse.personInfoModel?.mobileNoBind = 1
        
        if let _ = self?.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
          if(phoneNumber.length == 11){
            let mobileNo = phoneNumber.substring(to: 2) +  "********" + phoneNumber.substring(with: NSRange.init(location: phoneNumber.length-1, length: 1))
            self?.personInfoModel?.mobileNo = mobileNo
            ManagerModel.instanse.personInfoModel?.mobileNo = mobileNo
            self?.personInfoModel?.mobileNoBind = 1
          }
        }
        
        if let targetViewCtr = self?.navigationController?.searchNearViewController(targerClass: PersonCenterViewController.classForCoder()) {
          targetViewCtr.isFlushView = .FlushByNoShowLoading
        }
        
        // 这里是首页进入的
        if self?.fromViewPage == .fromHomePage {
          let time: TimeInterval = 2.0
          DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
            self?.navigationController?.popToRootViewController(animated: true)
          }
          return
        }
        
        // 这里时存款和取款进入的
        let time: TimeInterval = 2.0
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) {
          self?.navigationController?.popViewController(animated: true)
          self?.finishBindCallBackBlock?()
        }
      }
    }
  }
}


// MARK: 更改绑定手机号
extension BindPhoneViewController {

  func netChangeBindPhoneNum() {
    
    LoadingView.showLoadingViewWith(to: self.view)
    let phoneNumber = _phoneNumCell.contentTextField.text! as NSString
    let smsgCode = _messageCodeCell.contentTextField.text! as NSString
    let loginName = personInfoModel?.loginName! ?? ""
    
    _netModel.reBindMobileNo(smsgCode as String, loginName: loginName) { (result, errorDesc) -> (Void) in
      
      LoadingView.hideLoadingView(for: self.view)
      if errorDesc != nil {
        ProgressTopPopView.showPopView(content: errorDesc! , popStyle: .errorMsgToast)
        self._phoneNumCell.contentTextField.text = ""
        self._messageCodeCell.contentTextField.text = ""
      }
      else {
        ProgressTopPopView.showPopView(content: "手机号修改成功", popStyle: .successMsgToast)
        ManagerModel.instanse.personInfoModel?.mobileNoBind = 1
        if let _ = self.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
          
          if(phoneNumber.length == 11){
            let mobileNo = phoneNumber.substring(to: 2) +  "********" + phoneNumber.substring(with: NSRange.init(location: phoneNumber.length-1, length: 1))
            self.personInfoModel?.mobileNo = mobileNo
            self.personInfoModel?.mobileNoBind = 1
            ManagerModel.instanse.personInfoModel?.mobileNo = mobileNo
          }
        }
        if let targetViewCtr = self.navigationController?.searchNearViewController(targerClass: PersonCenterViewController.classForCoder()) {
          targetViewCtr.isFlushView = .FlushByNoShowLoading
        }
        self.navigationController?.popViewController(animated: true)
      }
    }
  }
}





