//
//  AddBitCardViewController.swift
//  PersonReport
//
//  Created by Casey on 15/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class AddBitCardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, BankInfoEditCelllDelegate{

    private var _tableView : UITableView?
    let _commitButton = UIButton()
    let _moneyAddressCell = BankInfoEditCell(.ContentBitCoin) // 钱包地址cell
    let _moneyAddressSureCell = BankInfoEditCell(.ContentBitCoinAgainSure) // 确认地址cell
  
    var currentEditingTextFiled: UITextField?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "添加比特币卡"
        initUIProperty()
        initLayoutSubview()
    }
  
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if  _commitButton.gradientLayer == nil {
          _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
          _commitButton.setTitleColor(.white, for: .normal)
        }
    }
  
    private func initUIProperty()    {
    
        _moneyAddressCell.cellStyle(.baseStyle)
        _moneyAddressCell.titleLabel.text = "钱包地址"
        _moneyAddressCell.contentTextField.placeholder = "请填写您的比特币钱包地址"
        _moneyAddressCell.delegate = self
      
        _moneyAddressSureCell.titleLabel.text = "确认地址"
        _moneyAddressSureCell.contentTextField.placeholder = "请再填写一次"
        _moneyAddressSureCell.cellStyle(.baseStyle)
        _moneyAddressSureCell.delegate = self
      
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView!.register(BankInfoEditCell.classForCoder(), forCellReuseIdentifier: "BankInfoEditCell")
        _tableView!.isScrollEnabled = false
        self.view.addSubview(_tableView!)
        
        _commitButton.backgroundColor = UIColor.init(colorValue: 0x2C2E38)
        _commitButton.setTitle("提交", for: .normal)
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        _commitButton.layer.cornerRadius = 8
        _commitButton.addTarget(self, action: #selector(commitEvent(_:)), for: .touchUpInside)
        _commitButton.clipsToBounds = true
        self.view.addSubview(_commitButton)
    }
    
    private func initLayoutSubview()    {
        _tableView?.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        _commitButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(189+50)
            make.height.equalTo(54)
        }
    }
  
    // 信息未提示信息
    func checkInfoIsValid() -> String? {
      
      if let errorImply =  _moneyAddressCell.checkContentInfo() {
        _tableView?.reloadData()
        return errorImply
      }
      if let errorImply =  _moneyAddressSureCell.checkContentInfo() {
        _tableView?.reloadData()
        return errorImply
      }
      return nil
    }
  
    //MARK: 提交事件
    @objc func commitEvent(_ sender:UIButton){
      
      if _moneyAddressCell.contentTextField.text != _moneyAddressSureCell.contentTextField.text! {
        _moneyAddressSureCell.setErrorImplyForCell(errorImply: "两次输入比特币地址不一致")
        return
      }
      netAddBitCard()
    }


    //MARK: tableview delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
          return _moneyAddressCell.cellHeight
        }else {
          return _moneyAddressSureCell.cellHeight
      }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if  indexPath.row == 0 {
            return _moneyAddressCell
        }else{
            return _moneyAddressSureCell
        }
    }
  
    //MARK: network
    func netAddBitCard()  {
      
      var cardInfo = [String:String]()
      cardInfo["btcName"] = "比特币钱包"
      cardInfo["btcUrl"] = _moneyAddressSureCell.contentTextField.text
      
      LoadingView.showLoadingViewWith(to: self.view)
      AddBitCardModelNet().netBitCardAdd(cardInfo) { (result, errorDesc) -> (Void) in
      
        LoadingView.hideLoadingView(for: self.view)
        if errorDesc != nil {
          ProgressTopPopView.showPopView(content: errorDesc ?? "" , popStyle: .errorMsgToast)
        }else {
          ProgressTopPopView.showPopView(content: "比特币卡添加成功", popStyle: .successMsgToast)
          if let targetViewCtr = self.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
            targetViewCtr.isFlushView = .FlushByNoShowLoading
          }
          
          self.navigationController?.popViewController(animated: true)
        }
      }
    }
}
