//
//  AddBitCardModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class AddBitCardModelNet: NSObject {
  
  
  // 添加比特币
  func netBitCardAdd(_ param:[String:Any] , _ completion:@escaping NetFinish)  {
    
    
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bitCardAdd.rawValue, parameters: param) { (result, error, isCache) in
      
      
      if let dateResult = result {
        
          completion(dateResult, error?.errorDesc)
        
      }else{
        
          completion(nil, error?.errorDesc)
      }
      
      
    }
    
  }
  
}
