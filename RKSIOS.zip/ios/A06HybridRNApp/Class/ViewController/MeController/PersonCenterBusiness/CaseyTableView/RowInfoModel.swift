//
//  RowInfoModel.swift
//  CaseyTableView
//
//  Created by Casey on 07/12/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

struct RowInfoModel {

    var y:CGFloat?;
    var height:CGFloat?;
    
}
