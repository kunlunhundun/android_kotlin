//
//  PersonCenterModuleNetPath.swift
//  A06HybridRNApp
//
//  Created by Casey on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

enum PersonCenterNetPath:String {
  
  case accountInfo = "/_glaxy_a06_/customer/getByLoginName"             // 账号信息
  case discountActivity = "/_glaxy_a06_/_extra_/a06/promo/a06MyPromo"   // 优惠活动
  case assetInfo = "/_glaxy_a06_/customer/getBalance"                   // 总资产
  
  // 查询报表记录
  case fundRecordInfo = "/_glaxy_a06_/credit/query"                     // 资金记录 存取款 （报表）（废弃）
  case fundRecordDeposit = "/_glaxy_a06_/deposit/queryTrans"            // 存款交易列表 （报表）
  case fundRecordWithdraw = "/_glaxy_a06_/withdraw/queryRequest"        // 提现交易列表 （报表）
  case fundRecordXM = "/_glaxy_a06_/xm/queryRequest"                    // 洗码提案列表 （报表）
  case fundRecordPromo = "/_glaxy_a06_/promo/queryRequest"              // 优惠提案列表（报表）
  
  // 删除报表记录
  case fundRecordDelete = "/_glaxy_a06_/credit/delete"                  // 资金记录删除 （废弃）
  case fundRecordDepositDelelte = "/_glaxy_a06_/deposit/deleteTrans"    // 删除存款交易记录  （报表）
  case fundRecordWithdrawDelelte = "/_glaxy_a06_/withdraw/deleteRequest"// 删除提现交易记录 （报表）
  case fundRecordXMDelelte = "/_glaxy_a06_/xm/deleteRequest"            // 删除洗码提案记录 （报表）
  case fundRecordPromoDelelte = "/_glaxy_a06_/promo/deleteRequest"      // 删除优惠提案记录（报表）
  
  case bankAndBitQuery = "/_glaxy_a06_/account/query"                   // 银行卡，比特币查询
  case bankCardAdd = "/_glaxy_a06_/account/createBank"                  // 银行卡添加
  case bitCardAdd = "/_glaxy_a06_/account/createBtc"                    // 比特币添加
  case bankCardDelete = "/_glaxy_a06_/account/delete"                   // 银行卡删除
  
  case bankNameList = "/_glaxy_a06_/account/queryBanks"                 // 银行列表
  case cityList = "/_glaxy_a06_/queryCities"                            // 城市列表
  case realName = "/_glaxy_a06_/customer/modify"                        // 实名认证
  
  case bindPhone = "/_glaxy_a06_/customer/bindMobileNoV2"               // 绑定手机号
  case changeBindPhone = "/_glaxy_a06_/customer/reBindMobileNo"         // 更换绑定的手机号
  case sendSmsCode = "/_glaxy_a06_/sms/sendCode"                        // 发送验证码
  case sendSmsCodeByLoginName = "/_glaxy_a06_/sms/sendCodeByLoginName"  // 通过用户名发送验证码
  case verifySmsCode = "/_glaxy_a06_/sms/verifySmsCode"                 // 验证短信验证码
  
//  func asURL() throws -> URL {
//    let urlString = ServiceRootPath + self.rawValue
//    return URL(string: urlString)!
//  }
  
}


