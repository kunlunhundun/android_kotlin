//
//  AddBankInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class AddBankInfoModel: NSObject, Codable {
  
  
  var accountName:String? // 账号名字
  var accountNo:String? // 账号
  var bankName:String? // 银行名
  var accountType:String? // 银行卡类别（借记卡)
  var province:String? // 省
  var city:String?  // 城市
  var bankBranchName:String? // 支行
  
  var btcName:String? // 比特币钱包
  var btcUrl:String? // 比特币 地址
  
  func test()  {
    
      let tesss = AddBankInfoModel()
    
  
    
  }
}
