//
//  BandNameInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class BandNameInfoModel: NSObject, HandyJSON, Codable {

  
  var  bankCode:String?
  
  var  bankIcon:String?
  var  bankIconUrl:String?{
    
    get{
      return  ManagerModel.instanse.fastCdnDomainName  + (bankIcon ?? "")
    }
  }
  var  bankName:String?
  
  
  required override init() {
    super.init()
  }
  
}


class CardBinTypeModel:HandyJSON {
  
  var bankCode:String?
  var bankName:String?
  var cardBin:String?
  var cardName:String?
  var bankIcon:String?
  var cardNoLength:String?
  var cardType:String?
  var cardTypeDesc:String?
  
  
  required init() {
    
  }
}
