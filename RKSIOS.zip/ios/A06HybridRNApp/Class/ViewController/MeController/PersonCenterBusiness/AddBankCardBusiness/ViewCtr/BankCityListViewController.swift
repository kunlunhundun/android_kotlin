//
//  BankCityListViewController.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class BankCityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
  
  var completionSelect:((_ provinceName:String?, _ cityName:String?)->(Void))?
  var dataModel:ProvinceInfoModel?

  private var _tableView:UITableView?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    self.title = "省份与城市"
    
    initUIProperty()
    initLayoutSubview()
  
  }
  
  private func initUIProperty()    {
    
    _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
    _tableView!.delegate = self
    _tableView!.dataSource = self
    _tableView!.backgroundColor = .clear
    _tableView!.separatorStyle = .none
    _tableView!.register(BankCardOfCityNameCell.classForCoder(), forCellReuseIdentifier: "BankCardOfCityNameCell")
    self.view.addSubview(_tableView!)
  }
  
  private func flushViewData() {
    
    
    _tableView?.reloadData()
    
  }
  
  private func initLayoutSubview()    {
    
    _tableView?.snp.makeConstraints { (make) in
      
      make.left.right.equalToSuperview()
      make.top.bottom.equalToSuperview()
      
    }
  }
  
  
  //MARK: tableview delegate
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
      return dataModel?.cities?.count ?? 0
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
    return 64
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "BankCardOfCityNameCell", for: indexPath) as? BankCardOfCityNameCell
    
    let cityInfo = dataModel?.cities?[indexPath.row]
    
    cell?.bankTypeNameLabel.text = cityInfo?.cityName ?? ""
    cell?.rightArrowImageView.isHidden = true
    
    return cell!
  }
  
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
    
      let cityInfo = dataModel?.cities?[indexPath.row]
      self.completionSelect?(dataModel?.provinceName, cityInfo?.cityName )
      self.completionSelect = nil
    
    var isFindAddBank = false
    guard (self.navigationController?.viewControllers) != nil else {
       return
    }
    for viewcontroller in (self.navigationController?.viewControllers)! {
      if (viewcontroller.isKind(of: AddBankCardViewController.classForCoder()) ){
         isFindAddBank = true
      }
    }
    if isFindAddBank {
      self.navigationController?.popToViewControllerOfClassName(classType: AddBankCardViewController.classForCoder(), animated: true)
    }else {
      self.navigationController?.popToViewControllerOfClassName(classType: ManualBankInputDetailViewController.classForCoder(), animated: true)

    }
    
  }
  
  
}
