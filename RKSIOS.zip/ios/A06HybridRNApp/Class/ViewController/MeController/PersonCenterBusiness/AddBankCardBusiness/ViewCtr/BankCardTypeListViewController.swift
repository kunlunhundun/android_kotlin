
//
//  BankCardTypeListViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class BankCardTypeListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var _tableView:UITableView?
    var _cardTypeNameArr = ["借记卡"]
    var completionSelect:((_ bandTypeName:String)->(Void))?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "银行卡类型"
        
        initUIProperty()
        initLayoutSubview()
    }
    
    private func initUIProperty()    {
        
      
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView!.register(BankCardTypeNameCell.classForCoder(), forCellReuseIdentifier: "BankCardTypeNameCell")
        self.view.addSubview(_tableView!)
    }
    
    private func initLayoutSubview()    {
        
        _tableView?.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.top.bottom.equalToSuperview()
            
        }
    }
    
    
    //MARK: tableview delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return _cardTypeNameArr.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 64
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "BankCardTypeNameCell", for: indexPath) as? BankCardTypeNameCell
        cell?.bankTypeNameLabel.text = _cardTypeNameArr[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        self.completionSelect?(self._cardTypeNameArr[indexPath.row])
        self.completionSelect = nil
        self.navigationController?.popViewController(animated: true)
    }
}

