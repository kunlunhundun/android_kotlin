//
//  CityInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class ProvinceInfoModel: NSObject, HandyJSON, Codable {
  
  var provinceName:String?
  var cities:[CityInfoModel]?
  
  required override init() {
    super.init()
  }
  
  
  private var _nextLevel:Bool?
  var isHaveNextLevel:Bool {
    
      get{
        
        if _nextLevel == nil {
          _nextLevel = true
          if self.cities?.count == 1 {
            
            let cityInfoModel = self.cities!.first
            let cityName = cityInfoModel?.cityName
            if let _ =  provinceName?.elementsEqual(cityName ?? "") {
              _nextLevel = false
            }
          }
        }
        
        return _nextLevel!
      }
    
  }
}


class CityInfoModel: NSObject, HandyJSON,  Codable {
  
    var cityName:String?
  
    required override init() {
      super.init()
    }
  
}
