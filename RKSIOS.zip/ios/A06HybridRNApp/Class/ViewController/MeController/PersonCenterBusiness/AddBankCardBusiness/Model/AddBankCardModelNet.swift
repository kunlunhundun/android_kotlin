//
//  AddBankCardModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 21/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class AddBankCardModelNet: NSObject {
  
  //MARK:添加银行卡
    func netBankCardAdd(_ param:[String:Any] , _ completion:@escaping NetFinish)  {
      CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bankCardAdd.rawValue, parameters: param) { (result, error, isCache) in
        if error?.errorCode.isEqual("GW_800824" as String) ?? false {
           completion(result, "暂不支持取款到银行信用卡,请更换")
        }else{
           completion(result, error?.errorDesc)
        }
    }
  }
  
  //MARK:银行列表
  func netBankCardList(_ param:[String:Any]? , _ completion:@escaping NetFinish)  {
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.bankNameList.rawValue, parameters: param) { (result, error, isCache) in
      var bankNameArr:[BandNameInfoModel]?
      if let dataResult = result?["result"] as? [[String:String]]{
          bankNameArr = [BandNameInfoModel].deserialize(from: dataResult) as? [BandNameInfoModel]
      }
      completion(bankNameArr, error?.errorDesc)
    }
  }
  
  //MARK:查询省市列表
  func  netQueryCityList(_ completion:@escaping NetFinish){
    CaseyNetwork().requestJsonPost(ServiceRootPath + PersonCenterNetPath.cityList.rawValue, parameters:nil) { (result, error, isCache) in
      var provinceModel = [ProvinceInfoModel]()
      if let dataResult = result?["result"] as? [[String:AnyObject]]{
        if let result = [ProvinceInfoModel].deserialize(from: dataResult) as? [ProvinceInfoModel]  {
            provinceModel = result
        }
      }
      completion(provinceModel, error?.errorDesc)
    }
  }
}
