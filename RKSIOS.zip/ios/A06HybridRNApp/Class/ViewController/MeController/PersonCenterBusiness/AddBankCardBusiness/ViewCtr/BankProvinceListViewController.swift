//
//  BankCardOfCityViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class BankProvinceListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    var _tableView:UITableView?
    var completionSelect:((_ provinceName:String?, _ cityName:String?)->(Void))?
    let _dataModelNet = AddBankCardModelNet()
    var _dataModel:[ProvinceInfoModel]?
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "省份与城市"
        
        initUIProperty()
        initLayoutSubview()
        netLoadData()
    }
    
    private func initUIProperty()    {
        
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView!.register(BankCardOfCityNameCell.classForCoder(), forCellReuseIdentifier: "BankCardOfCityNameCell")
        self.view.addSubview(_tableView!)
    }
  
    private func flushViewData() {
      
      
      _tableView?.reloadData()
      
    }
    
    private func initLayoutSubview()    {
        
        _tableView?.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.top.bottom.equalToSuperview()
            
        }
    }
    
    
    //MARK: tableview delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return _dataModel?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 64
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "BankCardOfCityNameCell", for: indexPath) as? BankCardOfCityNameCell
      
        let provinceInfoModel = _dataModel![indexPath.row]
      
        cell?.bankTypeNameLabel.text = provinceInfoModel.provinceName
        if provinceInfoModel.isHaveNextLevel {
          cell?.rightArrowImageView.isHidden = false
        }else{
          cell?.rightArrowImageView.isHidden = true
        }
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
      
        let provinceInfoModel = _dataModel![indexPath.row]
        if provinceInfoModel.isHaveNextLevel {
          
            let cityListVC = BankCityListViewController()
            cityListVC.dataModel = provinceInfoModel
            cityListVC.completionSelect = self.completionSelect
            self.navigationController?.pushViewController(cityListVC, animated: true)
          
        }else{
          
            self.completionSelect?(provinceInfoModel.provinceName, provinceInfoModel.provinceName )
            self.completionSelect = nil
            self.navigationController?.popViewController(animated: true)
        }
      
    }

  
    //MARK: Network
  
    func netLoadData()  {
      
      LoadingView.showLoadingViewWith(to: self.view)
      _dataModelNet.netQueryCityList() { (reslut, errorDesc)in
        
          LoadingView.hideLoadingView(for: self.view)
          self._dataModel = reslut as? [ProvinceInfoModel]
          self.flushViewData()
        
          if errorDesc != nil {
            
            ProgressTopPopView.showPopView(content: errorDesc! , popStyle: .errorMsgToast)
            
          }
        
      }
      
    }
    
}
