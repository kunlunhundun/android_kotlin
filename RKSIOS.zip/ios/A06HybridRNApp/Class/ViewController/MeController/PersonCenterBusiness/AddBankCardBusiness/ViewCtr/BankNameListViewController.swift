//
//  BankListViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit




class BankNameListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

  
    let dataModelNet = AddBankCardModelNet()
    var _dataModel:[BandNameInfoModel]?
    var _tableView:UITableView?
    
    var completionSelect:((_ data:BandNameInfoModel)->(Void))?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "选择银行"
        
        initUIProperty()
        initLayoutSubview()
        netLoadData()
    }
    
    private func initUIProperty()    {
        
        _tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        _tableView!.delegate = self
        _tableView!.dataSource = self
        _tableView!.backgroundColor = .clear
        _tableView!.separatorStyle = .none
        _tableView!.register(BankNameCell.classForCoder(), forCellReuseIdentifier: "BankNameCell")
        self.view.addSubview(_tableView!)
    }
  
    private func flushViewData() {
      
        _tableView?.reloadData()
    }
  
    private func initLayoutSubview()    {
        
        _tableView?.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.top.bottom.equalToSuperview()
            
        }
    }
    
    
    //MARK: tableview delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return _dataModel?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 64
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "BankNameCell", for: indexPath) as? BankNameCell
        cell?.dataModel = _dataModel?[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        self.completionSelect?(_dataModel![indexPath.row])
        self.completionSelect = nil
        self.navigationController?.popViewController(animated: true)
    }
  
  
  
  //MARK: Network
  
  func netLoadData()  {
    
    LoadingView.showLoadingViewWith(to: self.view)
    dataModelNet.netBankCardList(nil) { (reslut, errorDesc)in
      
        LoadingView.hideLoadingView(for: self.view)
        self._dataModel = reslut as? [BandNameInfoModel]
        self.flushViewData()
        if errorDesc != nil {
        
          ProgressTopPopView.showPopView(content: errorDesc! , popStyle: .errorMsgToast)

        }
    }
    
  }
    
}
