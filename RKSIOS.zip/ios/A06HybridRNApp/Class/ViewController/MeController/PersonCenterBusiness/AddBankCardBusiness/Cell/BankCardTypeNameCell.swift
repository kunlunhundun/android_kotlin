//
//  BankCardTypeNameCell.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class BankCardTypeNameCell: UITableViewCell {

    let bankTypeNameLabel =  UILabel()
    
    let _bottomLineView = UIView()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        initUIProperty()
        initLayoutSubview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    private func initUIProperty()  {
        
        self.backgroundColor = .clear
        self.selectionStyle = .none
        
        
        bankTypeNameLabel.textColor = .white
        bankTypeNameLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        self.contentView.addSubview(bankTypeNameLabel)
        
        _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        self.contentView.addSubview(_bottomLineView)
    }
    
    private func initLayoutSubview()  {
        
    
        
        bankTypeNameLabel.snp.makeConstraints { (make) in
            
            make.left.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
            make.width.equalTo(160)
            make.height.equalTo(30)
        }
        
        _bottomLineView.snp.makeConstraints { (make) in
            
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
}

