//
//  AddBankCardViewController.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit
import RxSwift

class AddBankCardViewController: UIViewController, CaseyTableViewDelegate, BankInfoEditCelllDelegate {

  
    var addBankInfo = AddBankInfoModel()
    var _selectBankName:BandNameInfoModel?
    var _cellArr = [BankInfoEditCell]()
    var finishCallBack:(()->Void)?
    var currentEditingTextFiled: UITextField?
    let disposeBag = DisposeBag()
    let _commitButton = UIButton()
    let _tapGeutton = UIButton()
  
    var tapGesture = UITapGestureRecognizer()
    
    private var _tableView : CaseyTableView?
    private var _titleArr:[(title:String, placehold:String, value:String)] = [("持卡人","输入持卡人姓名", ""),("银行卡号","您的取款银行卡号(不支持信用卡)", ""),("银行名称","请选择银行", ""),("省份与城市","请选择省份", ""), ("开户行支行","输入开户行支行", "")]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "添加银行卡"
        initUIProperty()
        initLayoutSubview()
        //registerForKeyboardNotifications()
    }
  
    func registerForKeyboardNotifications(){
      NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillAppear(_:) ), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
      NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillDisappear(_:) ), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
  
    @objc func keyboardWillAppear(_ anotification:Notification) {
      let Gesture = UITapGestureRecognizer.init(target: self, action: #selector(tapGestureEvent(_:)))
      self.tapGesture = Gesture
      
    }
    @objc func keyboardWillDisappear(_ anotification:Notification){
      _tableView?.removeGestureRecognizer(self.tapGesture)
    }
  
    override func viewDidLayoutSubviews() {
      super.viewDidLayoutSubviews()
      if  _commitButton.gradientLayer == nil {
        _commitButton.gradientInBottom(withVertical: true, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
        _commitButton.setTitleColor(.white, for: .normal)
      }
    }
  
    private func initUIProperty() {
        
        _tableView = CaseyTableView()
        _tableView!.cyDelegate = self
        self.view.addSubview(_tableView!)
    
        _commitButton.backgroundColor = UIColor.init(colorValue: 0x2C2E38)
        _commitButton.setTitle("提交", for: .normal)
        _commitButton.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
        _commitButton.layer.cornerRadius = 8
        _commitButton.addTarget(self, action: #selector(commitEvent(_:)), for: .touchUpInside)
        _commitButton.clipsToBounds = true
        self.view.addSubview(_commitButton)
      
        _tapGeutton.backgroundColor = UIColor.clear
        _tapGeutton.addTarget(self, action: #selector(keyhiden(_:)), for: .touchUpInside)
        self.view.addSubview(_tapGeutton)
    }
  
    @objc func tapGestureEvent(_ gesture:UITapGestureRecognizer){
      self.view.endEditing(true)
    }
    @objc func keyhiden(_ sender:UIButton) {
      self.view.endEditing(true)
    }
  
    private func initLayoutSubview() {
        _tableView?.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        _commitButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(94*3+60*2)
            make.height.equalTo(54)
        }
        _tapGeutton.snp.makeConstraints { (make) in
          make.left.equalToSuperview().offset(0)
          make.right.equalToSuperview().offset(0)
          make.height.equalTo(50+34)
          make.bottom.equalTo(_commitButton.snp.top).offset(0)
        }
    }
  
    //MARK: 提交事件
    @objc func commitEvent(_ sender:UIButton){
      for editCell in _cellArr {
        let errorImply =  editCell.checkContentInfo()
        if errorImply != nil {
          _tableView?.reloadData()
          return
        }
      }
      netAddBankCard()
    }
    
    // MARK: tableview delegate
    func tableView(_ tableView: CaseyTableView, numberOfRowsInSection section: Int) -> Int {
         return _titleArr.count
    }
    
    func tableView(_ tableView: CaseyTableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
      
      if indexPath.row < _cellArr.count {
        
          let cell = _cellArr[indexPath.row]
          return cell.cellHeight
        
      }else {
          return 64
      }
    }
    
    func tableView(_ tableView: CaseyTableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        if indexPath.row < _cellArr.count {
            return _cellArr[indexPath.row]
        }
      
      var cell:BankInfoEditCell?
      
      if indexPath.row == 0 {
        
        cell = tableView.dequeueReusableCell(withIdentifier: "BankRealNameInfoEditCell") as? BankInfoEditCell
        if cell == nil {
          cell = BankInfoEditCell()
          cell?.contentType = .ContentRealNameVerify
        }
        cell?.contentTextField.isEnabled = true
        if (ManagerModel.instanse.personInfoModel?.realName?.count ?? 0 ) > 1 {
          cell?.contentTextField.isEnabled = false
          let realNameStr = ManagerModel.instanse.personInfoModel?.realName
          cell?.contentTextField.text = realNameStr
        }
      }
     else if indexPath.row == 1 {
         cell = tableView.dequeueReusableCell(withIdentifier: "BankCardNumInfoEditCell") as? BankInfoEditCell
        
        if cell == nil {
          cell = BankInfoEditCell()
          cell?.contentTextField.keyboardType = .numberPad
          cell?.contentType = .ContentBankCardNum
          
          cell?.contentTextField.rx.text.orEmpty.changed.throttle(0.3, scheduler: MainScheduler.instance)
            .distinctUntilChanged().subscribe(onNext: { [weak self]  bankText in
 
              if bankText.count > 30 {
                 cell?.contentTextField.text = String(bankText.prefix(30))
              }
              
            if bankText.count >= 11 {
              
              // 获取银行卡类型
              var paramDic = ManagerModel.configLoginNameParamDic()
              paramDic["bankCardNo"] = bankText
              APITool.request(.getByCardBin, parameters: paramDic, successHandle: { (cardBinTypeModel:CardBinTypeModel) in

                guard let weakSelf = self else {
                  return
                }
            
                let selectedCell = weakSelf._cellArr[safe:2]
                
                let cartype:String = cardBinTypeModel.cardTypeDesc ?? ""
                if(cartype.isEqual("信用卡" as String)){
                    ProgressTopPopView.showPopView(content:"暂不支持取款到银行信用卡,请更换", popStyle: .errorMsgToast)
                }else{
                  selectedCell?.contentTextField.text = cardBinTypeModel.bankName
                  let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (cardBinTypeModel.bankIcon ?? "")
                  selectedCell?.contentImageView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: "logo"))
                  selectedCell?.contentImageView.width = 23
                  selectedCell?.contentTextField.x = 136
                }
                
              }, failureHandle: { (error) in

              })
            }
          }).disposed(by: disposeBag )
        }
      }
      else {
        cell = tableView.dequeueReusableCell(withIdentifier: "BankInfoEditCell") as? BankInfoEditCell
        if cell == nil {
           cell = BankInfoEditCell()
        }
      }
      
        _cellArr.append(cell!)

        cell?.delegate = self
        let (titile, placeholder, value) = _titleArr[indexPath.row]
        cell?.titleLabel.text = titile
        cell?.contentTextField.placeholder = placeholder
        if indexPath.row == 0 {
          
        }else{
          cell?.contentTextField.text = value
        }
        if indexPath.row == 4 {
            cell?.contentType = .ContentBankCardAddress
        }
      
        if indexPath.row == 2 {
            cell?.cellStyle(.arrowRightAndLogStyle)
        }else if indexPath.row == 3 {
            cell?.cellStyle(.arrowRightStyle)
        }else{
            cell?.cellStyle(.baseStyle)
        }
        
        if indexPath.row > 1 && indexPath.row < _titleArr.count - 1 {
            cell?.contentTextField.isEnabled = false
        }else if indexPath.row != 0 {
            cell?.contentTextField.isEnabled = true
        }
      return cell!
    }
  
    func tableView(_ tableView: CaseyTableView, didSelectRowAt indexPath: IndexPath) {
  
        self.currentEditingTextFiled?.resignFirstResponder()
        let selectedCell = self._cellArr[indexPath.row]
        if indexPath.row == 2 { // 选择银行
          
            let bankSelectVC = BankNameListViewController()
            bankSelectVC.completionSelect = { (selectResult) in
                self._selectBankName = selectResult
                let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (selectResult.bankIcon ?? "")
                selectedCell.contentImageView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: "logo"))
                selectedCell.contentTextField.text = selectResult.bankName
                selectedCell.contentImageView.width = 23
                selectedCell.contentTextField.x = 136
            }
            self.navigationController?.pushViewController(bankSelectVC, animated: true)
   
        }else if indexPath.row == 3 { // 城市省份
          let bankCardCityListVC = BankProvinceListViewController()
          bankCardCityListVC.completionSelect = { (provinceName, cityName) in
            if provinceName == cityName {
              selectedCell.contentTextField.text = provinceName
            }else{
              selectedCell.contentTextField.text = provinceName! + "-" + cityName!
            }
          }
          self.navigationController?.pushViewController(bankCardCityListVC, animated: true)
        }
    }
  
  //MARK :  Network
  
  func netAddBankCard()  {
    
    // 参数配置
      let arry = ["accountName", "accountNo", "bankName","province", "city", "bankBranchName"]
      var cardInfo = [String:String]()
      cardInfo = ["accountType":"借记卡"]
    
      var index = 0
      for cell  in _cellArr {
        if index < arry.count {
          if index == 3 { // 身份和城市
            let cityArr =  cell.contentTextField.text?.components(separatedBy: "-")
            cardInfo[arry[index]] = cityArr?.first
            index = index + 1
            cardInfo[arry[index]] = cityArr?.last
            
          }else {
            cardInfo[arry[index]] = cell.contentTextField.text
          }
        }
        index = index + 1
      }
    

      // 请求网络
      LoadingView.showLoadingViewWith(to: self.view)
      AddBankCardModelNet().netBankCardAdd(cardInfo) { [weak self] (result, errorDesc) -> (Void) in
        
        LoadingView.hideLoadingView(for: self?.view)
        if errorDesc != nil {
            ProgressTopPopView.showPopView(content: errorDesc ?? "" , popStyle: .errorMsgToast)
        }else {
          
          let tResult = result as![String:Any]
          let realName = tResult["realName"]
          
          ProgressTopPopView.showPopView(content: "银行卡添加成功", popStyle: .successMsgToast)
          if let targetViewCtr = self?.navigationController?.searchNearViewController(targerClass: PersonInfoViewController.classForCoder()) {
              targetViewCtr.isFlushView = .FlushByNoShowLoading
              ManagerModel.instanse.personInfoModel?.bankCardNum = 1
              ManagerModel.instanse.personInfoModel?.realName = realName as? String
          }
          if let _ = self?.navigationController?.searchNearViewController(targerClass: WithDrawViewController.classForCoder()) {
             ManagerModel.instanse.personInfoModel?.bankCardNum = 1
             ManagerModel.instanse.personInfoModel?.realName = realName as? String
             self?.finishCallBack?()
          }
          if let _ = self?.navigationController?.searchNearViewController(targerClass: ChargeViewController.classForCoder()) {
            ManagerModel.instanse.personInfoModel?.bankCardNum = 1
            ManagerModel.instanse.personInfoModel?.realName = realName as? String
            self?.finishCallBack?()
          }
          self?.navigationController?.popViewController(animated: true)
        }
      }
  }
}
