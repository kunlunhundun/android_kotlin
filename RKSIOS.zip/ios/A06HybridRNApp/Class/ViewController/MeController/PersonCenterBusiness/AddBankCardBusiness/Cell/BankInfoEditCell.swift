//
//  BankInfoBaseCell.swift
//  PersonReport
//
//  Created by Casey on 14/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit


@objc protocol BankInfoEditCelllDelegate{
    
    
    var currentEditingTextFiled: UITextField? {get set}
    
}

enum Style: Int {
    case baseStyle = 0
    case arrowRightStyle
    case arrowDownStyle
    case arrowRightAndLogStyle
    case smsCodeStyle
}


enum ContentCellType: Int {
  
    case ContentNormal = 0
    case ContentRealNameVerify = 1  // 实名认证
    case ContentPhone  // 手机号
    case ContentSmsCode  // 手机验证码
    case ContentBitCoin  // 比特币
    case ContentBitCoinAgainSure  // 再次确认
    case ContentBankCardNum // 银行卡号
    case ContentBankCardAddress  // 银行卡支行地址
  
}

class BankInfoEditCell: UITableViewCell, UITextFieldDelegate {

  
    let titleLabel = UILabel() // 标题
    let contentTextField = UITextField()
    let contentImageView = UIImageView()
    let _rightArrowImageView = UIImageView()
    let _bottomLineView = UIView() // 白红线
    var contentType:ContentCellType = .ContentNormal
  
    var sendCodeEventCheckInfoBlock:(()->())?
    private let sendMessageCodeButton = UIButton()
    private var cellUIStyle:Style = .baseStyle
    private var errorImplyLabel = UILabel() // 错误提示
  
    var cellHeight:CGFloat {
      
      get {
        if errorImplyLabel.text != nil && errorImplyLabel.text!.count > 0{
          return 94.0
        }
        return 64
      }
    }
  
    weak var delegate:BankInfoEditCelllDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
  
    convenience init(_ contentStyle:ContentCellType) {
        self.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: nil)
        self.contentType = contentStyle
    }
  
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        initUIProperty()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
      
        contentTextField.setValue(UIColor.init(colorValue: 0x858586), forKeyPath: "_placeholderLabel.textColor")
      
        titleLabel.x = 15
        titleLabel.y = 0
        titleLabel.width = 85
        titleLabel.heigth = 64
      
        contentTextField.x = 106
        contentTextField.y = 0
        contentTextField.width = self.width - 106
        contentTextField.heigth = 64
      
        _rightArrowImageView.right = self.width-25
        _rightArrowImageView.centerY = contentTextField.centerY
        _rightArrowImageView.width = 20
        _rightArrowImageView.heigth = 20
      
    
        _bottomLineView.x = 15
        _bottomLineView.width = self.width - 15
        _bottomLineView.y = 63
        _bottomLineView.heigth = 1
      
        errorImplyLabel.x = 15
        errorImplyLabel.width = contentTextField.width
        errorImplyLabel.y = 64
        errorImplyLabel.heigth = 30
  
      
        sendMessageCodeButton.right = self.width - 18
        sendMessageCodeButton.centerY = contentTextField.centerY
        sendMessageCodeButton.width = 90
        sendMessageCodeButton.heigth = 28
      
        initLayoutSubview(cellUIStyle)
    }
  
    func cellStyle(_ style:Style)  {
      
      cellUIStyle = style
      self.setNeedsLayout()
      
    }
  
    private func initUIProperty()  {
        
        self.backgroundColor = .clear
        self.selectionStyle = .none
        
        titleLabel.font = UIFont.PingFangSCRegular(ofSize: 15)
        titleLabel.textColor = .white
        self.contentView.addSubview(titleLabel)
      
        contentTextField.font = UIFont.PingFangSCRegular(ofSize: 15)
        contentTextField.textColor = .white
        contentTextField.tintColor = .white
        contentTextField.delegate = self
        //contentTextField.setValue(UIColor.init(colorValue: 0x858586), forKeyPath: "_placeholderLabel.textColor")
        self.contentView.addSubview(contentTextField)
      
        contentImageView.image = UIImage()
        self.contentView.addSubview(contentImageView)
        
        _rightArrowImageView.image = UIImage.init(named: "箭头右.png")
        self.contentView.addSubview(_rightArrowImageView)
        
        _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        self.contentView.addSubview(_bottomLineView)
      
        errorImplyLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        errorImplyLabel.textColor = UIColor.init(hexInt: 0xE14040)
        self.contentView.addSubview(errorImplyLabel)
      
        sendMessageCodeButton.setTitle("发送验证码", for: .normal)
        sendMessageCodeButton.setTitleColor(.white, for: .normal)
        sendMessageCodeButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 14)
        sendMessageCodeButton.backgroundColor = UIColor.init(colorValue: 0x8095FF)
        sendMessageCodeButton.layer.cornerRadius = 14
        sendMessageCodeButton.addTarget(self, action: #selector(senderMessageCodeEvent(_:)), for: .touchUpInside)
        sendMessageCodeButton.isHidden = true
        self.contentView.addSubview(sendMessageCodeButton)
    }
    
    private func initLayoutSubview(_ style:Style){
      
        if style == .baseStyle ||  style == .smsCodeStyle {
            _rightArrowImageView.isHidden = true
        }else{
            _rightArrowImageView.isHidden = false
        }
        if style == .arrowDownStyle {
            _rightArrowImageView.image = UIImage.init(named: "箭头下.png")
        }else{
            _rightArrowImageView.image = UIImage.init(named: "箭头右.png")
        }
        
        if style == .arrowRightAndLogStyle{
          
            contentImageView.isHidden = false
            contentImageView.x = 105
            contentImageView.width = 0
            contentImageView.centerY = 64/2
            contentImageView.heigth = 23
            contentTextField.x = 106
            contentTextField.width = self.width - 136 - 60
                  
        }else{
            contentImageView.isHidden = true
        }
      
        if style == .smsCodeStyle {
          sendMessageCodeButton.isHidden = false
        }else {
          sendMessageCodeButton.isHidden = true
        }
    }
  
    //MARK: textFieldDelegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        delegate?.currentEditingTextFiled = textField
        _bottomLineView.backgroundColor = .white
        _bottomLineView.heigth = 1
        flushTableView()
        if errorImplyLabel.text != nil && errorImplyLabel.text!.count >  0{
            errorImplyLabel.text = ""
            flushTableView()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.currentEditingTextFiled = nil
        _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        _bottomLineView.heigth = 1
        if let _ =  checkContentInfo(){
            flushTableView()
        }
    }
  
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        delegate?.currentEditingTextFiled = nil
        textField.resignFirstResponder()
        return true
    }
  
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
      
      if self.contentType == .ContentPhone {
        if (textField.text?.count ?? 0) + string.count > 11 {
            return false
        }
      }
      if self.contentType == .ContentSmsCode {
        if (textField.text?.count ?? 0) + string.count > 6 {
          return false
        }
      }
      return true
    }
  
  func checkContentInfo() -> String? {
    
      var errorImply:String? = nil
      let contentStr = contentTextField.text
    
      switch contentType {
      case .ContentRealNameVerify:
        if contentStr?.count == 0 {
            errorImply = "请输入姓名"
        }
        
        let name = ManagerModel.instanse.personInfoModel?.realName ?? ""
        
        if name.isEqual(contentStr as! String) ?? true {
          
        }else{
            if RegularExp.checkRealName(withRealName: contentStr!) == false {
              errorImply = "姓名输入有误"
            }
        }
        
      // 手机号码
      case .ContentPhone:
        if contentStr?.count == 0 {
          errorImply = "请输入手机号"
        }else if RegularExp.isValidateMobile(contentStr!) == false {
          errorImply = "手机号输入有误"
        }
        
        // 验证码
      case .ContentSmsCode:
        if contentStr?.count == 0 {
          errorImply = "请输入验证码"
        }else if contentStr!.count < 6 {
          errorImply = "验证码输入有误"
        }else if RegularExp.isValidateNum(contentStr!) == false {
          errorImply = "验证码输入有误"
        }
        
        // 比特币
      case .ContentBitCoin:
        if contentStr?.count == 0 {
          errorImply = "请输入比特币钱包地址"
        }else if RegularExp.checkBitcoinAddress(withBitAddress: contentStr!) == false {
          errorImply = "比特币钱包地址输入有误"
        }
      
      // 再次确认填写内容
      case .ContentBitCoinAgainSure:
          if contentStr?.count == 0 {
              errorImply = contentTextField.placeholder ?? "请再填写一次"
          }else if RegularExp.checkBitcoinAddress(withBitAddress: contentStr!) == false {
            errorImply = "比特币钱包地址输入有误"
          }
        
      // 银行卡号
      case .ContentBankCardNum:
        if contentStr?.count == 0 {
          errorImply = contentTextField.placeholder ?? "请输入银行卡号"
        }
        else if (contentStr?.count ?? 0) < 8 || (contentStr?.count ?? 0) > 30 {
          errorImply = "银行卡号输入有误"
        }
        else if RegularExp.isValidateNum(contentStr!) == false {
          errorImply = "银行卡号输入有误"
        }
        
        // 开户支行
      case .ContentBankCardAddress:
        if contentStr?.count == 0 {
           errorImply = contentTextField.placeholder ?? "请输入开户支行"
        }
      default: break
    }
  
    if errorImply != nil {
        errorImplyLabel.text = errorImply!
        _bottomLineView.backgroundColor = UIColor.init(hexInt: 0xE14040)
        errorImplyLabel.isHidden = false
    }else{
        _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
        errorImplyLabel.isHidden = true
    }
    return errorImply
  }
  
  func setErrorImplyForCell(errorImply:String){
    if errorImply.count > 0 {
      errorImplyLabel.text = errorImply
      _bottomLineView.backgroundColor = UIColor.init(hexInt: 0xE14040)
      errorImplyLabel.isHidden = false
    }else{
      _bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292D30)
      errorImplyLabel.isHidden = true
    }
  }
  
  //MARK 刷新tableview
  func flushTableView() {
    if let tableview =  self.searchSuperViewOfClass(CaseyTableView.classForCoder()) as? CaseyTableView {
        tableview.reloadData()
    }
  }
  
  //MARK: button事件
  private var timer:Timer?
  var _timerCount:Int = 60
  @objc private func senderMessageCodeEvent(_ sender:UIButton) {
    if timer == nil {
      self.sendCodeEventCheckInfoBlock?()
    }
  }
  
  func startTimerByExtern() {
    timer = Timer.init(timeInterval: 1, target: self, selector: #selector(timeCountEvent), userInfo: nil, repeats: true)
    _timerCount = 60
    RunLoop.current.add(timer!, forMode: .commonModes)
  }
  
  func invalidateTimer()  {
    timer?.invalidate()
    timer = nil
  }
  
  @objc  func timeCountEvent() {
    _timerCount = _timerCount - 1
    if _timerCount > 0 {
      sendMessageCodeButton.setTitle(String.init(format: "%d秒", _timerCount), for: .normal)
    }else {
      invalidateTimer()
      sendMessageCodeButton.setTitle("发送验证码", for: .normal)
    }
  }
}
