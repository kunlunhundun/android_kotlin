//
//  ReportRecordInfoModel.swift
//  A06HybridRNApp
//
//  Created by Casey on 23/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

enum FundRecordType:Int{
  
  case deposit = 1 // 充值
  case drawal = 2 // 提现
  case wash = 3 // 洗码
  case discount = 4 // 优惠
  
}

class FundRecordListModel: NSObject {
  
  var pageNO:Int? = 0
  var pageSize:Int? = 10
  var totalPage:Int?
  var totalRow:Int?
  var isLoadFinish:Bool? = false // 数据是否已经全部加载完了， false还有下一页， true没有下一页了
  var data:[FundRecordInfoModel]? = [FundRecordInfoModel]()
  
  var type:Int? // 资金类型 1 充值， 2 提现， 3 洗码， 4 优惠， 5 账变，6积分
  var lastDays:Int? = 7  // 时间类型默认近 7天
  var transaType:FundRecordType?
  
  init(_ type:FundRecordType) {
    self.type = type.rawValue
    self.transaType = type
    super.init()
  }
}

class FundRecordInfoModel: NSObject, HandyJSON, Codable {
  required override init() {
    super.init()
  }
  var title:String?// 名称
  var requestId:String? // 交易单号
  // 不可删状态：0 等待处理，1处理； 9审核，97 等待支付， 99 超时。 可删状态：2批准，  -1 前台取消， -2 后台取消， -3 拒绝 ；
  var flag:Int?
  var flagDesc:String? // 状态描述
  var amount:String? // 金额
  var rate:String?
  var createDate:String? // 申请日期
  var itemIcon:String?// 图片
  var remindFlag:Int?// 可催单标志
  
  var updateDate:String?
  var loginName:String?
  
  var bankName:String? // 银行
  var accountNo:String?
  
  var transCode:String?
  
  var enabelDelete:Bool? {
    
      if flag == 2 || flag == -1 || flag == -2 || flag == -3 {
        return true
      }else {
        return false
      }
  }
  
  
  var flagColor:UIColor? {
    
    get{
      
      switch flag {
        case 0: //0 等待处理
          return UIColor.init(colorValue: 0xE9664B)
        case 1: // 1处理中
          return UIColor.init(colorValue: 0xE9664B)
        case 2: // 2成功
          return UIColor.init(colorValue: 0x50E3C2)
        case 3: //  3 失败
          return UIColor.init(colorValue: 0xFA2663)
        case 4: // 4超时
          return UIColor.init(colorValue: 0xFA2663)
      default:
        return UIColor.init(colorValue: 0xFA2663)
      }
  
    }
    
  }
  
  //返回结构： 09-12 11:12
  private var _beginDateAndTimeDesc:String?
  var beginDateAndTimeDesc:String? {
    
      get{
        
          if _beginDateAndTimeDesc != nil {
            return _beginDateAndTimeDesc
          }
          let beginDateArr = createDate?.components(separatedBy: " ")
          if (beginDateArr?.count ?? 0) >= 2 {
            
              let dateStr = beginDateArr!.first
              let timeStr = beginDateArr!.last
            
              let dateSubArr =  dateStr!.components(separatedBy: "-")
              let timeSubArr =  timeStr!.components(separatedBy: ":")
              if dateSubArr.count >= 3 && timeSubArr.count >= 3 {
              
                  let result =  String.init(format: "%@-%@ %@:%@", dateSubArr[1], dateSubArr[2], timeSubArr[0], timeSubArr[1])
                  _beginDateAndTimeDesc = result
                  return _beginDateAndTimeDesc
              }
          }
          return ""
      }
  }
  
  var beginDateDesc:String? {
    
    get{
      
      let beginDateArr = createDate?.components(separatedBy: " ")
      if (beginDateArr?.count ?? 0) >= 1 {
        
        let dateStr = beginDateArr!.first
        let dateSubArr =  dateStr!.components(separatedBy: "-")
        if dateSubArr.count >= 3 {
          
          let result =  String.init(format: "%@-%@", dateSubArr[1], dateSubArr[2])
          return result
        }
      }
      return ""
    }
  }
  
  var beginTimeDesc:String? {
    
    get{
      
      let beginDateArr = createDate?.components(separatedBy: " ")
      if (beginDateArr?.count ?? 0) >= 2 {
        
        let timeStr = beginDateArr!.last
        let timeSubArr =  timeStr!.components(separatedBy: ":")
        if  timeSubArr.count >= 3 {
          
          let result =  String.init(format:"%@:%@" , timeSubArr[0], timeSubArr[1])
          return result
        }
      }
      return ""
    }
  }
  
  var beginTimeDescQuan:String? {
    
    get{
      
      let beginDateArr = createDate?.components(separatedBy: " ")
      if (beginDateArr?.count ?? 0) >= 2 {
        
        let timeStr = beginDateArr!.last
        let timeSubArr =  timeStr!.components(separatedBy: ":")
        if  timeSubArr.count >= 3 {
          
          let result =  String.init(format:"%@:%@:%@" , timeSubArr[0], timeSubArr[1],timeSubArr[2])
          return result
        }
      }
      return ""
    }
  }
  
 
  
  
  var amountDesc:String? {
    
    get{

        switch flag {
        case 0,1,9,97:
          flagDesc = "审核中"
          break
        case 2:
          flagDesc = "成功"
          break
        case -3,3,98,-1,-2,99:
          flagDesc = "未通过"
          break
        default:
          flagDesc = "审核中"
          break
        }
      
        if amount == nil {
          return "0.00"
        }
        let amountDec = amount!.toDoubleValue()
        let amountStr =  String.init(format: "%.2f", amountDec)
        return amountStr

    }
    
  }
  
  
  var isRecordSelected:Bool? = false // 是否被选中（删除业务）
  

}
