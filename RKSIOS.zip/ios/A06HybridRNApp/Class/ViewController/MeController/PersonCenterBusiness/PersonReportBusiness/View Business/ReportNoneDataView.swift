//
//  ReportNoneDataView.swift
//  PersonReport
//
//  Created by Casey on 10/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class ReportNoneDataView: UIView {

    
    private let _imageView = UIImageView.init(image: UIImage.init(named: "BlankIcon.png"))
    let _implyLable = UILabel()
    
    static func instance() -> ReportNoneDataView {
        
        let noneView = ReportNoneDataView()
        
        noneView.x = 0
        noneView.y = 0
        noneView.width = SCREEN_WIDTH
        noneView.heigth = 240 + 83*2
        return noneView
        
    }
    
    private override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        self.addSubview(_imageView)
        _imageView.snp.makeConstraints { (make) in
            
            make.center.equalToSuperview()
            make.width.equalTo(189)
            make.height.equalTo(137)
            
        }
      
        self.addSubview(_implyLable)
        _implyLable.text = "暂无数据~"
        _implyLable.textAlignment = .center
        _implyLable.textColor = UIColor.init(hex: 0x666666)
        _implyLable.font = UIFont.PingFangSCLight(ofSize: 20)
      
        _implyLable.snp.makeConstraints { (make) in
          
          make.left.right.equalToSuperview()
          make.top.equalTo(_imageView.snp.bottom).offset(25)
          make.height.equalTo(28)
          
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        
    }
    
    
}
