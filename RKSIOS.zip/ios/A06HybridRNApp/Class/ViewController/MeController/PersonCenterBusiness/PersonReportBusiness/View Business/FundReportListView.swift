//
//  DepositReportView.swift
//  PersonReport
//
//  Created by Casey on 07/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit


// 存款View
class FundReportListView: UIView ,  UITableViewDelegate, UITableViewDataSource, ReportTimeSelectDelegate {
  
  var  dataModel:FundRecordListModel = FundRecordListModel.init(.deposit)
  private var _firstLoadData:Bool = true // 第一次加载数据
  private let _reportTimeMenuView = ReportTimeMenuView()
  private let _tableView = ReportTableView()
  private let _deleteBottomMenuView = DeleteBottomMenuView()
  private var _noneView = ReportNoneDataView.instance()
  override init(frame: CGRect) {
    super.init(frame: frame)
    initUIProperty()
    initLayoutSubview()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  convenience init(style:FundRecordType) {
      self.init()
      dataModel = FundRecordListModel.init(style)
  }
  
  private func initUIProperty()  {
    
    _reportTimeMenuView.delegate = self
    self.addSubview(_reportTimeMenuView)
    
    _tableView.delegate = self
    _tableView.dataSource = self
    _tableView.separatorStyle = .none
    _tableView.estimatedRowHeight = 0;
    _tableView.backgroundColor = UIColor.clear
    self.addSubview(_tableView)
    
    weak var weakSelf = self
    _tableView.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
      weakSelf?.dataModel.pageNO = 0
      weakSelf?.netLoadRecordData(showLoading:false)
    })
    
    _tableView.mj_footer = MJRefreshAutoNormalFooter.init(refreshingBlock: {
      weakSelf?.netLoadRecordData(showLoading:false)
    })
    
    _deleteBottomMenuView.backgroundColor = UIColor.init(colorValue: 0x141723)
    _deleteBottomMenuView.allSelectButton.addTarget(self, action: #selector(self.allSelectDeteteEvent(_sender:)), for: .touchUpInside)
    _deleteBottomMenuView.deleteButton.addTarget(self, action: #selector(self.deteteEvent(_sender:)), for: .touchUpInside)
  }
  
  
  private func initLayoutSubview(){
    _reportTimeMenuView.snp.updateConstraints { (make) in
      make.top.equalToSuperview()
      make.left.equalToSuperview()
      make.right.equalToSuperview()
      make.height.equalTo(48)
    }
    _tableView.snp.updateConstraints { (make) in
      make.top.equalTo(_reportTimeMenuView.snp.bottom)
      make.right.equalToSuperview();
      make.left.equalToSuperview();
      make.bottom.equalToSuperview();
    }
    _deleteBottomMenuView.isHidden = true
  }
  
  //MARK: 界面第一次数据加载，调用这个方法
  func loadNetDataByExternal()  {
    if _firstLoadData {
      netLoadRecordData(showLoading: false)
    }
  }
  
  //MARK: 编辑模式下的布局
  private func editStyleLayoutSubview()  {
    _tableView.snp.updateConstraints { (make) in
      make.top.equalTo(_reportTimeMenuView.snp.bottom)
      make.right.equalToSuperview();
      make.left.equalToSuperview();
      make.bottom.equalToSuperview().offset(-68);
    }
    if _deleteBottomMenuView.superview == nil {
      self.addSubview(_deleteBottomMenuView)
    }
    _deleteBottomMenuView.isHidden = false
    _deleteBottomMenuView.snp.updateConstraints { (make) in
      make.left.equalToSuperview();
      make.right.equalToSuperview();
      make.bottom.equalToSuperview()
      make.height.equalTo(68)
    }
  }
  
  //MARK: 时间选择事件 ReportTimeSelectDelegate 近七天/近15天
  func selectReportTime(timeStyle: Int) {
    if timeStyle == 0{
      // 近七天
      if self.dataModel.lastDays != 7 {
         self.dataModel.lastDays = 7
         self.dataModel.pageNO = 0
         netLoadRecordData(showLoading:true)
      }
      
    }else{
      
      // 近15天
      if self.dataModel.lastDays != 15 {
        self.dataModel.lastDays = 15
        self.dataModel.pageNO = 0
        netLoadRecordData(showLoading:true)
      }
    }
  }
  
  //MARK: 界面编辑状态
  private var _isEditStatus:Bool = false // 默认view是不编辑状态的
  var isEditStatus:Bool {
    
    get{
      
      return _isEditStatus
      
    }set{
      
      _isEditStatus = newValue
      
      if _isEditStatus {
      
        _tableView.setEditing(true, animated: true)
        editStyleLayoutSubview()
        
      }else{
        
        _tableView.setEditing(false, animated: true)
        initLayoutSubview()
      }
      
      _tableView.reloadData()
    }
  }
  
  
  // MARK: 全选和删除事件
  @objc private func allSelectDeteteEvent(_sender: UIButton) {
    
    _deleteBottomMenuView.isAll = !_deleteBottomMenuView.isAll
    if _deleteBottomMenuView.isAll == false {
      _deleteBottomMenuView.allSelectButton.setTitle("取消全选", for: .normal)
      for model in dataModel.data! {
        if model.enabelDelete! {
          model.isRecordSelected = true
        }
      }
    }else{
      _deleteBottomMenuView.allSelectButton.setTitle("全选", for: .normal)
      for model in dataModel.data! {
        if model.enabelDelete! {
          model.isRecordSelected = false
        }
      }
    }
    _tableView.reloadData()
  }
  
  @objc private func deteteEvent(_sender: UIButton) {
    
    var selectCount = 0
    for model in dataModel.data! {
      if model.enabelDelete! && (model.isRecordSelected ?? false) == true {
        selectCount = 1
        break
      }
    }
    
    if selectCount == 0 {
      ProgressTopPopView.showPopView(content: "请至少选中1条数据", popStyle: .errorMsgToast)
      return
    }
    
    ProgressTopPopView.showPopViewCallBack(content: "确定删除您选中的信息吗？", popStyle: .oneTitleConfirm) { [weak self] (isConfirm) in
      if isConfirm {
        self?.netDeleteRecord(deleteModel: nil)
      }
    }
  }
  
  //MARK: TableViewDelegate
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    if dataModel.data!.count == 0 && !_firstLoadData{
      
      let transaType = dataModel.transaType
      if transaType == .deposit {
        _noneView._implyLable.text = "暂无存款记录"
      }else if transaType == .drawal{
        _noneView._implyLable.text = "暂无取款记录"
      }else if transaType == .wash{
        _noneView._implyLable.text = "暂无洗码记录"
      }else{
        _noneView._implyLable.text = "暂无优惠记录"
      }
      _tableView.addSubview(_noneView)
      _tableView.mj_footer.isHidden = true
    }else{
      _tableView.mj_footer.isHidden = false
      _noneView.removeFromSuperview()
    }
    return dataModel.data!.count
  }

  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return DepositReportInfoCell.cellHeight
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
  
    var cell = tableView.dequeueReusableCell(withIdentifier: "ReportInfoCell") as? DepositReportInfoCell
    if cell == nil {
      cell = DepositReportInfoCell.init(style: .default, reuseIdentifier: "ReportInfoCell")
      cell?.selectionStyle = .none
    }
    
    let subDataModel = dataModel.data?[indexPath.row]
    let transaType = dataModel.transaType
    cell?.dataModel = subDataModel

    if transaType == .wash {
      if subDataModel?.flag == 2 {
        cell?._payStatusLabel.text = "已派发"
      }
    }
    if transaType == .drawal && subDataModel?.flag == 1 {
      cell?._payStatusLabel.text = "支付中"
    }
    if transaType == .wash && subDataModel?.flag == 2 {
      cell?._payStatusLabel.text = "已派发"
    }
    if transaType == .discount && subDataModel?.flag == 2{
      cell?._payStatusLabel.text = "已派发"
    }
    return cell!
  }
  

  func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
    let model =  dataModel.data![indexPath.row]
    _tableView.enableDeteteStyle = model.enabelDelete!
    return "删除"
  }

  func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    return true
  }

  func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {

    if self.isEditStatus {
      return .insert
    }else{
      return .delete
    }
  }

  func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {

    let model = dataModel.data![indexPath.row]
    if editingStyle == .delete && model.enabelDelete! {
      ProgressTopPopView.showPopViewCallBack(content: "确定删除您选中的信息吗？", popStyle: .oneTitleConfirm) { [weak self] (isConfirm) in
        if isConfirm {
          self?.netDeleteRecord(deleteModel: model)
        }
      }
    }
  }
  

  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    let model = dataModel.data![safe:indexPath.row]
    let transaDetailModel = TransactionDetailModel()
  
    let amount = model?.amount ?? "0"
    let amountDec = amount.toDoubleValue()
    let amountStr =  String.init(format: "%.2f", amountDec)
    
    transaDetailModel.amount =  amountStr
    transaDetailModel.rate = model?.rate
    transaDetailModel.createDate = model?.createDate
    transaDetailModel.flag =  "\(model?.flag ?? 0 )"
    transaDetailModel.flagDesc = model?.flagDesc
    transaDetailModel.itemIcon = model?.itemIcon
    transaDetailModel.referenceId = model?.requestId
    transaDetailModel.remindFlag =  "\(model?.remindFlag ?? 0)"
    transaDetailModel.accountNo = model?.accountNo
    transaDetailModel.bankName = model?.bankName
    
    transaDetailModel.title = model?.title
    transaDetailModel.transaType = dataModel.transaType
   
    let  transaDetailVC = TransactiontDetailViewController.init(billNo: model?.requestId, isPersonCenter: false, isFromReport: true)
    transaDetailVC.transacDetailModel = transaDetailModel
    transaDetailVC.transacDetailModel?.transCode = model?.transCode
    self.nearNav()?.pushViewController(transaDetailVC, animated: true)
  }
  
  //MARK: NetWork
  func netLoadRecordData(showLoading:Bool) {
    
    // view第一次加载数据 用下拉动画
    let firstLoadingNet =  _firstLoadData
    _firstLoadData = false
    if firstLoadingNet {
      _tableView.setContentOffset(CGPoint.init(x: 0, y: -_tableView.mj_header.heigth), animated: true)
    }
    
    // 是否显示 全局性loading
    if showLoading {
      
    }
    
    PersonReportModelNet().netRecordData(self.dataModel) { (result, errorDesc) -> (Void) in
      
      self._tableView.mj_header.endRefreshing()
      
      if self.dataModel.isLoadFinish! && self.dataModel.data!.count > 0 {
        self._tableView.mj_footer.endRefreshingWithNoMoreData()
      }else{
        self._tableView.mj_footer.endRefreshing()
      }
      self._tableView.reloadData()
      
      if firstLoadingNet {
        self._tableView.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
      }
      
    }
  }
  
  
  // MARK: Network
  
  // 1 deleteModel值 单个cell删除模式; 无deleteModel值, 即 nil，是全选模式
  func netDeleteRecord(deleteModel:FundRecordInfoModel?) {
    
    
    // 数据data配置
    var param = [String]()
    var deleteModelArr = [FundRecordInfoModel]()
    
    if let model = deleteModel { // 单个cell删除模式
      
      param.append(model.requestId!)
      deleteModelArr.append(model)
      
    }else { // 全选模式
      
      for model in dataModel.data! {
        if model.enabelDelete! && (model.isRecordSelected ?? false) == true {
          param.append(model.requestId!)
          deleteModelArr.append(model)
        }
      }
    }
    
    // 网络
     PersonReportModelNet().netRecordDataDelete(type:self.dataModel.type!, param) { (result, error) -> (Void) in
      
      if error != nil {
        ProgressTopPopView.showPopView(content: error! , popStyle: .errorMsgToast)
      }else {
      
      ProgressTopPopView.showPopView(content: "您的删除操作已完成", popStyle: .successMsgToast)
        
      // 修改title （编辑/删除）
      let personReportInfoVC = self.nearViewController(PersonReportInfoViewController.classForCoder()) as? PersonReportInfoViewController
      personReportInfoVC?.finishEditEvent()
      
      // 删除 本地model，刷新table
      for mode in deleteModelArr {
        if let index = self.dataModel.data?.firstIndex(of: mode){
          self.dataModel.data?.remove(at: index)
        }
      }
      self.isEditStatus = false
      
      }
    }
  }
}







