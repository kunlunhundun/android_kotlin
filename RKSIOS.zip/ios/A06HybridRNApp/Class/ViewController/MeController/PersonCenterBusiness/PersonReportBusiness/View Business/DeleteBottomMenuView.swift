//
//  DeleteBottomMenuView.swift
//  PersonReport
//
//  Created by Casey on 09/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class DeleteBottomMenuView: UIView {

    let allSelectButton = UIButton() // 没下滑线，是属性，button的事件由外配配置
    let deleteButton = UIButton()  // 没下滑线，是属性，button的事件由外配配置
    var isAll:Bool = true;
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initUIProperty()
        initLayoutSubview()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    private func initUIProperty()  {
        
        allSelectButton.setTitle("全选", for: .normal)
        allSelectButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 16)
        allSelectButton.setTitleColor(.white, for: .normal)
        allSelectButton.contentVerticalAlignment = .center
        allSelectButton.tag = 1
        self.addSubview(allSelectButton)
        
        deleteButton.setImage(UIImage.init(named: "删除-2.png"), for: .normal)
        deleteButton.contentVerticalAlignment = .center
        deleteButton.tag = 0
        self.addSubview(deleteButton)
    }
  
    private func initLayoutSubview()  {
        
        allSelectButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(48)
            make.width.equalTo(82)
        }
        
        deleteButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(48)
            make.width.equalTo(82)
        }
    }
}
