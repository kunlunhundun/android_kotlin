//
//  PersonReportViewController.swift
//  PersonReport
//
//  Created by Casey on 07/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit
import SnapKit

// 40  48  
class PersonReportInfoViewController: UIViewController, UIScrollViewDelegate, ReportStyleMenuSelectDelegate {
  
    private let _listViewStartTag = 100
    let _reportStyleMenuView  = ReportStyleMenuView()
    let _scrollview = UIScrollView()
    let _navRightButton:UIButton = UIButton()
  
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "分类报表"
        initUIProperty()
        initLayoutSubview()
    }
  
    override func viewDidAppear(_ animated: Bool) {
      super.viewDidAppear(animated)
      if let firstListView = _scrollview.viewWithTag(_listViewStartTag) as? FundReportListView {
          firstListView.loadNetDataByExternal()
      }
    }
  
    private func initUIProperty()  {
        
        _navRightButton.frame = CGRect.init(x: 0, y: 0, width: 60, height: 44)
        _navRightButton.setTitleColor(.white, for: .normal)
        _navRightButton.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 16)
        _navRightButton.setTitle("编辑", for: .normal)
        _navRightButton.addTarget(self, action: #selector(self.eidtStatusEvent(_:)), for: .touchUpInside)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(customView: _navRightButton)
      
        _reportStyleMenuView.backgroundColor = UIColor.clear
        _reportStyleMenuView.delegate = self
        self.view.addSubview(_reportStyleMenuView)
        
        _scrollview.backgroundColor = UIColor.clear
        _scrollview.isScrollEnabled = false
        _scrollview.contentSize = CGSize.init(width: SCREEN_WIDTH*4, height: 0)
        self.view.addSubview(_scrollview)
      
        for index in 0...3 {
          let listView = FundReportListView.init(style: FundRecordType.init(rawValue: index+1) ?? .deposit)
          listView.tag = _listViewStartTag + index
          _scrollview.addSubview(listView)
        }
    }
  
    private func initLayoutSubview() {
      
        _reportStyleMenuView.snp.makeConstraints { (make) in
            make.top.equalToSuperview();
            make.left.equalToSuperview();
            make.right.equalToSuperview();
            make.height.equalTo(40)
        }
        _scrollview.snp.makeConstraints { (make) in
            make.top.equalTo(_reportStyleMenuView.snp.bottom);
            make.left.equalToSuperview();
            make.right.equalToSuperview();
            make.bottom.equalToSuperview()
        }
      
      for listView in _scrollview.subviews {
          let index = listView.tag - _listViewStartTag
          listView.snp.makeConstraints { (make) in
            make.top.equalToSuperview();
            make.left.equalToSuperview().offset(CGFloat(index)*SCREEN_WIDTH);
            make.width.equalTo(SCREEN_WIDTH);
            make.height.equalTo(SCREEN_HEIGHT-40-STATUS_NAV_BAR_Y)
          }
      }
    }
  
    //MARK: 报表类型菜单选择 ReportStyleMenuSelectDelegate
     func selectReportMenuStyle(menuStyle: Int) {
        _scrollview.setContentOffset(CGPoint.init(x: menuStyle*Int(_scrollview.width), y: 0), animated: true)
        changeEidtButtonTitle(index: menuStyle)
        if let listView =  _scrollview.viewWithTag(_listViewStartTag + menuStyle) as? FundReportListView{
            listView.loadNetDataByExternal()
      }
    }
    
    //MARK: 编辑状态button事件
    @objc private func eidtStatusEvent(_ sender:UIButton?) {
        let currentPageIndex = Int(_scrollview.contentOffset.x/_scrollview.width)
        if let listView =  _scrollview.viewWithTag(_listViewStartTag + currentPageIndex) as? FundReportListView{
            listView.isEditStatus = !listView.isEditStatus
            _reportStyleMenuView.isEditor = !_reportStyleMenuView.isEditor
        }
        changeEidtButtonTitle(index: currentPageIndex)
    }
  
    private func changeEidtButtonTitle(index:Int)  {
        if let listView =  _scrollview.viewWithTag(_listViewStartTag + index) as? FundReportListView{
            let editStutus = listView.isEditStatus
            if editStutus {
              _navRightButton.setTitle("取消", for: .normal)
            }else{
              _navRightButton.setTitle("编辑", for: .normal)
            }
        }
    }
  
    func finishEditEvent()  {
        _navRightButton.setTitle("编辑", for: .normal)
    }
}
