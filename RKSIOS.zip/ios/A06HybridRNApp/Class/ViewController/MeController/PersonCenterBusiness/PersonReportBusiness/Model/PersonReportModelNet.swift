//
//  PersonReportModelNet.swift
//  A06HybridRNApp
//
//  Created by Casey on 22/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class PersonReportModelNet: NSObject {
  
  // 存款记录
  func netRecordData(_ infoModel:FundRecordListModel , _ completion:@escaping NetFinish)  {
    
    var param = [String:Any]()
    param["pageNo"] = infoModel.pageNO!
    param["pageSize"] = infoModel.pageSize!
    param["lastDays"] = infoModel.lastDays!
    
    // 此三个参数由于优惠的数据出现了bug回来的数据超过了15天 查看了H5上传的参数下面三个参数没有上传给服务器 去掉三个参数后数据已经和H5一样了 此借口在做1888存款的时有过修改
    //param["type"] =  infoModel.type!
    //param["beginDate"] = ""
    //param["endDate"] = ""
    
    var urlPath = ""
    
    switch FundRecordType.init(rawValue: infoModel.type!)! {
      case .deposit:
            urlPath = PersonCenterNetPath.fundRecordDeposit.rawValue
      case .drawal:
            urlPath = PersonCenterNetPath.fundRecordWithdraw.rawValue
      case .wash:
            urlPath = PersonCenterNetPath.fundRecordXM.rawValue
      case .discount:
            urlPath = PersonCenterNetPath.fundRecordPromo.rawValue
    }
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + urlPath, parameters: param) { (result, error, isCache) in
      
      
      if let dateResult = result {
        
        infoModel.totalRow = dateResult["totalRow"] as? Int
        infoModel.totalPage = dateResult["totalPage"] as? Int
        if let dataArr = (dateResult["data"] as? [[String:Any]])  {
          
          if infoModel.pageNO == 0 {
            infoModel.data?.removeAll()
          }
        
          if dataArr.count < infoModel.pageSize! {
            
            infoModel.isLoadFinish = true
            
          }else{
            
            infoModel.isLoadFinish = false
          }
          
          
         
          if let modelArr = [FundRecordInfoModel].deserialize(from: dataArr) as? [FundRecordInfoModel]{
              infoModel.data!.append(contentsOf: modelArr)
          }
          
          
          infoModel.pageNO = infoModel.pageNO! + 1
          
        }
      }
      completion(nil, error?.errorDesc)
      
    }
    
  }
  
  // 资金记录删除
  func netRecordDataDelete(type:Int, _ recordIds:[String] , _ completion:@escaping NetFinish)  {
    
    var param = [String:Any]()
    param["requestIds"] = recordIds
    param["type"] = type
    
    var urlPath = ""
    switch FundRecordType.init(rawValue: type)! {
    case .deposit:
      urlPath = PersonCenterNetPath.fundRecordDepositDelelte.rawValue
    case .drawal:
      urlPath = PersonCenterNetPath.fundRecordWithdrawDelelte.rawValue
    case .wash:
      urlPath = PersonCenterNetPath.fundRecordXMDelelte.rawValue
    case .discount:
      urlPath = PersonCenterNetPath.fundRecordPromoDelelte.rawValue
    }
    
    CaseyNetwork().requestJsonPost(ServiceRootPath + urlPath, parameters: param) { (result, error, isCache) in
      
      
      
      completion(nil, error?.errorDesc)
      
    }
    
  }
  
  
}
