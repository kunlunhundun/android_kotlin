//
//  ReportInfoCell.swift
//  PersonReport
//
//  Created by Casey on 07/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

class DepositReportInfoCell: UITableViewCell {
  
    var dataModel:FundRecordInfoModel? {
      didSet {
          flushViewData()
      }
    }
    static let cellHeight:CGFloat = 90.0       // cell高度
    private let _contentBgView = UIView()
    private let _logImageView = UIImageView()  // log ImageView
    private let _payStyleNameLabel = UILabel() // 支付方式/类型
    private let _payDateLabel = UILabel()      // 支付日期+时间
    private let _payMoneyLabel = UILabel()     // 支付金额
    public let _payStatusLabel = UILabel()     // 支付状态
    let editButton =  CellEditButton()         // 编辑状态：左边编辑View
    let click =  UIButton()
    
    // 不可删除透明遮罩
    let _neverDeleteMaskView = MaskVisualEffectView.init(effect: UIBlurEffect.init(style: UIBlurEffect.Style.extraLight)) //
    let _neverDeleteDescLabel = UILabel()
  
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initUIProperty()
        initLayoutSubViews()
    }
  
    override func layoutSubviews() {
        super.layoutSubviews()
      
        if let targertView = self.searchSubViewOfClassName("UITableViewCellEditControl") {
            // 编辑状态
            targertView.isHidden = true
            editButton.isHidden = false
            editButton.removeFromSuperview()
            editButton.frame = CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height)
            editButton.frame = targertView.frame
          
            click.frame = CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height)
            self.addSubview(editButton)
            self.addSubview(click)
          
            _neverDeleteMaskView.isHidden = dataModel!.enabelDelete!
            if(!_neverDeleteMaskView.isHidden) {
                editButton.setImage(UIImage(named: "Oval 12 Copy 4.png"), for: .normal)
            }else {
                editButton.setImage(UIImage(named: "Oval 12 Copy 3.png"), for: .normal)
            }
            editButton.isSelected = dataModel?.isRecordSelected ?? false
          
        }else {
            editButton.isHidden = true
            editButton.isSelected = false
            _neverDeleteMaskView.isHidden = true
        }
    }
  
    private func initUIProperty()  {
      
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
      
        editButton.setImage(UIImage(named: "Oval 12 Copy 3.png"), for: .normal)
        editButton.setImage(UIImage(named: "正确提示icon.png"), for: .selected)
        editButton.addTarget(self, action: #selector(editStatusSelectEvent(_:)), for: .touchUpInside)
      
        click.addTarget(self, action: #selector(editStatusSelectEventClick(_:)), for: .touchUpInside)
      
        _contentBgView.backgroundColor = UIColor.init(colorValue: 0x2A2E32)
        _contentBgView.layer.cornerRadius = 5
        self.contentView.addSubview(_contentBgView)
      
        _logImageView.image = UIImage.init(named: "在线支付.png")
        _contentBgView.addSubview(_logImageView)
        
        _payStyleNameLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _payStyleNameLabel.textColor = .white
        _payStyleNameLabel.textAlignment = .left
        _payStyleNameLabel.text = "银联支付"
        _contentBgView.addSubview(_payStyleNameLabel)
        
        _payDateLabel.text = "09-19 17:34"
        _payDateLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _payDateLabel.textColor = UIColor.init(colorValue: 0x888888)
        _payDateLabel.textAlignment = .left
        _contentBgView.addSubview(_payDateLabel)
      
        _payMoneyLabel.text = "¥5,000.00"
        _payMoneyLabel.font = UIFont.PingFangSCRegular(ofSize: 16)
        _payMoneyLabel.textColor = .white
        _payMoneyLabel.textAlignment = .right
        _contentBgView.addSubview(_payMoneyLabel)
        
        _payStatusLabel.text = "拒绝"
        _payStatusLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _payStatusLabel.textColor = UIColor.init(colorValue: 0xFA2663)
        _payStatusLabel.textAlignment = .right
        _contentBgView.addSubview(_payStatusLabel)
      
        // 不可删除 遮罩
        _neverDeleteDescLabel.text = "不可删除"
        _neverDeleteDescLabel.textAlignment = .center
        _neverDeleteDescLabel.textColor = .white
        _neverDeleteDescLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        _neverDeleteDescLabel.backgroundColor = UIColor.clear
        _neverDeleteMaskView.contentView.addSubview(_neverDeleteDescLabel)
      
        _neverDeleteMaskView.backgroundColor = UIColor.init(R: 42, G: 46, B: 50, A: 1)
        _contentBgView.addSubview(_neverDeleteMaskView)
      
        if IS_IPHONE_SMALL {
          _payStyleNameLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
          _payMoneyLabel.font = UIFont.PingFangSCRegular(ofSize: 14)
        }
    }
  
    private func flushViewData() {
      
      let cdnImgUrl = ManagerModel.instanse.fastCdnDomainName + (dataModel?.itemIcon ?? "")
      _logImageView.sd_setImage(with: URL.init(string: cdnImgUrl ), placeholderImage: UIImage.init(named: "logo"))
      
      let data:String = dataModel?.beginDateDesc ?? ""
      let time:String = dataModel?.beginTimeDescQuan ?? ""
      _payDateLabel.text = data + " " + time
      
      let transCode = dataModel?.transCode
      let weihao = dataModel?.accountNo
      let title = dataModel?.title
      
      if transCode != nil {
        if transCode?.isEqual("1" as String) == true { _payStyleNameLabel.text = "人工存款" }
        if transCode?.isEqual("2" as String) == true { _payStyleNameLabel.text = "网银在线存款"  }
        if transCode?.isEqual("3" as String) == true {_payStyleNameLabel.text = "点卡存款"  }
        if transCode?.isEqual("4" as String) == true {_payStyleNameLabel.text = "微信扫码" }
        if transCode?.isEqual("5" as String) == true {_payStyleNameLabel.text = "支付宝扫码"  }
        if transCode?.isEqual("6" as String) == true {_payStyleNameLabel.text = "银行卡转账"  }
        if transCode?.isEqual("7" as String) == true {_payStyleNameLabel.text = "QQ扫码"  }
        if transCode?.isEqual("8" as String) == true {_payStyleNameLabel.text = "微信支付" }
        if transCode?.isEqual("9" as String) == true {_payStyleNameLabel.text = "支付宝支付" }
        if transCode?.isEqual("11" as String) == true {_payStyleNameLabel.text = "QQ钱包支付"  }
        if transCode?.isEqual("15" as String) == true {_payStyleNameLabel.text = "银联扫码"  }
        if transCode?.isEqual("16" as String) == true {_payStyleNameLabel.text = "京东扫码"  }
        if transCode?.isEqual("17" as String) == true {_payStyleNameLabel.text = "京东支付"  }
        if transCode?.isEqual("18" as String) == true {_payStyleNameLabel.text = "银联在线存款"  }
        if transCode?.isEqual("19" as String) == true {_payStyleNameLabel.text = "银联在线存款"  }
        if transCode?.isEqual("20" as String) == true {_payStyleNameLabel.text = "比特币支付"  }
        if transCode?.isEqual("22" as String) == true {_payStyleNameLabel.text = "微信转账"  }
        if transCode?.isEqual("26" as String) == true {_payStyleNameLabel.text = "支付宝转账"  }
      }
      if weihao != nil && transCode == nil {
        _payStyleNameLabel.text = "尾号" + weihao!
      }
      if weihao == nil && transCode == nil{
        _payStyleNameLabel.text = title!
      }
      
      _payMoneyLabel.text = String.init(format: "¥%@", dataModel?.amountDesc ?? "")
      _payStatusLabel.text = dataModel?.flagDesc
      _payStatusLabel.textColor = dataModel?.flagColor
      
      // 颜色的处理
      if dataModel?.flag == 0 || dataModel?.flag == 1 { // 0等待处理 和 1处理中
        _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
      }else if dataModel?.flag == 2 { // 2成功
        _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
      }else{ // 3失败 和 4超时
        _payStatusLabel.textColor = UIColor.init(colorValue : 0x999999)
      }
      
      let str:String = dataModel?.flagDesc ?? ""
      if(str.isEqual("审核中" as String)){
        _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
      }
      if(str.isEqual("支付中" as String)){
        _payStatusLabel.textColor = UIColor.init(colorValue : 0xE9664B)
      }
      if(str.isEqual("未通过" as String)){
        _payStatusLabel.textColor = UIColor.init(colorValue : 0x999999)
      }
      if(str.isEqual("成功" as String)){
        _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
      }
      if(str.isEqual("已派发" as String)){
        _payStatusLabel.textColor = UIColor.init(colorValue : 0x50E3C2)
      }
    }
  
    private func initLayoutSubViews()  {
        
        _contentBgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(5)
            make.right.equalToSuperview().offset(-15)
            make.bottom.equalToSuperview().offset(-5)
        }
        _logImageView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
            make.width.equalTo(25)
            make.height.equalTo(25)
        }
        _payStyleNameLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(65)
            make.width.equalTo(130)
            make.top.equalToSuperview().offset(15)
            make.height.equalTo(22)
        }
        _payDateLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(65)
            make.bottom.equalToSuperview().offset(-15)
            make.height.equalTo(22)
        }
        _payMoneyLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.left.equalTo(_payStyleNameLabel.snp.right).offset(5)
            make.top.equalToSuperview().offset(15)
            make.height.equalTo(22)
        }
        _payStatusLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.width.equalTo(90)
            make.bottom.equalToSuperview().offset(-15)
            make.height.equalTo(22)
        }
      
        // 不可删除 遮罩
        _neverDeleteDescLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        _neverDeleteMaskView.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    
    @objc func editStatusSelectEvent(_ sender:UIButton)  {
      if dataModel!.enabelDelete! {
          sender.isSelected = !sender.isSelected
          dataModel?.isRecordSelected = sender.isSelected // 处理model逻辑
      }
    }
  
    @objc func editStatusSelectEventClick(_ sender:UIButton)  {
      if dataModel!.enabelDelete! {
        sender.isSelected = !sender.isSelected
        editButton.isSelected = !editButton.isSelected
        dataModel?.isRecordSelected = sender.isSelected // 处理model逻辑
      }
    }

}
