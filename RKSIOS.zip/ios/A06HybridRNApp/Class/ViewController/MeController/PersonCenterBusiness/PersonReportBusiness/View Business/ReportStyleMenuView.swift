//
//  ReportStyleMenuView.swift
//  PersonReport
//
//  Created by Casey on 07/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

@objc protocol ReportStyleMenuSelectDelegate:AnyObject {
    
    @objc optional func selectReportMenuStyle(menuStyle:Int)
    
}

class ReportStyleMenuView: UIView {


    weak var delegate:ReportStyleMenuSelectDelegate?
    var isEditor:Bool = false
    
    private var _currentSelectButton:UIButton?
    private let _redLineView = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
      
        let array = ["存款", "取款", "洗码","优惠"]
      
      
        for index in 0...array.count-1 {
            
            let button = UIButton()
            button.setTitle(array[index], for: .normal)
            button.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
            button.setTitleColor(.white, for: .selected)
            button.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 15)
            button.tag = index
            button.addTarget(self, action: #selector(selectMenuEvent(sender:)), for: .touchUpInside)
            if index == 0 {
                
                _currentSelectButton = button
                _currentSelectButton?.isSelected = true
                
            }
            self.addSubview(button)
            
            button.snp.makeConstraints { (make) in
                make.left.equalTo(index * Int(SCREEN_WIDTH/CGFloat(array.count)))
                make.top.equalToSuperview()
                make.width.equalTo(SCREEN_WIDTH/CGFloat(array.count))
                make.bottom.equalToSuperview()
            }
        }
        
        // 灰色分界线
        let bottomLineView = UIView()
        bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292d30)
        self.addSubview(bottomLineView)
        
        bottomLineView.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(1)
            make.bottom.equalToSuperview()
        }
        
        // 红色线
        self.addSubview(_redLineView)
        _redLineView.backgroundColor = UIColor.init(colorValue: 0xFB2464)
        _redLineView.snp.makeConstraints { (make) in
            make.width.equalTo(27)
            make.centerX.equalTo(_currentSelectButton!.snp.centerX)
            make.height.equalTo(3)
            make.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    override func layoutSubviews() {
      super.layoutSubviews()
      
      if _redLineView.gradientLayer == nil {
          _redLineView.gradientInBottom(withVertical: false, startGdColor: UIColor.init(colorValue: 0xEB5D4D), endGdColor: UIColor.init(colorValue: 0xFB2464))
      }
    }
    
    @objc private func selectMenuEvent(sender:UIButton) {
        
        if _currentSelectButton == sender {
            return
        }
      
        if isEditor {
          return
        }
      
        _currentSelectButton?.isSelected = false
        _currentSelectButton = sender
        _currentSelectButton?.isSelected = true
      
        delegate?.selectReportMenuStyle?(menuStyle: _currentSelectButton!.tag)
        UIView.animate(withDuration: 0.2, animations: {
            
            self._redLineView.centerX = self._currentSelectButton!.centerX
            
        }) { _ in
            
            
        }
    }
}
