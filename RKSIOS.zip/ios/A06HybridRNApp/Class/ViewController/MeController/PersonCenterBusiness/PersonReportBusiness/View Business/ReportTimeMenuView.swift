//
//  ReportTimeMenuView.swift
//  PersonReport
//
//  Created by Casey on 07/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit


@objc protocol ReportTimeSelectDelegate:AnyObject {
    
    @objc optional func selectReportTime(timeStyle:Int)
    
}

class ReportTimeMenuView: UIView {

    
    weak var delegate:ReportTimeSelectDelegate?
    private var _currentSelectButton:UIButton?
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let array = ["近7天", "近15天"]
        
        for index in 0...array.count-1 {
            
            let button = UIButton()
            button.setTitle(array[index], for: .normal)
            button.setTitleColor(UIColor.init(colorValue: 0x888888), for: .normal)
            button.setTitleColor(.white, for: .selected)
            button.titleLabel?.font = UIFont.PingFangSCRegular(ofSize: 15)
            button.tag = index
            button.addTarget(self, action: #selector(self.selectTimeEvent(sender:)), for: .touchUpInside)
            if index == 0 {
                
                _currentSelectButton = button
                _currentSelectButton?.isSelected = true
                
            }
            self.addSubview(button)
            
            button.snp.makeConstraints { (make) in
                
                make.left.equalTo(index * Int(SCREEN_WIDTH/CGFloat(array.count)))
                make.top.equalToSuperview()
                make.width.equalTo(SCREEN_WIDTH/CGFloat(array.count))
                make.bottom.equalToSuperview()
            }
        }
        
        // 灰色分界线
        let bottomLineView = UIView()
        bottomLineView.backgroundColor = UIColor.init(colorValue: 0x292d30)
        self.addSubview(bottomLineView)
        
        bottomLineView.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(1)
            make.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //
    @objc private func selectTimeEvent(sender:UIButton) {
        
        if _currentSelectButton == sender {
            return
        }
        
        _currentSelectButton?.isSelected = false
        _currentSelectButton = sender
        _currentSelectButton?.isSelected = true
        
        delegate?.selectReportTime?(timeStyle: sender.tag)
    }
}
