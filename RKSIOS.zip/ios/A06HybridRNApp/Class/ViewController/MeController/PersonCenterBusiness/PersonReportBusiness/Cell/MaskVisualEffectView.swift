//
//  MaskVisualEffectView.swift
//  A06HybridRNApp
//
//  Created by Casey on 27/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class MaskVisualEffectView: UIVisualEffectView {

  override func layoutSubviews() {
      super.layoutSubviews()
    
    if self.subviews.count > 2 {
      
        self.alpha = 0.88
      
        let oneview = self.subviews[0]
      //  oneview.backgroundColor = UIColor.init(R: 42, G: 46, B: 50, A: 0.7)
        oneview.alpha = 0.8
      
        let twoview = self.subviews[1]
       // twoview.backgroundColor = UIColor.init(R: 42, G: 46, B: 50, A: 0.7)
        twoview.alpha = 0.2
      
        let threeview = self.subviews[2]
        threeview.alpha = 1
       // threeview.backgroundColor = UIColor.init(R: 42, G: 46, B: 50, A: 0.7)
    }
    
  }

}
