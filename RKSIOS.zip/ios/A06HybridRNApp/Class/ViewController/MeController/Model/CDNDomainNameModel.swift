//
//  CSDNDomainNameModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 29/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class CDNDomainNameModel: HandyJSON {

  var cdnDomainNames:[String]?
  
  required init() {
    
  }
}
