//
//  WithDrawModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 17/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class WithDrawModel: HandyJSON {

  
  var balance:String?
  var localBalance:String?
  var minWithDrawAmount:String?
  var platformBalances:PlatformBalancesModel?
  var platformTotalBalance:String?
  var withdrawBal:String?

  required init() {
    
  }


}

class PlatformBalancesModel:HandyJSON{
  
  var balance:String?
  var platformCode:String?
  var platformName:String?
  
  required init() {
    
  }
}


class BankCardBtcModel:HandyJSON{
  
  var accounts:[PersonInfoCardModel]?
  var btcRate:String?
  
  required init() {
    
  }
}



class CreateRequestModel:HandyJSON{
  
  var amount:String?
  var btcRate:String?
  var loginName:String?
  var referenceId:String?
  var type:String?   // 0 ：银行卡 1: btc
  
  required init() {
    
  }
}


