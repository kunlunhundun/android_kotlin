//
//  WashCodeModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 19/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON
class WashCodeModel: HandyJSON {
  
  var minBetAmount:String?
  var minXmAmount:String?
  var totalBetAmount:String?
  var totalRemBetAmount:String?
  var totalXmAmount:String?
  var xmBeginDate:String?
  var xmEndDate:String?
  var xmList:[XMListModel]?
  
  required init() {
    
  }

}


class XMListModel:HandyJSON{
  
  var betAmount:String?
  var totalBetAmont:String?
  var xmAmount:String?
  var xmName:String?
  var xmRate:String?
  var xmTypes:[[String:Any]]?

  required init() {
    
  }
}

class XmCreateRequestModel:HandyJSON{
  
  var loginName:String?
  var xmAmount:String?
  var referenceId:String?
  var xmResult:[XMResultModel]?

  required init() {
  }
}

class XMResultModel: HandyJSON {
  
  var errCode:String?
  var errMsg:String?
  var flag:String?
  var xmAmount:String?
  var xmType:String?
  var xmTypeName:String?
  var xmRate:String?
  var betAmount:String?

  required init() {
  }
}


/* xmList =     (
 {
 betAmount = 0;
 totalBetAmont = 227516558;
 xmAmount = 0;
 xmName = "\U771f\U4eba\U5a31\U4e50";
 xmRate = "0.9";
 xmTypes =             (
 {
 betAmount = 0;
 totalBetAmount = 227516558;
 xmAmount = 0;
 xmRate = "0.9";
 xmType = XM300;
 }
 );
 },
 {
 betAmount = 0;
 totalBetAmont = 75920442;
 xmAmount = 0;
 xmName = "\U7535\U5b50\U5a31\U4e50";
 xmRate = "1.2";
 xmTypes =             (
 {
 betAmount = 0;
 totalBetAmount = 75920442;
 xmAmount = 0;
 xmRate = "1.2";
 xmType = XM500;
 }
 );
 },
 {
 betAmount = 0;
 totalBetAmont = 0;
 xmAmount = 0;
 xmName = "\U5f69\U7968";
 xmRate = 1;
 xmTypes =             (
 {
 betAmount = 0;
 totalBetAmount = 0;
 xmAmount = 0;
 xmRate = 1;
 xmType = XM400;
 }
 );
 },  */
