//
//  CustomerServeViewController.swift
//  A06HybridRNApp
//
//  Created by Casey on 20/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class CustomerServeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      
        self.navigationItem.title = "客服"
        self.navigationItem.leftBarButtonItem = nil
      
      let aaa = Int("23.5")
      let bb = Double("222")
      let ccc = Double("23.66")
      let ddd = Int(ccc ?? 22)
      
      let xmTypeDic:[String:Any] = ["xmAmount":ccc, "bb":"23.5"]
      
      let xmTypeAmount = xmTypeDic["xmAmount"]
      
      
      var testAmount = (xmTypeAmount as? String)
    
      let ttt = "".anyToString(value: xmTypeAmount!)
      
      let strTypeAmount = "\(xmTypeAmount)"
      let dbAmount = Double(strTypeAmount)
      let ttAmount = Double(ttt ?? "0" )

      let bbbb = xmTypeDic["bb"]
      print(bbbb)
      
    }
    

  

}
