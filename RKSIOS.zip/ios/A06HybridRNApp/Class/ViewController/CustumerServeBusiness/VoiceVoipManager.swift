//
//  VoiceVoipManage.swift
//  A06HybridRNApp
//
//  Created by kunlun on 24/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class VoiceVoipManager: NSObject,CallApiDelegate {
  
  let callStatusSubject = PublishSubject<CallStatus>()
  
  var ishungup:Bool = false
  
  func onCallState(_ callInfo: CallInfo!) {
    
    callingInfo = callInfo
  
    callStatusSubject.onNext(callInfo.callStatus)
    
    switch callInfo.callStatus {
    case CallStatus_Calling : do{
      
      }
      break
    case CallStatus_Disconnected : do {
      
      if !ishungup{
        CallApi.enableSpeaker(false)
        CallApi.terminateCall()
        ishungup = true
      }
      
    }
      break
    case CallStatus_Failed : do {
      if !ishungup{
        CallApi.enableSpeaker(false)
        CallApi.terminateCall()
        ishungup = true
      }
    }
      break
    default:
      break
    }
    
  }
  
  func onRegisterState(_ regInfo: RegInfo!) {
    
    registInfo = regInfo
    if (SipRegStatus_Connected == regInfo.regStatus){
      print("login---Connected----->")
      makePhoneCall()
    }
    else{
      var regState = ""
      if SipRegStatus_Connecting == regInfo.regStatus {
          regState = "login……"
      }else if SipRegStatus_Disconnecting == regInfo.regStatus {
        regState = "logout……"
      }else if SipRegStatus_Offline == regInfo.regStatus {
        regState = "offline……"
      }else if SipRegStatus_Failed == regInfo.regStatus {
        regState = "failed……"
      }
      print("onRegisterState--->\(regState)")
    }
    
  }
  
  func onCallStatString(_ callStat: String!) {
    
    print("onCallStatString---->\(callStat ?? "") ")
    
  }
  

  var callNumber:String?
  var customerUid:String?
  
  var callingInfo:CallInfo?
  var registInfo:RegInfo?
  
  internal override init(){
    super.init()
    
    initData()
  }
  
  func initData() {

    _ = CallApi()
    CallApi.setDelegate(self)
    callingInfo = nil
    registInfo = nil
    let sipConfig = ApiConfig.init()
    customerUid = "00000000000"
    sipConfig.userName = customerUid
    sipConfig.password = "jx@123"
    sipConfig.displayName = customerUid
    sipConfig.domain = "218.213.95.77"
    sipConfig.proxyServer = "218.213.95.77"
    sipConfig.port = 9060
    CallApi.setConfig(sipConfig)
    
    let codecs = ["PCMA"] //["ilbc","PCMA"]
    CallApi.setPreferredAudioCodecs(codecs)
    
    CallApi.startRegister()
    
  }
  
  func swichWithUid(uid:String , phoneNumber:String = "7770755566610601"){
    
    customerUid = uid
    self.initData()
    
  }
  
  
  func makePhoneCall(){
    
    CallApi.enableSpeaker(true)
    CallApi.makeCall("7770755566610601")
    
  }
  
  func sendNumberDtmf(number:String){
    
    CallApi.sendDTMF(number)
  }
  
  func callCancel(){
    
    
    if !ishungup{
      CallApi.enableSpeaker(false)
      CallApi.terminateCall()
      ishungup = true
    }

  }
  
  
  func setSpeakerOn(turnOn:Bool){
    
    let isSuccess = CallApi.enableSpeaker(turnOn);
    let speakerState = isSuccess ? "扬声器操作成功" : "扬声器操作失败"
    
    print("speakerState:\(speakerState)")
    
  }
  
  
}
