//
//  CustomerVoiceDialView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 22/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

let DialIConWidth:CGFloat = 75.0
let DialIConHeight:CGFloat = 98.0

class CustomerVoiceDialView: UIView {
  
  static var voiceDailView:CustomerVoiceDialView?

  var numNormalArr:[String]!
  var numhoverArr:[String]!
  var numberArr:[String]!

  var numBackView:UIView!
  var voiceBackView:UIView!
  var numShowLab:UILabel!
  var timeLab:UILabel!
  var dialDesLab:UILabel!
  var callTimer:Timer?
  var callCount = 0
  var voiceVoipManager:VoiceVoipManager!
  var callInfoStatus:CallStatus?
  
  let disposeBag = DisposeBag()
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    
    self.frame = CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH , height: SCREEN_HEIGHT)
    
    self.gradient(withVertical: true, startGdColor: UIColor.init(colorValue: 0x272F36), endGdColor: UIColor.init(colorValue: 0x0D0F12))
    
   
    initData()
    setupNumberView()
    setupView()
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func initData(){
    
    numberArr = ["1","2","3","4","5","6","7","8","9","*","0","#"]
    numNormalArr = ["dial_1","dial_2","dial_3","dial_4","dial_5","dial_6","dial_7","dial_8","dial_9","dial_star","dial_0","dial_cc"]
    numhoverArr = ["dial_1hover","dial_2hover","dial_3hover","dial_4hover","dial_5hover","dial_6hover","dial_7hover","dial_8hover","dial_9hover","dial_starhover","dial_0hover","dial_cchover"]
    
   voiceVoipManager = VoiceVoipManager.init()
    
   
    voiceVoipManager.callStatusSubject.subscribe(onNext: {  [weak self] (callStatus:CallStatus) in
     
        self?.callInfoStatus = callStatus
        self?.handleCallStatus(callStatus: callStatus)
      
      }).disposed(by:disposeBag)
    
    
  }
  
  func handleCallStatus(callStatus:CallStatus){
    
    if callStatus ==  CallStatus_Connected {
      print("handleCallStatus------>CallStatus_Connected---->通话成功")
      startTimer()
  
    }else if callStatus ==  CallStatus_Calling {
       timeLab.text = "正在呼叫……"
    }else if callStatus ==  CallStatus_Disconnected || callStatus == CallStatus_Failed {
       timeLab.text = "挂断"
    }
    
  }
  
  
  func setupNumberView(){
    let numHeight = SCREEN_HEIGHT - (BOTTOM_MARGIN+35+DialIConHeight)
     numBackView = UIView.init(frame: .zero)
    self.addSubview(numBackView)
    numBackView.isHidden = true
    numBackView.snp.makeConstraints { (make) in
      make.left.right.top.equalToSuperview()
      make.height.equalTo(numHeight)
    }
    
    let numShowHeight = IS_IPHONE_X ? 64 + 20 : 64
    numShowLab = UILabel.init(color: UIColor.white, font: UIFont.PFM24_Font)
    numBackView.addSubview(numShowLab)
    numShowLab.textAlignment = .center
    numShowLab.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.right.equalToSuperview().offset(-15)
      make.top.equalToSuperview().offset(numShowHeight)
      make.height.equalTo(32)
    }
    
    let leftMargin:CGFloat = IS_IPHONE_SMALL ? 20 : 45
    let  dialMarginWidth:CGFloat = (SCREEN_WIDTH - leftMargin*2 - DialIConWidth * 3 )/2.0
    for i in 0...11 {
      
      let numberBtn = UIButton.init(frame: .zero)
      numberBtn.tag = 200 + i
      numberBtn.addTarget(self, action: #selector(numberAction(_: )), for: .touchUpInside)
      numBackView.addSubview(numberBtn)
      
      let nurNormalImgName = numNormalArr[safe:i] ?? ""
      let numhoverImgName = numhoverArr[safe:i] ?? ""
      numberBtn.setImage(UIImage.init(named: nurNormalImgName), for: .normal)
      numberBtn.setImage(UIImage.init(named: numhoverImgName), for: .selected)
      numberBtn.snp.makeConstraints { (make) in
        make.left.equalToSuperview().offset(45+(dialMarginWidth+DialIConWidth)*CGFloat(i%3))
        make.width.equalTo(DialIConWidth)
        make.height.equalTo(DialIConWidth)
        make.top.equalToSuperview().offset(145+CGFloat(i/3)*(DialIConWidth+15))
      }
    }
    
  }
  
  
  func setupView(){
    
    let numHeight = SCREEN_HEIGHT - (BOTTOM_MARGIN+35+DialIConHeight)
     voiceBackView = UIView.init(frame: .zero)
    self.addSubview(voiceBackView)
    voiceBackView.snp.makeConstraints { (make) in
      make.left.right.top.equalToSuperview()
      make.height.equalTo(numHeight)
    }
    
    let voiceCirCle = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 64, height: 64))
    voiceBackView.addSubview(voiceCirCle)
    voiceCirCle.layer.cornerRadius = 32
    voiceCirCle.backgroundColor = UIColor.clear
    voiceCirCle.center = CGPoint.init(x: SCREEN_WIDTH/2.0, y: 120+40)
    let rippleAnimationView = RippleAnimationView.init(frame: CGRect.init(x: 0, y: 0, width: 64, height: 64))
    rippleAnimationView.center = voiceCirCle.center
    voiceBackView.addSubview(rippleAnimationView)
    
    voiceBackView.addSubview(voiceCirCle)
    let voiceImgView = UIImageView.init(frame: .zero)
    voiceCirCle.addSubview(voiceImgView)
    voiceImgView.image = UIImage.init(named: "voice_icon")
    voiceImgView.snp.makeConstraints { (make) in
      make.edges.equalToSuperview()
    }
   let voiceLab = UILabel.init(color: UIColor.view_white, font: UIFont.L_Font)
    voiceLab.text = "语音通话"
    voiceLab.textAlignment = .center
    voiceBackView.addSubview(voiceLab)
    voiceLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(voiceCirCle.snp.bottom).offset(32+20)
      make.centerX.equalToSuperview()
    }
    timeLab = UILabel.init(color: UIColor.view_white, font: UIFont.M_Font)
   voiceBackView.addSubview(timeLab)
    timeLab.textAlignment = .center
    timeLab.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.top.equalTo(voiceLab.snp.bottom)
      make.height.equalTo(30)
    }
    let  leftMargin:CGFloat = IS_IPHONE_SMALL ? 20 : 45
    let  dialMarginWidth:CGFloat = (SCREEN_WIDTH - leftMargin*2 - DialIConWidth * 3 )/2.0
    for i in 0...2 {
      let dialBtn = UIButton.init(frame: .zero)
      dialBtn.tag = 100 + i
      dialBtn.addTarget(self, action: #selector(dialAction(_: )), for: .touchUpInside)
      self.addSubview(dialBtn)
      let desLab = UILabel.init(color: UIColor.white, font: UIFont.L_Font)
      desLab.textAlignment = .center
      self.addSubview(desLab)
      if i == 0 {
        dialBtn.setImage(UIImage.init(named: "hang_up"), for: .normal)
        desLab.text = "挂断"
      }else if i == 1 {
        dialBtn.setImage(UIImage.init(named: "hands_free_normal"), for: .normal)
        dialBtn.setImage(UIImage.init(named: "hands_free_hover"), for: .selected)
        desLab.text = "免提"
      }else if i == 2 {
        dialBtn.setImage(UIImage.init(named: "dial_hidden"), for: .normal)
        dialBtn.setImage(UIImage.init(named: "dial_dial"), for: .selected)
        desLab.text = "拨号"
        dialDesLab = desLab
      }
   
      dialBtn.snp.makeConstraints { (make) in
        make.left.equalToSuperview().offset(45+(dialMarginWidth+DialIConWidth)*CGFloat(i))
        make.width.equalTo(DialIConWidth)
        make.height.equalTo(DialIConHeight)
        make.bottom.equalToSuperview().offset(-(BOTTOM_MARGIN+35))
      }
      desLab.snp.makeConstraints { (make) in
        make.left.right.equalTo(dialBtn)
        make.top.equalTo(dialBtn.snp.bottom)
        make.height.equalTo(25)
      }
    }
  }
  
  
  func startTimer(){
    
    callTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerForCallConnect(_ : )), userInfo: nil, repeats: true)
 
  }
  
  @objc func timerForCallConnect(_ timer:Timer){
    
    callCount = callCount + 1
    
    let second = callCount%60
    let minite = (callCount/60)%60
    let hour = callCount/60/60
    let secondText = second < 10 ? "0\(second)" :  "\(second)"
    let miniteText = minite < 10 ? "0\(minite)" :  "\(minite)"
    
    timeLab.text = "0:" + "\(hour)" + miniteText + "\(secondText)"
    
  }
  
  

  @objc func numberAction(_ sendBtn:UIButton){
    
    let curNumber = numberArr[safe:sendBtn.tag-200] ?? ""
    numShowLab.text = (numShowLab.text ?? "") + curNumber
    
    if callInfoStatus == CallStatus_Connected {
      voiceVoipManager.sendNumberDtmf(number: curNumber)
    }

  }
  
  @objc func dialAction(_ sendBtn:UIButton){
  
    if sendBtn.tag == 100 {
      
      voiceVoipManager.callCancel()
  
      hidenView()

    }else if sendBtn.tag == 101 {
      sendBtn.isSelected = !sendBtn.isSelected
      voiceVoipManager.setSpeakerOn(turnOn: sendBtn.isSelected)
      
    }else if sendBtn.tag == 102 {
      
      sendBtn.isSelected = !sendBtn.isSelected
      numBackView.isHidden = !sendBtn.isSelected
      voiceBackView.isHidden = sendBtn.isSelected
      
      if sendBtn.isSelected {
        dialDesLab.text = "隐藏"
      }else{
        dialDesLab.text = "拨号"
      }
    }
  
  }
  

  class func showPopView(){
    
    voiceDailView = CustomerVoiceDialView.init(frame: .zero)
    voiceDailView?.showView()
  }
  
  func showView(){
    UIApplication.shared.delegate?.window??.addSubview(self)
    
  }
  
  func hidenView(){
    self.removeFromSuperview()
    callTimer?.invalidate()
    callTimer = nil
  }

  

}
