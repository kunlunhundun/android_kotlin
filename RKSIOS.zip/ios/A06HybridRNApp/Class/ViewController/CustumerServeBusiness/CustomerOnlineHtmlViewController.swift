//
//  CustomerOnlineHtmlViewController.swift
//  A06HybridRNApp
//
//  Created by kunlun on 26/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import WebKit
import XCGLogger

class CustomerOnlineHtmlViewController:UIViewController,WKUIDelegate,WKNavigationDelegate,WKScriptMessageHandler {
  
  var webView:WKWebView!
  var webUrl:String?
  var isFromCustomerView:Bool = false
  var isFromRnView:Bool = false

  var requestModel:RequestGameModel?
  let loadingView:GameLoadingView = GameLoadingView.getLoadingView()

  convenience init(isFromCustomer:Bool,isFromRN:Bool=false){
    self.init()
    self.isFromCustomerView = isFromCustomer
    self.isFromRnView = isFromRN
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    if requestModel?.gameUrl != nil {
       self.title = ""
       setUpWKwebView()
       webUrl = requestModel?.gameUrl
       loadWebViewURL()
      
    }else{
      requestLiveChaAddress()
      if isFromCustomerView == true {
        //setupLeftBackBtn()
      }else{
        self.navigationController?.navigationBar.isHidden = true
      }
      setUpWKwebView()
    }
  }
                                                                                                                                                                                         
  override func viewDidDisappear(_ animated: Bool) {
    super.viewDidDisappear(animated)
    ManagerModel.instanse.customerLiveChatVC = nil
  }
  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    if isFromRnView {
      ManagerModel.instanse.showHidenTabbar(false)
    }
    if isFromCustomerView == true {
      
    }else{
      self.navigationController?.navigationBar.isHidden = false
    }
  }
  
  func setupLeftBackBtn(){
    
   let  backBtn = UIButton.init(frame: .zero)
    backBtn.contentHorizontalAlignment = .left
    backBtn.addTarget(self, action: #selector(backAction), for: .touchUpInside)
    backBtn.setImage(UIImage.init(named: "navBackArrow"), for: .normal)
    
    let navBarView = UIView.init(frame: .zero)
    self.view.addSubview(navBarView)
    navBarView.backgroundColor = UIColor.view_backBlack
    navBarView.snp.makeConstraints { (make) in
      make.left.top.right.equalToSuperview()
      make.height.equalTo(STATUS_NAV_BAR_Y)
    }
    navBarView.addSubview(backBtn)
    backBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(15)
      make.bottom.equalToSuperview()
      make.height.equalTo(44)
      make.width.equalTo(60)
    }
    
    let titleLab = UILabel.init(color: UIColor.white, font: UIFont.PFMXL_Font)
    titleLab.text = "在线客服"
    titleLab.textAlignment = .center
    navBarView.addSubview(titleLab)
    titleLab.snp.makeConstraints { (make) in
      make.left.equalTo(backBtn.snp.right)
      make.right.equalToSuperview().offset(-75)
      make.bottom.equalToSuperview()
      make.height.equalTo(44)
    }
  }
  
  @objc func backAction(){
    self.dismiss(animated: true) {
      
    }
  }
  
  func setUpWKwebView() {
  
    let webConfiguration = WKWebViewConfiguration()
    webConfiguration.preferences = WKPreferences()
    webConfiguration.preferences.javaScriptEnabled = true
    webConfiguration.preferences.javaScriptCanOpenWindowsAutomatically = true
    webConfiguration.processPool = WKProcessPool()
    webConfiguration.userContentController = WKUserContentController()
    webView = WKWebView(frame: .zero, configuration: webConfiguration)
    webView.uiDelegate = self
    webView.navigationDelegate = self
    view.addSubview(webView)
    webView.snp.makeConstraints { (make) in
      make.left.right.bottom.equalToSuperview()
      make.top.equalToSuperview().offset(STATUS_NAV_BAR_Y_KEFU)
      if self.isFromRnView == true {
        make.top.equalToSuperview().offset( (isFromCustomerView ? STATUS_NAV_BAR_Y : 0))
      }
    }
    webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
  }
  
  func loadWebViewURL(){
    let requestUrl = webUrl ?? ""
    let myRequest = URLRequest(url: URL.init(string: requestUrl)!)
    webView.load(myRequest)
  }
  
  
  override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    var progressValue:Float = 0
    if keyPath == "estimatedProgress"{
      progressValue = Float(CGFloat(webView.estimatedProgress))
      let pross = CGFloat(webView.estimatedProgress) * 100
      loadingView.setProgress(CGFloat(pross))
    }
    if progressValue >= 0.98{
     
      let time: TimeInterval = 0.5
      DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + time) { [weak self] in
          self?.loadingView.cancelrimer()
          self?.loadingView.removeFromSuperview()
        }
      }
    }
  
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    XCGLogger.debug("\(message)")
  }
  func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    XCGLogger.debug("didFinish")
  }
  func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
    XCGLogger.debug("didFailProvisionalNavigation")
  }
  func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
    XCGLogger.debug("didFail navigation")
  }
  func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    
    XCGLogger.debug("didStartProvisionalNavigation---->\(webView.url?.absoluteString)")
  
    let gatewayAddressDomain_http =  EnviromentManager.gatewayAddressRequet_domain.replacingOccurrences(of: "https", with: "http") + "/"
    let gatewayAddressDomain_https = EnviromentManager.gatewayAddressRequet_domain + "/"
    
    let parId:String = ReadChannelDomain.getParentId()
    
    let parId_http:String = "http://" + parId + "/"
    let parId_https:String = "https://" + parId + "/"
  
    if requestModel?.gameCode == "KLC" {
      
    }else{
      
      if parId.isEqual("" as String) == true{ //主包
        if webView.url?.absoluteString.contains(gatewayAddressDomain_http) == true || webView.url?.absoluteString.contains(gatewayAddressDomain_https) == true{
          if isFromCustomerView == false {
            //ManagerModel.instanse.showHidenTabbar(false)
            self.navigationController?.popViewController(animated: true)
          }else{
            self.backAction()
          }
        }
      }
      
      else{ // 渠道包
        if webView.url?.absoluteString.contains(parId_http) == true || webView.url?.absoluteString.contains(parId_https) == true{
          if isFromCustomerView == false {
            //ManagerModel.instanse.showHidenTabbar(false)
            self.navigationController?.popViewController(animated: true)
          }else{
            self.backAction()
          }
        }
      }
    }


    let absoluteString = webView.url?.absoluteString ?? ""
    if absoluteString.contains("itms-services://") {
      if #available(iOS 10.0, *) {
        UIApplication.shared.open(URL.init(string: absoluteString)!, options: [:]) { (success) in
          
        }
      }else{
        UIApplication.shared.openURL(URL.init(string: absoluteString)!)
      }
    }
  }  
  
  func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
    if navigationAction.targetFrame?.isMainFrame == false {
      self.webView.load(navigationAction.request)
    }else if (navigationAction.targetFrame?.isMainFrame == nil) {
      if (navigationAction.request.url?.absoluteString == "about:blank" ){
       loadWebViewURL() 
        return nil
      }
      self.webView.load(navigationAction.request)
    }
    return nil
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    XCGLogger.debug("decidePolicyFor navigation---->\(webView.url?.absoluteString)")
    decisionHandler(WKNavigationActionPolicy.allow)
  }
  
  func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
  decisionHandler(WKNavigationResponsePolicy.allow)
    XCGLogger.debug("decidePolicyFor navigationResponse")

  }
  
//  func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
//
//  }
  
  func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
  
    XCGLogger.debug("\(message)")
  }
  
  func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {

    XCGLogger.debug("\(message)")
  }
  
  
  func requestLiveChaAddress(){
  
      LoadingView.showLoadingViewWith(to: self.view)
     let param = ManagerModel.configLoginNameParamDic()
      APITool.request(.liveChatAddress, parameters: param, successHandle: { [weak self]  (liveChatModel : LiveChatAddModel) in
        LoadingView.hideLoadingView(for: self?.view)
        self?.webUrl = liveChatModel.body
        self?.loadWebViewURL()
        
      }) { [weak self] (apiError) in
        LoadingView.hideLoadingView(for:self?.view)
        XCGLogger.debug("queryOnlineBanks error \n")
        ProgressTopPopView.showPopView(content: apiError?.kl_tips ?? "", popStyle: .errorMsgToast)
      }
  }
}
