//
//  CustomerOnlineView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 22/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class CustomerOnlineView: UIView {


  override  init(frame: CGRect) {
    super.init(frame: frame)
    
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-220-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 220)
    self.layer.cornerRadius = 5.0
    
    setupView()
   
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  
  func setupView(){
    self.backgroundColor = UIColor.view_popBlackColor
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "客服热线"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    
    let numberLab = UILabel.init(frame: .zero)
    self.addSubview(numberLab)
    numberLab.textAlignment = .center
    numberLab.textColor = UIColor.view_white
    numberLab.font = UIFont.SF20_Font
    numberLab.text = "400-1200-667"
    numberLab.snp.makeConstraints { (make) in
      make.top.equalTo(lineView.snp.bottom).offset(0)
      make.height.equalTo(120)
      make.left.right.equalToSuperview()
    }
    
    let cancelBtn = UIButton.init(frame: .zero)
    cancelBtn.backgroundColor = UIColor.btn_leftLightBlack
    self.addSubview(cancelBtn)
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.titleLabel?.font = UIFont.PFML_Font
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.bottom.equalToSuperview().offset(-10)
      make.width.equalTo((self.newWidth-10*3)/2)
      make.height.equalTo(48)
    }
    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("呼叫", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalTo(cancelBtn.snp.right).offset(10)
      make.height.equalTo(48)
      make.bottom.equalTo(cancelBtn.snp.bottom)
    }
    
    
    
  }
  
  func showView(){
    
    MaskView.show(subView: self)
   
  }
  
  
  @objc func cancelAction(){
    
    hidenView()
  }
  
  @objc func sureAction(){
    
    UIApplication.shared.openURL(URL.init(string: "tel://4001200667")! )
    hidenView()
  }
  
  @objc func closeAction(){
    
    hidenView()

  }
  
  func hidenView(){
    MaskView.hiden()
  }
  

}
