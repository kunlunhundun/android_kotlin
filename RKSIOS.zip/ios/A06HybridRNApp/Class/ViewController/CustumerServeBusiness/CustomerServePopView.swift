//
//  CustomerServePopView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 21/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class CustomerServePopView: UIView,UITableViewDataSource,UITableViewDelegate {

  static var customerServeView:CustomerServePopView?
  
  var tableView:UITableView?
  override init(frame: CGRect) {
    super.init(frame: frame)
    self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT, width: SCREEN_WIDTH, height: 0)
    self.clipsToBounds = true
    setupView()
    
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  
  private func setupView()  {
    
    tableView = UITableView.init(frame: .zero, style: .plain)
    tableView?.delegate = self
    tableView?.dataSource = self
    tableView?.separatorStyle = .none
    self.addSubview(tableView!)
    
  //  let tabHeight = 320
    tableView?.snp.makeConstraints({ (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.equalToSuperview()
      make.height.equalTo(240)
    })
    tableView?.backgroundColor = UIColor.view_popBlackColor
    tableView?.layer.cornerRadius = 5.0
    
    let cancelBtn = UIButton.init(frame: .zero);
    self.addSubview(cancelBtn)
    cancelBtn.addTarget(self, action: #selector(cancelAction), for: .touchUpInside)
    cancelBtn.backgroundColor = UIColor.view_popBlackColor
    cancelBtn.layer.cornerRadius = 5.0
    cancelBtn.setTitle("取消", for: .normal)
    cancelBtn.setTitleColor(UIColor.view_white, for: .normal)
    cancelBtn.titleLabel?.font = UIFont.M_Font
    cancelBtn.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(View_Margin)
      make.right.equalToSuperview().offset(-View_Margin)
      make.top.equalTo(tableView!.snp.bottom).offset(10)
      make.height.equalTo(60)
    }
    
  }
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
   
    return 4
  }
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    var cell = tableView.dequeueReusableCell(withIdentifier: "CustomerViewCell") as? CustomerViewCell
    if cell == nil {
      
      cell = CustomerViewCell.init(style: .default, reuseIdentifier: "CustomerViewCell",isShowImg:true)
      cell?.selectionStyle = .none
      cell?.backgroundColor = UIColor.clear
    }
    
    if indexPath.row == 0 {
      cell?.imgView.image = UIImage.init(named: "VoiceDial")
      cell?.contentLab.text = "语音通话"
    }
   else if indexPath.row == 1 {
      cell?.imgView.image = UIImage.init(named: "DialCallBack")
      cell?.contentLab.text = "电话回拨"
    }else if indexPath.row == 2 {
      cell?.imgView.image = UIImage.init(named: "OnlineCustomer")
      cell?.contentLab.text = "在线客服"
    }
    if indexPath.row == 3 {
      
      var cell = tableView.dequeueReusableCell(withIdentifier: "NormalCustomerViewCell") as? CustomerViewCell
      if cell == nil {
        cell = CustomerViewCell.init(style: .default, reuseIdentifier: "NormalCustomerViewCell",isShowImg:false)
        cell?.selectionStyle = .none
        cell?.backgroundColor = UIColor.clear
      }
      cell?.contentLab.text = "客服热线：400-1200-667"
      return cell!
    }
    
    return cell!
  }
  
  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 60
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    self.frame =  CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 0)

    if indexPath.row == 3 {
      
      let onlineView = CustomerOnlineView.init(frame: .zero)
      MaskView.maskView?.addSubview(onlineView)
    }
    else if indexPath.row == 1 {
      let dialCallBackView =  CustomerDialCallBackView.init(frame: .zero)
      MaskView.maskView?.addSubview(dialCallBackView)
    }
    else if indexPath.row == 0 {
      
      hidenView()
      CustomerVoiceDialView.showPopView()
    }
    else if indexPath.row == 2 {
      
      hidenView()
      let currentVC = UIViewController.getCurrentShow()
      let CustomerOnlineVC = CustomerOnlineHtmlViewController.init(isFromCustomer: true)
      CustomerOnlineVC.isFromRnView = true
      ManagerModel.instanse.customerLiveChatVC = CustomerOnlineVC
      currentVC?.present(ManagerModel.instanse.customerLiveChatVC!, animated: true, completion: {
        
      })
      
    }

  }
  
  class func showPopView() {
    customerServeView = CustomerServePopView.init(frame: .zero)
    
    customerServeView?.showView()
    
  }
  
  
  func showView(){
    MaskView.show(subView: self)
    UIView.animate(withDuration: 0.6) {
      self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT - 310 - BOTTOM_MARGIN, width: SCREEN_WIDTH, height: 310 + BOTTOM_MARGIN)
    }
  }
  
  func hidenView(){
    
    UIView.animate(withDuration: 0.5, animations: {
      self.frame = CGRect.init(x: 0, y: SCREEN_HEIGHT, width: SCREEN_WIDTH, height: 0)
    }) { ( isFinished) in
      MaskView.hiden()
    }
    
  }
  
  @objc func cancelAction(){
    
    hidenView()
    
  }
  
  
}


class CustomerViewCell:UITableViewCell{
  
  let lineView:UIView = UIView.init()
  let contentLab = UILabel.init(frame: .zero)
  let imgView = UIImageView.init(frame: .zero)
  var isShowImgView:Bool = true
  convenience init(style: UITableViewCellStyle, reuseIdentifier: String,isShowImg:Bool) {
    self.init(style: style, reuseIdentifier: reuseIdentifier)
    isShowImgView = isShowImg
    setupView()
  }
  

  
  
  func setupView(){
  
    contentView.backgroundColor = UIColor.clear
    if isShowImgView {
      let backView = UIView.init(frame: .zero)
      contentView.addSubview(backView)
      backView.contentMode = UIView.ContentMode.center
      backView.snp.makeConstraints { (make) in
        make.width.equalTo(130)
        make.top.bottom.equalToSuperview()
        make.centerX.equalTo(contentView.snp.centerX)
      }
      backView.addSubview(imgView)
      backView.addSubview(contentLab)
      contentLab.text = ""
      contentLab.textColor = UIColor.view_white
      contentLab.font = UIFont.M_Font
      imgView.image = UIImage.init(named: "IconAlipay")
      imgView.contentMode = UIView.ContentMode.scaleAspectFit
      imgView.snp.makeConstraints { (make) in
        make.left.equalTo(backView).offset(0)
        make.centerY.equalTo(backView.snp.centerY)
        //make.size.equalTo(CGSize.init(width: 30, height: 30))
      }
      contentLab.snp.makeConstraints { (make) in
        make.left.equalTo(imgView.snp.right).offset(15)
        make.centerY.equalTo(backView.snp.centerY)
      }
    }else{
      
      contentLab.text = ""
      contentLab.textColor = UIColor.view_white
      contentLab.font = UIFont.M_Font
      contentLab.textAlignment = .center
      contentView.addSubview(contentLab)
      contentLab.snp.makeConstraints { (make) in
        make.left.equalToSuperview().offset(View_Margin)
        make.right.equalToSuperview().offset(-View_Margin)
        make.centerY.equalTo(contentView.snp.centerY)
      }
    }
   
    contentView.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
    make.left.right.equalToSuperview()
    make.bottom.equalTo(contentView.snp.bottom)
    make.height.equalTo(1)
    }
  
  }
}
  


