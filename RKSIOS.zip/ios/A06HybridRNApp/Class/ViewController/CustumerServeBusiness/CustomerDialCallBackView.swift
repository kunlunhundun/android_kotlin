//
//  CustomerDialCallBackView.swift
//  A06HybridRNApp
//
//  Created by kunlun on 22/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import RxSwift

class CustomerDialCallBackView: UIView {

  var disposeBag = DisposeBag()
  var numberTextField:UITextField!
  
  override  init(frame: CGRect) {
    super.init(frame: frame)
    
    self.frame = CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-284-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 284)
    self.layer.cornerRadius = 5.0
    
    registerForKeyboardNotifications()
    
    setupView()
    
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  
  func setupView(){
    self.backgroundColor = UIColor.view_popBlackColor
    
    let titleLab = UILabel.init(frame: .zero)
    titleLab.textColor = UIColor.view_white
    titleLab.font = UIFont.PFML_Font
    titleLab.text = "电话回拨"
    titleLab.textAlignment = .center
    self.addSubview(titleLab)
    
    let closeBtn = UIButton.init(frame: .zero)
    self.addSubview(closeBtn)
    closeBtn.setImage(UIImage.init(named: "close"), for: .normal)
    closeBtn.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
    
    titleLab.snp.makeConstraints { (make) in
      make.top.equalToSuperview()
      make.width.equalTo(100)
      make.height.equalTo(40)
      make.centerX.equalTo(self.snp.centerX)
    }
    closeBtn.snp.makeConstraints { (make) in
      make.right.equalTo(self).offset(-View_Margin)
      make.top.equalToSuperview().offset(5)
      make.width.equalTo(30)
      make.height.equalTo(30)
    }
    let lineView = UIView.init(frame: .zero)
    self.addSubview(lineView)
    lineView.backgroundColor = UIColor.view_lineColor
    lineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.height.equalTo(1)
      make.top.equalTo(self).offset(40)
    }
    
    
    let numberBackView = UIView.init(frame: .zero)
    self.addSubview(numberBackView)
    numberBackView.snp.makeConstraints { (make) in
      make.top.equalToSuperview().offset(100)
      make.left.equalToSuperview().offset(20)
      make.right.equalToSuperview().offset(-20)
      make.height.equalTo(40)
    }
    
    let numberLineView = UIView.init(frame: .zero)
    numberBackView.addSubview(numberLineView)
    numberLineView.backgroundColor = UIColor.view_lineColor
    numberLineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.bottom.equalToSuperview()
      make.height.equalTo(1)
    }
    
    let brightLineView = UIView.init(frame: .zero)
    numberBackView.addSubview(brightLineView)
    brightLineView.isHidden = true
    brightLineView.backgroundColor = UIColor.view_white
    brightLineView.snp.makeConstraints { (make) in
      make.left.right.equalToSuperview()
      make.bottom.equalToSuperview()
      make.height.equalTo(2)
    }
    
    let dialNumbImgView = UIImageView.init(frame: .zero)
    numberBackView.addSubview(dialNumbImgView)
    dialNumbImgView.image = UIImage.init(named: "DialCallBack")
    dialNumbImgView.contentMode = UIView.ContentMode.scaleAspectFit
    dialNumbImgView.snp.makeConstraints { (make) in
      make.left.equalToSuperview().offset(10)
      make.centerY.equalTo(numberBackView.snp.centerY)
    }
    
    let dialNumberTextField = UITextField.init(frame: .zero)
    numberBackView.addSubview(dialNumberTextField)
    dialNumberTextField.textColor = UIColor.view_white
    dialNumberTextField.font = UIFont.L_Font
    dialNumberTextField.keyboardType = .numberPad
    numberTextField = dialNumberTextField
    dialNumberTextField.setAppPlaceholder(text: "请输入您的联系电话")
    dialNumberTextField.snp.makeConstraints { (make) in
    //  make.left.equalToSuperview().offset(60)
      make.top.bottom.equalToSuperview()
      make.width.equalTo(150)
      make.centerX.equalToSuperview()
    }
    
    dialNumberTextField.rx.controlEvent(.allEditingEvents).asObservable().subscribe(onNext: {
      brightLineView.isHidden = !dialNumberTextField.isFirstResponder
    }).disposed(by: self.disposeBag)
    

    let sureBtn = UIButton.init(frame: .zero)
    sureBtn.backgroundColor = UIColor.btn_rightRed
    self.addSubview(sureBtn)
    sureBtn.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
    sureBtn.layer.cornerRadius = 5.0
    sureBtn.setTitle("提交回拨", for: .normal)
    sureBtn.titleLabel?.font = UIFont.PFML_Font
    sureBtn.snp.makeConstraints { (make) in
      make.right.equalToSuperview().offset(-10)
      make.left.equalToSuperview().offset(10)
      make.height.equalTo(48)
      make.bottom.equalToSuperview().offset(-10)
    }
    
    
  }
  
  func showView(){
    
    MaskView.show(subView: self)
    
  }
  
  
  func registerForKeyboardNotifications(){
    
    NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillAppear(_:) ), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
    
    
    NotificationCenter.default.addObserver(self, selector:#selector(keyboardWillDisappear(_:) ), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
  }
  
 @objc func keyboardWillAppear(_ anotification:Notification) {
  
//  CGRect frame = [aNotification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
 
    let keyboardinfo = anotification.userInfo![UIKeyboardFrameEndUserInfoKey]
    let keyboardheight:CGFloat = ((keyboardinfo as AnyObject).cgRectValue.size.height)
    //print((anotification.userInfo?["UIKeyboardBoundsUserInfoKey"] as! CGRect).height)
  
    UIView.animate(withDuration: 0.6) {
       self.frame =  CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-284-keyboardheight, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 284)
    }
  
  }
  @objc func keyboardWillDisappear(_ anotification:Notification){
    
    UIView.animate(withDuration: 0.6) {
     self.frame =  CGRect.init(x: CGFloat(View_Margin), y: SCREEN_HEIGHT-284-BOTTOM_MARGIN, width: SCREEN_WIDTH - CGFloat(View_Margin*2), height: 284)
    }
    
  }
  
  
  @objc func cancelAction(){
    
    hidenView()
  }
  
  @objc func sureAction(){
    
    let numberText =  numberTextField.text ?? ""
    if numberText.count < 1 {
      ProgressTopPopView.showPopView(content: "请输入正确的号码", popStyle: .errorMsgToast)
      return
    }
    if  !RegularExp.isValidateMobile(numberText) {
      ProgressTopPopView.showPopView(content: "请输入正确的号码", popStyle: .errorMsgToast)
      return
    }
    
    CustomerViewModel.requestCallBackPhone(phoneNumber: numberText, finishHandleBlock: { [weak self ] (phoneCallBackModel) in
      
       self?.hidenView()
    
      let currentVC =  UIViewController.getCurrentShow()
      
      ProgressTopPopView.showPopView(content: "客服将在1分钟内致电，请保持电话畅通", popStyle: .successMsgToast)
      
      //PopSuccessView.showPopView(currentView:currentVC?.view,content: "客服将在1分钟内致电，请保持电话畅通" )
      
    }) { (error) in
      
    }
    
  }
  
  @objc func closeAction(){
    
    NotificationCenter.default.removeObserver(self)
    hidenView()
    
  }
  
  func hidenView(){
    MaskView.hiden()
  }
  

}
