//
//  CustomerModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 26/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class LiveChatAddModel: HandyJSON {

  var body:String?
  
  required init() {
    
  }
  
}



class PhoneCallBackModel:HandyJSON {
  
  var body:Bool?
  
  required init() {
    
  }
  
}
