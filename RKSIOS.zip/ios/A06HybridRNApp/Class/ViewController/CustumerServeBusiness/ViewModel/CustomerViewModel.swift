//
//  CustomerViewModel.swift
//  A06HybridRNApp
//
//  Created by kunlun on 26/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

class CustomerViewModel: NSObject {

  
 class func requestCallBackPhone(phoneNumber:String,  finishHandleBlock:@escaping (_ phoneCallBackModel:PhoneCallBackModel )->() ,failureHandleBlok:@escaping (_ error:APIError)->()){
    
    var param = ManagerModel.configLoginNameParamDic()
    param["mobileNo"] = phoneNumber
    LoadingView.showLoadingViewWith(to: UIApplication.shared.keyWindow)
    
    APITool.request(.callBackPhone, parameters: param, successHandle: {  (phoneCallBackModel : PhoneCallBackModel) in
      LoadingView.hideLoadingView(for: UIApplication.shared.keyWindow)
      finishHandleBlock(phoneCallBackModel)
    }) { (apiError) in
      print("queryOnlineBanks error \n")
      LoadingView.hideLoadingView(for: UIApplication.shared.keyWindow)
      let error = apiError ?? APIError()
      failureHandleBlok(error)
    }
  }
  
  class func requestUpdateApp(){
    
    let param = ManagerModel.configBasicParamDic()
    
    APITool.request(.upgradeApp, parameters: param, successHandle: {  (updateVersionModel:UpdateVersionModel) in

      // 新包的地址不存在
      if updateVersionModel.appDownUrl?.count ?? 0 < 1 {
        return
      }

      // 判断版本号
      let oldVersion = param["v"] as! String
      let newVersion:String = updateVersionModel.versionCode ?? ""
      let oldVersionNumStr = oldVersion.replacingOccurrences(of: ".", with: "")
      let newVersionNumStr = newVersion.replacingOccurrences(of: ".", with: "")

      let oldVersionNum = CGFloat(Int(oldVersionNumStr) ?? 0)
      let newVersionNum = CGFloat(Int(newVersionNumStr) ?? 0)

      if newVersionNum > oldVersionNum {
      
        let cancelTitle = (updateVersionModel.flag?.toIntValue() ?? 0) == 1 ? "取消" : "退出应用"

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+3, execute: {

          UpDateVersionPopView.showPopViewCallBack(cancelTitle: cancelTitle, callBackBlock: { (isConfirm) in
            
            guard let appDownUrl = URL.init(string: updateVersionModel.appDownUrl!) else {
              return
            }
            
            if isConfirm  {
              if #available(iOS 11.0, *) {
                UIApplication.shared.open(appDownUrl, options: [:], completionHandler: { (isSuccess) in
                  exit(0)
                })
                
              }else{
                UIApplication.shared.openURL(appDownUrl)
              }
            }
          })
        })
      }
    
    }) { (apiError) in
      _ = apiError ?? APIError()
    }
  }
}
