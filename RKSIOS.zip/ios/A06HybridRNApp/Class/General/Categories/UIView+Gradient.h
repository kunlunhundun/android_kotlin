//
//  UIView+Gradient.h
//  INTEDSGame
//
//  Created by bux on 2018/2/21.
//  Copyright © 2018年 INTECH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Gradient)


@property (nonatomic, strong)CAGradientLayer *gradientLayer;

-(void)GradientWithVertical:(BOOL)isVertical startGdColor:(UIColor *)startGdColor endGdColor:(UIColor*)endGdColor;  // 两种颜色的渐变

-(void)gradientInBottomWithVertical:(BOOL)isVertical startGdColor:(UIColor *)startGdColor endGdColor:(UIColor*)endGdColor;


+ (BOOL)isViewShowWithSuperView:(UIView *)superView targetView:(Class)targetView;

- (void)hideKeyBoard;
@end
