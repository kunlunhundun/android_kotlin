//
//  NSString+Contains.h
//  MLinkTeacher
//
//  Created by kunlun on 17/4/12.
//  Copyright © 2017年 MLink. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>

@interface NSString (Contains)

/**
 *  @brief  判断URL中是否包含中文
 *
 *  @return 是否包含中文
 */
- (BOOL)mlk_isContainChinese;

/**
 *  @brief  是否包含空格
 *
 *  @return 是否包含空格
 */
- (BOOL)mlk_isContainBlank;

/**
 *  @brief  Unicode编码的字符串转成NSString
 *
 *  @return Unicode编码的字符串转成NSString
 */
- (NSString *)mlk_makeUnicodeToString;

- (BOOL)mlk_containsCharacterSet:(NSCharacterSet *)set;

/**
 *  @brief 是否包含字符串
 *
 *  @param string 字符串
 *
 *  @return YES, 包含;
 */
- (BOOL)mlk_containsaString:(NSString *)string;

/**
 *  @brief 获取字符数量
 */
- (NSInteger)mlk_wordsCount;

/**
 *  是否为空（nil，空字符串）
 *
 *  @param string 字符串
 *
 *  @return 是否为空
 */
+ (BOOL)mlk_isEmptyWithString:(NSString *)string;

+(NSString*)createUUID;

+(NSString*)sortedByAscending:(NSString*)beforeSort;
+(NSString*)sortedParamByAscending:(NSString*)beforeSort;

+ (NSString *)md5:(NSString *)str ;

+ (NSString *)md5Low:(NSString *)str; //小写

+ (NSString*)encodeBase64String:(NSString *)input;
+ (NSString*)decodeBase64String:(NSString *)input;
+ (NSString*)encodeBase64Data:(NSData *)data;
+ (NSString*)decodeBase64Data:(NSData *)data;


+(NSString *)TripleDES:(NSString *)plainText encryptOrDecrypt:(CCOperation)encryptOrDecrypt encryptOrDecryptKey:(NSString *)encryptOrDecryptKey;

+(NSString *)doEncryptStr:(NSString *)originalStr key:(NSString *)gkey;

/** 转换货币字符串 */
- (NSString *)getMoneyString;
// ios四舍五入的算法
+ (float)roundFloat:(float)price;

@end
