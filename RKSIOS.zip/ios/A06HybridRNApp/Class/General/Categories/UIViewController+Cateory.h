//
//  UIViewController+Cateory.h
//  A02_iPhone
//
//  Created by Robert on 04/08/2017.
//  Copyright © 2017 Robert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Cateory)
/**
 判断是否是当前页面
 
 @return BOOL, YES 当前页面正在显示，NO 当前页面不在显示
 */
- (BOOL)isCurrentViewControllerVisible;

/**
 获取当前屏幕显示的UIViewController
 
 @return 当前显示的controller
 */
+ (UIViewController * _Nullable)getCurrentShowController;

- (void)dismissToRootViewControllerAnimated:(BOOL)flag completion:(void (^ __nullable)(void))completion;

- (void)dismissToViewController:(Class _Nullable )viewController flag:(BOOL)flag completion:(void (^ __nullable)(void))completion;

- (void)setRootViewController:(UIViewController *_Nullable)rootViewController;
@end
