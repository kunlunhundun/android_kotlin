//
//  UIViewController+Cateory.m
//  A02_iPhone
//
//  Created by Robert on 04/08/2017.
//  Copyright © 2017 Robert. All rights reserved.
//

#import "UIViewController+Cateory.h"
#import <objc/runtime.h>

@implementation UIViewController (Cateory)

/**
 判断是否是当前页面
 
 @return BOOL, YES 当前页面正在显示，NO 当前页面不在显示
 */
- (BOOL)isCurrentViewControllerVisible {
    
    return (self.isViewLoaded && self.view.window);
}


/**
 获取当前屏幕显示的UIViewController
 
 @return 当前显示的controller
 */
+ (UIViewController * _Nullable)getCurrentShowController {
  
  UIViewController *result = nil;
  UIWindow * window = [[UIApplication sharedApplication] keyWindow];
  //app默认windowLevel是UIWindowLevelNormal，如果不是，找到它
  if (window.windowLevel != UIWindowLevelNormal) {
    NSArray *windows = [[UIApplication sharedApplication] windows];
    for(UIWindow * tmpWin in windows) {
      if (tmpWin.windowLevel == UIWindowLevelNormal) {
        window = tmpWin;
        break;
      }
    }
  }
  id nextResponder = nil;
  UIViewController *appRootVC = window.rootViewController;
  //1、通过present弹出VC，appRootVC.presentedViewController不为nil
  if (appRootVC.presentedViewController) {
    nextResponder = appRootVC.presentedViewController;
  }else{
    //2、通过navigationcontroller弹出VC
    NSLog(@"subviews == %@",[window subviews]);
    UIView *frontView = [[window subviews] objectAtIndex:0];
    nextResponder = [frontView nextResponder];
  }
  
  if ([nextResponder isKindOfClass:[UITabBarController class]]){//1、tabBarController
    UITabBarController * tabbar = (UITabBarController *)nextResponder;
    UINavigationController * nav = (UINavigationController *)tabbar.viewControllers[tabbar.selectedIndex];
    //或者 UINavigationController * nav = tabbar.selectedViewController;
    result = nav.childViewControllers.lastObject;
  }else if ([nextResponder isKindOfClass:[UINavigationController class]]){//2、navigationController
    UIViewController * nav = (UIViewController *)nextResponder;
    result = nav.childViewControllers.lastObject;
  }else{//3、viewControler
    result = nextResponder;
  }
  return result;
  
}


- (void)dismissToRootViewControllerAnimated:(BOOL)flag completion:(void (^ __nullable)(void))completion {
    UIViewController *parentVC = self.presentingViewController;
    UIViewController *bottomVC;
    while (parentVC) {
        bottomVC = parentVC;
        parentVC = parentVC.presentingViewController;
    }
    [bottomVC dismissViewControllerAnimated:YES completion:completion];
}

- (void)dismissToViewController:(Class)viewController flag:(BOOL)flag completion:(void (^ __nullable)(void))completion {
    UIViewController *parentVC = self.presentingViewController;
    if (!parentVC.presentingViewController) return;
    while (![parentVC isKindOfClass:viewController])  {
        parentVC = parentVC.presentingViewController;
    }
    [parentVC dismissViewControllerAnimated:flag completion:completion];
}

- (void)setRootViewController:(UIViewController * _Nullable)rootViewController {
    UIViewController *presentedViewController = [self traversePresentedViewControllerFrom:self.view.window.rootViewController];
    [self dismissPresentedViewController:presentedViewController completion:^{
        [self.view.window setRootViewController:rootViewController];
    }];
}

- (void)dismissPresentedViewController:(UIViewController * _Nullable)vc completion:(void(^)(void))block {
    
    if ([vc presentingViewController]) {
        __block UIViewController *nextVC = vc.presentingViewController;
        [vc dismissViewControllerAnimated:NO completion:^ {
            if ([nextVC presentingViewController]) {
                [self dismissPresentedViewController:nextVC completion:block];
            } else {
                if (block) {
                    block();
                }
            }
        }];
    } else {
        if (block != nil) {
            block();
        }
    }
}


- (UIViewController *)traversePresentedViewControllerFrom:(UIViewController* )startViewController {
    if ([startViewController isKindOfClass:[UINavigationController class]]) {
        return [self traversePresentedViewControllerFrom:[(UINavigationController *)startViewController topViewController]];
    }
    
    if ([startViewController isKindOfClass:[UITabBarController class]]) {
        return [self traversePresentedViewControllerFrom:[(UITabBarController *)startViewController selectedViewController]];
    }
    
    if (startViewController.presentedViewController == nil || startViewController.presentedViewController.isBeingDismissed) {
        return startViewController;
    }
    
    return [self traversePresentedViewControllerFrom:startViewController.presentedViewController];
}


@end
