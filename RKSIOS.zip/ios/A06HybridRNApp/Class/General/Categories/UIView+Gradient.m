//
//  UIView+Gradient.m
//  INTEDSGame
//
//  Created by bux on 2018/2/21.
//  Copyright © 2018年 INTECH. All rights reserved.
//

#import "UIView+Gradient.h"
#import <objc/runtime.h>



@implementation UIView (Gradient)


-(void)GradientWithVertical:(BOOL)isVertical startGdColor:(UIColor *)startGdColor endGdColor:(UIColor*)endGdColor{
  
  CAGradientLayer *gradientLayer = [CAGradientLayer layer];
  gradientLayer.colors = @[(__bridge id)startGdColor.CGColor, (__bridge id)endGdColor.CGColor];
  gradientLayer.locations = @[@0,  @1.0];
  if (isVertical) {
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(0.0, 1.0);
  }
  else{
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1.0, 0.0);
  }
  
  gradientLayer.frame = self.bounds;
  [self.layer addSublayer:gradientLayer];
 
}


-(void)gradientInBottomWithVertical:(BOOL)isVertical startGdColor:(UIColor *)startGdColor endGdColor:(UIColor*)endGdColor{
  
  if (self.gradientLayer) {
      [self.gradientLayer removeFromSuperlayer];
      self.gradientLayer = nil;
  }
  CAGradientLayer *gradientLayer = [CAGradientLayer layer];
  gradientLayer.colors = @[(__bridge id)startGdColor.CGColor, (__bridge id)endGdColor.CGColor];
  gradientLayer.locations = @[@0,  @1.0];
  if (isVertical) {
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(0.0, 1.0);
  }
  else{
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1.0, 0.0);
  }
  

  gradientLayer.frame = self.bounds;
  
  self.gradientLayer = gradientLayer;
  
  [self.layer insertSublayer:gradientLayer atIndex:0];
  
}


- (CAGradientLayer*)gradientLayer{
  
  return objc_getAssociatedObject(self, @selector(gradientLayer));
  
}

- (void)setGradientLayer:(CAGradientLayer *)layer{
  
  objc_setAssociatedObject(self, @selector(gradientLayer), layer, OBJC_ASSOCIATION_RETAIN);
}


+ (BOOL)isViewShowWithSuperView:(UIView *)superView targetView:(Class)targetView {
    for(UIView *subview in [superView subviews]){
        if([subview isKindOfClass:targetView]){
            return YES;
        }
    }
    return NO;
}



- (void)hideKeyBoard {
    for (UIWindow* window in [UIApplication sharedApplication].windows) {
        for (UIView* view in window.subviews) {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

- (BOOL)dismissAllKeyBoardInView:(UIView *)view {
    if([view isFirstResponder]) {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews) {
        if([self dismissAllKeyBoardInView:subView]) {
            return YES;
        }
    }
    return NO;
}
@end
