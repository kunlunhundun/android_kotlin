

#import "NativeInteraction.h"
#import "A06HybridRNApp-Swift.h"
#import "RCTRootView.h"
#import <SignCore/SignCore.h>


#define TestNativeJsonData @"{\"callback1\":\"123\",\"callback2\":\"asd\"}"

@implementation NativeInteraction
{
  RCTPromiseResolveBlock _resolveBlock;
  RCTPromiseRejectBlock _rejectBlock;
}
RCT_EXPORT_MODULE();

//RCT_EXPORT_METHOD(setUserInfo) {
//  NSLog(@"RN调用iOS");
//}

RCT_EXPORT_METHOD(setUserInfo:(NSString *)loginInfo) {
  // ManagerModel.instanse
  [[ManagerModel shareInstanse] setLoginUserInfo:loginInfo];
  NSLog(@"来自RN的数据：%@",loginInfo);
}

RCT_EXPORT_METHOD(setWelcomeInfo:(NSString *)welcomeInfo) {
  NSLog(@"来自RN的数据：%@",welcomeInfo);
  [[ManagerModel shareInstanse] setWelcomeInfo:welcomeInfo];
}

RCT_EXPORT_METHOD(openNative:(NSString *)methodName) {
  NSLog(@"来自RN的数据：%@",methodName);
  [[ManagerModel shareInstanse] openNative:methodName];
}

RCT_EXPORT_METHOD(finishPage) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [[ManagerModel shareInstanse] finishPage];
  });
}

RCT_EXPORT_METHOD(updateMessageCount) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [[ManagerModel shareInstanse] queryLetterMsg];
  });
}

RCT_EXPORT_METHOD(showNavigationBar:(BOOL) ishow) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [[ManagerModel shareInstanse] showHidenTabbar:ishow];
  });
}

RCT_EXPORT_METHOD(setAllowRotation:(BOOL) allowRotation) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [AppDelegate.sharedAppDelegate setRNAllowRotation:allowRotation];
  });
}

RCT_EXPORT_METHOD(setBanlanceInfo:(NSString *)balanceInfo) {
  NSLog(@"来自RN的数据：%@",balanceInfo);
}

RCT_EXPORT_METHOD(setCDNDomainName:(NSString *)cdnDomainName) {
  [[ManagerModel shareInstanse] setCdnDomainName:cdnDomainName];
}

RCT_EXPORT_METHOD(clearLoginStatus) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [[ManagerModel shareInstanse] clearLoginStatusByRN];
  });
}

RCT_EXPORT_METHOD(playGame:(NSString *)gameJson) {
  dispatch_async(dispatch_get_main_queue(), ^{
    [[ManagerModel shareInstanse] playGameForRN:gameJson];
  });
}

RCT_EXPORT_METHOD(dial:(NSString *)number) {
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *telNumber = [NSString stringWithFormat:@"tel://%@",number];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString: telNumber]];

  });
}

+ (void)removeRNPage {
  [ [ManagerModel shareInstanse].homePageVC.view.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    if ([obj isKindOfClass:[RCTRootView class]]) {
      [obj removeFromSuperview];
      return;
    }
  }];
}

RCT_EXPORT_METHOD(getGateway:(RCTResponseSenderBlock)callback) {
  NSString *gateways =  [ManagerModel getRNGateway];
  callback(@[gateways]);
}

RCT_REMAP_METHOD(getSign,src:(NSString *)src qid:(NSString*)qid keyEnum:(NSString*)keyEnum callBack:(RCTResponseSenderBlock)callback) {
  NSString *sign = [ManagerModel getSignWithSrc:src qid:qid keyEnum:keyEnum];
  callback(@[sign]);
}

//RCT_REMAP_METHOD(RNTransferIOSWithParameterAndCallBack, para1:(NSString *)para1 para2:(NSString *)para2 resolver:(RCTPromiseResolveBlock)resolver rejecter:(RCTPromiseRejectBlock)reject) {
//  NSLog(@"来自RN的数据：para1——%@， para2——%@",para1, para2);
//
//  _resolveBlock=resolver;
//  _rejectBlock=reject;
//  NSString *jsonString = TestNativeJsonData;
//  _resolveBlock(@[jsonString]);
//}

@end
