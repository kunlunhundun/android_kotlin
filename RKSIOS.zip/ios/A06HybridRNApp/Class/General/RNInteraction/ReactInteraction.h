

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface ReactInteraction : RCTEventEmitter <RCTBridgeModule>

+ (instancetype)shareInstance;

- (void)jumpToPage:(NSString *)rnRouter;
- (void)getGateway:(NSString*)gateway;
- (void)login;
- (void)logOut;
- (void)logoutLocal;
- (void)refreshData;
- (void)goToPromo:(NSString *)promoCode;

@end
