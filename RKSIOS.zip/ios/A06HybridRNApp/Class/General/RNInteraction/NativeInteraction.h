

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

@interface NativeInteraction : NSObject <RCTBridgeModule>

+ (void)removeRNPage;

@end
