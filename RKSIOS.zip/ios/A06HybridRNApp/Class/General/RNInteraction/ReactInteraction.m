

#import "ReactInteraction.h"

#define JumpToPage @"jumpToPage"
#define Login @"login"
#define LogOut @"logOut"
#define GetGateway @"getGateway"
#define LogoutLocal @"logoutLocal"
#define RefreshData @"refreshData"
#define GoToPromo @"goToPromo"


@implementation ReactInteraction
static ReactInteraction *instance = nil;

RCT_EXPORT_MODULE();
+ (instancetype)shareInstance {
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    instance = [[self alloc] init];
  });
  return instance;
}

- (NSArray<NSString *> *)supportedEvents{
   return @[JumpToPage,LogOut,GetGateway,LogoutLocal,RefreshData,GoToPromo];
}

RCT_EXPORT_METHOD(jumpToPage:(NSString *)rnRouter) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[JumpToPage, rnRouter]
                  completion:NULL];
}

RCT_EXPORT_METHOD(getGateway:(NSString *)gateway) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[GetGateway, gateway]
                  completion:NULL];
}
RCT_EXPORT_METHOD(login) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[Login,@""]
                  completion:NULL];
}
RCT_EXPORT_METHOD(logOut) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[LogOut,@""]
                  completion:NULL];
}

RCT_EXPORT_METHOD(logoutLocal) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[LogoutLocal,@""]
                  completion:NULL];
}

RCT_EXPORT_METHOD(refreshData) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[RefreshData,@""]
                  completion:NULL];
}

RCT_EXPORT_METHOD(goToPromo:(NSString *)promoCode) {
  [self.bridge enqueueJSCall:@"RCTDeviceEventEmitter"
                      method:@"emit"
                        args:@[GoToPromo,promoCode]
                  completion:NULL];
}

@end
