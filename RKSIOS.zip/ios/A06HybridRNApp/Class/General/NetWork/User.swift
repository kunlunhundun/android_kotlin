//
//  User.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import HandyJSON

class User: HandyJSON {
  
  var email: String?
  
  var userName: String?
  
  var userToken: String?
  
  required init() { }
  
  func mapping(mapper: HelpingMapper) {
    mapper <<<
      [
        self.email              <-- "mail",
        self.userName           <-- "userName",
        self.userToken          <-- "utoken"
    ]
  }
}

