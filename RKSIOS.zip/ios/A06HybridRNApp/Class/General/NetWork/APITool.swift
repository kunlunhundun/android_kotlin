//
//  APITool.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import Alamofire
import HandyJSON
import RxSwift
import XCGLogger
import SignCore

let TokenInvalid_ErrorCode      = "GW_890202"    // 无效访问凭证
let TokenExpired_ErrorCode      = "GW_890203"
let TokenForbid_ErrorCode       = "GW_890204"    // 访问凭证被禁止
let TokenNotMatch_ErrorCode     = "GW_890205"    // 凭证不匹配
let TokenFailure_ErrorCode      = "GW_890206"    // 凭证不匹配
let TokenBad_ErrorCode          = "GW_890201"
let SingleDeviceLogin_ErrorCode = "GW_890206"    // 单设备登陆
let GW_800406                   = "GW_800406"

class APITool {
  
 /*  var headers1: HTTPHeaders {
    get {
     // let client = UIDevice.systemVersion // 获取系统的版本号，在工具类中
      var result: [String: String] = ["pid": config_pid]
      result["appId"] = config_appId
      return result
    }
    set{
      _headers1 = newValue
      print("\(newValue)")
    }
  } */
  
  @objc class func singleDeviceLoginAccount(){
    
  }
  @objc class func tokenExpiredExitLogin(){
    
  }
}

extension APITool  {
  
  class func request<T: HandyJSON>(_ url: Router, method: HTTPMethod = .post, uploadData: Data? = nil, parameters: Parameters? ,successHandle:@escaping (_ responseModel: T)->(),failureHandle:@escaping(_ error:APIError?)->() ) {
   
      if let uploadData = uploadData {
      // upload(observer: observer, url: url, method: method, uploadData: uploadData, parameters: parameters, returnType: returnType)
      } else {
        
        requestData(url: url, parameters: parameters,  successHandle: { (resultModel:T) in
          successHandle(resultModel)
        }) { (apiError) in
          failureHandle(apiError)
        }
      }
  }
  

  fileprivate  class func requestData<T: HandyJSON>(url: Router, method: HTTPMethod = .post, parameters: Parameters!, successHandle:@escaping (_ responseModel: T)->(), failureHandle:@escaping(_ error:APIError?)->() ) {
    
    let paramJson = BaseJsonTool.dictionaryToString(parameters as [String : AnyObject])
    var preMd5Str = ""

    let qid = ManagerModel.creatUUID()
    
    let domainName = ManagerModel.getDomainNameInfo()
    let tempDeviceId = KeyChain.getKeychainIdentifierUUID()
    let deviceId:String = tempDeviceId ?? ""
    var token = ""
    if url.appendURL.contains("welcome") {
      preMd5Str = paramJson + qid + config_appId + DeviceTool.getAppVersion()  +  ReadChannelDomain.getParentId() + domainName + deviceId
    }else{
      token =  ManagerModel.instanse.token
      if token.count < 1 {
        token = ManagerModel.instanse.infoModel?.token ?? ""
      }
      preMd5Str = paramJson + qid + config_appId + DeviceTool.getAppVersion() + ReadChannelDomain.getParentId() + domainName + token + deviceId
    }
    let keyEnum = (EnviromentManager.currentEnvironment == .Local_Environment) ? "1" : "0"
    let finalMd5Str =  SignUtil.getSign(preMd5Str, qid: qid , keyEnum: keyEnum)
    
    var  headers: HTTPHeaders = ["pid":config_pid]
    headers["appId"] = config_appId
    headers["sign"] = finalMd5Str
    headers["qid"] = qid
    headers["v"] = DeviceTool.getAppVersion()
    headers["domainName"] = domainName
    headers["deviceId"] = deviceId
    headers["token"] = token
    headers["parentId"] = ReadChannelDomain.getParentId()
    headers["Content-Type"] = "application/json"
    //headers["productId"] = "A06"
    
    XCGLogger.debug("qid------>\(ManagerModel.instanse.qid)")
    XCGLogger.debug("preMd5Str------>\(preMd5Str)")
    XCGLogger.debug("finalMd5Str------>\(finalMd5Str)")

    let manager = Alamofire.SessionManager.default
    manager.session.configuration.timeoutIntervalForRequest = 20
    
    Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers).responseJSON(completionHandler: { response in
     
      switch response.result {
      case .success:
      
        // 服务器返回数据残缺
        guard let JSON = response.result.value,
          let jsonDic = JSON as? Dictionary<String, AnyObject> else {
            failureHandle(APIError.APIErrorWithErrorCode(error_msg:"服务器返回数据残缺"))
            return
        }
        print("responseJSON-->>>url--->\(url) ---->\(jsonDic)")
        var statusCode = ""
        var errMsg = ""
        let headDic = jsonDic["head"]
        if headDic is Dictionary<String, AnyObject> {
          statusCode = headDic?["errCode"] as? String ?? ""
          errMsg = headDic?["errMsg"] as? String ?? ""
        }
        if statusCode == "0000"{
          var bodyDic = jsonDic["body"] as? Dictionary<String, AnyObject>
          if bodyDic == nil {
             bodyDic = jsonDic
          }
          guard let resultModel = T.deserialize(from: NSDictionary(dictionary: bodyDic!)) else {
            failureHandle(APIError.APIErrorWithErrorCode(error_msg:"数据解析错误"))
            return
          }
          
          successHandle(resultModel)  // 数据解析成功
        }
          
        else{
          if url.appendURL.contains("countUnread"){
            return
          }
          if statusCode == SingleDeviceLogin_ErrorCode  {
            ManagerModel.singleDeviceLogout()
          }
          else if statusCode == TokenExpired_ErrorCode || statusCode == TokenInvalid_ErrorCode || statusCode == TokenNotMatch_ErrorCode || statusCode == TokenBad_ErrorCode {
            ManagerModel.tokenExpiredExitLogin()
          }
          else if statusCode == GW_800406{
            
            var bodyErrMsg:NSNumber = 0
            
            let body = jsonDic["body"] as! Dictionary<String, AnyObject>
            
            if body is Dictionary<String, AnyObject> {
              bodyErrMsg = body["restTryCount"] as! NSNumber
              let avgSpeedStr = "登录密码错误,您还有" + "\(bodyErrMsg)" + "次机会"
              failureHandle(APIError.APIErrorWithErrorCode(error_code: statusCode, error_msg: avgSpeedStr))
              return
            }
          }
          
          failureHandle(APIError.APIErrorWithErrorCode(error_code: statusCode, error_msg: errMsg))
          return
        }
        break

      case .failure(let error):
        
        failureHandle(APIError.APIErrorWithErrorCode(error_msg:"网络不稳定,请稍后再试"))
        break
      }
    })
  }
  

/* fileprivate  class func upload<T: HandyJSON>(url: Router, method: HTTPMethod = .post, uploadData: Data, parameters: Parameters?, returnType: T.Type ,successHandle:@escaping (_ responseModel: T)->(), failureHandle:@escaping(_ error:APIError?)->()  ) {
    Alamofire.upload(multipartFormData: { (data: MultipartFormData) in
    
      
      
      // Parameters
      if let parameters = parameters {
        for param in parameters {
          let value = (param.value as! String).data(using: .utf8)
          data.append(value!, withName: param.key)
        }
      }
      
      // uploadData
      data.append(uploadData, withName: "attachment", fileName: "attachment.jpg", mimeType: "image/jpg")
      
    },
      to: url, method: .post, headers: headers,encodingCompletion: { (result: SessionManager.MultipartFormDataEncodingResult) in
          switch result {
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response: DataResponse<Any>) in
    
                      //  self.successHandle(observer: observer, result: response.result, returnType: returnType)
                  })
                  break
                        
                  case .failure(let encodingError):
                     // self.failHandle(observer: observer, error: encodingError)
                      break
                }
          })
  
  } */
  

}


