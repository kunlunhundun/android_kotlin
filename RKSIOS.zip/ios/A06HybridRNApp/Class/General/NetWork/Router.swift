//
//  Router.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import Alamofire

/// 请求路由
enum Router: String, URLConvertible {
  
  case welcome = "/_glaxy_a06_/welcome"
  case upgradeApp =  "/_glaxy_a06_/upgrade"                       //检测版本更新
  case loginUserName = "/_glaxy_a06_/customer/login"                               //用户名登录
  case registUserName = "/_glaxy_a06_/customer/createRealAccount"                  //用户名注册
  case logout = "/_glaxy_a06_/customer/logout"                                     //用户退出
  case comeInGame =  "/_glaxy_a06_/game/inGame"                                    //进入游戏
  case goOutGame = "/_glaxy_a06_/game/outGame"                                     //退出游戏大厅
  case transferToGame = "/_glaxy_a06_/game/transferToGame"                         //转帐到游戏
  
  case autoLoginByToken = "/_glaxy_a06_/customer/getByToken"                       //自动登录
  case queryByKeyList = "/_glaxy_a06_/_extra_/a06/queryByKeyList"                  //个性化接口
  case getByLoginName = "/_glaxy_a06_/customer/getByLoginName"                     //根据token获取会员信息
  case queryPayWaysV3 = "/_glaxy_a06_/deposit/queryPayWaysV3"                      //查询存款方式的接口
  
  case queryAmountList = "/_glaxy_a06_/deposit/queryAmountList"                    //查询手动BQ和手动银行存款限额列表
  case queryOnlineBanks   = "/_glaxy_a06_/deposit/queryOnlineBanks"                //查询在线银行卡，在线支付，银行，扫码支付
  case queryBQBanks   =   "/_glaxy_a06_/deposit/queryBQBanks"                      //查询公司BQ可用的银行列表用于支付
  case createOnlineOrder =  "/_glaxy_a06_/deposit/createOnlineOrder"               //创建订单（网银在线 扫码支付 比特币支付）
  case queryManualBank =  "/_glaxy_a06_/deposit/queryRequestBanks"                 //查询手动银行存款卡列表
  case BQPayment =   "/_glaxy_a06_/deposit/BQPayment"                              //支付宝支付
  case createRequestBank  =  "/_glaxy_a06_/deposit/createRequest"                  //手动存款创建订单
  case queryPointCardList  =  "/_glaxy_a06_/deposit/queryPointCardList"            //查询点卡支付列表
  case queryBtcRateAndAddress =  "/_glaxy_a06_/deposit/queryBtcRateAndAddress"     //查询比特币汇率及存款地址
  case pointCardPayment  =  "/_glaxy_a06_/deposit/pointCardPayment"                //点卡支付
  case manualBtcPayment  =  "/_glaxy_a06_/deposit/btcPayment"                      //btc支付

  case queryDepositTrans =  "/_glaxy_a06_/deposit/findTranById"                    //存款交易记录查询
  case queryPointCardPayResult  =  "/_glaxy_a06_/deposit/queryPointCardPayResult"  //点卡交易记录查询
  case transactionRemain = "/_glaxy_a06_/message/remain"                           //催单
  
  case getBalance =  "/_glaxy_a06_/customer/getBalance"                            //获取会员额度
  case queryBankAndBit = "/_glaxy_a06_/account/query"                              //银行卡，比特币查询
  case queryBtcRate  = "/_glaxy_a06_/withdraw/queryBtcRate"                        //获取比特币汇率
  case createRequest = "/_glaxy_a06_/withdraw/createRequest"                       //创建取款提案
  case xmCalcAmountV2 = "/_glaxy_a06_/xm/calcAmountV2"                             //查询洗码
  case xmCreateRequest = "/_glaxy_a06_/xm/createRequest"                           //创建洗码提案
  case callBackPhone  =  "/_glaxy_a06_/callback"                                   //消息中心电话回访
  case liveChatAddress  =  "/_glaxy_a06_/liveChatAddress"                          //消息中心电话回访
  case queryLetter = "/_glaxy_a06_/letter/countUnread"                             //站内消息查询query
  case getByCardBin = "/_glaxy_a06_/getByCardBin"                                  //根据银行卡信息获取银行类型(银行名，信用卡）

  case queryDomainList = "/_glaxy_a06_/deposit/queryDomainList"                    //查询支付列表接口
  
  // http://www.pt-gateway.com/_glaxy_a03_/welcome
  static var baseURL: String {
    get {
      return EnviromentManager.gatewayAddressRequet_domain
    }
  }
  
  var appendURL: String {
    get {
      return rawValue
    }
  }
  
  func asURL() throws -> URL {
    // let nowTimeInterval = Int64(NSDate().timeIntervalSince1970)
    let urlString = Router.baseURL.appending(appendURL)
    print("urlString------>\(urlString)")
    return URL(string: urlString)!
  }
}

