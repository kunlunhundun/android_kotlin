//
//  NetWorkEnvironmentConfig.swift
//  A06HybridRNApp
//
//  Created by kunlun on 14/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit
import Alamofire
import XCGLogger

let Config_APIEnvironmentSwitch:Int = PackageConfig.packageEnvirmentType()    //0:本地  1:运测  2:运营

let Config_DefaultDevelopmentGatewaysAddr     = "http://m.a06n.com"   //"http://www.pt-gateway.com"   // 本地 "http://m.a06n.com" //
let Config_DefaultGrayDevelopmentGatewaysAddr = "http://m3.ksbet168.net"      // 运测
let Config_DefaultPublishGatewaysAddr         = "https://m.ks0990.com"        // 运营

let Development_GatewayAddress     = "Development_GatewayAddress"             // 本地
let GrayDevelopment_GatewayAddress = "GrayDevelopment_GatewayAddress"         // 运测
let Publish_GatewayAddress         = "Publish_GatewayAddress"                 // 运营
let NetworkEnvironment_key         = "NetworkEnvironment_key"                 // 保存本地环境的key用于调试

enum APIEnvironment:Int {
  case Local_Environment    = 0 // 本地
  case Gray_Environment     = 1 // 运测
  case Publish_Environment  = 2 // 运营
}

let EnviromentManager = NetWorkEnvironmentConfig.shareInstance()

class NetWorkEnvironmentConfig: NSObject {
  
  static let instance = NetWorkEnvironmentConfig()
  var environmentName = ""
  var domainName = ""
  @objc var netWorkState:Bool = true
  @objc var gatewayAddressRequet_domain:String = ""
  @objc var heartPacket_socket_ip:String = "202.83.195.101"
  @objc var heartPacket_socket_port:Int = 28721
  
  var currentEnvironment:APIEnvironment = .Publish_Environment
  var networkReachabilitManager:NetworkReachabilityManager?
  
 @objc  class func shareInstance() -> NetWorkEnvironmentConfig {
    return instance
 }
  
  override  init(){
    super.init()
    
    // 0:本地 1:运测 2:运营
    switch Config_APIEnvironmentSwitch {
    case 0:
  
      currentEnvironment = .Local_Environment
      readEnvironmentWithApiEnvironment(apienvironment: currentEnvironment)
      
      break
    case 1:
    
      currentEnvironment = .Gray_Environment
      readEnvironmentWithApiEnvironment(apienvironment: currentEnvironment )
      
      break
    case 2:
    
        currentEnvironment = .Publish_Environment
        readEnvironmentWithApiEnvironment(apienvironment: currentEnvironment)
      
      break
    default:
      break
    }
  }

  
  func readEnvironmentWithApiEnvironment(apienvironment:APIEnvironment,netWorkAddress:String = ""){
    
    switch apienvironment {
    case .Local_Environment:
      environmentName = "本地环境"
      var gatewayAddr = ""
      if netWorkAddress.count > 1 {
        gatewayAddr = netWorkAddress
      }
      if gatewayAddr.count < 1 {
         gatewayAddr = Config_DefaultDevelopmentGatewaysAddr
      }
      gatewayAddressRequet_domain = gatewayAddr
      domainName = gatewayAddr.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "")
      ManagerModel.instanse.domainName = domainName
      ManagerModel.instanse.fastCdnDomainName = gatewayAddressRequet_domain
      break
      
    case .Gray_Environment:
      environmentName = "运测环境"
      var gatewayAddr = ""
      if netWorkAddress.count > 1 {
        gatewayAddr = netWorkAddress
      }
      if gatewayAddr.count < 1 {
         gatewayAddr = Config_DefaultGrayDevelopmentGatewaysAddr
      }
      gatewayAddressRequet_domain = gatewayAddr
      domainName = gatewayAddr.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "")
      ManagerModel.instanse.domainName = domainName
      ManagerModel.instanse.fastCdnDomainName = gatewayAddressRequet_domain
      
      heartPacket_socket_ip = "115.84.241.212"
      heartPacket_socket_port = 8090
      break
      
    case .Publish_Environment:
      environmentName = "运营环境"
      var gatewayAddr = ""
      if netWorkAddress.count > 1 {
        gatewayAddr = netWorkAddress
      }
      if gatewayAddr.count < 1 {
        gatewayAddr = Config_DefaultPublishGatewaysAddr
      }
      gatewayAddressRequet_domain = gatewayAddr
      domainName = gatewayAddr.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "")
      ManagerModel.instanse.domainName = domainName
      ManagerModel.instanse.fastCdnDomainName = gatewayAddressRequet_domain
      heartPacket_socket_ip = "202.83.195.101"
      heartPacket_socket_port = 28721
      break
    }
    print("=============================================================================当前环境"+environmentName)
  }
  
  
  func readGatewayAddress() -> String {
    var gatewayAddr = ""
    
    if Config_APIEnvironmentSwitch > 0 {
      gatewayAddr = UserDefaultsExtend.readUserDeftalusStringKey(key: Development_GatewayAddress)
      if gatewayAddr.count < 1 {
        gatewayAddr = Config_DefaultDevelopmentGatewaysAddr
      }
    }
    else{
      gatewayAddr = UserDefaultsExtend.readUserDeftalusStringKey(key: Publish_GatewayAddress)
      if gatewayAddr.count < 1 {
        gatewayAddr = Config_DefaultPublishGatewaysAddr
      }
    }
    return gatewayAddr
  }
  
  func saveGatewayAddress(gatewayAddress:String) {
    
    UserDefaultsExtend.writeUserDefaultsWithKey(key: Publish_GatewayAddress, value:gatewayAddress)
    gatewayAddressRequet_domain = gatewayAddress
    domainName = gatewayAddress.replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "http://", with: "")
    ManagerModel.instanse.domainName = domainName
  }
}

// MARK:网络的监测
extension NetWorkEnvironmentConfig {
  func startNetworkReachabilityObserver() {
    networkReachabilitManager?.listener = { [weak self]  status in
      if self?.networkReachabilitManager?.isReachable != nil {
        switch status {
        case .notReachable:
          EnviromentManager.netWorkState = false
          XCGLogger.debug("notReachable")   // 不可用的网络(未连接)
          ProgressTopPopView.showPopView(content: "未连接网络,请检查网络设置", popStyle: .errorMsgToast)
          break
        case .unknown:
          EnviromentManager.netWorkState = true
          XCGLogger.debug("unknown")        // 未识别的网络
          break
        case .reachable(.ethernetOrWiFi):
          EnviromentManager.netWorkState = true
          XCGLogger.debug("ethernetOrWiFi") // wifi网络
          break
        case .reachable(.wwan):
          EnviromentManager.netWorkState = true
          XCGLogger.debug("wwan")           //"2G,3G,4G...的网络"
          break
        }
      }
    }
  }
}


