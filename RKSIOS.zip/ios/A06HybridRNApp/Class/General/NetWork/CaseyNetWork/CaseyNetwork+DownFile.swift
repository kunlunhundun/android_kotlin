//
//  CaseyNetwork+DownFile.swift
//  CaseyNetWork
//
//  Created by Casey on 17/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit

extension CaseyNetwork  {
    
    
}


