//
//  APIError.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

let GW_800102 = "GW_800102"
let GW_800103 = "GW_800103"
let WS_300020 = "WS_300020"
let GW_800505 = "GW_800505"
let GW_890402 = "GW_890402"
let GW_890405 = "GW_890405"
let GW_890206 = "GW_890206"
let GW_880102 = "GW_880102"
let GW_890209 = "GW_890209"
let GW_999999 = "GW_999999"
let WS_300027 = "WS_300027"
let GW_890205 = "GW_890205"
let WS_300021 = "WS_300021"
let GW_800211 = "GW_800211"
let GW_800203 = "GW_800203"
let WS_300002 = "WS_300002"
let WS_300022 = "WS_300022"
let WS_201723 = "GW_201723"
let WS_201722 = "GW_201722"
let GW_800605 = "GW_800605"
let GW_800601 = "GW_800601"

class APIError: Error {

  var kl_code : String?
  var kl_tips : String?
  
  class func APIErrorWithErrorCode(error_code:String? = nil, error_msg:String?) -> APIError {
    let apiError =  APIError()
    var errorMsg:String? = error_msg
    if error_code == GW_800102 {
      errorMsg = "图型验证吗不正确"
    }else if error_code == GW_800103 {
      errorMsg = "图型验证吗不正确"
    }else if error_code == WS_300020 {
      errorMsg = "短信验证码不正确"
    }else if error_code == GW_800505 {
      errorMsg = "该账号未绑定安全手机,为保障安全,请联系客服找回密码"
    }else if error_code == GW_890402 {
      errorMsg = "用户名不存在"
    }else if error_code == GW_890405 {
      errorMsg = "您的账号已登出,如有疑问请联系客服"
    }else if error_code == GW_890206 {
      errorMsg = "您的账号正在其他地方登陆,您被迫退出,如非本人操作请立即联系客服"
    }else if error_code == GW_880102 {
      errorMsg = "您长时间未操作,请重新登陆"
    }else if error_code == GW_890209 {
      errorMsg = "您长时间未操作,请重新登陆"
    }else if error_code == GW_999999 {
      errorMsg = "系统繁忙,请稍后再试"
    }else if error_code == WS_300027 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == GW_890205 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == WS_300021 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == GW_800211 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == GW_800203 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == WS_300002 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == WS_300022 {
      errorMsg = "短信验证吗不正确"
    }else if error_code == WS_201723 {
      errorMsg = "您的操作太频繁,请稍后再试"
    }else if error_code == WS_201722 {
      errorMsg = "该手机号的操作次数太频繁,请明天再试"
    }else if error_code == GW_800605 {
      errorMsg = "网络不稳定,请刷新或选择其他游戏"
    }else if error_code == GW_800601 {
      errorMsg = "网络不稳定,请刷新或选择其他游戏"
    }
    
    apiError.kl_code = error_code
    apiError.kl_tips = errorMsg
    return apiError
  }
}


