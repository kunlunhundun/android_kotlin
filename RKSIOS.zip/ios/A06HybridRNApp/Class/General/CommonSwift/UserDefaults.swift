//
//  UserDefault.swift
//  A06HybridRNApp
//
//  Created by kunlun on 14/01/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class UserDefaultsExtend: NSObject {

  
  class func readUserDeftalusStringKey(key:String?) ->String {
    
    var value = ""
    if key == nil || key?.count == 0 {
      return value
    }
    value = UserDefaults.standard.object(forKey: key!) as? String ?? ""
    return value
  
  }
  
  class  func writeUserDefaultsWithKey(key:String,value:String){
    
    var curValue = value
    if key == nil || key.count == 0 {
      curValue = value
    }
    UserDefaults.standard.setValue(curValue, forKey: key)
    UserDefaults.standard.synchronize()
    
  }
  
  class func readUserDefaultsIntegerKey(key:String?) -> Int {
    var value = 0
    if key == nil || key?.count == 0 {
      return value
    }
    value = UserDefaults.standard.object(forKey: key!) as? Int ?? 0
    return value
  }
  
 class func writeUserDefaultIntegerWithKey(key:String,value:Int){
    var curValue = value
    if key == nil || key.count == 0 {
      curValue = value
    }
    UserDefaults.standard.setValue(curValue, forKey: key)
    UserDefaults.standard.synchronize()
  }
  
  class func removeAnyObjectWithKey(key:String?) {
    
    if key == nil || key?.count == 0 {
      return
    }
    UserDefaults.standard.removeObject(forKey: key!)
    UserDefaults.standard.synchronize()
    
  }
  
}
