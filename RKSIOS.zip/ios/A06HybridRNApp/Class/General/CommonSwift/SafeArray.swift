//
//  SafeArray.swift
//  A06HybridRNApp
//
//  Created by kunlun on 23/11/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

extension Array {
  subscript (safe index: Int) -> Element? {
    return (0..<count).contains(index) ? self[index] : nil
  }
}
