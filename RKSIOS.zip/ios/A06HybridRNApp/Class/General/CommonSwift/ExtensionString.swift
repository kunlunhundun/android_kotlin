//
//  ExpendString.swift
//  A06HybridRNApp
//
//  Created by kunlun on 20/12/2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

import UIKit

extension String {

  
    func anyToString(value:Any) ->String? {
      
      let strValue = value as? String
      if strValue != nil {
        return strValue!
      }
      
      let intValue = value as? Int
      if intValue != nil {
        return "\(intValue!)"
      }
      let doubleValue = value as? Double
      if doubleValue != nil {
        return "\(doubleValue!)"
      }
      return nil
    }
  
   func toIntValue() -> Int64!{
    if self.count < 1 {
      return 0
    }
    var tempValue = Int64(self)
    
    if tempValue != nil {
      return tempValue
    }
    let floatValue = Double(self)
    if floatValue != nil {
       tempValue = Int64(floatValue!)
      if tempValue == nil {
        return 0
      }
      return tempValue
    }
    
    return 0
  }
  
  func toDoubleValue() -> Double {
    
    if self.count < 1 {
      return 0.0;
    }
    let floatValue = Double(self)
    if floatValue != nil {
      return floatValue!
    }
    let tempValue = Int64(self)
    if tempValue != nil {
       let doValue = Double(tempValue!)
      return doValue
    }
    return 0.0
  }
  
  
  func testString(){
    
    let text = "nihaopiaoliangdemalaimeizi"
    
    let prefixMaxText = text.prefix(text.count-2)
    let sufixMaxText = text.suffix(5)
    let prefixIndex = text.prefix(upTo: text.endIndex)
    
  //  nameTextField?.text = prefixText  + "·"
    let index = text.index(text.endIndex, offsetBy: -2)
    let lastStr = text[index..<text.endIndex]
    let last2Charater = lastStr.first
    
    let suffixIndexText = text.suffix(from: index)
    let prfixIndexText = text.prefix(upTo: index)
    
    let normalIndex = text.index(text.startIndex, offsetBy: 3)
    let normalText = text[normalIndex]
    
    if last2Charater == nil {
      return
    }
    
  }
  
  
  
}
