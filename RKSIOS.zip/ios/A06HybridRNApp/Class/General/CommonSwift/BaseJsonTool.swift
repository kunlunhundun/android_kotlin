//
//  BaseJsonTool.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/6.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

class BaseJsonTool: NSObject {

   class func stringToDictionary(_ jsonString : String) -> [String : AnyObject] {
    var dict = [String : AnyObject]()
    
    let jsonData = jsonString.data(using: String.Encoding.utf8)
    
    do{
      let dictTry = try JSONSerialization.jsonObject(with: jsonData!, options: JSONSerialization.ReadingOptions.mutableContainers)
      if let d = dictTry as? [String : AnyObject] {
        dict = d
      }
    }catch{
      //// XCGLogger.debug(closure: "-------DictToString--->解析失败")
    }
    
    return dict
  }
  
  class func dictionaryToString(_ dict:[String : AnyObject]) -> String {
    
    var jsonData : NSData?
    var jsonStr  : String = ""
    do{
      if #available(iOS 11.0, *) {
        jsonData = try JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.sortedKeys) as NSData
        if jsonData == nil{
          jsonData = NSData()
        }
        let originStr = String(data: jsonData! as Data, encoding: String.Encoding.utf8) ?? ""
        jsonStr = originStr
        jsonStr = originStr.replacingOccurrences(of: " ", with: "")
        jsonStr = jsonStr.replacingOccurrences(of: "\n", with: "")

      } else {
         jsonData = try JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions.prettyPrinted) as NSData

        if jsonData == nil{
          jsonData = NSData()
        }
        let originStr = String(data: jsonData! as Data, encoding: String.Encoding.utf8) ?? ""
        jsonStr = originStr.replacingOccurrences(of: " ", with: "")
        jsonStr = jsonStr.replacingOccurrences(of: "\n", with: "")
      }
     
    }catch{
      // XCGLogger.debug(closure: "-------dictionaryToString--->解析失败")
    }
    return jsonStr
  }
  

 class  func base64Encoding(plainString:String)->String{
       let plainData = plainString.data(using: String.Encoding.utf8)
       let base64String = plainData?.base64EncodedString(options: NSData.Base64EncodingOptions.init(rawValue: 0))
       return base64String!
    }

  
 class func  base64Decoding(encodedString:String)->String{
    let decodedData = NSData(base64Encoded: encodedString, options: NSData.Base64DecodingOptions.init(rawValue: 0))
    let decodedString = NSString(data: decodedData! as Data, encoding: String.Encoding.utf8.rawValue)! as String
    return decodedString
 }
 
  

  

}
