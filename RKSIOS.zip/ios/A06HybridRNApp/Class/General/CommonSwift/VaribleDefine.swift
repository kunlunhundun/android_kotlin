//
//  VaribleDefine.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/5.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit
import Foundation

let SCREEN_WIDTH = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height

let SCREEN_MAX_LENGTH  = max(SCREEN_WIDTH, SCREEN_HEIGHT)
let IS_IPHONE_4_OR_LESS = SCREEN_MAX_LENGTH < 568.0
let IS_IPHONE_5 = SCREEN_MAX_LENGTH == 568.0
let IS_IPHONE_6 = SCREEN_MAX_LENGTH == 667.0
let IS_IPHONE_6P = SCREEN_MAX_LENGTH == 736.0
let IS_IPHONE_X = SCREEN_MAX_LENGTH >= 812.0
let IS_IPHONE_SMALL = SCREEN_WIDTH == 320

let STATUS_NAV_BAR_Y:CGFloat = IS_IPHONE_X == true ? 88.0 : 64.0
let TABBAR_HEIGHT:CGFloat = IS_IPHONE_X == true ? 83.0 : 49.0
let STATUSBAR_HEIGHT:CGFloat = IS_IPHONE_X == true ? 44.0 : 20.0
let BOTTOM_MARGIN:CGFloat = IS_IPHONE_X == true ? 30 : 15

let View_Margin = 15

let STATUS_NAV_BAR_Y_KEFU:CGFloat = IS_IPHONE_X == true ? 44.0 : 20.0


/*
 * 颜色
 */
let TINT_COLOR = UIColor(red: 164.0/255, green: 0.0/255, blue: 0.0/255, alpha: 1.0)
let TABBAR_TINT_COLOR = UIColor(red: 237.0/255, green: 31.0/255, blue: 59.0/255, alpha: 1.0)
let MAIN_WHITE_COLOR = UIColor(red: 242.0/255, green: 242.0/255, blue: 242.0/255, alpha: 1.0)
let LABEL_TEXT_COLOR = UIColor.gray
let INVEST_PERSON = UIColor(red: 34.0/255, green: 160.0/255, blue: 43.0/255, alpha: 1.0)
let INVEST_COM = UIColor(red: 237.0/255, green: 31.0/255, blue: 59.0/255, alpha: 1.0)
let INVEST_NEW = UIColor(red: 253.0/255, green: 143.0/255, blue: 27.0/255, alpha: 1.0)
let BTN_BACK_COLOR = UIColor(red: 18.0/255, green: 147.0/255, blue: 255.0/255, alpha: 1.0)
let LABEL_BLACK_COLOR = UIColor(red: 30.0/255, green: 30.0/255, blue: 30.0/255, alpha: 1.0)

//#141723 100%

let fontSegSemiBold16:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 16)
let fontSegSemiBold20:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 20)
let fontSegSemiBold28:UIFont? = UIFont.init(name: "PingFangSC-Semibold", size: 28)

let fontpfl12:UIFont? = UIFont.init(name: "PingFangSC-Light", size: 12)
let fontpfl14:UIFont? = UIFont.init(name: "PingFangSC-Light", size: 14)
let fontpfr14:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 14)
let fontpfr15:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 15)
let fontpfr16:UIFont? = UIFont.init(name: "PingFangSC-Regular", size: 16)
let fontpfm16:UIFont? = UIFont.init(name: "PingFangSC-Medium", size: 16)

let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height

let color2a2e32 = UIColor.init(hex: 0x2A2E32)
let color292d30 = UIColor.init(hex: 0x292D30)
let color2c2e38 = UIColor.init(hex: 0x2C2E38)
let color888888 = UIColor.init(hex: 0x888888)
let color333333 = UIColor.init(hex: 0x333333)
let colorc0c0c0 = UIColor.init(hex: 0xc0c0c0)
let color2e3337 = UIColor.init(hex: 0x2E3337)

let config_appId = "A06DS02"
let config_pid = "A06"
let config_DefaultKey0 = "eac8ff4a800d2864ba2acbb74007388e635b07d"
let config_PublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSu2AZPdT2Fqpqxctx3EbnRuuYdBxFZDYG7MASIgw/DFl3P9FAp7S9WaQjdM1NmgBDgvfUWx1xj72LNz4EP4Euh9EESKceNCeoE4M8ZP4ENUQX0nDMbpmIG3/JCI8B5Iv2FKj2q0gGbE0WsLdrYDzFXTYbZKRJSbMMjHT3HtKD/wIDAQAB"


