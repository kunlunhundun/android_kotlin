//
//  UIResponseSearchViewCtr.swift
//  PersonReport
//
//  Created by Casey on 10/11/2018.
//  Copyright © 2018 Casey. All rights reserved.
//

import UIKit


extension UIResponder {
    
    
    func nearViewController() -> UIViewController? {
        
        if  self.isKind(of: UIViewController.classForCoder()) {
            
            return self as? UIViewController
            
        }else {
            
            if let response = self.next {
                
                return response.nearViewController()
                
            }else {
                
                return nil
            }
        }
    }
    
    func nearViewController(_ targert:AnyClass) -> UIViewController? {
        
        if  self.isKind(of: targert) {
            
            return self as? UIViewController
            
        }else {
            
            if let response = self.next {
                
                return response.nearViewController(targert)
                
            }else {
                
                return nil
            }
        }
        
    }
    
    // 获取最近的导航条
    func nearNav() -> UINavigationController? {
        
        if  self.isKind(of: UINavigationController.classForCoder()) {
            
            return self as? UINavigationController
            
        }else {
            
            if let response = self.next {
                
                return response.nearNav()
                
            }else {
                
                return nil
            }
        }
        
    }
}
