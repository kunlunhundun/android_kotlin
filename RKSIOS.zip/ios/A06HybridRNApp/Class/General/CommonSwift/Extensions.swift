//
//  Extensions.swift
//  A06App
//
//  Created by bux on 2018/11/6.
//  Copyright © 2018 James. All rights reserved.
//

import Foundation
import UIKit

extension UILabel{
  convenience init(color:UIColor,font:UIFont?){
    self.init()
    self.textColor = color
    self.font = font
    
  }
}

extension UIColor{
  convenience init(red: Int, green: Int, blue: Int) {
    self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
  }
  convenience init(hex:Int) {
    self.init(red:(hex >> 16) & 0xff, green:(hex >> 8) & 0xff, blue:hex & 0xff)
  }
}

extension UIImageView {
  convenience init(named name: String) {
    guard let image = UIImage(named: name) else {
      self.init()
      return
    }
    
    self.init(image: image)
  }
  convenience init?(named name: String, contentMode: UIViewContentMode = .scaleToFill) {
    guard let image = UIImage(named: name) else {
      return nil
    }
    
    self.init(image: image)
    self.contentMode = contentMode
  }
}

extension UIImage {
  
  open class func maskWithColor(color: UIColor) -> UIImage? {
    let img = UIImage.init()
    let maskImage = img.cgImage!
    
    let width = 1
    let height = 1
    let bounds = CGRect(x: 0, y: 0, width: width, height: height)
    
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
    let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
    
    context.clip(to: bounds, mask: maskImage)
    context.setFillColor(color.cgColor)
    context.fill(bounds)
    
    if let cgImage = context.makeImage() {
      let coloredImage = UIImage(cgImage: cgImage)
      return coloredImage
    } else {
      return nil
    }
  }
  
}

extension UITextField {
  func setAppPlaceholder(text:String!) {
    let attriStr = NSMutableAttributedString(string: text)
    attriStr.addAttribute(NSAttributedStringKey.foregroundColor, value: colorc0c0c0, range: NSRange(location: 0, length: text.count))
    attriStr.addAttribute(NSAttributedStringKey.font, value: UIFont.init(name: "PingFangSC-Light", size: 14)!, range: NSRange(location: 0, length: text.count))
    self.attributedPlaceholder = attriStr
  }
}
