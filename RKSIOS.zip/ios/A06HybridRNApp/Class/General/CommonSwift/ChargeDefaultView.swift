//
//  ChargeDefaultView.swift
//  A06HybridRNApp
//
//  Created by hopper on 01/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

import UIKit

class ChargeDefaultView: UIView {

  var iconView:UIView = UIView()
  var nameView:UIView = UIView()
  var typeView:UIView = UIView()
  var tomttomView:UIView = UIView()
}

extension ChargeDefaultView {
  
  func layoutUI() {
    self.addSubview(iconView)
    self.addSubview(nameView)
    self.addSubview(typeView)
    self.addSubview(tomttomView)
    
    self.iconView.backgroundColor = color2e3337
    self.iconView.layer.cornerRadius = 25
    self.nameView.backgroundColor = color2e3337
    self.nameView.layer.cornerRadius = 3
    self.typeView.backgroundColor = color2e3337
    self.typeView.layer.cornerRadius = 3
    self.tomttomView.backgroundColor = color2e3337
    self.tomttomView.layer.cornerRadius = 6
    
    iconView.snp.makeConstraints { (make) in
      make.top.equalToSuperview().offset(10)
      make.left.equalToSuperview().offset(10)
      make.width.equalTo(50)
      make.height.equalTo(50)
    }
    nameView.snp.makeConstraints { (make) in
      make.centerY.equalTo(iconView.snp.centerY)
      make.left.equalTo(iconView.snp.right).offset(15)
      make.width.equalTo(200)
      make.height.equalTo(25)
    }
    typeView.snp.makeConstraints { (make) in
      make.top.equalTo(iconView.snp.bottom).offset(10)
      make.left.equalToSuperview().offset(10)
      make.width.equalTo(200)
      make.height.equalTo(25)
    }
    tomttomView.snp.makeConstraints { (make) in
      make.bottom.equalToSuperview().offset(-150)
      make.left.equalTo(20)
      make.right.equalTo(-20)
      make.height.equalTo(50)
    }
    
    let a = 5;
    for i in 0 ..< a {
      let view:UIView = UIView()
      view.backgroundColor = color2e3337
      view.layer.cornerRadius = 3
      view.frame = CGRect(x: 15 + (10+50)*i, y: 150, width: 50, height: 50)
      self.addSubview(view)
    }
    
    let b = 4;
    for i in 0 ..< b {
      let view:UIView = UIView()
      view.backgroundColor = color2e3337
      view.layer.cornerRadius = 3
      view.frame = CGRect(x: 15 + (10+50)*i, y: 220, width: 50, height: 50)
      self.addSubview(view)
    }
  }
}

