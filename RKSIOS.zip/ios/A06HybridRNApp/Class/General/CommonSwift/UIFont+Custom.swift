//
//  UIFont+Custom.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/7.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

extension UIFont {

  @objc static var S_Font:UIFont{get{return UIFont.systemFont(ofSize: 12)}}
  @objc static var M_Font:UIFont{get{return UIFont.systemFont(ofSize: 14)}}
  @objc static var L_Font:UIFont{get{return UIFont.systemFont(ofSize: 16)}}
  @objc static var XL_Font:UIFont{get{return UIFont.systemFont(ofSize: 18)}}
  @objc static var SF20_Font:UIFont{get{return UIFont.systemFont(ofSize: 20)}}
  @objc static var SF24_Font:UIFont{get{return UIFont.systemFont(ofSize: 24)}}

  @objc static var SF28_Font:UIFont{get{return UIFont.systemFont(ofSize: 28)}}

  
  @objc static var DBS_Font:UIFont{get{return UIFont.init(name: "DINAlternate-Bold", size: 12) ?? S_Font }}
  @objc static var DBM_Font:UIFont{get{return UIFont.init(name: "DINAlternate-Bold", size: 14) ?? M_Font }}

  
  @objc static var PFMM_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 14) ?? M_Font }}
  @objc static var PFML_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 16) ?? M_Font }}
  @objc static var PFMXL_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 18) ?? M_Font }}
  @objc static var PFM20_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 20) ?? M_Font }}
  @objc static var PFM24_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 24) ?? M_Font }}
  @objc static var PFM28_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 28) ?? M_Font }}
  @objc static var PFM30_Font:UIFont{get{return UIFont.init(name: "PingFangSC-Medium", size: 30) ?? M_Font }}

  
  static func PingFangSCMedium(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "PingFangSC-Medium", size: ofSize) ?? UIFont.systemFont(ofSize:ofSize)
  }
  
  static func PingFangSCRegular(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "PingFangSC-Regular", size: ofSize) ?? UIFont.systemFont(ofSize:ofSize)
  }
  
  static func PingFangSCLight(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "PingFangSC-Light", size: ofSize) ?? UIFont.systemFont(ofSize:ofSize)
  }
  
  static func PingFangSCSemibold(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "PingFangSC-Semibold", size: ofSize) ?? UIFont.boldSystemFont(ofSize:ofSize)
  }
  
  
  static func SegoeUISemibold(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "SegoeUI-Semibold", size: ofSize) ?? UIFont.boldSystemFont(ofSize:ofSize)
  }
  
  static func SegoeUI(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "SegoeUI", size: ofSize) ?? UIFont.systemFont(ofSize:ofSize)
  }
  
  static func SFProDisplayRegular(ofSize:CGFloat) -> UIFont {
    return UIFont.init(name: "SFProDisplay-Regular", size: ofSize) ?? UIFont.systemFont(ofSize:ofSize)
  }
  
 
  
}
