//
//  UIColor+Custom.swift
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/7.
//  Copyright © 2018年 Facebook. All rights reserved.
//

import UIKit

extension UIColor {

  convenience  init( colorValue : Int) {
    let r = CGFloat((colorValue & 0xFF0000) >> 16)
    let g = CGFloat((colorValue & 0xFF00) >> 8)
    let b = CGFloat(colorValue & 0xFF)
    self.init(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: CGFloat(1.0))
  }
  convenience init(R:Int,G:Int,B:Int,A:Float)
  {
    let r = CGFloat(R)/255.0
    let g = CGFloat(G)/255.0
    let b = CGFloat(B)/255.0
    let a = CGFloat(A)
    self.init(red: r, green: g, blue: b, alpha: a)
  }
  @objc static var view_backBlack: UIColor { get { return UIColor(colorValue: 0x141723) } }
  @objc static var view_white: UIColor { get { return UIColor(colorValue: 0xffffff) } }
  @objc static var view_lineColor: UIColor { get { return UIColor(colorValue: 0x32373B) } }  //0x292D30 32373B
  @objc static var view_popBlackColor: UIColor { get { return UIColor(colorValue: 0x1F2337) } }
  @objc static var font_lightWhiteColor: UIColor { get { return UIColor(colorValue: 0x999999) } }
  @objc static var font_littleWhiteColor: UIColor { get { return UIColor(colorValue: 0xcdcdcd) } }

  @objc static var font_lightBlackWhiteColor: UIColor { get { return UIColor(colorValue: 0x888888) } }

  @objc static var line_lightBlack: UIColor { get { return UIColor(colorValue: 0x32373B) } }
  @objc static var line_redColor: UIColor { get { return UIColor(colorValue: 0xE14040) } }

  @objc static var font_errorRedColor: UIColor { get { return UIColor(colorValue: 0xE14040) } }
  @objc static var font_blueColor: UIColor { get { return UIColor(colorValue: 0x8095ff) } }
  @objc static var font_purplishRedColor: UIColor { get { return UIColor(colorValue: 0xE9664B) } }
  @objc static var font_pinkRedColor: UIColor { get { return UIColor(colorValue: 0xEA4288) } }
  @objc static var font_brightRedColor: UIColor { get { return UIColor(colorValue: 0xFB2764) } }
  @objc static var font_brightBlueColor: UIColor { get { return UIColor(colorValue: 0x50E3C2) } }


  @objc static var btn_leftLightBlack: UIColor { get { return UIColor(colorValue: 0x313648) } }
  @objc static var btn_rightRed: UIColor { get { return UIColor(colorValue: 0xFB2464) } }
  @objc static var view_orangeColor:UIColor { get { return UIColor(colorValue:0xF56262)}   }
  @objc static var view_blueColor:UIColor { get { return UIColor(colorValue:0x7ED321)}   }
  @objc static var view_yellowColor:UIColor { get { return UIColor(colorValue:0xFB7A24)}   }


 
}
