//
//  INCustomerAlertView.h
//  INTEDSGame
//
//  Created by bux on 2018/3/30.
//  Copyright © 2018年 INTECH. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^ConfirmBtnBlock) (BOOL isConfirm );


@interface INCustomerAlertView : UIView

+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title sureTitle:(NSString*)sureTitle confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock; //只有一个title的时候

+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title content:(NSString*)content  cancelTitle:(NSString*)cancelTitle sureTitle:(NSString*)sureTitle confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock;  //一个title和一个内容的时候


/*
 cancelTitle = nil 时显示一个按钮
 sureBtnColor  定制右边按钮的背景的颜色
 */

+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title content:(NSString*)content  cancelTitle:(NSString*)cancelTitle cancelBtnColor:(UIColor *)cancelBtnColor  sureTitle:(NSString*)sureTitle sureBtnColor:(UIColor *)sureBtnColor confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock;  //一个title和一个内容的时候


@end
