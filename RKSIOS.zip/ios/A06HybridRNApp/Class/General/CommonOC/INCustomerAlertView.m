//
//  INCustomerAlertView.m
//  INTEDSGame
//
//  Created by bux on 2018/3/30.
//  Copyright © 2018年 INTECH. All rights reserved.
//

#import "INCustomerAlertView.h"
#import "Masonry.h"

#define CustAlertHeight    165

@interface INCustomerAlertView()

@property(nonatomic,strong) UIView *alertView;
@property(nonatomic,copy) ConfirmBtnBlock confirmBtnBlock;

@property(nonatomic,strong) UILabel *titleLab ;
@property(nonatomic,strong) UIButton *confirmBtn ;

@property(nonatomic,strong) UIView *alertTwoTitleView;
@property(nonatomic,strong) UIButton  *cancelBtn;
@property(nonatomic,strong) UIButton *otherBtn ;
@property(nonatomic,strong) UILabel *titleTwoLab;
@property(nonatomic,strong) UILabel *contentLab;


@end


@implementation INCustomerAlertView

+ (INCustomerAlertView*)sharedView {
    static dispatch_once_t once;
    
    static INCustomerAlertView *sharedView;
#if !defined(SV_APP_EXTENSIONS)
    dispatch_once(&once, ^{ sharedView = [[self alloc] initWithFrame:[[[UIApplication sharedApplication] delegate] window].bounds]; });
#else
    dispatch_once(&once, ^{ sharedView = [[self alloc] initWithFrame:[[UIScreen mainScreen] bounds]]; });
#endif
    return sharedView;
    
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
        
        
        UIView *alertView = [[UIView alloc]initWithFrame:CGRectZero];
        [self addSubview:alertView];
        _alertView = alertView;
        alertView.layer.cornerRadius = 8 ;
        alertView.backgroundColor = [UIColor whiteColor];
        
        UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [alertView addSubview:titleLab];
        titleLab.text = @"为6～16位英文字母、数字、字符组合（不能是纯数字）";
        titleLab.textAlignment = NSTextAlignmentCenter;
        titleLab.font = [UIFont systemFontOfSize:16];
        titleLab.textColor = [UIColor blackColor];
        _titleLab = titleLab;
        
        titleLab.numberOfLines = 0;
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:titleLab.text];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:10];//调整行间距
        [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [titleLab.text length])];
        titleLab.attributedText = attributedString;
      
        UIButton *confirmBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [alertView addSubview:confirmBtn];
        confirmBtn.backgroundColor = [UIColor yellowColor];
        [confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
        confirmBtn.layer.cornerRadius = 5;
        [confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        confirmBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [confirmBtn addTarget:self action:@selector(confirmBtnAction) forControlEvents:UIControlEventTouchUpInside];
        _confirmBtn = confirmBtn;
        
        [alertView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.centerY.equalTo(self);
            make.width.mas_equalTo(IPHONE_WIDTH-15*2);
            make.height.mas_equalTo(CustAlertHeight);
        }];
        
        [titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(alertView).offset(10);
            make.right.equalTo(alertView).offset(-10);
            make.top.equalTo(alertView).offset(15);
            make.height.mas_equalTo(60);
        }];
        
        
        [confirmBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(alertView).offset(-10);
            make.left.equalTo(alertView).offset(10);
            make.top.equalTo(titleLab.mas_bottom).offset(25);
            make.height.mas_equalTo(48);
        }];
        
        //带两行的样式的定制
        UIView *alertTwoTitleView = [[UIView alloc]initWithFrame:CGRectZero];
        [self addSubview:alertTwoTitleView];
        _alertTwoTitleView = alertTwoTitleView;
        _alertTwoTitleView.hidden = YES;

        alertTwoTitleView.layer.cornerRadius = 8 ;
        alertTwoTitleView.backgroundColor = [UIColor whiteColor];
        UILabel *titleTwoLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [alertTwoTitleView addSubview:titleTwoLab];
        titleTwoLab.text = @"确认删除吗？";
        titleTwoLab.textAlignment = NSTextAlignmentLeft;
        titleTwoLab.font = [UIFont systemFontOfSize:16];
        titleTwoLab.textColor = [UIColor blackColor];
        _titleTwoLab = titleTwoLab;
        
        UILabel *contentLab = [[UILabel alloc]initWithFrame:CGRectZero];
        [_alertTwoTitleView addSubview:contentLab];
        contentLab.text = @"此操作不可撤销，删除的消息无法恢复";
        contentLab.textAlignment = NSTextAlignmentLeft;
        contentLab.font = [UIFont systemFontOfSize:14];
        contentLab.textColor = [UIColor grayColor];
        _contentLab = contentLab;
        contentLab.numberOfLines = 0;
        
        UIButton *cancelBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_alertTwoTitleView addSubview:cancelBtn];
        [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancelBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        cancelBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        cancelBtn.layer.cornerRadius = 5;
        cancelBtn.layer.borderWidth = 1;
        cancelBtn.layer.borderColor = UIColorFromRGB(0xCCCCCC).CGColor ;
        [cancelBtn addTarget:self action:@selector(cancelBtnAction) forControlEvents:UIControlEventTouchUpInside];
        _cancelBtn = cancelBtn;
        
        UIButton *otherBtn = [[UIButton alloc]initWithFrame:CGRectZero];
        [_alertTwoTitleView addSubview:otherBtn];
        otherBtn.backgroundColor = [UIColor yellowColor];
        [otherBtn setTitle:@"好" forState:UIControlStateNormal];
        otherBtn.layer.cornerRadius = 5;
        [otherBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        otherBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [otherBtn addTarget:self action:@selector(confirmBtnAction) forControlEvents:UIControlEventTouchUpInside];
        _otherBtn = otherBtn;
        
        [alertTwoTitleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.centerY.equalTo(self);
            make.width.mas_equalTo(IPHONE_WIDTH-15*2);
            make.height.mas_equalTo(CustAlertHeight);
        }];
        
        [titleTwoLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(alertView).offset(15);
            make.right.equalTo(alertView).offset(-15);
            make.top.equalTo(alertView).offset(15);
            make.height.mas_equalTo(25);
        }];
        
        [contentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(alertView).offset(15);
            make.right.equalTo(alertView).offset(-15);
            make.top.equalTo(titleTwoLab.mas_bottom).offset(10);
            make.height.mas_equalTo(20);
        }];
        
        [cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(alertTwoTitleView).offset(10);
            make.bottom.equalTo(alertTwoTitleView.mas_bottom).offset(-20);
            make.height.mas_equalTo(48);
            make.width.mas_equalTo((IPHONE_WIDTH-15*2- 15*3 )/2.0);
        }];
        
        [otherBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(alertTwoTitleView).offset(-10);
            make.bottom.equalTo(cancelBtn.mas_bottom);
            make.height.mas_equalTo(48);
            make.width.mas_equalTo((IPHONE_WIDTH-15*2- 15*3 )/2.0);
        }];
        
    }
    return self;
}



+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title  sureTitle:(NSString*)sureTitle confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock{
    [[self sharedView] showToastViewWithConfirmBtnBlock:title  sureTitle:sureTitle confirmBtnBlock:confirmBtnBlock];
    
}

- (void)showToastViewWithConfirmBtnBlock:(NSString*)title sureTitle:(NSString*)sureTitle confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock{
    
    _titleLab.text = title;
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:_titleLab.text];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:10];//调整行间距
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [_titleLab.text length])];
    _titleLab.attributedText = attributedString;
    _titleLab.textAlignment = NSTextAlignmentCenter;
    [_confirmBtn setTitle:sureTitle forState:UIControlStateNormal];
    
    _alertTwoTitleView.hidden = YES;
    _alertView.hidden = NO;

    __weak INCustomerAlertView *weakSelf = self;
    self.confirmBtnBlock = confirmBtnBlock;
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        __strong INCustomerAlertView *strongSelf = weakSelf;
        if(strongSelf){
            
            [[[[UIApplication sharedApplication] delegate] window] addSubview:self];
            
         //   strongSelf.alertView.transform = CGAffineTransformScale(strongSelf.alertView.transform, 1/1.5f, 1/1.5f);
            //0.2
            [UIView animateWithDuration:0.0
                                  delay:0
                                options:(UIViewAnimationOptions) (UIViewAnimationOptionAllowUserInteraction | UIViewAnimationCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState)
                             animations:^{
                                 
                             //    strongSelf.alertView.transform = CGAffineTransformIdentity;
                                 
                             } completion:^(BOOL finished) {
                                 
                                 
                             }];
            
            
        }
    }];
}


+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title content:(NSString*)content  cancelTitle:(NSString*)cancelTitle sureTitle:(NSString*)sureTitle confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock{
    
    [[self sharedView] showToastViewWithConfirmBtnBlock:title content:content cancelTitle:cancelTitle  cancelBtnColor:nil sureTitle:sureTitle sureBtnColor:nil confirmBtnBlock:confirmBtnBlock];
    
}

+ (void)showToastViewWithConfirmBtnBlock:(NSString*)title content:(NSString*)content  cancelTitle:(NSString*)cancelTitle cancelBtnColor:(UIColor *)cancelBtnColor  sureTitle:(NSString*)sureTitle sureBtnColor:(UIColor *)sureBtnColor confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock{
    
    [[self sharedView] showToastViewWithConfirmBtnBlock:title content:content cancelTitle:cancelTitle  cancelBtnColor:cancelBtnColor sureTitle:sureTitle sureBtnColor:sureBtnColor confirmBtnBlock:confirmBtnBlock];

}

- (void)showToastViewWithConfirmBtnBlock:(NSString*)title content:(NSString*)content  cancelTitle:(NSString*)cancelTitle cancelBtnColor:(UIColor *)cancelBtnColor sureTitle:(NSString*)sureTitle sureBtnColor:(UIColor *)sureBtnColor confirmBtnBlock:(ConfirmBtnBlock)confirmBtnBlock{
    
    _alertTwoTitleView.hidden = NO;
    _alertView.hidden = YES;
    _titleTwoLab.text = title;
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:content];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:5];//调整行间距
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [content length])];
    _contentLab.attributedText = attributedString;
    
    CGSize contentSize = [_contentLab sizeThatFits:CGSizeMake(IPHONE_WIDTH-15*2-30, 80)];
    
    if (contentSize.height > 25) { //大于1行时
        [_alertTwoTitleView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo( CustAlertHeight + (contentSize.height - 20));
        }];
        
        [_contentLab mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(contentSize.height+5);
        }];
    }
    
    if (!cancelTitle) {
       
        _cancelBtn.hidden = YES;
        [_otherBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.alertTwoTitleView).offset(15);
            make.right.equalTo(self.alertTwoTitleView).offset(-15);
        }];
        
    }else{
        [_cancelBtn setTitle:cancelTitle forState:UIControlStateNormal];
    }
    
    [_otherBtn setTitle:sureTitle forState:UIControlStateNormal];
    
    if (cancelBtnColor) {
        _cancelBtn.backgroundColor = cancelBtnColor;
    }
    if (sureBtnColor) {
        _otherBtn.backgroundColor = sureBtnColor;
        [_otherBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    
    
    __weak INCustomerAlertView *weakSelf = self;
    self.confirmBtnBlock = confirmBtnBlock;
    
    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
        __strong INCustomerAlertView *strongSelf = weakSelf;
        if(strongSelf){
            
            [[[[UIApplication sharedApplication] delegate] window] addSubview:self];
            
          //  strongSelf.alertTwoTitleView.transform = CGAffineTransformScale(strongSelf.alertTwoTitleView.transform, 1/1.5f, 1/1.5f);
            //0.2
//            [UIView animateWithDuration:0.2
//                                  delay:0
//                                options:(UIViewAnimationOptions) (UIViewAnimationOptionAllowUserInteraction | UIViewAnimationCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState)
//                             animations:^{
//
//                                 strongSelf.alertTwoTitleView.transform = CGAffineTransformIdentity;
//
//                             } completion:^(BOOL finished) {
//
//
//                             }];
            
            
        }
    }];
}


-(void)cancelBtnAction{
    if (self.confirmBtnBlock) {
        self.confirmBtnBlock(NO);
    }
    [self hideToast];
}

-(void)confirmBtnAction{
    if (self.confirmBtnBlock) {
        self.confirmBtnBlock(YES);
    }
    [self hideToast];
}

- (void)hideToast {
    
    [UIView animateWithDuration:0.2
                          delay:0.0
                        options:(UIViewAnimationOptionCurveEaseIn | UIViewAnimationOptionBeginFromCurrentState)
                     animations:^{
                         
                       //  self.alertView.transform = CGAffineTransformScale(self.alertView.transform, 1/1.3f, 1/1.3f);
                        // self.alertTwoTitleView.transform = CGAffineTransformScale(self.alertTwoTitleView.transform, 1/1.3f, 1/1.3f);
                         
                     } completion:^(BOOL finished) {
                         
                         [self removeFromSuperview];
                     }];
}


@end
