//
//  PickerView.m
//  A02_iPhone
//
//  Created by Robert on 11/09/2017.
//  Copyright © 2017 robert. All rights reserved.
//

#import "DataPickerView.h"
#import "Masonry.h"

@interface DataPickerView()<UIPickerViewDataSource,UIPickerViewDelegate>

@property (strong, nonatomic) UIView *maskView;

@property (strong, nonatomic) UIView *contentView;

@property (strong, nonatomic) UIPickerView *pickerView;

@property (strong, nonatomic) UIButton *cancelBtn;

@property (strong, nonatomic) UIButton *okBtn;

@property (strong, nonatomic) NSArray *dataArray;

@property (assign, nonatomic) NSInteger index;

@property (strong, nonatomic) NSString *selectedString;

@property (strong, nonatomic) UIView *lineView;

@property (copy, nonatomic) DataPickerViewCompleteBlock completeBlock;
@end

@implementation DataPickerView

+ (void)showDataPickerViewWithDataArray:(NSArray *)dataArray
                          completeBlock:(DataPickerViewCompleteBlock)completeBlock {
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    DataPickerView *dataPickerView = [[DataPickerView alloc] initWithFrame:window.bounds];
    [window addSubview:dataPickerView];
    dataPickerView.dataArray = dataArray;
    if (dataPickerView.dataArray.count > 0) {
        dataPickerView.selectedString = dataPickerView.dataArray[0];
    }
    dataPickerView.completeBlock = completeBlock;
    [dataPickerView performSelector:@selector(show) withObject:nil afterDelay:0.1];
}

#pragma mark 私有方法
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self addSubview:self.maskView];
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.cancelBtn];
    [self.contentView addSubview:self.okBtn];
    [self.contentView addSubview:self.pickerView];
    [self.contentView addSubview:self.lineView];
    
    [self.maskView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(0);
        make.right.equalTo(self.mas_right).offset(0);
        make.top.equalTo(self.mas_bottom);
        make.height.mas_equalTo(self.mas_height);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(0);
        make.right.equalTo(self.mas_right).offset(0);
        make.width.mas_equalTo(self.mas_width);
        make.bottom.equalTo(self.mas_bottom).offset(240);
        make.height.mas_equalTo(240);
    }];
    
    [self.cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.top.equalTo(self.contentView.mas_top).offset(0);
        make.width.mas_equalTo(70);
        make.height.mas_equalTo(40);
    }];

    [self.okBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.top.equalTo(self.contentView.mas_top).offset(0);
        make.width.mas_equalTo(70);
        make.height.mas_equalTo(40);
    }];

    [self.pickerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(0);
        make.top.equalTo(self.okBtn.mas_bottom).offset(0);
        make.right.equalTo(self.contentView.mas_right).offset(0);
        make.bottom.equalTo(self.contentView.mas_bottom).offset(0);
    }];
}

- (void)show {
    [UIView animateWithDuration:0.2 animations:^{
        [self.maskView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_top).offset(0);
        }];
    
        [self.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.mas_bottom);
        }];
        [self layoutIfNeeded];
    }];
}

- (void)removeDataPickerView {
    [UIView animateWithDuration:0.2 animations:^{
        [self.maskView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_top).offset(self.frame.size.height);
        }];
        
        [self.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.mas_bottom).offset(240);
        }];
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.completeBlock = nil;
        [self removeFromSuperview];
    }];
}

- (void)cancelBtnAction:(UIButton *)btn {
    [self removeDataPickerView];
}

- (void)okBtnAction:(UIButton *)btn {
    if (self.completeBlock) {
        self.completeBlock(self.index,self.selectedString);
    }
    [self removeDataPickerView];
}

#pragma mark UIPickerViewDelete
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.dataArray.count;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 44;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {

    for(UIView *singleLine in pickerView.subviews){
        if (singleLine.frame.size.height < 1) {
            singleLine.backgroundColor = [UIColor lightGrayColor];
        }
    }
    UILabel *genderLabel = [[UILabel alloc] init];
    genderLabel.textAlignment = NSTextAlignmentCenter;
    genderLabel.text = self.dataArray[row];
    genderLabel.font = [UIFont systemFontOfSize:23.0];
    genderLabel.textColor = [UIColor blackColor];
    return genderLabel;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.index = row;
    self.selectedString = self.dataArray[row];
}

#pragma mark GET SET
- (UIView *)maskView {
    if (!_maskView) {
        _maskView = [[UIView alloc] initWithFrame:CGRectZero];
        _maskView.alpha = 0.2;
        _maskView.backgroundColor = [UIColor blackColor];
        [self addSubview:_maskView];
    }
    return _maskView;
}

- (NSArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [[NSArray alloc] init];
    }
    return _dataArray;
}

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectZero];
        _contentView.backgroundColor = [UIColor colorWithRed:238.f/ 255.f green:238.f/ 255.f blue:238.f/ 255.f alpha:1];
    }
    return _contentView;
}

- (UIButton *)cancelBtn {
    if (!_cancelBtn) {
        _cancelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        _cancelBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [_cancelBtn addTarget:self action:@selector(cancelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cancelBtn;
}

- (UIButton *)okBtn {
    if (!_okBtn) {
        _okBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_okBtn setTitle:@"完成" forState:UIControlStateNormal];
        _okBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [_okBtn addTarget:self action:@selector(okBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _okBtn;
}

- (UIPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [[UIPickerView alloc]initWithFrame:CGRectZero];
        _pickerView.backgroundColor = [UIColor colorWithRed:203.f/ 255.f green:205.f/ 255.f blue:210.f/ 255.f alpha:1];
        _pickerView.dataSource = self;
        _pickerView.delegate = self;
    }
    return _pickerView;
}

- (UIView *)lineView {
    if (!_lineView) {
        _lineView = [[UIView alloc] initWithFrame:CGRectZero];
        _lineView.backgroundColor = [UIColor blackColor];
    }
    return _lineView;
}
@end
