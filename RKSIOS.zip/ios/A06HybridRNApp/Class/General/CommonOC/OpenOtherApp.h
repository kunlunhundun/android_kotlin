//
//  OpenOtherApp.h
//  HyEntireGame
//
//  Created by kunlun on 2018/10/8.
//  Copyright © 2018年 kunlun. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^OpenAppCompleteBlock)(BOOL success);

@interface OpenOtherApp : NSObject


+ (void)openOtherAppWithURL:(NSString *)URL completeBlock:(OpenAppCompleteBlock)completeBlock;

+ (void)openOtherAppWithURLtest:(NSString *)URL ;


@end
