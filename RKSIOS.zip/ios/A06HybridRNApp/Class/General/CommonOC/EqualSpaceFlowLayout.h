//
//  EqualSpaceFlowLayout.h
//  client
//
//  Created by bux on 2018/9/11.
//  Copyright © 2018年 bux. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,AlignType){
    AlignWithLeft,
    AlignWithCenter,
    AlignWithRight
};
@interface EqualSpaceFlowLayout : UICollectionViewFlowLayout
//两个Cell之间的距离
@property (nonatomic,assign)CGFloat betweenOfCell;
//cell对齐方式
@property (nonatomic,assign)AlignType cellType;
-(instancetype)initWthType : (AlignType)cellType itemSpace:(NSNumber *)itemSpace leftRightSpace:(NSNumber *)leftRightSpace topBottomSpace:(NSNumber *)topBottomSpace;

@end
