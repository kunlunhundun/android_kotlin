//
//  UIImageTools.m
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/10.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import "UIImageTools.h"

@implementation UIImageTools



+ (UIImage *)applyBlurRadius:(CGFloat)radius toImage:(UIImage *)image
{
  if (radius < 0) radius = 0;
  
  CIContext *blurContext = [CIContext contextWithOptions:nil];
  CIImage *inputImage = [CIImage imageWithCGImage:image.CGImage];
  // Setting up gaussian blur
  CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur"];
  [filter setValue:inputImage forKey:kCIInputImageKey];
  [filter setValue:[NSNumber numberWithFloat:radius] forKey:@"inputRadius"];
  CIImage *result = [filter valueForKey:kCIOutputImageKey];
  
  CGImageRef cgImage = [blurContext createCGImage:result fromRect:[inputImage extent]];
  UIImage *returnImage = [UIImage imageWithCGImage:cgImage];
  CGImageRelease(cgImage);
  return returnImage;
  
}

+(UIImage*)fullScreenshots{
  
  UIWindow *screenWindow = [UIApplication sharedApplication].delegate.window;
  UIGraphicsBeginImageContext(screenWindow.frame.size);
  [screenWindow.layer renderInContext:UIGraphicsGetCurrentContext()];
  UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  return image;
}

+(UIImage*)screenshotsView:(UIView *)shotView{
  
  UIGraphicsBeginImageContext(shotView.frame.size);
  [shotView.layer renderInContext:UIGraphicsGetCurrentContext()];
  UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  return image;
}


+(UIImage*)applyBlurFullScreenShots{
  
  UIImage *shotScreenImg = [self fullScreenshots];
  UIImage *blurImage = [self applyBlurRadius:5.0 toImage:shotScreenImg];
  return blurImage ;
  
}


+ (void)iOS8BlurImageImplement:(UIView*)supView {
  
  UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
  UIVisualEffectView *view = [[UIVisualEffectView alloc] initWithEffect:beffect];
  view.frame = supView.bounds;
  view.alpha = 0.85;
  [supView addSubview:view];

}
  
 



@end
