//
//  RegularExp.h
//  iSalesOA
//
/*
 *  正则表达式验证
 */

#import <Foundation/Foundation.h>

@interface RegularExp : NSObject

/*邮箱验证 MODIFIED BY HELENSONG*/
+(BOOL)isValidateEmail:(NSString *)email;

/*手机号码验证 MODIFIED BY HELENSONG*/
+(BOOL)isValidateMobile:(NSString *)mobile;

/*车牌号验证 MODIFIED BY HELENSONG*/
+(BOOL)validateCarNo:(NSString *)carNo;

/*数字验证*/
+(BOOL)isValidateNum:(NSString *)number;

/*用户名验证*/
+(BOOL)isValidateLoginNum:(NSString *)loginNum;

/*密码验证*/
+(BOOL)isValidatePassword:(NSString *)passWord;

/*验证联通号码*/
+(BOOL)isValidateUnionNumber:(NSString *)number;

/*大写字母验证*/
+(BOOL)isValidateUpAlphabet:(NSString *)alphabet;

/*小写字母验证*/
+(BOOL)isValidateLowAlphabet:(NSString *)alphabet;

/*中英文字母、数字和下划线*/
+ (BOOL) isValidateCnDigitEn_:(NSString *)string;

/*英文字母、数字*/
+(BOOL)isValidateDigitEn:(NSString *)ch;

/*中文*/
+(BOOL) isChinese:(NSString *)string;

/*国内电话号码*/
+(BOOL) isChinesePhoneNumber:(NSString *)number;

/*手机号码、国内电话号码 */
+(BOOL) isChineseMobileAndPhoneNumber:(NSString *)number;

/*URL*/
+(BOOL) isCorrectURL:(NSString *)url;

/*URL  商品详情页的URL*/
+(BOOL) isProductURL:(NSString *)url;
    
/*IDcard (15或18位)*/
+(BOOL)isIDcardNumber:(NSString *)IDNumber;

/*第二代身份证号18位*/
+(BOOL)isTheSecond_generationIDCard:(NSString *)IDNumber;

/*15位身份证号*/
+(BOOL)isOldIDCard:(NSString *)IDNumber;

/*英文字母、数字和下划线*/
+(BOOL)isLettersDigitEn_:(NSString *)string;

/** 检查用户名登录的规则 */
+ (NSString *)checkUserNameLoginLegalWithUserName:(NSString *)userName
                                         userPass:(NSString *)userPass;

/** 检查用户名注册规则 */
+ (NSString *)checkUserRegisterLegalWithUserName:(NSString *)userName
                                        userPass:(NSString *)userPass;

/** 检查密码规则 */
+ (NSString *)checkPassLegalWithPassword:(NSString *)password;

/** YES 是1开头，11位的手机号，NO 相反 */
+ (BOOL)checkInputPhone:(NSString *)inputPhone;

/** 检查备注和收货地址是合法 */
+ (BOOL)checkRemarkLegalWithRemakStr:(NSString *)remark;

/** 检查银行卡地址是合法 */
+ (BOOL)checkBankBranchAddressWithBranchAddress:(NSString *)branchAddress;

/** YES 含有表情，NO 相反 */
+ (BOOL)checkEmojiWithEmojiStr:(NSString *)emojiStr;

/**
 检查真实姓名是否合法
 
 @return YES合法，NO不合法
 */
+ (BOOL)checkRealNameWithRealName:(NSString *)realName;

/** 检查用户名规则 */
+ (NSString *)checkUserNameLegalWithUserName:(NSString *)userName;

/** 检查比特币地址是否合法 */
+ (BOOL)checkBitcoinAddressWithBitAddress:(NSString *)bitAddress;

/**
 检查预留信息是否合法
 
 @return YES 合法，NO不合法
 */
+ (BOOL)checkReservedMessageWithMessage:(NSString *)message;

+ (BOOL)checkPastePhoneWithPhone:(NSString *)phone;


// 新的密码的验证
+ (NSString *)checkPassword:(NSString *)password;


@end
