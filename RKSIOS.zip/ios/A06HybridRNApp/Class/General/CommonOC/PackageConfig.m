//
//  PackageConfig.m
//  A06HybridRNApp
//
//  Created by hopper on 02/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "PackageConfig.h"
#import "AppInitializeValueConfig.h"

@implementation PackageConfig

+ (NSInteger)PackageEnvirmentType{
   return EnvirmentType;
}

@end
