//
//  RegularExp.m
//  iSalesOA
//

#import "RegularExp.h"
#import "NSString+Font.h"

@implementation RegularExp


/*邮箱验证 MODIFIED BY HELENSONG*/
+(BOOL)isValidateEmail:(NSString *)email{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


/*手机号码验证 MODIFIED BY HELENSONG*/
+(BOOL)isValidateMobile:(NSString *)mobile{
    //手机号以11，12，13，14，15，17，18开头，八个 \d 数字字符
    NSString *phoneRegex = @"^((13[0-9])|(15[^4])|(18[0-9])|(17[0-8])|(19[8,9])|(166)|(14[5,7]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}


/*车牌号验证 MODIFIED BY HELENSONG*/
+(BOOL)validateCarNo:(NSString *)carNo{
    NSString *carRegex = @"^[A-Za-z]{1}[A-Za-z_0-9]{5}$";
    NSPredicate *carTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",carRegex];
    return [carTest evaluateWithObject:carNo];
}


/*数字验证*/
+(BOOL)isValidateNum:(NSString *)number{
    NSString *numRegex = @"^[0-9]*$";
    NSPredicate *numTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",numRegex];
    return [numTest evaluateWithObject:number];
}


/*用户名验证*/
+(BOOL)isValidateLoginNum:(NSString *)loginNum{
    NSString *num = @"^[A-Z][A-Z0-9_]{0,19}$";
    NSPredicate *numTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",num];
    return [numTest evaluateWithObject:loginNum];
}


/*密码验证 包含（大小写字母、数字、下划线以及特殊符号）*/
+(BOOL)isValidatePassword:(NSString *)passWord{
    NSString *word = @"^[A-Za-z0-9_]+$";
    NSPredicate *wordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",word];
    return [wordTest evaluateWithObject:passWord];
}


/*验证联通号码*/
+(BOOL)isValidateUnionNumber:(NSString *)number{
    NSString *num = @"^1(3[0-2]|4[5]|5[56]|8[56])\\d{8}$";
    NSPredicate *numTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",num];
    return [numTest evaluateWithObject:number];
}


/*大写字母验证*/
+(BOOL)isValidateUpAlphabet:(NSString *)alphabet{
    NSString *alph = @"^[A-Z]+$";
    NSPredicate *alphTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",alph];
    return [alphTest evaluateWithObject:alphabet];
}


/*小写字母验证*/
+(BOOL)isValidateLowAlphabet:(NSString *)alphabet{
    NSString *alph = @"^[a-z]+$";
    NSPredicate *alphTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",alph];
    return [alphTest evaluateWithObject:alphabet];
}


/*中英文字母、数字和下划线*/
+(BOOL)isValidateCnDigitEn_:(NSString *)string{
    NSString * regularExpression = @"^[\\u4e00-\\u9fa5A-Za-z0-9_]+$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    return [testPredicate evaluateWithObject:string];
}


/*英文字母、数字*/
+(BOOL)isValidateDigitEn:(NSString *)ch{
    NSString *sym = @"^[A-Za-z0-9]+$";
    NSPredicate *symTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",sym];
    return [symTest evaluateWithObject:ch];
}


/*中文*/
+(BOOL)isChinese:(NSString *)string{
    NSString * regExp = @"^[\\u4e00-\\u9fa5]+$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regExp];
    return [testPredicate evaluateWithObject:string];
}


/*国内电话号码*/
+(BOOL)isChinesePhoneNumber:(NSString *)number{
    NSString * regExp = @"^(\\d{3,4}-\\d{7,8}(-\\d{3,4})?$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regExp];
    return [testPredicate evaluateWithObject:number];
}


/*手机号码、国内电话号码*/
+(BOOL)isChineseMobileAndPhoneNumber:(NSString *)number{
    NSString * regularExpression = @"^(\\d{3,4}-\\d{7,8}(-\\d{1,4})?)|(1[1,2,3,4,5,7,8]\\d{9})$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    return [testPredicate evaluateWithObject:number];
}


/*URL  http 协议的URL*/
+(BOOL) isCorrectURL:(NSString *)url{
    NSString * regExp = @"^http://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?";
    NSPredicate * testPrdct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regExp];
    return [testPrdct evaluateWithObject:url];
}

/*URL  商品详情页的URL*/
+(BOOL) isProductURL:(NSString *)url{
    NSString * regExp = @"^http://(buy|shop).ccb.com/products/(\\w+)_(\\d+)?\\.jhtml(.*)?";
    NSPredicate * predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regExp];
    return [predicate evaluateWithObject:url];
}

/*兼容15 18位身份证号*/
+(BOOL)isIDcardNumber:(NSString *)IDNumber{
    NSString * regExp = @"^([1-9]\\d{5}(19|20)\\d{2}((0[1-9])|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}(\\d|x|X))|([1-9]\\d{5}\\d{2}((0[1-9])|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3})$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regExp];
    return [testPredicate evaluateWithObject:IDNumber];
}


/*15位身份证号*/
+(BOOL)isOldIDCard:(NSString *)IDNumber{
    NSString * regExp = @"^([1-9]\\d{5}\\d{2}((0[1-9])|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3})$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHS %@",regExp];
    return [testPredicate evaluateWithObject:IDNumber];
}


/*18位身份证号*/
+(BOOL)isTheSecond_generationIDCard:(NSString *)IDNumber{
    NSString * regExp = @"^([1-9]\\d{5}(19|20)\\d{2}((0[1-9])|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}(\\d|x|X))$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHS %@",regExp];
    return [testPredicate evaluateWithObject:IDNumber];
}


/*英文字母、数字和下划线*/
+(BOOL)isLettersDigitEn_:(NSString *)string{
    NSString * regularExpression = @"^[A-Za-z0-9_]+$";
    NSPredicate * testPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regularExpression];
    return [testPredicate evaluateWithObject:string];
}

/** 检查用户名登录的规则 */
+ (NSString *)checkUserNameLoginLegalWithUserName:(NSString *)userName
                                         userPass:(NSString *)userPass {
    NSString *str = [self checkUserNameLegalWithUserName:userName];
    if (![self isBlankString:str]) {
        return str;
    }
    str = [self checkPassLegalWithPassword:userPass];
    
    if (![self isBlankString:str]) {
        return str;
    }
    return @"";
}


/** 检查用户名注册规则 */
+ (NSString *)checkUserRegisterLegalWithUserName:(NSString *)userName
                                        userPass:(NSString *)userPass {
    NSString *str = [self checkUserNameLegalWithUserName:userName];
    if (![self isBlankString:str]) {
        return str;
    }
    str = [self checkPassLegalWithPassword:userPass];
    
    if (![self isBlankString:str]) {
        return str;
    }
    return @"";
}

/** 检查用户名规则 */
+ (NSString *)checkUserNameLegalWithUserName:(NSString *)userName {
    NSPredicate *predicate = nil;
    NSString *regular = @"";
    regular = @"^[a-z0-9]{4,10}";
    predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
    if (![predicate evaluateWithObject:userName]) {
        return @"账号由4-10位小写字母或数字组成";
    }
    return @"";
}

/** 检查密码 */
+ (NSString *)checkPassLegalWithPassword:(NSString *)password {
    NSPredicate *predicate = nil;
    NSString *regular = @"";
    regular = @"^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$";
    predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
    if (![predicate evaluateWithObject:password]) {
        return @"请输入8-16位数字和字母组成的密码";
    }
    return @"";
}

/** 新的检查密码 */
+ (NSString *)checkPassword:(NSString *)password {
  NSPredicate *predicate = nil;
  NSString *regular = @"";
  regular = @"^[0-9A-Za-z]{6,16}$";
  predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
  if (![predicate evaluateWithObject:password]) {
    return @"请输入6-16位数字和字母组成的密码";
  }
  return @"";
}


/** YES 是1开头，11位的手机号，NO 相反 */
+ (BOOL)checkInputPhone:(NSString *)inputPhone {
    NSPredicate *predicate = nil;
    // 检查用户名是否是类似手机号
    NSString *regular = @"^(1)[0-9]{10}";
    predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
    if ([predicate evaluateWithObject:inputPhone]) {
        return YES;
    }
    return NO;
}

/** 检查备注和收货地址是合法 */
+ (BOOL)checkRemarkLegalWithRemakStr:(NSString *)remark {
    NSString *regular = @"[0-9a-zA-Z\u4e00-\u9fa5]+";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
    if (![predicate evaluateWithObject:remark]) {
        return NO;
    }
    return YES;
}

/** 检查银行卡地址是合法 */
+ (BOOL)checkBankBranchAddressWithBranchAddress:(NSString *)branchAddress {
    NSString *regular = @"^[\u4e00-\u9fa5]";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regular];
    if ([predicate evaluateWithObject:branchAddress]) {
        return YES;
    }
    return NO;
}

/** YES 含有表情，NO 相反 */
+ (BOOL)checkEmojiWithEmojiStr:(NSString *)emojiStr {
    // 过滤所有表情。returnValue为NO表示不含有表情，YES表示含有表情
    __block BOOL returnValue = NO;
    [emojiStr enumerateSubstringsInRange:NSMakeRange(0, [emojiStr length]) options:NSStringEnumerationByComposedCharacterSequences usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
        
        const unichar hs = [substring characterAtIndex:0];
        // surrogate pair
        if (0xd800 <= hs && hs <= 0xdbff) {
            if (substring.length > 1) {
                const unichar ls = [substring characterAtIndex:1];
                const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                if (0x1d000 <= uc && uc <= 0x1f77f) {
                    returnValue = YES;
                }
            }
        } else if (substring.length > 1) {
            const unichar ls = [substring characterAtIndex:1];
            if (ls == 0x20e3) {
                returnValue = YES;
            }
        } else {
            // non surrogate
            if (0x2100 <= hs && hs <= 0x27ff) {
                returnValue = YES;
            } else if (0x2B05 <= hs && hs <= 0x2b07) {
                returnValue = YES;
            } else if (0x2934 <= hs && hs <= 0x2935) {
                returnValue = YES;
            } else if (0x3297 <= hs && hs <= 0x3299) {
                returnValue = YES;
            } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                returnValue = YES;
            }
        }
    }];
    return returnValue;
}

/**
 检查真实姓名是否合法
 
 @return YES合法，NO不合法
 */
+ (BOOL)checkRealNameWithRealName:(NSString *)realName; {
    NSString *realNameRegex = @"[a-zA-Z•·\u4e00-\u9fa5]{2,12}";
    NSPredicate *realNamePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",realNameRegex];
    if (![realNamePredicate evaluateWithObject:realName]) {
        return NO;
    }
    return YES;
}

+ (BOOL) isBlankString:(NSString *) objString {
    if (objString == nil || objString == NULL) {
        return YES;
    }
    if ([objString isKindOfClass:[NSNull class]]) {
        return YES;
    }
    if ([[objString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
        return YES;
    }
    return NO;
}

/** 检查比特币地址是否合法 */
+ (BOOL)checkBitcoinAddressWithBitAddress:(NSString *)bitAddress {
    NSString *bitcoinRegex = @"^[a-zA-Z0-9]{26,35}";
    NSPredicate *bitcoinPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",bitcoinRegex];
    if (![bitcoinPredicate evaluateWithObject:bitAddress]) {
        return NO;
    }
    return YES;
}

/**
 检查预留信息是否合法
 
 @return YES 合法，NO不合法
 */
+ (BOOL)checkReservedMessageWithMessage:(NSString *)message {
    NSString *realNameRegex = @"^[a-zA-Z0-9\u4e00-\u9fa5]{1,16}";
    NSPredicate *realNamePredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",realNameRegex];
    if (![realNamePredicate evaluateWithObject:message]) {
        
        return NO;
    }
    return YES;
}

+ (BOOL)checkPastePhoneWithPhone:(NSString *)phone {
    if ([NSString isBlankString:phone]) {
        return NO;
    }
    else {
        NSString *regex = @"[+0-9 ]+$";
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
        if ([predicate evaluateWithObject:phone]) {
            return YES;
        }
    }
    return NO;
}
@end
