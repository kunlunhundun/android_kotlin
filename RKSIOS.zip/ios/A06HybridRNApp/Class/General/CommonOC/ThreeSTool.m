//
//  ThreeSTool.m
//  A06HybridRNApp
//
//  Created by hopper on 12/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "ThreeSTool.h"

@implementation ThreeSTool

+ (void)filshedLanch{
  [IN3SAnalytics launchFinished];
}

+ (void)setLoginName:(NSString *)loginName{
  [IN3SAnalytics setUserName:loginName];
}

+ (void)appdidFinishLaunching{
#if DEBUG
  [IN3SAnalytics debugEnable:YES];
#endif
  [IN3SAnalytics configureSDKWithProduct:@"A06"];
}

+ (void)appDidEnterBackground{
  [IN3SAnalytics exitApp];
}

+ (void)payVCDidAppearHasRecord:(BOOL)hasRecord beginDate:(NSDate *)beginDate{
  if (!hasRecord) {
     //beginDate 为点击入口时记录的时间，与结束计算时间之差，耗时间隔毫秒
     NSDate *endDate = [NSDate date];
     NSTimeInterval duration = [endDate timeIntervalSinceDate:beginDate] * 1000;
     NSString *timeString = [NSString stringWithFormat:@"%f", [beginDate timeIntervalSince1970]];
     //支付的页面名填固定的 PaymentPageLoad
     [IN3SAnalytics enterPageWithName:@"PaymentPageLoad" responseTime:duration timestamp:timeString];
  }
}

- (void)AGQJWebViewStartLoad{
  self.startTime = [[NSDate date] timeIntervalSince1970];
}

// AGQJ加载成功
- (void)AGQJWebViewDidFinishLoad:(WKWebView *)webView{
  [self loadFinished:webView.URL.absoluteString msg:nil resCode:200];
}

// AGQJ加载失败
- (void)AGQJWebViewDidFailLoad:(WKWebView *)webView error:(NSError *)error{
  [self loadFinished:webView.URL.absoluteString msg:@"加载失败" resCode:(int)error.code];
}
- (void)loadFinished:(NSString *)url msg:(NSString *)msg resCode:(int)resCode{
  //加载完成时间
  double endTime = [[NSDate date] timeIntervalSince1970];
  //总加载时长
  double durationTime = (endTime - self.startTime) * 1000;
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  [IN3SAnalytics loadWebViewWithUrl:url responseTime:durationTime responseCode:resCode msg:msg timestamp:timestamp];
}


- (void)startPreload{
  //预加载开始，执行埋点
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  [IN3SAnalytics loadAGQJWithResponseTime:0 loadFinish:NO msg:nil timestamp:timestamp];
  //开始时间戳
  self.preloadstartTime = [[NSDate date] timeIntervalSince1970];
}
- (void)endPreload{
  //完成时间戳
  double endTime = [[NSDate date] timeIntervalSince1970];
  //总耗时
  double durationTime = (endTime - self.preloadstartTime) * 1000;
  //预加载开始，执行埋点
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  //预加载完成，执行埋点
  [IN3SAnalytics loadAGQJWithResponseTime:durationTime loadFinish:YES msg:nil timestamp:timestamp];
}

- (void)startNormalLoad{
  //加载开始，执行埋点
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  [IN3SAnalytics loadAGQJWithResponseTime:0 loadFinish:NO msg:nil timestamp:timestamp];
  //开始时间戳
  self.normalstartTime = [[NSDate date] timeIntervalSince1970];
}
- (void)endNormalLoad{
  double endTime = [[NSDate date] timeIntervalSince1970];
  //总耗时
  double durationTime = (endTime - self.normalstartTime) * 1000;
  //加载完成，执行埋点
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  [IN3SAnalytics loadAGQJWithResponseTime:durationTime loadFinish:YES msg:nil timestamp:timestamp];
}

- (void)startRequestWithUrl{
  self.urlstartTime = [[NSDate date] timeIntervalSince1970];
  
  //   NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
  //   [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss:SSS"];
  //   NSDate *datenow = [NSDate date];
  //   NSString *nowtimeStr = [formatter stringFromDate:datenow];
  //   self.start = nowtimeStr;
}
- (void)endRequestWithUrl:(NSString *)url code:(int)resCode message:(NSString *)msg{
  
  double endTime = [[NSDate date] timeIntervalSince1970];
  //总耗时
  double durationTime = (endTime - self.urlstartTime) * 1000;
  NSString *timestamp = [NSString stringWithFormat:@"%.3lf",[[NSDate date] timeIntervalSince1970]];
  
  //  NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
  //  [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss:SSS"];
  //  NSDate *datenow = [NSDate date];
  //  NSString *nowtimeStr = [formatter stringFromDate:datenow];
  //  self.end = nowtimeStr;
  
  [IN3SAnalytics requestWithUrl:url responseTime:durationTime responseCode:resCode msg:msg timestamp:timestamp];
}

@end
