//
//  BaseTextfiled.m
//  A06HybridRNApp
//
//  Created by hopper on 25/02/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "BaseTextfiled.h"

@implementation BaseTextfiled
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender {
  UIMenuController *menuController = [UIMenuController sharedMenuController];
  if(menuController) {
    [UIMenuController sharedMenuController].menuVisible=NO;
  }
  return NO;
}
@end
