//
//  OpenOtherApp.m
//  HyEntireGame
//
//  Created by kunlun on 2018/10/8.
//  Copyright © 2018年 kunlun. All rights reserved.
//

#import "OpenOtherApp.h"
#import <UIKit/UIKit.h>


@implementation OpenOtherApp


+ (void)openOtherAppWithURL:(NSString *)URL completeBlock:(OpenAppCompleteBlock)completeBlock {
    if (@available(iOS 10.0, *)) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:URL] options:@{} completionHandler:^(BOOL success) {
          if (success == NO){
            if (completeBlock) {
              completeBlock(success);
            }
          }
        }];
    }
    else {
        BOOL success = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:URL]];
        if (success == NO) {
          if (completeBlock) {
            completeBlock(success);
          }
        }
        else {
          // [[UIApplication sharedApplication] openURL:[NSURL URLWithString:URL]]; 目前都不打开
        }
    }
}

@end
