//
//  ReadChannelDomain.m
//  INTEDSGame
//
//  Created by Robert on 04/05/2018.
//  Copyright © 2018 INTECH. All rights reserved.
//

#import "ReadChannelDomain.h"

@implementation ReadChannelDomain
/** 获取渠道包id */
+ (NSString *)getParentId {

    NSString *pidPath = [[NSBundle mainBundle] pathForResource:@"app" ofType:@"json"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:pidPath]) {
        return @"";
    }
    NSString *string = [[NSString alloc] initWithContentsOfFile:pidPath encoding:NSUTF8StringEncoding error:nil];
    if ([self isBlankString:string]) {
        return @"";
    }
    NSDictionary *pidDict = [self stringToDictWithStr:string];
    NSString *parentId = @"";
    if(pidDict && [pidDict.allKeys containsObject:@"parentId"]) {
        parentId = pidDict[@"parentId"];
    }
    return parentId;
}

/**
 字符串转字典
 
 @return 返回解析后的字典
 */
+ (NSDictionary *)stringToDictWithStr:(NSString *)str {
    if (!self) {
        return nil;
    }
    NSData *jsonData = [str dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if(error) {
        return nil;
    }
    return dict;
}

+ (BOOL)isBlankString:(NSString *)string {
    if (string == nil || string == NULL) {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    
    if ([string isEqualToString:@"<null>"]) {
        return YES;
    }
    
    if ([string isEqualToString:@"(null)"]) {
        return YES;
    }
    
    if ([string isEqualToString:@"null"]) {
        return YES;
    }
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 0) {
        return YES;
    }
    return NO;
}
@end
