//
//  PickerView.h
//  A02_iPhone
//
//  Created by Robert on 11/09/2017.
//  Copyright © 2017 robert. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^DataPickerViewCompleteBlock) (NSInteger index, NSString *string);

@interface DataPickerView : UIView

+ (void)showDataPickerViewWithDataArray:(NSArray *)dataArray
                          completeBlock:(DataPickerViewCompleteBlock)completeBlock;

@end
