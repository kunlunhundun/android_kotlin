//
//  DeviceTool.h
//  INTEDSGame

//

#import <Foundation/Foundation.h>

@interface DeviceTool : NSObject

/** 获取运营商信息 */
+ (NSString *)getCarrierName;

/** 获取设备类型 */
+ (NSString *)getDeviceType;

/** 获取app版本号 */
+ (NSString *)getAppVersion;

/** 获取mac */
+ (NSString *)getMacAddress;

/** 获取系统版本 */
+ (NSString *)getSystemVersion;

//获取当前时间戳
+ (NSString *)getCurrentTimeStamp;

/** 获取当前时区 */
+ (NSString *)getCurrentTimeZone;

/** 获取网络类型 */
+ (NSString *)getNetworktype;

/** YES 有网络,NO 无网络 */
+ (BOOL)isHaveNetwork;

/** 获取bundleId */
+ (NSString *)getbundleIdStr;

/** 解析JSON */
+ (NSDictionary *)dictWithJsonData:(NSData *)data;

/** 字典转json串 */
+ (NSString *)dictToJsonStr:(NSDictionary *)dict;

/** 替换空字符串 */
+ (NSString *)replaceStringNull:(NSString *)string;

+ (BOOL)isBlankString:(NSString *)string;

/**
 处理URL路径后缀的/
 
 @param URL   URL路径
 @return 处理后的URL
 */
+ (NSString *)removeURLSuffire:(NSString *)URL;

/**
 处理URL路径(去掉所有的开头字符串/)
 
 @param URL URL路径
 @return 处理后的URL路径
 */
+ (NSString *)removeURLPrefix:(NSString *)URL;

/** 获取UUID */
+ (NSString*)UUID;


#pragma mark 总内存
+ (double)totalMemorySize;

#pragma mark 可用内存
+ (double)availabaleMemorySize;

#pragma mark APP使用内存
+ (double)usedMemory;

+ (NSString *)getDeviceIPAdress ;

@end
