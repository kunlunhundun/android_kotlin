//
//  ReadChannelDomain.h
//  INTEDSGame
//
//  Created by Robert on 04/05/2018.
//  Copyright © 2018 INTECH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ReadChannelDomain : NSObject
/** 获取渠道包id */
+ (NSString *)getParentId;
@end
