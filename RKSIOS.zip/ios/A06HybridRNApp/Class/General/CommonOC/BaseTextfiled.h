//
//  BaseTextfiled.h
//  A06HybridRNApp
//
//  Created by hopper on 25/02/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseTextfiled : UITextField

@end

NS_ASSUME_NONNULL_END
