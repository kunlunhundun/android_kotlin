//
//  GameLoadingView.m
//  A06HybridRNApp
//
//  Created by hopper on 01/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "GameLoadingView.h"
#import "Masonry.h"

@interface GameLoadingView ()

@property (nonatomic, strong) UIImageView *icon;
@property (nonatomic, strong) UIImageView *iconLabel;

@property (nonatomic, strong) UIImageView *car1;
@property (nonatomic, strong) UIImageView *car2;
@property (nonatomic, strong) UIImageView *car3;
@property (nonatomic, strong) UIImageView *car4;

@property (nonatomic, strong) UIImageView *Anicar1;
@property (nonatomic, strong) UIImageView *Anicar2;
@property (nonatomic, strong) UIImageView *Anicar3;
@property (nonatomic, strong) UIImageView *Anicar4;

@property (nonatomic, strong) UIView *leftView;
@property (nonatomic, strong) UIView *rightView;
@property (nonatomic, strong) UILabel *prolabel;
@property (nonatomic, strong) UILabel *jiazai;

@property (nonatomic, assign) NSInteger send;
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSTimer *timerNoamal;
@property (nonatomic, assign) CGFloat lastFloat;
@property (nonatomic, assign) NSInteger defautCount;

@end

@implementation GameLoadingView

+ (instancetype)getLoadingView{
  GameLoadingView *view = [[GameLoadingView alloc]init];
  view.frame = CGRectMake(0, 0, IPHONE_WIDTH, IPHONE_HEIGHT);
  view.send = view.count = 0;
  [view layoutUI];
  return view;
}

- (void)setLabtext:(NSString*)text{
  self.jiazai.text = text;
}

- (void)layoutUI{
  
  self.lastFloat = 0.0;

  [self addSubview:self.icon];
  [self addSubview:self.iconLabel];
  [self addSubview:self.car1];
  [self addSubview:self.car2];
  [self addSubview:self.car3];
  [self addSubview:self.car4];
  [self addSubview:self.Anicar1];
  [self addSubview:self.Anicar2];
  [self addSubview:self.Anicar3];
  [self addSubview:self.Anicar4];
  
  // [self addSubview:self.leftView];
  // [self addSubview:self.rightView];
  
  [self addSubview:self.prolabel];
  [self addSubview:self.jiazai];
  
  [self.Anicar1 setHidden:YES];
  [self.Anicar2 setHidden:YES];
  [self.Anicar3 setHidden:YES];
  [self.Anicar4 setHidden:YES];
  
  [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
    make.centerX.mas_equalTo(self.mas_centerX);
    make.top.mas_offset(138);
    make.height.mas_equalTo(100);
    make.width.mas_equalTo(100);
  }];
  [self.iconLabel mas_makeConstraints:^(MASConstraintMaker *make) {
    make.top.mas_equalTo(self.icon.mas_bottom).offset(35);
    make.height.mas_equalTo(55.3);
    make.left.mas_offset(68);
    make.right.mas_offset(-68);
  }];

  // 灰色的低图
  [self.car1 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(-82);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.car2 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(-41);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.car3 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(5);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.car4 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(46);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  
  // 扑克动画
  [self.Anicar1 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(-82);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.Anicar2 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(-41);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.Anicar3 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(5);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  [self.Anicar4 mas_makeConstraints:^(MASConstraintMaker *make) {
    make.left.mas_equalTo(self.mas_centerX).mas_offset(46);
    make.top.mas_equalTo(self.iconLabel.mas_bottom).offset(41);
    make.height.mas_equalTo(36);
    make.width.mas_equalTo(25);
  }];
  
  [self.prolabel mas_makeConstraints:^(MASConstraintMaker *make) {
    make.centerX.mas_equalTo(self.mas_centerX);
    make.top.mas_equalTo(self.car4.mas_bottom).offset(35);
    make.height.mas_equalTo(14);
  }];
  [self.jiazai mas_makeConstraints:^(MASConstraintMaker *make) {
    make.centerX.mas_equalTo(self.mas_centerX);
    make.top.mas_equalTo(self.prolabel.mas_bottom).mas_offset(10);
    make.height.mas_equalTo(12);
  }];

//  [self.leftView mas_makeConstraints:^(MASConstraintMaker *make) {
//    make.left.mas_equalTo(self.mas_centerX).mas_offset(-60-50);
//    make.centerY.mas_equalTo(self.prolabel.mas_bottom).mas_offset(5);
//    make.height.mas_equalTo(5);
//    make.width.mas_equalTo(50);
//  }];
//  [self.rightView mas_makeConstraints:^(MASConstraintMaker *make) {
//    make.left.mas_equalTo(self.mas_centerX).mas_offset(60);
//    make.top.mas_equalTo(self.prolabel.mas_bottom).mas_offset(5);
//    make.height.mas_equalTo(5);
//    make.width.mas_equalTo(50);
//  }];
  
  [self startTimer];
}

- (int)getRandomNumber:(NSInteger)from to:(NSInteger)to{
  return (int)(from + arc4random() % (to - from + 1));
}

- (void)defautProgress{
  CGFloat miao = [self getRandomNumber:10 to:15]/100.00;
  self.defautCount = [self getRandomNumber:20 to:30];
  self.timerNoamal = [NSTimer timerWithTimeInterval:miao target:self selector:@selector(timerAction2:) userInfo:nil repeats:YES];
  [[NSRunLoop mainRunLoop] addTimer:self.timerNoamal forMode:NSRunLoopCommonModes];
}
- (void)timerAction2:(NSTimer *)sender{
  self.count += 1;
  self.prolabel.text = [NSString stringWithFormat:@"%ld%@",self.count,@"%"];
  self.lastFloat = (CGFloat)self.count;
  if (_count >= self.defautCount ) {
    [self.timerNoamal invalidate];
    self.timerNoamal = nil;
  }
}

- (void)startTimer{
  self.timer = [NSTimer timerWithTimeInterval:0.5 target:self selector:@selector(timerAction:) userInfo:nil repeats:YES];
  [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}
- (void)cancelrimer{
  [self.timer invalidate];
  self.timer = nil;
}
- (void)setProgress:(CGFloat)progress {
  if(progress >= self.lastFloat){
    
    if(self.timerNoamal != nil){
      [self.timerNoamal invalidate];
      self.timerNoamal = nil;
    }
    
    if(progress < 99){
      self.prolabel.text = [NSString stringWithFormat:@"%.f%@",progress,@"%"];
      self.lastFloat = progress;
    }
  }
}
- (void)timerAction:(NSTimer *)sender {
  self.send += 1;
  
  if (self.send == 1) {
    [self.Anicar4 setHidden:YES];
    [self.Anicar1 setHidden:NO];
    [self.car1 setHidden:YES];
    [self.car4 setHidden:NO];
    [self startAnimation:self.Anicar1];
  }
  if (self.send == 2) {
    [self.Anicar1 setHidden:YES];
    [self.Anicar2 setHidden:NO];
    [self.car2 setHidden:YES];
    [self.car1 setHidden:NO];
    [self startAnimation:self.Anicar2];
  }
  if (self.send == 3) {
    [self.Anicar2 setHidden:YES];
    [self.Anicar3 setHidden:NO];
    [self.car3 setHidden:YES];
    [self.car2 setHidden:NO];
    [self startAnimation:self.Anicar3];
  }
  if (self.send == 4) {
    [self.Anicar3 setHidden:YES];
    [self.Anicar4 setHidden:NO];
    [self.car4 setHidden:YES];
    [self.car3 setHidden:NO];
    [self startAnimation:self.Anicar4];
  }
  
  if (self.send == 4) {
    self.send = 0;
  }
}

- (void)startAnimation:(UIImageView *)imageview{
  CABasicAnimation* rotationAnimation;
  rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
  rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI_2 * 2];
  rotationAnimation.duration = 0.25;
  rotationAnimation.cumulative = YES;
  rotationAnimation.repeatCount = 10;
  [imageview.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

- (UIImageView *)icon{
  if(_icon == nil){
     _icon = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/logo" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _icon.image = image;
  }
  return _icon;
}
- (UIImageView *)iconLabel{
  if(_iconLabel == nil){
    _iconLabel = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/slogan" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _iconLabel.image = image;
  }
  return _iconLabel;
}
- (UIImageView *)car1{
  if(_car1 == nil){
    _car1 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/grayIcon1" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _car1.image = image;
  }
  return _car1;
}
- (UIImageView *)car2{
  if(_car2 == nil){
     _car2 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/grayIcon2" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _car2.image = image;
  }
  return _car2;
}
- (UIImageView *)car3{
  if(_car3 == nil){
    _car3 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/grayIcon3" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _car3.image = image;
  }
  return _car3;
}
- (UIImageView *)car4{
  if(_car4 == nil){
     _car4 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/grayIcon4" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _car4.image = image;
  }
  return _car4;
}


- (UIImageView *)Anicar1{
  if(_Anicar1 == nil){
    _Anicar1 = [[UIImageView alloc]init];
    _Anicar1.image = [UIImage imageNamed:@"icon1"];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/icon1" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _Anicar1.image = image;
  }
  return _Anicar1;
}
- (UIImageView *)Anicar2{
  if(_Anicar2 == nil){
    _Anicar2 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/icon2" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _Anicar2.image = image;
  }
  return _Anicar2;
}
- (UIImageView *)Anicar3{
  if(_Anicar3 == nil){
    _Anicar3 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/icon3" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _Anicar3.image = image;
  }
  return _Anicar3;
}
- (UIImageView *)Anicar4{
  if(_Anicar4 == nil){
    _Anicar4 = [[UIImageView alloc]init];
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/LoadingPage/icon4" ofType:@"png"];
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    _Anicar4.image = image;
  }
  return _Anicar4;
}
- (UIView *)leftView{
  if(_leftView == nil){
     _leftView = [[UIView alloc]init];
    _leftView.backgroundColor = [UIColor lightGrayColor];
    _leftView.layer.cornerRadius = 2.5;
  }
  return _leftView;
}
- (UIView *)rightView{
  if(_rightView == nil){
    _rightView = [[UIView alloc]init];
    _rightView.backgroundColor = [UIColor lightGrayColor];
    _rightView.layer.cornerRadius = 2.5;
  }
  return _rightView;
}
- (UILabel *)prolabel{
  if(_prolabel == nil){
     _prolabel = [[UILabel alloc]init];
    _prolabel.font = [UIFont systemFontOfSize:12];
    _prolabel.textColor = [UIColor whiteColor];
    _prolabel.textAlignment = NSTextAlignmentCenter;
    _prolabel.text = @"0%";
  }
  return _prolabel;
}
- (UILabel *)jiazai{
  if(_jiazai == nil){
    _jiazai = [[UILabel alloc]init];
    _jiazai.text = @"加载中,请稍后...";
    _jiazai.font = [UIFont systemFontOfSize:14];
    _jiazai.textColor = [UIColor whiteColor];
    _jiazai.textAlignment = NSTextAlignmentCenter;
  }
  return _jiazai;
}

@end
