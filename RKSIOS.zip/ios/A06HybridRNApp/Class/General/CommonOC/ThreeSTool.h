//
//  ThreeSTool.h
//  A06HybridRNApp
//
//  Created by hopper on 12/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WKWebView.h>
#import "IN3SAnalytics.h"


@interface ThreeSTool : NSObject

@property (assign, nonatomic) double startTime;
@property (assign, nonatomic) double preloadstartTime;
@property (assign, nonatomic) double normalstartTime;
@property (assign, nonatomic) double urlstartTime;

@property (copy, nonatomic) NSString *start;
@property (copy, nonatomic) NSString *end;


+ (void)filshedLanch;

// 设置用户名
+ (void)setLoginName:(NSString *)loginName;

// app开始加载
+ (void)appdidFinishLaunching;

// app进入后台
+ (void)appDidEnterBackground;

// 支付界面已经出现
+ (void)payVCDidAppearHasRecord:(BOOL)hasRecord beginDate:(NSDate *)beginDate;

// AGQJ开始加载
- (void)AGQJWebViewStartLoad;

// AGQJ加载成功
- (void)AGQJWebViewDidFinishLoad:(WKWebView *)webView;

// AGQJ加载失败
- (void)AGQJWebViewDidFailLoad:(WKWebView *)webView error:(NSError *)error;

// 预加载的耗时
- (void)startPreload;
- (void)endPreload;

// 加载的耗时
- (void)startNormalLoad;
- (void)endNormalLoad;

// 网络请求的时长
- (void)startRequestWithUrl;
- (void)endRequestWithUrl:(NSString *)url code:(int)resCode message:(NSString *)msg;

@end

