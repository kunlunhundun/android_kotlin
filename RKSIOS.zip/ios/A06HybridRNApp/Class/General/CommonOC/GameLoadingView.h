//
//  GameLoadingView.h
//  A06HybridRNApp
//
//  Created by hopper on 01/03/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameLoadingView : UIView

+ (instancetype)getLoadingView;
- (void)cancelrimer;
- (void)setProgress:(CGFloat)progress;
- (void)defautProgress;
- (void)setLabtext:(NSString*)text;

@end

