//
//  UIImageTools.h
//  A06HybridRNApp
//
//  Created by kunlun on 2018/11/10.
//  Copyright © 2018年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageTools : NSObject

+(UIImage*)applyBlurFullScreenShots;
+ (void)iOS8BlurImageImplement:(UIView*)supView;
+(UIImage*)screenshotsView:(UIView *)shotView;

@end
