//
//  ManagerModel.swift
//  A06KSEntireGame
//
//  Created by kunlun on 2018/11/3.
//  Copyright © 2018年 kunlun. All rights reserved.
//

import UIKit
import SignCore
import RxSwift

let RNPageHome = "Main"
let RNPageMessage = "Message"
let RNPagePromo = "Promo"
let RNPageDownload = "Download"
let RNPageSubscribe = "Subscribe"
let RNPageChangePassword = "ChangePassword"
let RNPageGoToPromo = "goToPromo"

class ManagerModel:NSObject {
  static let instanse = ManagerModel()
  
  var threeStool:ThreeSTool = ThreeSTool()
  var  mainTabBarViewCtrl:MainTabBarViewCtroller?

  var customerLiveChatVC:UIViewController?
  
  var gamePlayVC:GamePlayViewController?
  var lastgamePlayVC:GamePlayViewController?
  
  @objc var homePageVC:HomeRNViewController?
  
  let loginStatusRnSubject = PublishSubject<Bool>()
  let disposeBag = DisposeBag()

  var dateFormatter:DateFormatter?
  var qid = ""
  var domainName:String = ""
  var token:String = ""
  var publicKey = ""
  var key0 = ""
  @objc var curLoginName = ""
  var infoModel:InfoModel? = nil
  var totalAmount:String = "0"
  var personInfoModel:PersonInfoModel?
  var letterMsgModel:LetterMsgModel?
  var lastAgRequestGameModel:RequestGameModel?
  var cdnDomainNameModel:CDNDomainNameModel?
  var fastCdnDomainName:String = ""
  var timerMsg:Timer?
  var chargeDomainListModel:[String] = []
  var _loginSuccessModel:LoginSuccessModel?
  var loginSuccessModel: LoginSuccessModel? {
  
    willSet{
      _loginSuccessModel = newValue
      ManagerModel.instanse.token = _loginSuccessModel?.token ?? ""
      ManagerModel.instanse.curLoginName = _loginSuccessModel?.loginName ?? ""
    }
  }

  var activityShow:Bool = false
  var isShowTopview:Bool = false
  
 @objc class func shareInstanse() -> ManagerModel{
    return instanse
  }
  
  internal override init(){
    super.init()
    initData()
  }

  func initData() {
    qid =  ManagerModel.creatUUID()
    timerMsg = Timer.scheduledTimer(timeInterval: 1*60*5, target: self, selector: #selector(queryLetterMsg), userInfo: nil, repeats: true)
  }
 
  class  func creatUUID() -> String {
    let startArr:[String] = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"]
    var resultStr = ""
    for _ in 0...31 {
      let randomIndex:UInt32 = arc4random() % UInt32(startArr.count)
      resultStr = resultStr + startArr[ Int(randomIndex) ]
    }
    return resultStr ;
  }
  
  func preCreatHomeRNViewController(){
    homePageVC = HomeRNViewController()
  }
  
  func queryPersonInfo(){
    
    let accountInfoReq = PersonCenterModelNet().accountInfoRequest()
    let netArr = [accountInfoReq]
    CaseyNetwork().requestMultiTask(tasks: netArr) {
      
    }
  }
  
 @objc func queryLetterMsg(){
  if loginSuccessModel?.loginName?.count ?? 0 < 1 {
    return
  }
    let paramDic = ManagerModel.configLoginNameParamDic()
    APITool.request(.queryLetter, parameters: paramDic, successHandle: { [weak self] (letterMsgModel : LetterMsgModel) in
      
      self?.mainTabBarViewCtrl?.messageButton?.messageCount(count: letterMsgModel.body ?? "0")
    }) { (apiError) in
      print("queryLetter error \n")
    }
  }
  
  func clearLogout(){
    
     self.loginSuccessModel = nil
     personInfoModel = nil
     lastAgRequestGameModel?.loginStateChange = true
     mainTabBarViewCtrl?.messageButton?.messageCount(count: "0")
     NBSAppAgent.setUserIdentifier(self.loginSuccessModel?.loginName)
    
    //let customerId = ManagerModel.instanse.loginSuccessModel?.customerId?.toIntValue() ?? 0
    HeartSocketManager.shareInstance()?.sendHeartPacket(withApnsToken: nil, userid: 0)
    ThreeSTool.setLoginName(nil)
  }
  
  func clearLogoutView(){
    
    var isNewVC = true
    let topViewController = getTopViewController()
    if topViewController.isKind(of: HomeRNViewController.classForCoder())  {
      isNewVC = false
    }
    LoadingView.showLoadingViewWith(to: topViewController.view)
    loginStatusRnSubject.subscribe(onNext: {  (success:Bool) in
      LoadingView.hideLoadingView(for: topViewController.view)
      if isNewVC == true {
        topViewController.navigationController?.popToRootViewController(animated: true)
      }
    }).disposed(by:disposeBag)
  
    return
  }

  class func singleDeviceLogout(){
    
    let topViewController =  ManagerModel.instanse.getTopViewController()
    ProgressTopPopView.showPopView(content: "您的账号正在其他地方登陆,您被迫退出,如非本人操作请立即联系客服", popStyle: .errorMsgToast)
    topViewController.navigationController?.popToRootViewController(animated: true)
    ReactInteraction.shareInstance()?.logoutLocal()
    ManagerModel.instanse.clearLogout()
  
  }
  class func tokenExpiredExitLogin(){
    
    let topViewController =  ManagerModel.instanse.getTopViewController()
    ProgressTopPopView.showPopView(content: "您长时间未操作，请重新登录", popStyle: .errorMsgToast)
    topViewController.navigationController?.popToRootViewController(animated: true)
    ReactInteraction.shareInstance()?.logoutLocal()
    ManagerModel.instanse.clearLogout()
    
  }
  
  class func getDomainNameInfo() -> String {
    return instanse.domainName
  }
  
 @objc func setLoginUserInfo(_ loginUserInfo:String){
  
    self.loginSuccessModel = LoginSuccessModel.deserialize(from: loginUserInfo)
    personInfoModel = PersonInfoModel.deserialize(from: loginUserInfo)
    lastAgRequestGameModel?.loginStateChange = true
    let customerId = ManagerModel.instanse.loginSuccessModel?.customerId?.toIntValue() ?? 0
    HeartSocketManager.shareInstance()?.sendHeartPacket(withApnsToken: nil, userid: Int32(customerId))
    queryPersonInfo()
    queryLetterMsg()
    ThreeSTool.setLoginName(self.loginSuccessModel?.loginName)
  
    if self.loginSuccessModel?.loginName != nil {
      getActivityInfo()
    }
  }
  
  // MARK:获取活动的链接
  func getActivityInfo(){
    
    var param = [String:Any]()
    
    param["productId"] = "A06"
    param["loginName"] = self.loginSuccessModel?.loginName
    param["referenceId"] = "10000018786" //运测10000018786 //运营1000002002
    param["pageNo"] = 1
    param["pageSize"] = 1000
    param["lastDays"] = 0
    param["type"] = 4
    
    var urlPath = ""
    urlPath = PersonCenterNetPath.fundRecordPromo.rawValue

    CaseyNetwork().requestJsonPost(ServiceRootPath + urlPath, parameters: param) { (result, error, isCache) in
      
      let infoModel = FundRecordListModel.init(.discount)
      if let dateResult = result {
      
        if let dataArr = (dateResult["data"] as? [[String:Any]]) {
          
          if let modelArr = [FundRecordInfoModel].deserialize(from: dataArr) as? [FundRecordInfoModel]{
            infoModel.data!.append(contentsOf: modelArr)
          }
          
          let arr:[FundRecordInfoModel] = infoModel.data!
          var tallaAmount:CGFloat = 0.0
          // 遍历data把金额累加起来
          for (_,value) in arr.enumerated() {
              let tall:String = value.amount ?? ""
              let doubleTall:Double = Double(tall) ?? 0
              tallaAmount = tallaAmount + CGFloat(doubleTall)
          }
          
          // true显示 false不显示
          if tallaAmount >= 1888 {
            self.activityShow = false
          }else{
            self.activityShow = true
          }
        }
      }
    }
  }
  
  @objc func setWelcomeInfo(_ welcomeInfo:String){
    
    let welcomeModel = WelcomeModel.deserialize(from: welcomeInfo)
    
    key0 = welcomeModel?.key0 ?? ""
    publicKey = welcomeModel?.publicKey ?? ""
    let info = welcomeModel?.info ?? ""
    let baseInfo =  BaseJsonTool.base64Decoding(encodedString: info)
    let webInfoModel:InfoModel? =  InfoModel.deserialize(from: baseInfo)
    infoModel = webInfoModel
  }
  
  @objc func setCdnDomainName(_ cndDomainName:String){
//    if !(cndDomainName.isEqual("" as String)){
//       fastCdnDomainName = cndDomainName
//    }
  }
  
  @objc func playGameForRN(_ playGameStr:String) {
    let requestGameModel = RequestGameModel.deserialize(from: playGameStr)
    if requestGameModel?.gameCode == "KLC" {
      let onlineCustomerVC = CustomerOnlineHtmlViewController()
      onlineCustomerVC.requestModel = requestGameModel
      self.getTopViewController().navigationController?.pushViewController(onlineCustomerVC, animated: true)
      return
    }
    if requestGameModel?.gameCode.contains("A06003") == true {
       requestGameModel?.gameType = "BAC"
    }
    if requestGameModel?.gameType.contains("BAC") == true && requestGameModel?.gameCode.contains("A06003") == true {
      if gamePlayVC == nil || gamePlayVC?.isAgDidFinish == false {
         gamePlayVC = GamePlayViewController.init(requestModel: requestGameModel)
         lastgamePlayVC = gamePlayVC
      }
      else if gamePlayVC != nil && lastAgRequestGameModel != nil {
        self.threeStool.startNormalLoad() // 与加载开始
        if lastAgRequestGameModel?.loginStateChange == true {
          gamePlayVC = GamePlayViewController.init(requestModel: requestGameModel)
        }
      }
      
      gamePlayVC?.transTogame()
      
      lastAgRequestGameModel = requestGameModel
      lastAgRequestGameModel?.loginStateChange = false
      self.getTopViewController().navigationController?.pushViewController(gamePlayVC!, animated: true)
      
      // ag旗舰的预加载结束
      if gamePlayVC != nil && lastAgRequestGameModel != nil && gamePlayVC?.isAgDidFinish == true {
        self.threeStool.endNormalLoad()
      }
      
      if lastgamePlayVC != gamePlayVC{
         gamePlayVC?.requestGameData()
      }
      
    }else{
      
      let gamePlayViewController = GamePlayViewController.init(requestModel: requestGameModel)
      self.getTopViewController().navigationController?.pushViewController(gamePlayViewController, animated: true)
    }
  }
  
  @objc func showHidenTabbar(_ isShow:Bool){
      // let topViewController = self.getTopViewController()
      ManagerModel.shareInstanse().mainTabBarViewCtrl?.showHidenTabbar(isHiden: !isShow)
  }
  
  @objc func getTopViewController() -> UIViewController {
    
    let topViewController = ManagerModel.shareInstanse().mainTabBarViewCtrl?.pageHomeViewNav.topViewController
    return topViewController ?? ManagerModel.shareInstanse().homePageVC!
  }
  
  @objc func openNative(_ methodName:String){
    
    print("opennative----->\(methodName)")
    DispatchQueue.main.async {
      if methodName == "Profile" {
        
        let personCenterViewCtrl = PersonCenterViewController()
        personCenterViewCtrl.isFromHomePage = true
        self.getTopViewController().navigationController?.pushViewController(personCenterViewCtrl, animated: true)
      }
      
      if methodName == "Recharge" {
        let chargeVC = ChargeViewController()
        chargeVC.isComefromeActivity = false
        self.getTopViewController().navigationController?.pushViewController(chargeVC, animated: true)
      }
      if methodName == "RechargeActivity" {
        let chargeVC = ChargeViewController()
        chargeVC.isComefromeActivity = true
        self.getTopViewController().navigationController?.pushViewController(chargeVC, animated: true)
      }
      if methodName == "Withdraw" {
        let withDrawVC = WithDrawViewController()
        self.getTopViewController().navigationController?.pushViewController(withDrawVC, animated: true)
      }
      if methodName == "Rebate" {
        WashCodeAlertView.showPopView { (index) in
          
        }
      }
      if methodName == "OnlineCustomer"{
        let  onlineCustomerVC = CustomerOnlineHtmlViewController.init(isFromCustomer:false, isFromRN:true)
        self.getTopViewController().nearNav()?.pushViewController(onlineCustomerVC, animated: true)
      }
      if methodName == "BindPhone"{
        let persoinModel = ManagerModel.instanse.personInfoModel
        let bindPhoneVC = BindPhoneViewController()
        bindPhoneVC.personInfoModel = persoinModel
        self.getTopViewController().nearNav()?.pushViewController(bindPhoneVC, animated: true)
      }
      if methodName == "BindCard"{
        let addBankVC = AddBankCardViewController()
        self.getTopViewController().nearNav()?.pushViewController(addBankVC, animated: true)
      }
    }
  }
  
  @objc func clearLoginStatusByRN(){
      loginStatusRnSubject.onNext(true)
  }
  
  
 @objc func finishPage(){
    self.getTopViewController().navigationController?.popViewController(animated: true)
    // _ =  mainTabBarViewCtrl?.pageHomeViewNav.popViewController(animated: true)
  }
  
  @objc class func getRNGateway() -> String {
    
    let gateway = EnviromentManager.gatewayAddressRequet_domain + "/_glaxy_a06_/"
    let gateWayParam : [String : Any] = ["gateWay":gateway,"versionName":DeviceTool.getAppVersion()] //
    let resultJson = BaseJsonTool.dictionaryToString(gateWayParam as [String : AnyObject])
    return  resultJson
  }
  
  @objc class func getSign(src:String,qid:String,keyEnum:String) -> String {
    
    let deviceId = KeyChain.getKeychainIdentifierUUID() ?? ""
    
    let sign = SignUtil.getSign(src+deviceId+instanse.domainName+ReadChannelDomain.getParentId(), qid: qid, keyEnum: keyEnum)
    
    if EnviromentManager.netWorkState == false {
      DispatchQueue.main.async {
         ProgressTopPopView.showPopView(content: "未连接网络,请检查网络设置", popStyle: .errorMsgToast)
      }
    }
    let signParam : [String : Any] = ["sign":sign,"parentId":ReadChannelDomain.getParentId(),"domainName":instanse.domainName,"deviceId":deviceId, "isNetWorkConnected": EnviromentManager.netWorkState]
    let resultJson = BaseJsonTool.dictionaryToString(signParam as [String : AnyObject])
    return resultJson
  }
  
  class func jumpRNPage(pageName:String,needBack:Bool,isNewVC:Bool = false){
    
    let rnDic:[String : AnyObject] = ["pageName":pageName as AnyObject,"needBack":needBack as AnyObject]
    let rnRoute = BaseJsonTool.dictionaryToString(rnDic)
    ReactInteraction.shareInstance()?.jump(toPage: rnRoute)
    
    if isNewVC {
      let messageVC = RNViewController()
      let walltime = DispatchWallTime.now() + 0.3
      DispatchQueue.main.asyncAfter(wallDeadline: walltime) {
        messageVC.view.addSubview(ManagerModel.shareInstanse().homePageVC?.view ?? UIView())
        let currentVC = ManagerModel.instanse.getTopViewController()
        currentVC.navigationController?.pushViewController(messageVC, animated: true)
      }
    }
  }
  
  
 class func configBasicParamDic() -> [String:Any] {
    
    var paramDic:[String:Any] = ["productId":config_pid]
    paramDic["v"] = DeviceTool.getAppVersion()
    if instanse.domainName.count < 1 {
      paramDic["domainName"] = ManagerModel.getDomainNameInfo()
      instanse.domainName = ManagerModel.getDomainNameInfo()
    }else{
     // instanse.domainName = DeviceTool.removeURLSuffire(instanse.domainName)
      paramDic["domainName"] = instanse.domainName
    }
  
    return paramDic
  }
  
  class func configLoginNameParamDic() -> [String:Any] {
    
    var paramDic = configBasicParamDic()
    paramDic["loginName"] = instanse.curLoginName

    return paramDic
  }
  
  class func encrypPswOrPhoneNumWith(passWordOrPhoneNum:String) -> String{
    
    var publicKey:String = instanse.publicKey
    if publicKey.count < 1 {
       publicKey = config_PublicKey
    }
    var  encrypPassword =   RSAEncryptor.encryptString(passWordOrPhoneNum, publicKey: publicKey)
    encrypPassword = encrypPassword ?? ""
    
    return encrypPassword!
  }
  
  
  func getCDNDomainName(){
    
    WithDrawViewModel .requestQueryByKeyList();
  }
  
  class func configDateFormatter() -> DateFormatter {
    
    if instanse.dateFormatter == nil {
      instanse.dateFormatter = DateFormatter.init()
      instanse.dateFormatter?.dateFormat = "yyyy年MM月dd日00分"
    }
    return instanse.dateFormatter!
  }
  
  class func getNowDateFormatStr() -> String {
    
      let formatter = ManagerModel.configDateFormatter()
      formatter.dateFormat = "YYYY-MM-dd HH:mm:ss"
     let nowTime = formatter.string(from:Date.init())
      return nowTime
  }
}
