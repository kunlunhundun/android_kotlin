//
//  IN3SWebViewController.h
//  IN3SAnalytics
//
//  Created by Key on 01/04/2019.
//  Copyright © 2019 Key. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IN3SWebViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
