//
//  IN3SRequestModel.m
//  IN3SAnalytics
//
//  Created by Key on 2019/2/11.
//  Copyright © 2019年 Key. All rights reserved.
//

#import "IN3SRequestModel.h"

@implementation IN3SRequestModel
- (IN3SAnalyticsEvent)eventType
{
    return IN3SAnalyticsEventRequest;
}
@end
