//
//  IN3SExitModel.m
//  IN3SAnalytics
//
//  Created by Key on 2019/2/11.
//  Copyright © 2019年 Key. All rights reserved.
//

#import "IN3SExitModel.h"

@implementation IN3SExitModel
- (IN3SAnalyticsEvent)eventType
{
    return IN3SAnalyticsEventExit;
}
@end
