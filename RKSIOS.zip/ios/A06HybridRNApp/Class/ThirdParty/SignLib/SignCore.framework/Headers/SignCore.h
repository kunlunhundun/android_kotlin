//
//  SignCore.h
//  SignCore
//
//  Created by zaky on 18/01/2019.
//  Copyright © 2019 zaky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignUtil.h"

//! Project version number for SignCore.
FOUNDATION_EXPORT double SignCoreVersionNumber;

//! Project version string for SignCore.
FOUNDATION_EXPORT const unsigned char SignCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SignCore/PublicHeader.h>


