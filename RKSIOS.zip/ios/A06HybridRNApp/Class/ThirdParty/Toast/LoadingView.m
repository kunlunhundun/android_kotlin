//
//  LoadingView.m
//  INTEDSGame
//
//  Created by Robert on 13/04/2018.
//  Copyright © 2018 INTECH. All rights reserved.
//

#import "LoadingView.h"
#import "Masonry.h"

@interface LoadingView()
@property (strong, nonatomic) UIView *maskView;

@property (strong, nonatomic) UIView *contentView;

@property (strong, nonatomic) UIImageView *rmbImageView;

@end

@implementation LoadingView

+ (void)showLoadingViewWithToView:(UIView *)toView {
    [self hideLoadingViewForView:toView];
    if (toView) {
        LoadingView *loadingView = [[LoadingView alloc] initWithFrame:toView.bounds];
        [toView addSubview:loadingView];
    }
    else {
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        LoadingView *loadingView = [[LoadingView alloc] initWithFrame:toView.bounds];
        [window addSubview:loadingView];
    }
}

+ (void)showLoadingViewForWithDrawToView:(UIView *)toView{
  [self hideLoadingViewForView:toView];
  if (toView) {
    LoadingView *loadingView = [[LoadingView alloc] initWithFrame:toView.bounds];
    loadingView.contentView.backgroundColor = [UIColor clearColor];
    [loadingView.contentView mas_updateConstraints:^(MASConstraintMaker *make) {
      make.centerX.equalTo(loadingView.mas_centerX);
      make.centerY.equalTo(loadingView.mas_centerY);
      make.width.mas_equalTo(84);
      make.height.mas_equalTo(84);
    }];

    [toView addSubview:loadingView];
  }
}

+ (void)hideLoadingViewForView:(UIView *)view {
    if (view) {
        for (UIView *subView in [view subviews] ) {
            if ([subView isKindOfClass:[LoadingView class]]) {
                LoadingView *loadingView = (LoadingView*)subView;
                [loadingView removeLoadingSubViews];
            }
        }
    }
    else {
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        for (UIView *subView in [window subviews] ) {
            if ([subView isKindOfClass:[LoadingView class]]) {
                LoadingView *loadingView = (LoadingView*)subView;
                [loadingView removeLoadingSubViews];
            }
        }
    }
}
#pragma mark 内部方法
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.maskView];
        [self addSubview:self.contentView];
        [self.maskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(self);
        }];
        [self.contentView addSubview:self.rmbImageView];
        [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.centerY.equalTo(self.mas_centerY).offset(-84/2.0);
            make.width.mas_equalTo(84);
            make.height.mas_equalTo(84);
        }];
        [self.rmbImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.contentView.mas_centerX);
            make.centerY.equalTo(self.contentView.mas_centerY);
            make.width.mas_equalTo(36);
            make.height.mas_equalTo(36);
        }];
        [self startImageAnimation];
    }
    return self;
}

- (void)startImageAnimation {

  CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
  rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2.0];
  rotationAnimation.duration = 0.5;
  rotationAnimation.repeatCount = 20000;
  [self.rmbImageView.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];

}



- (void)removeLoadingSubViews {
  
    [self.rmbImageView.layer removeAllAnimations];
    for (UIView *view in [self subviews]) {
        [view removeFromSuperview];
    }
    [self removeFromSuperview];
}

#pragma mark GET SET
- (UIView *)maskView {
    if (!_maskView) {
        _maskView = [[UIView alloc] initWithFrame:CGRectZero];
       // _maskView.backgroundColor = UIColorFromRGB(0x000000);
        _maskView.backgroundColor = [UIColor clearColor];
        //_maskView.alpha = 0.2;
    }
    return _maskView;
}

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectZero];
        _contentView.layer.masksToBounds = YES;
        _contentView.layer.cornerRadius = 8;
       _contentView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.56 ] ;
  
    }
    return _contentView;
}

- (UIImageView *)rmbImageView {
    if (!_rmbImageView) {
        _rmbImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
      NSBundle *bundle = [NSBundle mainBundle];
      NSString *path = [bundle pathForResource:@"Bundle/assets/src/images/common/loading" ofType:@"png"];
      UIImage *image = [UIImage imageWithContentsOfFile:path];
      _rmbImageView.image = image;
      _rmbImageView.contentMode = UIViewContentModeScaleAspectFit;
      _rmbImageView.userInteractionEnabled = YES;
    }
    return _rmbImageView;
}
@end
